"use strict";

/* =====================================================================
   i18n
   ===================================================================== */
const I18N = {
  en:{
    tagline:"Multi Crop by DetailCrop — drag boxes over each image to mark the detail crops you want. Several per image, multiple images cropped at once, out as a single zip. Everything happens in your browser — no upload, no account needed.",
    dropTitle:"Drop your images here",
    dropBody:"JPEG, PNG, WebP, AVIF or GIF. Up to 200 files, 200 MB each. Your files never leave this computer.",
    pick:"Choose images",
    trySample:"Try the sample",
    sampleName:"night-city",
    dropNote:"Made for people who need the same set of detail shots out of every picture in a lineup — product listings, artwork, prints, fabric, real estate.",
    cropCount:"Crops on this image · 0 = skip",
    move:"MOVE", size:"Size", pos:"Position",
    autoPlace:"Auto-place", spread:"Spread out", samePrev:"Same boxes as previous image", confirmNext:"Confirm & next →",
    settings:"Settings", ratio:"Crop ratio", custom:"Custom",
    free:"Free",
    feedHd:"Instagram feed split",
    feed3:"3 posts", feed6:"6 posts", feed9:"9 posts", feedOff:"off",
    feedNote:"Numbers are the ORDER TO POST, not the reading order. Post no.1 first — a profile grid stacks newest first, so the bottom-right piece has to go up before the top-left one.",
    feedTiles:(n)=>`${n} tiles · drag the block to reframe`,
    outSize:"Output size", outNative:"Original pixels", outFixed:"Fixed size",
    fixedNote:"Fixed size needs a locked ratio. Crops smaller than this get scaled up, which softens them.",
    format:"Format", quality:"Quality", naming:"File names",
    namingNote:"{name} original file name · {n} crop number · {nn} 01, 02… · {i} image number · {w}×{h} output size",
    exportHd:"Export", exportAll:"Export all as .zip", exportOne:"Export this image only",
    clearAll:"Clear all images",
    removeOne:"Remove this image",
    shortcuts:"Shortcuts",
    upscaleWarn:"This box is smaller than the output size, so the crop will be scaled up and lose sharpness. Make the box bigger.",
    hint:"Drag a box to move it, or drag its corner dot to resize. Click anywhere on the picture to jump the selected box there.<br><kbd>1</kbd>–<kbd>6</kbd> pick a box · <kbd>←↑→↓</kbd> move (<kbd>Shift</kbd> faster)<br><kbd>−</kbd><kbd>+</kbd> resize · <kbd>Enter</kbd> confirm &amp; next (the next image starts from these boxes) · <kbd>[</kbd><kbd>]</kbd> prev / next image<br>Scroll over the picture nudges the box; <kbd>Ctrl</kbd>+scroll resizes it.",
    imagesDone:(d,t)=>`/ ${t} image${t===1?"":"s"} confirmed`,
    summary:(c,f)=>`${c} crop${c===1?"":"s"} across ${f} image${f===1?"":"s"} ready to export.`,
    summaryNone:"No crops set yet.",
    exporting:(a,b)=>`Exporting ${a} / ${b}…`,
    exported:(n)=>`${n} file${n===1?"":"s"} saved to your downloads.`,
    failed:(n)=>`${n} crop${n===1?"":"s"} left out — the browser ran out of memory drawing ${n===1?"it":"them"}. Close other tabs or apps and export again.`,
    nothing:"Nothing to export — set at least one crop.",
    tooBig:(n)=>`${n} skipped — over 200 MB.`,
    tooWide:(n,px)=>`${n} skipped — longer than ${px}px on a side, which is more than a browser canvas can hold.`,
    cantOpen:(n)=>`${n} skipped — this browser could not open them. Usually too large for the device.`,
    notImage:(n)=>`${n} skipped — not an image.`,
    confirmClear:"Remove all images and start over?",
    dims:(w,h)=>`${w} × ${h} px`,
    footPrivacy:"Runs entirely in your browser. Your images are never uploaded.",
    footFree:"Free to use.",
    todayVisits:"visits today", todayPeople:" people", todayExports:"exports",
    h1sr:" — Multi Crop: batch crop multiple images at once, several detail crops per image, exported as one zip",
    artAlt:"The image being cropped, with the Multi Crop boxes laid over it",
    footAbout:"About DetailCrop", footHow:"How to crop many images at once", footUses:"What people use it for",
    straighten:"Rotate", kHoriz:"Horiz.", kVert:"Vert.", resetZero:"Back to zero", alignTitle:"Alignment",
    footContact:"Advertising & partnerships:",
    footStats:"Anonymous usage stats. Your photos are never recorded or sent anywhere.",
    statsOn:"turn off",
    statsOff:"stats off · turn back on",
    footLead:"Multi Crop — detail crops for your whole product lineup, in one sitting.",
    footBody:"A detail crop is rarely a one-off. The same kind of close-up has to come out of every picture in a lineup — same ratio, same output size, same naming rule. A general image editor has no memory of any of that, so those constraints get rebuilt by hand for every file and quietly drift apart over a long batch. DetailCrop holds them for the whole run instead. What you get back is a set, not a pile of separately cropped files.",
    t1:"Drag a box to move it, or pull the corner dot to resize. Click anywhere on the picture to jump the selected box there.",
    t2:"Set how many crops this image gets — up to six. Choose 0 to skip the image entirely.",
    t3:"Every crop you place shows up here. Click one to select it, then fine-tune with the arrow keys.",
    t4:"Lock a ratio so every crop across every image comes out identical. Output size, format and file names live here too.",
    t5:"Load a whole batch and step through it here. A green dot marks each image you have confirmed.",
    t6:"When the batch is done, everything lands in your downloads as one zip.",
    tourSkip:"Skip",
    tourNext:"Next",
    tourDone:"Got it",
    tourBtn:"How it works",
    scopeAll:"Whole batch", scopeOne:"Selected crop",
    pickCrop:(n)=>`crop ${n}`, pickAll:"every crop",
    ratioNoteAll:"Every crop on every image takes this ratio, and new ones start on it.",
    ratioNoteOne:"Only the selected crop changes, so one image can carry a 4:5 and a 16:9 at the same time.",
    ratioNoteGrid:"A feed grid lays its own tiles, so the ratio stays on the whole batch while one is on.",
    cbKicker:"The other half of DetailCrop",
    cbBeta:"beta",
    cbBody:"Same idea, moving pictures: drag several crops over one clip and they all come out as mp4 in a single pass — a 9:16 for Shorts, a 1:1 for the feed, a 4:5 for the carousel.",
    cbGo:"Open the video tool",
    wideOn:"Work on a bigger canvas",
    wideOff:"Show the intro panel",
    sampleBadge:"SAMPLE",
    sampleTip:"Sample image — it steps aside as soon as you add your own",
    whyQ:"What was this batch for? (pick any)",
    whyShop:"Product photos for a shop", whyArt:"Artwork or prints", whySocial:"Instagram or social posts",
    whyData:"AI training dataset", whyPhoto:"Photo delivery or prints", whyDocs:"Documents, scans or screenshots",
    whyTry:"Just trying it out", whyOther:"Something else",
    whySend:"Send", whySkip:"Skip",
    whyThanks:"Thanks — that helps.",
    jobQ:"And what do you do? (optional)",
    jobSeller:"Online seller", jobPhoto:"Photographer", jobCreator:"Artist or designer",
    jobMarketer:"Marketer", jobOther:"Other",
    jobPh:"Your line of work, in a few words (no names or contact details)",
    memberLine:"Sign in to keep your own settings as presets.",
    footPolicy:"Privacy",
    presetHd:"Presets", presetLoginTag:"Sign in",
    presetNote:"A preset keeps the ratio, output size, format, quality, file names, feed split and where the boxes sit — never the images, and not the straighten values. Loading one sets the batch to it and lays its boxes on this image, on images you have not opened yet and on images you add next. Images you have already worked on keep their boxes.",
    presetSave:"Save",
    presetEmpty:"Nothing saved yet. Set things up the way you like, name it, and save.",
    presetLocked:"Sign in to save setups like this one to your account and load them on any device.",
    presetLoad:"Load", presetRename:"Rename", presetDelete:"Delete", presetLastTag:"last used",
    presetPh:"Name this setup",
    presetDefault:(n)=>`Preset ${n}`,
    presetLast:(n)=>`last: ${n}`,
    presetSaved:(n)=>`Saved “${n}”.`,
    presetLoaded:(n)=>`Loaded “${n}”.`,
    presetAsk:"New name",
    presetDelAsk:(n)=>`Delete the preset “${n}”?`,
    presetReplace:(n)=>`Replace the saved preset “${n}” with the current setup?`,
    presetFull:(m)=>`That is ${m} presets, the most an account keeps. Delete one first.`,
    presetFail:"That did not go through. Check your connection and try again.",
    presetMember:"Members only: saving and loading presets",
    loginTitle:"Sign in",
    loginLead:"Sign in with Google and your presets are kept in your account, ready on any device you sign in on.",
    loginFine:"Your photos are never stored and never reach our server. Ages 14 and up.",
    loginLoading:"Loading Google sign-in…",
    loginGisFail:"Google sign-in could not load. An ad or tracker blocker may be stopping it — allow it for this site, or try again later.",
    loginFail:"Sign-in did not go through. Please try again.",
    loginTooMany:"Too many tries. Wait a minute and try again.",
    loginExpired:"Your sign-in has ended. Please sign in again.",
    loginClose:"Close",
    acctWho:(e)=>`Signed in as ${e}`,
    acctLogout:"Sign out", acctDelete:"Delete account",
    acctDelAsk:"Delete your account and every preset saved in it? This cannot be undone.",
    acctDeleted:"Your account and its presets have been deleted.",
  },
  ko:{
    tagline:"디테일크롭의 멀티크롭 — 이미지 위에 상자를 끌어 원하는 확대컷 구역을 잡습니다. 한 장에 여러 컷, 여러 이미지를 한번에 자르고, 결과는 zip 하나로. 모든 처리가 브라우저 안에서 끝나며 업로드도 가입도 필요 없습니다.",
    dropTitle:"여기에 이미지를 놓으세요",
    dropBody:"JPEG, PNG, WebP, AVIF, GIF. 최대 200장, 장당 200MB. 파일은 이 컴퓨터를 벗어나지 않습니다.",
    pick:"이미지 선택",
    trySample:"예시 이미지로 해보기",
    sampleName:"야경-도시",
    dropNote:"라인업의 모든 사진에서 같은 종류의 디테일 컷을 뽑아야 하는 분들을 위해 만들었습니다 — 상품 상세컷, 그림, 인쇄물, 원단, 매물 사진.",
    cropCount:"이 이미지의 컷 수 · 0은 건너뛰기",
    move:"이동", size:"크기", pos:"위치",
    autoPlace:"자동 배치", spread:"고르게 펼치기", samePrev:"이전 이미지와 같은 영역", confirmNext:"확정하고 다음 →",
    settings:"설정", ratio:"크롭 비율", custom:"직접 입력",
    free:"자유",
    feedHd:"인스타 피드 분할",
    feed3:"3분할", feed6:"6분할", feed9:"9분할", feedOff:"끄기",
    feedNote:"번호는 읽는 순서가 아니라 올리는 순서입니다. 1번부터 차례로 올리세요 — 프로필은 최신 글이 왼쪽 위에 오기 때문에, 오른쪽 아래 조각을 먼저 올려야 그림이 맞습니다.",
    feedTiles:(n)=>`${n}조각 · 블록을 끌어 위치를 잡으세요`,
    outSize:"출력 크기", outNative:"원본 해상도", outFixed:"고정 크기",
    fixedNote:"고정 크기는 비율이 잠겨 있어야 씁니다. 이보다 작은 상자는 확대되어 흐려집니다.",
    format:"포맷", quality:"품질", naming:"파일명",
    namingNote:"{name} 원본 파일명 · {n} 컷 번호 · {nn} 01, 02… · {i} 이미지 번호 · {w}×{h} 출력 크기",
    exportHd:"내보내기", exportAll:"전체 zip으로 내보내기", exportOne:"이 이미지만 내보내기",
    clearAll:"이미지 전체 비우기",
    removeOne:"이 이미지 빼기",
    shortcuts:"단축키",
    upscaleWarn:"상자가 출력 크기보다 작습니다. 확대되면서 선명도가 떨어지니 상자를 키우세요.",
    hint:"상자를 끌어 옮기고, 모서리 점을 끌어 크기를 바꿉니다. 그림 아무 곳이나 클릭하면 선택된 상자가 그 자리로 옵니다.<br><kbd>1</kbd>–<kbd>6</kbd> 상자 선택 · <kbd>←↑→↓</kbd> 이동 (<kbd>Shift</kbd> 크게)<br><kbd>−</kbd><kbd>+</kbd> 크기 · <kbd>Enter</kbd> 확정하고 다음 (다음 이미지가 이 상자들로 시작) · <kbd>[</kbd><kbd>]</kbd> 이전 / 다음 이미지<br>그림 위에서 휠을 굴리면 상자가 움직이고, <kbd>Ctrl</kbd>+휠은 크기입니다.",
    imagesDone:(d,t)=>`/ ${t}장 확정`,
    summary:(c,f)=>`${f}장에서 ${c}컷, 내보낼 준비가 됐습니다.`,
    summaryNone:"아직 지정된 컷이 없습니다.",
    exporting:(a,b)=>`내보내는 중 ${a} / ${b}…`,
    exported:(n)=>`${n}개 파일이 다운로드 폴더에 저장됐습니다.`,
    failed:(n)=>`${n}개 컷은 메모리가 모자라 그리지 못해 뺐습니다. 다른 탭이나 앱을 닫고 다시 내보내 보세요.`,
    nothing:"내보낼 컷이 없습니다. 최소 한 컷은 지정하세요.",
    tooBig:(n)=>`${n}장은 200MB를 넘어 건너뛰었습니다.`,
    tooWide:(n,px)=>`${n}장은 한 변이 ${px}px를 넘습니다. 브라우저 캔버스가 감당하는 한계라 자를 수 없습니다.`,
    cantOpen:(n)=>`${n}장은 이 브라우저가 열지 못했습니다. 기기에 비해 너무 큰 경우입니다.`,
    notImage:(n)=>`${n}개는 이미지가 아니라 건너뛰었습니다.`,
    confirmClear:"이미지를 전부 지우고 처음부터 시작할까요?",
    dims:(w,h)=>`${w} × ${h} px`,
    footPrivacy:"모든 처리가 브라우저 안에서 이루어집니다. 이미지는 업로드되지 않습니다.",
    footFree:"무료로 쓰세요.",
    todayVisits:"오늘 방문", todayPeople:"명", todayExports:"내보내기",
    h1sr:" — 멀티크롭: 여러 이미지 한번에 자르기, 한 장에서 확대컷 여러 개를 zip으로",
    artAlt:"멀티크롭 상자가 올라간, 지금 자르고 있는 이미지",
    footAbout:"About", footHow:"사용법", footUses:"활용 예시",
    straighten:"회전", kHoriz:"수평", kVert:"수직", resetZero:"0으로 되돌리기", alignTitle:"정렬 보정",
    footContact:"광고·제휴 문의:",
    footStats:"익명 사용 통계를 모읍니다. 사진은 기록하지도, 서버로 보내지도 않습니다.",
    statsOn:"끄기",
    statsOff:"통계 꺼짐 · 다시 켜기",
    footLead:"멀티크롭 — 라인업 전체의 확대컷을, 한자리에서.",
    footBody:"확대컷은 한 장을 잘 자르는 일이 아니라, 여러 장을 같은 규칙으로 자르는 일입니다. 같은 종류의 클로즈업이 모든 사진에서 같은 비율, 같은 출력 크기, 같은 파일명 규칙으로 나와야 합니다. 그런데 일반적인 편집기는 그 규칙을 기억하지 않습니다. 파일마다 조건을 다시 세우게 되고, 장수가 쌓일수록 결과는 조금씩 어긋납니다. 이 도구는 그 규칙을 작업 전체에 붙들어 둡니다. 그래서 손에 남는 것은 따로따로 자른 파일 더미가 아니라 하나의 세트입니다.",
    t1:"상자를 끌어 옮기고, 모서리의 점을 당겨 크기를 바꿉니다. 그림 아무 곳이나 클릭하면 선택된 상자가 그 자리로 옵니다.",
    t2:"이 이미지에서 몇 컷을 뽑을지 정합니다. 최대 6컷이고, 0을 고르면 이 이미지는 건너뜁니다.",
    t3:"지정한 컷이 여기에 미리보기로 쌓입니다. 하나를 클릭해 고른 뒤 방향키로 미세하게 조정하세요.",
    t4:"비율을 잠그면 모든 이미지의 모든 컷이 같은 규격으로 나옵니다. 출력 크기와 포맷, 파일명 규칙도 여기 있습니다.",
    t5:"여러 장을 한꺼번에 올리면 여기서 넘기며 작업합니다. 확정한 이미지에는 초록 점이 붙습니다.",
    t6:"다 잡았으면 전체가 zip 하나로 다운로드 폴더에 떨어집니다.",
    tourSkip:"건너뛰기",
    tourNext:"다음",
    tourDone:"시작하기",
    tourBtn:"사용법 보기",
    scopeAll:"전체", scopeOne:"선택한 컷",
    pickCrop:(n)=>`${n}번 컷`, pickAll:"모든 컷",
    ratioNoteAll:"모든 이미지의 모든 컷이 이 비율을 따르고, 새로 만드는 컷도 이 비율로 시작합니다.",
    ratioNoteOne:"선택한 컷만 바뀝니다. 한 이미지에서 4:5와 16:9를 동시에 잡을 수 있습니다.",
    ratioNoteGrid:"피드 분할은 자기 조각을 따로 놓기 때문에, 켜져 있는 동안 비율은 전체에만 적용됩니다.",
    cbKicker:"DetailCrop의 나머지 절반",
    cbBeta:"베타",
    cbBody:"같은 방식으로 움직이는 화면을 — 영상 하나 위에 컷을 여러 개 잡아두면 한 번의 재생으로 전부 mp4가 됩니다. 쇼츠용 9:16, 피드용 1:1, 캐러셀용 4:5를 한 번에.",
    cbGo:"영상 크롭 열기",
    wideOn:"더 큰 화면에서 작업하기",
    wideOff:"설명 칸 다시 보기",
    sampleBadge:"예시",
    sampleTip:"예시 이미지 — 직접 올린 이미지가 들어오면 자동으로 빠집니다",
    whyQ:"이번 작업, 어디에 쓰시나요? (복수 선택 가능)",
    whyShop:"쇼핑몰 상품 사진", whyArt:"작품·프린트", whySocial:"인스타·SNS 게시물",
    whyData:"AI 학습용 데이터셋", whyPhoto:"사진 납품·인쇄", whyDocs:"문서·스캔·화면 캡처",
    whyTry:"그냥 써 보는 중", whyOther:"기타",
    whySend:"보내기", whySkip:"건너뛰기",
    whyThanks:"고맙습니다. 큰 도움이 됩니다.",
    jobQ:"어떤 일을 하시나요? (선택)",
    jobSeller:"온라인 셀러", jobPhoto:"사진가", jobCreator:"작가·디자이너",
    jobMarketer:"마케터", jobOther:"기타",
    jobPh:"하시는 일을 짧게 (이름·연락처는 적지 마세요)",
    memberLine:"로그인하면 개인 맞춤 설정을 저장해 쓸 수 있습니다.",
    footPolicy:"개인정보 처리방침",
    presetHd:"프리셋", presetLoginTag:"로그인",
    presetNote:"비율, 출력 크기, 포맷, 품질, 파일명, 피드 분할, 상자 위치를 저장합니다. 이미지와 수평·원근 값은 담지 않습니다. 불러오면 설정이 작업 전체에 걸리고, 상자는 지금 이미지와 아직 열지 않은 이미지, 앞으로 추가하는 이미지에 놓입니다. 이미 작업한 이미지의 상자는 그대로입니다.",
    presetSave:"저장",
    presetEmpty:"저장한 프리셋이 없습니다. 원하는 대로 설정한 뒤 이름을 붙여 저장하세요.",
    presetLocked:"로그인하면 지금 같은 설정을 계정에 저장해 두고 어느 기기에서든 불러올 수 있습니다.",
    presetLoad:"불러오기", presetRename:"이름 변경", presetDelete:"삭제", presetLastTag:"마지막 사용",
    presetPh:"설정값 입력",
    presetDefault:(n)=>`프리셋 ${n}`,
    presetLast:(n)=>`마지막: ${n}`,
    presetSaved:(n)=>`“${n}” 저장했습니다.`,
    presetLoaded:(n)=>`“${n}” 불러왔습니다.`,
    presetAsk:"새 이름",
    presetDelAsk:(n)=>`“${n}” 프리셋을 삭제할까요?`,
    presetReplace:(n)=>`저장된 “${n}”을(를) 지금 설정으로 바꿀까요?`,
    presetFull:(m)=>`프리셋은 계정당 ${m}개까지 저장됩니다. 하나를 먼저 삭제하세요.`,
    presetFail:"처리하지 못했습니다. 인터넷 연결을 확인하고 다시 시도하세요.",
    presetMember:"프리셋 저장 · 불러오기, 로그인 전용",
    loginTitle:"로그인",
    loginLead:"구글 계정으로 로그인하면 프리셋이 계정에 저장되어, 로그인한 어느 기기에서든 불러올 수 있습니다.",
    loginFine:"사진은 저장되지 않고 서버로 가지 않습니다. 만 14세 이상만 가입할 수 있습니다.",
    loginLoading:"구글 로그인을 불러오는 중…",
    loginGisFail:"구글 로그인을 불러오지 못했습니다. 광고·추적 차단 확장 프로그램이 막고 있을 수 있습니다 — 이 사이트에서 허용하거나 잠시 뒤 다시 시도하세요.",
    loginFail:"로그인하지 못했습니다. 다시 시도해 주세요.",
    loginTooMany:"시도가 너무 잦습니다. 1분 뒤 다시 시도해 주세요.",
    loginExpired:"로그인이 끝났습니다. 다시 로그인해 주세요.",
    loginClose:"닫기",
    acctWho:(e)=>`${e} 로그인 중`,
    acctLogout:"로그아웃", acctDelete:"회원 탈퇴",
    acctDelAsk:"계정과 저장한 프리셋을 모두 지울까요? 되돌릴 수 없습니다.",
    acctDeleted:"계정과 프리셋을 지웠습니다.",
  },
  ja:{
    tagline:"ディテールクロップのマルチクロップ — 画像の上でボックスをドラッグし、切り出したい部分を指定します。1枚に複数カット、複数の画像をまとめてトリミング、結果はzipひとつ。処理はすべてブラウザ内で完結し、アップロードも登録も不要です。",
    dropTitle:"ここに画像をドロップ",
    dropBody:"JPEG、PNG、WebP、AVIF、GIF。最大200ファイル、1ファイル200MBまで。ファイルがこの端末から出ることはありません。",
    pick:"画像を選ぶ",
    trySample:"サンプルで試す",
    sampleName:"夜の街",
    dropNote:"並んだ商品や作品すべてから同じ種類のディテールカットを用意する人のための道具です — 商品詳細画像、アート、プリント、生地、物件写真。",
    cropCount:"この画像のカット数 · 0でスキップ",
    move:"移動", size:"サイズ", pos:"位置",
    autoPlace:"自動配置", spread:"均等に広げる", samePrev:"前の画像と同じ範囲", confirmNext:"確定して次へ →",
    settings:"設定", ratio:"切り抜き比率", custom:"手入力",
    free:"自由",
    feedHd:"インスタ フィード分割",
    feed3:"3分割", feed6:"6分割", feed9:"9分割", feedOff:"オフ",
    feedNote:"番号は読む順ではなく投稿する順です。1番から順に投稿してください — プロフィールは新しい投稿が左上に来るため、右下のピースを先に上げないと絵が合いません。",
    feedTiles:(n)=>`${n}ピース · ブロックをドラッグして位置を決めます`,
    outSize:"出力サイズ", outNative:"元の解像度", outFixed:"固定サイズ",
    fixedNote:"固定サイズは比率を固定しているときだけ使えます。これより小さいボックスは拡大されて甘くなります。",
    format:"形式", quality:"画質", naming:"ファイル名",
    namingNote:"{name} 元のファイル名 · {n} カット番号 · {nn} 01, 02… · {i} 画像番号 · {w}×{h} 出力サイズ",
    exportHd:"書き出し", exportAll:"すべてzipで書き出す", exportOne:"この画像だけ書き出す",
    clearAll:"画像をすべて消す",
    removeOne:"この画像を外す",
    shortcuts:"ショートカット",
    upscaleWarn:"ボックスが出力サイズより小さいため、拡大されて解像感が落ちます。ボックスを大きくしてください。",
    hint:"ボックスをドラッグして移動、角の点をドラッグしてサイズ変更。画像上をクリックすると選択中のボックスがそこへ移動します。<br><kbd>1</kbd>–<kbd>6</kbd> ボックス選択 · <kbd>←↑→↓</kbd> 移動（<kbd>Shift</kbd>で大きく）<br><kbd>−</kbd><kbd>+</kbd> サイズ · <kbd>Enter</kbd> 確定して次へ（次の画像はこのボックスから始まります） · <kbd>[</kbd><kbd>]</kbd> 前 / 次の画像<br>画像の上でホイールを回すとボックスが動き、<kbd>Ctrl</kbd>+ホイールでサイズが変わります。",
    imagesDone:(d,t)=>`/ ${t}枚 確定`,
    summary:(c,f)=>`${f}枚から${c}カット、書き出せます。`,
    summaryNone:"まだカットが指定されていません。",
    exporting:(a,b)=>`書き出し中 ${a} / ${b}…`,
    exported:(n)=>`${n}件のファイルをダウンロードに保存しました。`,
    failed:(n)=>`${n}件のカットはメモリ不足で描けなかったため除きました。ほかのタブやアプリを閉じて、もう一度書き出してください。`,
    nothing:"書き出すカットがありません。最低1カット指定してください。",
    tooBig:(n)=>`${n}件は200MBを超えるためスキップしました。`,
    tooWide:(n,px)=>`${n}件は一辺が${px}pxを超えています。ブラウザのキャンバス上限のため切り抜けません。`,
    cantOpen:(n)=>`${n}件はこのブラウザで開けませんでした。端末に対して大きすぎる場合です。`,
    notImage:(n)=>`${n}件は画像ではないためスキップしました。`,
    confirmClear:"画像をすべて消して最初からやり直しますか？",
    dims:(w,h)=>`${w} × ${h} px`,
    footPrivacy:"処理はすべてブラウザ内で行われます。画像がアップロードされることはありません。",
    footFree:"無料で使えます。",
    todayVisits:"本日の訪問", todayPeople:"人", todayExports:"書き出し",
    h1sr:" — マルチクロップ：複数の画像を一括トリミング、1枚から複数カットをzipで書き出し",
    artAlt:"マルチクロップの枠を重ねた、トリミング中の画像",
    footAbout:"DetailCropについて", footHow:"複数の画像をまとめて切り抜く方法", footUses:"こんな使い方",
    straighten:"回転", kHoriz:"水平", kVert:"垂直", resetZero:"0に戻す", alignTitle:"傾き補正",
    footContact:"広告・提携のお問い合わせ:",
    footStats:"匿名の利用統計を取っています。写真は記録も送信もしません。",
    statsOn:"オフにする",
    statsOff:"統計オフ · 再びオンにする",
    footLead:"マルチクロップ — ラインナップ全体のディテールカットを、一度に。",
    footBody:"ディテールカットは、1枚をうまく切る作業ではなく、複数枚を同じ規則で切る作業です。同じ種類の寄りが、すべての写真から同じ比率・同じ出力サイズ・同じ命名規則で出てこなければなりません。ところが一般的な画像編集ソフトはその規則を覚えていないため、ファイルごとに条件を立て直すことになり、枚数が増えるほど仕上がりは少しずつずれていきます。このツールはその規則を作業全体に固定します。手元に残るのは個別に切った寄せ集めではなく、ひとつのセットです。",
    t1:"ボックスをドラッグして移動、角の点を引いてサイズ変更。画像上をクリックすると選択中のボックスがそこへ移動します。",
    t2:"この画像から何カット取るかを決めます。最大6カット、0を選ぶとこの画像はスキップされます。",
    t3:"指定したカットがここにプレビューされます。クリックして選び、方向キーで微調整してください。",
    t4:"比率を固定すれば、すべての画像のすべてのカットが同じ規格で出力されます。出力サイズ・形式・ファイル名の規則もここです。",
    t5:"複数枚を読み込むとここで送りながら作業できます。確定した画像には緑の点が付きます。",
    t6:"仕上がったら、すべてがzipひとつでダウンロードに保存されます。",
    tourSkip:"スキップ",
    tourNext:"次へ",
    tourDone:"はじめる",
    tourBtn:"使い方を見る",
    scopeAll:"全体", scopeOne:"選択中のカット",
    pickCrop:(n)=>`カット${n}`, pickAll:"全カット",
    ratioNoteAll:"すべての画像のすべてのカットがこの比率になり、新しいカットもこの比率で始まります。",
    ratioNoteOne:"選択中のカットだけが変わります。1枚の画像で4:5と16:9を同時に指定できます。",
    ratioNoteGrid:"フィード分割は専用のタイルを敷くため、オンの間は比率が全体にのみ適用されます。",
    cbKicker:"DetailCropのもう半分",
    cbBeta:"ベータ",
    cbBody:"同じ考え方で動く映像も — 1本の動画の上にカットをいくつも取れば、一度の再生ですべてmp4になります。ショート用9:16、フィード用1:1、カルーセル用4:5を一度に。",
    cbGo:"動画ツールを開く",
    wideOn:"大きな画面で作業する",
    wideOff:"説明パネルを表示",
    sampleBadge:"見本",
    sampleTip:"サンプル画像 — ご自身の画像を追加すると自動で外れます",
    whyQ:"今回の作業、何に使いますか？（複数選択可）",
    whyShop:"ネットショップの商品写真", whyArt:"作品・プリント", whySocial:"インスタ・SNSの投稿",
    whyData:"AI学習用データセット", whyPhoto:"写真の納品・プリント", whyDocs:"書類・スキャン・スクリーンショット",
    whyTry:"試しに使っている", whyOther:"その他",
    whySend:"送信", whySkip:"スキップ",
    whyThanks:"ありがとうございます。とても参考になります。",
    jobQ:"お仕事は何ですか？（任意）",
    jobSeller:"ネットショップ運営", jobPhoto:"写真家", jobCreator:"作家・デザイナー",
    jobMarketer:"マーケター", jobOther:"その他",
    jobPh:"お仕事を短く（名前や連絡先は書かないでください）",
    memberLine:"ログインすると、自分好みの設定を保存して使えます。",
    footPolicy:"プライバシーポリシー",
    presetHd:"プリセット", presetLoginTag:"ログイン",
    presetNote:"比率、出力サイズ、形式、画質、ファイル名、フィード分割、ボックスの位置を保存します。画像と傾き補正の値は含みません。読み込むと設定が作業全体にかかり、ボックスはこの画像・まだ開いていない画像・これから追加する画像に置かれます。作業済みの画像のボックスはそのままです。",
    presetSave:"保存",
    presetEmpty:"保存したプリセットはありません。好みの設定にしてから名前を付けて保存してください。",
    presetLocked:"ログインすると、今のような設定をアカウントに保存して、どの端末からでも読み込めます。",
    presetLoad:"読み込む", presetRename:"名前変更", presetDelete:"削除", presetLastTag:"前回使用",
    presetPh:"設定名を入力",
    presetDefault:(n)=>`プリセット ${n}`,
    presetLast:(n)=>`前回: ${n}`,
    presetSaved:(n)=>`「${n}」を保存しました。`,
    presetLoaded:(n)=>`「${n}」を読み込みました。`,
    presetAsk:"新しい名前",
    presetDelAsk:(n)=>`プリセット「${n}」を削除しますか？`,
    presetReplace:(n)=>`保存済みの「${n}」を今の設定で置き換えますか？`,
    presetFull:(m)=>`プリセットは1アカウント${m}件までです。先にひとつ削除してください。`,
    presetFail:"処理できませんでした。接続を確認してもう一度お試しください。",
    presetMember:"プリセットの保存・読み込み、ログイン専用",
    loginTitle:"ログイン",
    loginLead:"Googleアカウントでログインすると、プリセットがアカウントに保存され、ログインしたどの端末からでも読み込めます。",
    loginFine:"写真は保存されず、サーバーにも送られません。14歳以上の方のみ登録できます。",
    loginLoading:"Googleログインを読み込み中…",
    loginGisFail:"Googleログインを読み込めませんでした。広告・トラッカーのブロック機能が止めている可能性があります — このサイトで許可するか、しばらくしてからお試しください。",
    loginFail:"ログインできませんでした。もう一度お試しください。",
    loginTooMany:"試行が多すぎます。1分後にもう一度お試しください。",
    loginExpired:"ログインの期限が切れました。もう一度ログインしてください。",
    loginClose:"閉じる",
    acctWho:(e)=>`${e} でログイン中`,
    acctLogout:"ログアウト", acctDelete:"退会",
    acctDelAsk:"アカウントと保存したプリセットをすべて削除しますか？元に戻せません。",
    acctDeleted:"アカウントとプリセットを削除しました。",
  }
};

/* =====================================================================
   Embedded sample plate (webp, 1200px) — hero backdrop + demo source
   ===================================================================== */
const DEMO = "data:image/webp;base64,UklGRkjPAgBXRUJQVlA4IDzPAgCwmwidASqwBCwGPqlQoEymJKooJ7QKsUAVCWNmhZ/Vbx7Ec+h8O/7ezf+l/5vRZ/z/QF/l0fnQ/+T9yPcN/TP975O/937t+qT7H062ef97/+frA/nv/M9WH/953P5//9+Xpcj877Y3UfiN+8n/t3VjbP/Wf7b89DSf/f7mv/e/0HlJdof/J/i/gE/oX97/6/nrd2LuV7Af9s/yn/q/0ftlfwv2g9T/2p/azsL/9z0d/2f/d/t58A367f97/J+6b/r/cr05fcPpAZPJ138uwrmf8Jn/9odcbz9/zPoM/9eHPz3l+++/7Hn8/9Hr3/vP/O9if+2+jz/5fu38Bv73/7/VL+73rG+oj/O+pJ/pvSl9bb+w+rh52fra/5H0n/+91/fQD+aeSv57/f/tr5E/n3vY/0HtfYH/je7L++s/n+p4W/vf9t6Bf6p3Xe3Y3j/regd7o/lvLp/k86f4L/lewJ5beMj9w/93sO/1H/l+sX/4eeT9e/8XsPftp/+v9l2/S9NroxLHWTdRtsl3pDw7OXFj7rJgqUgo7Dhy4rglqUt66ja+U+m1kYfM2Xpgly+tdg+TcxkvijtVUA4UDBhMNr3zZEDmKsntbJJjtm93pw7YEUJQ3XWoyBWuiRDMchU89lr4tKIHGi4J4o1VHHzYQj1/5u8HG8EKyzyay9l9iY6ybqOm+X3rqaZkTGf+vIC6x1k3UbbJc82Ho15mxAYGePSLT7as5RYTpY2ADf9/xB2pW44OsqZHgzNroxJOG2NWWpWDJu5lGC4YaCjrLmtaSa1j7rycVwnLaGFJFVFcVl47jbGeNmbcS6ffqMIF03Js1F4wm0bJLyxUz6R2auwhmbUp2rm+kLkCbox1+Sayx1k3Ke3iWOsikgVsYsieTEdgb9C3S8OrL4ajpBNmk9RYI0EVWJ2JXfmbDrG3A22S2vaqunUfCtdKfA9RHzNroyJjbZLa6MI5la5IXbjbMAUTaDIylgc7gbpkfIpHM2x4gpjUOxDdSjXf2IVQwqxNMUY0oCbZMyQP3OKHu7VQ8H7OyCxdgZwflVLNlrBMxu318avr6m5koRao7q0froNwnRG0YnCNsltWWalMbbJbXfTjbJbUajY1VuALrLpkBVMZ7fGDt70BjYXMBg6DoCbCfASrw3CdJc4p09cn7USxc1iLu+OC/SZlUExLpumgHBYRbLzTmLUR9detPS2FCAyHqznl3LmcG/7Q9zWaI/SfC7Dh0Q3O5hf5PmbXRigLwKw5k3c7ly4rgzd55JNt+6OsgXl9eHhGyLucXbqzXUAjyt6k36GMG4/MhPhbQwsfRFKPx06/TWIyb2TkH4jSJHSqOtttGxpFkxvbggQQYkb35oUZGiB2Aw84d4qmmJB+BYJbXRiWOsnAcC+JY6ybqOT/eZ1k3gM+8mi6PmiR7Y5YQhqA3co+n/waZWfD2sHmnbBvy16qMGX57iAzVZCRnxv2quC31S5DCwXrmAIw/5HwrPDB1Ktx6T7gz1g3TR0Cy5Cc+d+0yXZwoLrtYsfQAUdiJsuKDVejY41jeijBTXEDbZLa5FijhPc4aElRqdxoIx4316oj8uAFsrncBIToR64Yzx57kBbiVYUmU7csNputj5fD0eoeOVXK8FGE2SDbRVDNcrVsAfJ/hrEe5TnfXtfvvoVVt2g08U+d3uSvH0bQGrda3/ZWndVWcyiF0oE9nYh2nDmTG1GoHFcGbtfRgcMiYk9PVyPYQyb/2Ju8o8za+zrwy8EwNhy2Rfubl7fTJEGMZdR9SPz/x981y/eN1hndB8SiQrnpssLWCYGap9kuA/aHMhvQn4r6i68rQC5J9Nu47F3GZNZxcdfnlRGe0YPK4o6+MnvrpkolZ8dXuevUyCW3gS/LglqSYjIaWaDgbbJWI1AgiHliv6uDKsBquXC8QSYONsltRU+KrZ35DuBnqbfVJOtrW4OyDziAhb88r4ghUxQLc8I/7xnSP6Lr5Xs+AoNJLsueCJm3V30LsbPtgUHCfcToTtn/jVampYbaw2NX5rWl7XJzZXl5HtT0XCI5m7HdTST9WxM+Y7BmzIJMd3MwN6IUEq2TP0PT/M2ujEscV4VrvcdRfmDuP6IqXtjXrPwmqEHda8upFTewmbaLSiw1asSV6dCmgeTzSiVkxrVy8gwD0DXHJBDGul6Uriq8Ccd2nuEG4hIpM/xjm/G75n5fHpzCyk6kDCV1qvFSi/AFuMMuK30E0EZ/Osm6jHJzoWTc1NAkwLi1NnjFb+ph4YDmhtkkB9+fR3BYQi09Y3TBA4xmXCjWF+Dzm9IxQqLfxJixHZUkDnARvyxlYjuJQIVLMYldtaGNDGi6cs6D7qU+/rMUckiz+wxf6y9xioelgfZCnmh06BW/Rg90dZsRCTIEo4qqvEm08z/kQzNroxLHWPgF9ir6+mjvywXhx3q9dj//b1krPX/8oHleR3LItHqdzVb0WAAjzNh01BkaB37s4mGiFj9GIxtqAekghC1bXYt441jj58/LSzVT3GDPP59Lz5gieFdOsywwukiUT3ceBA+auCf21VLkJXoUGa6X+KCmtfwAQ7aBxl6MlcIb0ZEyITAo6ycnwPpAYcyEbbNJG3rLHWTcZiBDGX+64vnnTDWfyxV9EbDuVpvSzG58TRnYeww5Rhx0Gawc/iWl1PWvDDT9fBDcUrXwgGIv5+XiApr+bZqIlGUQj8FZin1kvKOufiZhggceH0cRXwuBe7lm2whdLykbXtuKYqADDkTHCH5As7qPd5k9gpOAN076fMDlxXHgyaxgqCuXFcGZtdGLRqMSx2jDB1Hk160Y/D6cGtVKeTuRdPlSFc6qzJiHd5bQGsGPAmy4Psc5fH1hDZRwQQ1VGdm7QaA1My7xlZE3bKnmkvYl4T+hg244socSXa3cut/mw02vZwyW/T3vQnmzuv67IT0DgJfmDl/So6ygE4rfrybqOK2P2vAOyr3xgZPgwaYIXfvyLhuLkUhpmv0Cnu9he6v/3qBTWGquEhsNjr1YSe4RI0ZS14L1BSDW/sMDk4qvaMvnsPXG1ndePLVYv6G/nRHZk/pWPYuB8GVWuocx9Bzxw8Ej1vhwaqB7fWw2hDRDmiIgHrZ+c0O2DWjRAoYSkX/udWz6AHm4XTo2DYRUAmE+SsDlpBeX5+5XXlEtDRRgWoa0oxLHFh7f1Gx9WrviWbDvAwCOvOLEhfRhwgxVLUThjiFiMbTv9t7y9fPMgOSmCxGNu51h8qYXGfvlhREQAkgvv5USms5RISfgw7qbvPSO01rewpUxt5yTrwMseL47aIM4TVrB/HtxfM2gYlAXGbapU+11zBtgBOzIiIsHBBev4/pDqUFV98yFg57lTSBFdGSWZj1Ul7xrybs1g6stn45u79mzlCfSKquXZpMlJT3NI+m1YvVElfRIUr0Kq4Gi0LAZtUYsudGTbMHhoPAOdQTiUjNJNmtTM4DlxbbCUnwF7fLVifGHQbOpfTik2rLyrt/w8zSCejrhexlbeT38SagqMSZbFPrtulnxR3HSs/HlGPsn7idSckNSegVYhs6ihY8FfbRw5aDaE/eQXQet+TFh1dDeBkP+BX5YAdUqWZF9nrsevIJGWKjKyQBX9g0lfakZaiHLW2RqmgO/HpPVo1O8ZUX8YNkaIYlslDop1ve4pxi2MvHuDD2S0OHV7HZNZxjOqP+32jP5Ylj4xB6BlBJT79GjbJNcnYsfZrP5D7/0uHfgXqfMpLiXF+Z5ND/I1VII+/itbMI1/xxAnuHuttD8QLnlGoon9RgMJw8sOVBUswJuED7KpEti29ldo6c0jJn0ZlHYGhUdJiG8t/EVDvpehlLS3eMtFbVwlIswKR8gihwCl1B5I2ufzuyElY8SnaJonKxs/AmsB0DbNlbtOdL21B4wF3KcobrKbSvgWBcVwcQ53az68fS2iiJ/xLLTxZA//hyloTsdajy8t/tLh5Cvly9dyO/xcWHTo2QEsLGxvPtjkfiKKiON/UpNfsZNT6tqFp+skeCCT9L2wF1hSpXGKtigWqxeYTRXmKuPzWgjbEv1rH4IKdlEDGJjoUK6VxaNGnLGHJhX3JS39hlqsf+foMqt20KkBc/35hUI3LNCTJlYgkcw/JQ0eT6Ducry5elaKMDHtYePPStqA5ZD6tDLjms5oBhYCDMeuq7WYWKZHwkTL/SJyvnnGvbMyrJn5RpjG07PGUCQ30KLQl+2y2r8H0/Ch4rJLGlGsRQGPK3USdXzslmApL09RGMt/AFGpPcwmVOok47h6cMvnJfY3oC7+37WRso0t63rNsJjMb3q3aqQLfe90LmnBIw0Kb1WFs3iRHfJ6tsNxsV306kdnl6zjroTefyQjGJEYeNFbXSBBPsBBymI+kBv6LqdIp8qPp4ie5AplODC0/Xf2JYQNnBMvmaDk0MRLB4ssgg7XNaZBEq+YrRDFdU4vF3Sw+sAeff7olTGxi5lgh5NQFtlZLkWIRWeELXGjcpmCyHSU3NVXq/+pS/Yyc81qe+LLfZn1q5pJtUwyu6RlEOuKdxqqsG+jFP8sZVGcEyZqj+AwU05q1EL9URYzE3+K3kMaP/iy4fQLqvwJ6ut9R0qcwMIJP35dzKU+Bj2ow4FgMCxhfy9ciJQ9ItZTCTe7uDetQiX2zIhgsEigcNjHPirionBRqG514q9KiP6kH/lF+IZWVEC0M9ioMr68/eRoLFUOMoVKfDN61kbzPtVen78JR2Ebdlc6ApJNRw500/TZZSAAWq1k0Gef1Mic1ewHxjd3BLlYxLsiHSbgDmDRwe+EhajentbgBzZsYqMjIxLHWZyA7um+DX/xVTgqvaCyAiOL6tXxbguUnX9803c7x4scff09eh6j8DyTKz6IT3Ps8NdiGsLcrUe51TyJWKB8W2QIE9wa7+4fdd3fEpPdbJoGaykO5i0jqFujzXoPAQOFzG5B8vpxG6UKPFqU/1p42vJE6l8hMMOH3vzcoO7FEtFg0mJbx6TrH2YrDClJv9g44PESDnZMXapV99yzflkkaPDg+zFBMVM7QNN5/Dagsww1YGi+dfDCFsJbFqoFbV2znl1Fqnw6H7Iufsx1Ivqejp8+V8+2RO+pWJF2rJPwvC5tRQsd6DC7ISUlW6MLxqRwbkCRAq9JfOZff5ah2LBAyHP6YFxAiVVMDYcQ6ksDNZ4s+njqQW54zZ2s8HYttcubqTUQZeLCJ8folPAw1zmPz1WK/YcAj8QU2Rg4rPvde3/dR6D8jLYormcXi3mndRtspIaPkDu49etRX09fvc1wRZ340RuOF0QRCW/MvgXAI80l/eUgGy2w/U9LhzMFlfxMhTabaWByT0Q/yr/6tZw10Yxz/ac9/8vMrEJltNo2pEP7PT2NiugtrsY+WYdpuqQGz90N8ScH8DeuJi6/SBRZpGkmU+5G7MMzzhx3M/WC/EGDO5bzOS/Mnf0tvM8BjpudiFUPs8bYZ0JmukcJOtiwKI9kjbfu7sUkkyPbYjelAhZGTKy8/PLGgto3gou2WVmcFtjpIh/cxbFd9sGjwKzv0vTgTS+BeVSgg2GK4vwbs+ApO0EhsH1Qs6OCftCSwPtdJXzLKV9XVb+GbrFXdPf0G5+JI9BInm5qpy5f5JjI4L2XNknRI+z15Jqd2ZldAqwHdClLLQlSAQnwcJxkGEkPACT//VqW1fbel95xTJVlHwjBn0nfDLuY2N9fMo9+hqhHT1BmgYkJdfncWlNVplLTYTSz/SrNEIAJbXfQ50egFvRmac0/cdcsmGSt/Ybda/C10NGaA0H7v5tNELFJxngpUjGLydJtRe0lPrQfl4r2HBbXU2GcX5dl6kybk33xPBFJ1eb9k1qHalzOpdJuK3Poq2sCnTFTYGUDRfXcI2djXlnV+lze2WJKd+r2U7iVCf/al6MD6jBJzKWk4wtaB3q9U223AwfySMnq6TG6JuqhMpoRXeLY9qcyM1OyZuGTuq+fZ8fH5+2Q9STTUJ3DWaJWDm6Mhh0wst8sVaESQtBW/EBJgkMzgjONiRRTPXp4zl9vo74CKY7VmcB2v/tMLAtk19V+MbVX/9l2+CWgZsP8o9/2fyvevyQCfjgbTaQ+7R38Vpf4kAlYFfHehHvmNFWy9GrLIXzV3zf/815L9pubFA4gdb8mAI0hpGXmM08x2V5wfAybEs9uhnpYl5izcx4Fa3qCT2Yzeoa//bqZR9iSaq4vx15YRBIEa8cLEbZLa6IQox0osfBqn8cxSl6mWN+ojLIuwvsR9TvUCTlMgxrtrLyniyG7L9zh6r3snon1cEYSua7G8j/qfwpGsMkgR7DaYmUvH3Zo9yU+wW9a5US6/NAt5bB5QW5uZAIJgAZVR9XiF9FQVx//eGJ+vr0gJlQFN/7ZUqwyUXdTWjuMIG215OQDsC+GRW8DB8kQaqLQSul178X50vM+ot/dIXaX9e6/YQTVv1efKfVFI4Z4qUUNFl4ZktfB9dX1D0Y1cuK4Muhdsuy7KTOL3KWtWprShb92y3oYc9DlqqWy65nSeCT9UC3J7JxqCniMvDS5xC4CYZ5LfkvYs8rgt4HrXSsB/8vl4uKgsPMoLZzNj/l7IV5qZ3PiqYZGLXX0MjGgr25CX6BlUHtNBEIHPEwhUFwHAIpob3HvrQLmD//t2XKmte/plog/t7FKLM+Ehy/8cTgxAd84GG14xPfupPqlxb8/iv6C3OJBAR6QR6vSXA1ehQbSPxlUQF1cpwIJto/wtILXpv8gva9TEKe3Rj6cc/HZm0yQ9uq7XjCuprNd9Hb7JVlSNO8Cq+5vwe8XxGZSF63Yj800kxstDxfeo7pmYjbnQMV1QjOcGHiCx6yHEm9uD96Eg3fjTn1//iLHZBoam/p726I7hPhh56Kr6VSuxJVFEq2YpOLw1TYkZZgzAcMn7aiLrqXYZmxh+0/Unkt9pG6+qk6mbH34JAnjQzRYkC6Cc/2iT2CFP8C9RpF64yli42AYgYzrlZxwiQ2evdusRO1H3Ppxfwf+Vz9eaHx1i2gSg1c4XseDsza6ThfF4lR409p3GEAfUgXZsIURP5Yan507gXZnOuJqA/QRDhOC/uxagjjA4Eq5rBZmBJa9qAp+rT+wiOuNynrY3/0036T+Pyo1GwcVoq08etLC7gJW2vKHrv35KWBQuEbIi3Las6r9lga10lvQwLHMVlpLCLE77KFOhm1cnIdiNaUsH2gNMMD4EVT2q3sdwjVv4e3iAr/iBZBNpxUQyIElxoQc7I7q9FqXG73HWZ4IDje5HtESWORTQosKSf3+NImuAjUFDBuwoNHjuOyesqxipnEXqswuaV0yeuln9KQ+KHWobNVo4WZdzl4mkJAYe88LZuatd7QV8vumIVukUgDUetb67BRmGWexz9zQTfJs1yNtj8IClQUs7nnbd+fd9Wxf5zveaeft8tKRvCCEYBvJwj816IiCN+VGl+1hcVSeW+ZH48jFyaM0f7nbiN5CsWiGRv8+eeZD3q6UzQ7ZiCA5ZwM6JjlHmeawZRHOvKbsG/PKfGjzfCLI1IXkNbzWKIWA6WA8n6gtziOFkG+8bJhPrxUJbicvZYrd1WX5t3XeyLFTnWcv8g8uGT/UFsUQc0c8SpEPNNkbLZ/lRkNv5DclmaKlNryvsEyVSfQ/XqCyS+134NlvTn/9nnnv7eZmWmVzODG7xXZZDh5Iv6ND5dRTQQ+Si6DS61Rd3csEDXnPJ7XxMUrg8BC4WfQ8EYf4aVehKEZ+kLix9+yf/VSnD24FiTMqZLZk7+1T0jj4OFjG9K7XjF5AO7SX125k/OGQAc0TxYTcIS8q//XczgU9OgdlzpgHSnRS6l8vUyOsAqXMMpkGX9azY2H6AWGTgxTsigV+jm6R29Az9MvOGSXf8BuouRZn9q3r+N8etSidLph0ZTi88DkO71A6xdYY8tCq+gZPDWVYM1NSTj8SzTnjW4vsZTbQyoO+YZRiPg26k5Q03DtAK/CrT1ZmS6OhyLc3Ywf8gdeZiWOsqo+pcmICSCc23q8d2lBO9huVBGyohH8sLiELEO6Rw5M1B6s573ElfIk/p54zSXaNmqfCK8B/beZhAKwk5r5uEKcUCnGCdHYx26//2czlQjuydc35kj5fSzDIweFYwpayef9YSGUS+vAzdWj/Mhvy8daUkkwLyKLy/VqA77Gv2eUTUWf4BzpviiAVWUERNMp96iv43J33teRnhjgylZYfzM200e6+x5VqyifJ0dbDcjWkG2ltBqR8Gu7r5KRX8w+IbYIXOhAuYVLhb1MtBLJXdO82c9j3702kCvP8J5W9QZ0c2meEyUirAUb7Iw8TtjVmCcF9QGwAn2C//f97+7chkWwue1FNSD6ZlM9PwKoftC6Egv4J6QcPLZz5h0ehGse/6M+BJxQjOr1/DBqJTx4RzC44icCQ9BJg/WBEXlSoLhUpiTtDqOOpXDL21rqa5oiOWrPJKbGO/3mXT/nHr/92/8NW4r0ireXmnE60F3sKinYuA0zS0foSpyTJViiv68ObTrIVY/hqHSiwT7Mh5OYhV/2jb4y238XAVVmgl+w/4IhFe2kvn7XTJwcTigWz4tbDMJ+TFDx6lB4VjQjWg3TkIKP5ZgH0/sSGZqaTkKE6Bi9dRxCmZ2/XMHRUWq3wfkfqg3hCg2RW9/fsE6fkWqSGSUCVpYZx/aWS5UaJwQayASryMGy6UfY41Pf3Pj7khjQd09Kn2Vuo0HVkBSFIQOpVWs8hQdgkAn+2vxzWaMEseDbKmijDWM65TcgvGM2zl0f7RHy3OSnWfcoJpJu8tvWtJR+K1RXdKwh771KJk81yNvBodyt/1GT9mbB/ymWy3VYaZQ4yPeJJJFLj4ZraxYUgjwYMk414D7o+ep+QZBXd7Ixsm7qMqjIBpw79naazTMau1UP48ANortyzhtwdgAddbsi1tMWKU7o81z5IZvp3+w1P/rFNVV7bmlU2HJhQiWIsJURvuKXoFRqrcHSpajY988f/m0FpC4UdgNNxUJQ+w7fOER0joMe+DsfbASNsjSARwKNi+XWRrckkaGGKFKoD+LPopx0rHKSZwXUgCwjf7PGFQFXVbE4H/aH9axZ44GZCDJ+2ihxkuo55GzZbsBDZNhs/7F97n74MvXCQCTyie6T0FBnA09MZoqN4lF5KwWYaguS8gANt159J5QJ2aAkgDHsbCHvscnl/FkhTo17e0wVXiPzfKo6dukRvb7d7l1zse2tFUR6qpqfu/1iRgTjwHy4PKx3sDJrd6CfZ9ZrB0OrHi40UMJTQSu5qVHXAny5bTch97b5f3GKLFLxRPAHiYc838YHzDOhhQSszY+/WrGLTDGXX92bJDH42/isClNUoUnuTb55eoCe3HwNKrSbXh2MbVYXQYDlS/fb05h+YZNSmPDLMllPzYbLia4TtHIdXNub1yYOIw59cz/6WQKkSCRlnUPjsauO6jIe3gPaCQkaFACG1Ed/mz2uXLSR4O7kJo9z0MZ+zsqb+X1IFXt2Jp6dg1NcMtz6vAOpgMgTvdUmdu5Ns7DeVQDYU0mPx2r3mxouZ6nGqn+tehu6lJ0eaincK6McW+uBDpFOGkwqXsx5yA2lzOG7TyO6qhyPGhDJW0mDRPuCJNFX9tF6gcqX23i+nS8bogTdvaYd6gu9QLS63cf+UMal9aPCf6+XKxujNYLYUmWmtHslo+0bFofujYx9Bm6yEF67Tq77mED0ApRXE+rtvIQAsX5w/leO45CIugVSS7Iq5hoZlbzH0Ktzu2wQleDW8+h9LkOOZ1V5i7vk3IdSTeqFPNI+3h9VsCzaxk/pFUVJpo76EgkGUcy5qP6yflV3lAaRTG05fmgZsEppEjscNEfoOR28drORZgz/nqEcOw2k3npa1VqDCof9MZg8Bj6cZ1CSCmq8v+Pwzcnf4jPUzodMu9GjOfNEoxYYa411RE727MXOctXlR9dXrP2cNdw3Ksv48zwD+c1iiRX67w2xmc/EXQzNFskty04h5N5tt2OnNUeWnC4qX/e8+0gv/rP69V0/0nJjMdeJ0JqA94ncw0S1e/cLZGeI2suhbtMZV/bLR2eoyPiV/13MW1CKrt2ieJrnIlalEFccV4oD0AdsFnLoZqEPensbUtHgvjUz2W7xiZ5GQdvFRhSsg6UOuISJXCeXG2IPC0Zv3ULd/emM2GNVc3yL5fq+uipEvLYKKsvikHuZehAObbFWoQWKTI41X5G8HzHDaGSDSIG/U4eObzsKsqkTouQ6eSECVHYVw5sX8xFMXo/UYM2hv22jS6tyNzhSGdJrseX9LNboHaLlXxf29KLBhz66sOYDce74fDEIYfl+cKpUW1ygARU/eNG358YGVpkUrIWHXnr+ObrhmdyfcTr4IVUV1NDrjMOb24xAav4K/oaDr40992S3lueRQxCOOghB+JfLFnLIu2zONf1c8kyJelasN194P5oaBMCfpk3hoTx1Rrsm/oxXvPbpyTAT0770p58eYc46G7wbv/qveM+W2ty1eCrXBzjyBviy6TqbQE4cmtx//KI6bIuF152VV3/53YfLs16muppppF6Z6tNWw6OnqMU+uyEdGgwawLKCxkwhjI5K8U6zzlfSGrN+l8wc5tKQ78tMut2mjfgUwUd6Xiacglis4sETAOOo0wwR+hywp/PMXIzA5fQsOkVSqyVlO77NCUJhIlxmkx4luGeKBG2OkbE8SFyhlez0wcAS9LjgerTncFIx4Mldmjyg9/VxQ7cUiN0CuQjpfq2//yn1TxOdJfIpOX8CsOvf///vbJUBLNAZfVRu1HbLG24QiBulBBc6x0c9QtVn5hwN6uYs4TRsV5X9aaebRaAKMMkjqF/wFqGXvcesh9wspM6M4MaIK+Ylie36nPTXZp086wSd5De61aYf3eWf/6qj938mlQj/XmtUyO2hh5gZl63h+JsL7roPGypJX4kLfeFCwFy4/WH5FYazw8EhLOMPoKv/jzoRS2PblOd3+LTorPoJ1wNEOE3oKVSbX5yAOV/8HrXWDQvw2u5zixcVwbn9nnsO9zZ1HXRzolnMx3fTWFDktv//O3bij2xTVo3X4mOzB6nBOj9z3rfiD+xFVnMzBrz0cfUL7+7V0y2AxfgSfrjz6v3YZsuzbNpDEjgteN7nwYcm279AWPHNOiyuxZw1RHEbJmOBTyz9OrQe+V74A0U5ccnvXJycu2CEDVsuSMFDCFEtFhwGQ6tZr0AOkeNk4aRZkDUkbVwTuJaGJ0diz94EyJDdAIlY3IJR/svLaGNkAjKlrgdOiXq9vBqxtHkqi9cPOHKl3PPzY8xrR8DS3vgzbOH5rHROPQ9vOA8xc+GsSv+rrTS4hIijx+NRAc/uT/78eezb91kJzyDqKIiOgGIqpY5slSo6CTIGfBr+5cz8wNUet2mJpiEUvzAkXBXCQOlFa4GDCMa+jZQfGOd+rmISWfn4apT8EFykt+ooK+40dnMTZYmv5T0T4SnV9lVxOXf/M5+LFF7Wvo9WgRAFmuHNpIuRbOKHRSuQ4HPhWPly/+ooHr6PG5jkDmU7YTk0gKIZCACmoZMj8kpPM/DGu3AeoCC0Pj2ZtIlZdx3ieZ0gx1aSCUc2jzX+t0WQI1tvLxsXe4L0osSdiNF5nFZF4QXhWQmlg7sHvUISrj0QToe43lFORGP0h913A4y65A4kHcPquU8ta8VNmjy7/DoBPTNiIwX3xxzbXuuFYkXgJdO+72Reav/TxIIZC+jTPyJP/w7gN165gp0Ys4elHOYTcoTRukChTjrEJAcWKJwtAlvSc46qcI4gk+xDNP/+WtHgr1R0+mweMSnZj+GMNPZEqnb0IDePGSxjNlbGQlgz5zQPs2HLsiYU1Mfk0Ja+BCjgUikitqqPYIf1mCWiQoYWiEjHA7RXqA6R8+i8vZWDlK7QN4eGSrPQMXrZ2jhzXRPo316mmkkL2o4Cb0AGs////tt3I5M0PEUMVAV2Cig8rvzHFgeO0217fxw3glNf/7zwW7iM4NwgwvmKtsGvnulZ5A3PfflKf6wMvh79aOIz5yK2aq/ACdEcwURN3SOvkQ+fJX44Re+7p5yYhyHIWNds+DcqLlcTBU5qmUV7yYJT+RNFK1MD0hunlmC9Sn3L4gqvxdwg2LrCnr3M1qP2XNAzBRZb09YIo18We6d+EVMIr4pEEzPWJ15ToD6c9PubM/f2qMoxxv2yeSNmMQHzObv3pb9eu2RsXU5cw69+lj4vWtROFDJ6KSrKUe9iNzL9oi5WroGed1uSAkHXNzt8jvengaRp7hU4vWaN6SK1/gtVcBzl5CX4tS6hA3RtpVCPkWlKjSoxlmWwhozgo/YpjnZlavwLEDlo9y1EnupwWCuJ5f4k+1N1lfnmfPC/YpkRyi98uRhpoc2Bqax1FMztyqNVrqscPozlA6UzShphdQhbON/wAZd+8vzucrQbh0Ctx37LTZHzq1/N0xulwevYqhRN2dkhTGJQL+Kr1m2lmFG92p0rLmSKXtAoNyMDHL4Ls813YMs08Sks3Vjea0tuGKDJFDnXYBy61aZytQAj/ZMxwluBW+BIkRKSBxBq+6V6iQCM7p7zGx0Fb+Hteq7s4BMbnQbFGuVCyiFblfSb3L9O0qxUTdqiiW2sUYAblxzX+3TOXpoFYF6vaRTGPZR61HcFi87Fp1NjFsdlNh1ZpXVM8GHaNxjPaDt07X4KcNp9VR5qoKCLOT+LuftB90XdgrqJ8Emg10uC1O8mApeDyib3KA+GVjOKgqOP/GO21NZgW7++ZPgqFF9djSbylBO2y2RDMP2li7XAM/QR7AeGBfWPRWL93rnTnSKUov7/yP/kZX+IwPHKPK8xYSLY68N7enFuDFLbj6Cqm0fIRrosV+kOGnwBTyOn/vAkK66K6F/ssT9Q9BEAPzFANDDl35+qZivWuSQ7hogDhILTsPW8Nub0I5jo5f56Ad3g+azpfvZ7M1BESv/7ShbWDnvNVahxXksdgfXA8P/wpROjSvLfQcpZ7Mq0gm6gU6MhGaQkPm/w0TEwSs4/pvoV/Qm++FWESFDCiQ1dUCgvaXzMVJ7SJtpyJ91qP/K+x+bhqifrJ6GekEJnUy/60i0rroUob0U5x2oBKSUzgf7kFqQNSUIExjOuS1J0j/covd+2SicpHiVp918uyqAosMHxIYPcMV8AXoaE+WFBx9WuixmRtGzYyfIN9jcMvBGX/RB59GXZq/V7HD0tq48YiOZZt4S/W37w6rx2y2XYNrXqyvfPDePb7M6vANpGhjYZd4KlD0g8+1f+OwwejizOGCIfXeKjIc0RJnGqWq+XxOuvPh2n2neywcG10rYKj1cC7wvM18dV+AFE+FZ9vkXJbAbuNLn8DwR8MrKlYSj75Nq98lVP159Y5exz5Vqt5ohjKi1BhhpJnjBKwXAXiv3CwS6vV9ZY7R4GfdNMOXrZDtfE1SXOp44LT3a8vmsuKrGpo0H2RstEM1005qjkP+w7rYP4OjJ4gtmFw9vmCxuqGUmbS1UYNSvOKyLp7PF6k+tiPLI6fuTJ7XhGm9rAT5XHbcctGF0TQCQnqhRrdtqCa+YZRH6YDNfhKRaGCnGIldP5th55sXtjzybSczh5MLrPvwWJ2UHNbaOxFIV+1ZhhHDQk7K5MLLZM+CjEgkviUmGIraPhM2jH4XpfxnGOG1/rtf/DUQOSgPFRvYImzycEt6XT1wEkWu1eKkjwNKPnaNsvPn4xkYKkpW+3E2WPsAg6RE0JzkJGw/75t7A8le/iHmmgQV/J12dsejdVi7w7It9QkZazvJVGLGuZ9MgGwCoTkrWoQ1s9q/3PTsKXHBttIQif4BSObj2AcKfyQ/W6+1Y6NCpanO52MMYjHrkoQievBH9s+K6J1yM0XQmxxm4f2sMV2COrLg6ksfX+ZcsdJWfK3yBLGOs4Y1zxN8/VK3MeEl+XE6swOGLj4EWcyaMBin+WpzSWGD6ANphMJ2C3E+gHBQ3mqPnKvvvmxUGfF5Qv/FnkNj9LYor3DkGaAjw+NKaVNz1/4TI+Ch/pf82l/ps3PAEqDZ5Zc+5l/1CEGmqIC3UGxbnID6o9EcEaZBPxEyS74somYL4ZrkgmsKfM+/wFXnduZUsi8z2yaXGDo1gz2X9fkgYr67WdUWHOgD1lo4IQPc1iYeHZJ7Nk4TffkANXO+VLA4VZiJLjaxiIUrToYt69QuRkguBnAs+VqvVPuwQYH0S7ea0Z3IiP4ZaqyQ338v7Ux/C1pvfbJ/vECBKKfYG///CfSo17QkotuqvvlQsD3mhh+EW001eCQXIQ0byxw7k9umkf9lB4JhCuM7cENkaZ7Xo7w38I/JpZQ/T01n++9cHh3kIOSn1FrENYckAYINAFsvHO6dlMTytmkn/GRd37/3atGHDVYJO5imDFjf6nvSpLlkfts0NcxwIZ0MJRt1D8WtBwpnm7ClR9A2/HZvGGv5obiS8pPardPqkYfNcrN8+RDfJC1wBoTUaNPvYNdH/XXCxO07h+ks0mNv7k38AyxkiqaGdQ61lTf6sCjL7HfoyT7aNLPvJa33Y680c4UXFuanenA0jEKEjB6O8dj06hd3WTQZiOQHw7RWYWsNsfIa7KsS0bVF3w3hrrBLyct/xD1dEQSqYi6oufTM+VE7L3SDkFkNHc+wcoROf9EBmOvvI3Wf4zZ9R3Icsb3/NHz+OcDCDTekrD5N2XRhJ7YqsHwSHu2v/aQmlbS3hsJVoCJc15qRMEK4oMnWXxRXMq3Ms4iLhvwPf+0tanz68zRR0lqLGbABbNgvcYtR1EahwWhOd6+64819FWmfX3VqrNoN5h7hz5WA/PgdpNLtGxJoEB8YuepvoZkEXz+AwcogXCPHhi2t8CJvgR/PZXlvNpg0cnKJ6ruqW+xAsuEb2Li0d7GFMVrYf8Sb/stTMMQGNlahc8EyMl2I316m852lEViJW96ZwayOTkjLXwgybhhTEGHgO38GYZaPlX6m5gVK9TTx9lWZIzGW3b+KEwWZKjf4RPExyyJfOe5DDvSCjSWXvzCTId3ssopK/4tTPizcH9484oUyzEzYPK1vi53xjbSzA/SrxsZGCZ0VWi+gbUcR9jJruQmzpznGLNfLv7v7tTBxvPT7PuPkS1YmlyWtalMbGo8qXDO8b/cXvzqZoDVdgIdiv3p8m+U9tPLk5cAyb7IrNpRJjWntf/x7aUyjICnZUwNM/jhSsvcYCbvTKmlvHMrgymz5XAns+VFkMejrFqRyH0r6ihlsWeJH53wQYwlIRGf5H21jIDlAzNaMtPQ4Cmjwr1+H9NQlI+FC1dRXo0bjb3sPDQz7TnGt3BEfMrca/zvCNEvZU3NEil5Nl/KDe2Y0Q+mvGebHG1HSjmaBEq7RfedqUJy3H/84KVi5FxL/HI27XANpjBaillZhG7fi9dmCbnp2KhMmw63RKVK8TRdnlsNQBgqhLs/FTFZLTARN7VOW9BWrzjKCGDqU2+8/ymmFuC14how0SvDbQJliJhMSsTZWiICfA6Bpw2vTN8tzXy8+I8odBBvJLPNbKcNAVXAGlYtDM9SS19PIYz7rwlJco/x4+via5Vy1bee6RfUVcrR5Eq7+xUZlyxFeJWGoZq/8l3p8NjUV/Ofg/6UNXk7t9jNWY41tH894U4iUqzi7nz0gWdnuaMtJIS81e64XIH3tCZD91dcJ4pqxC5P1R7iD0GpTBJpmgkEzOvOD1Q4ZZUEYBgCBYRMKqu4965gWFGot3uNoi8bIecTqjTdYkRm2LnBOK47rGJLqmD9qY3w/tfiNaXijsGsBSX/2QWjGLzRo9y3A3xIrFMflHMYRvcCtGYK2ZCwmJmLDViBLCllTjy5XTOX/fMLYC4s4ZyLQVkMf6pufq3kLRwc6BHksYjHtPOdgyH/VF7PtLQDM35tEYoqUfZb8k4BQDVF+maNc76azmPOcHDkiLfJu7Zd3OTa3JfcAlkrJ/ZuAXYCFeT2nr9IqBqDFDrclznzPZ6vJirlgy4MVKIQ4RgEu8V+m9V7N/dGjrI/ossUNG18AMNsoC2dWlnjEf+yQXl5nWlyGhFwSPpXu9G/6mEbFG6Lt7GbnVVfPtOTKQ8milDgr8NGktxPJTsiguFC5oxm/cGE/SKH7I69xM3G2y5F9ZE7PoqZbp7kdKkGxbXxOaXhGiXv6Mq64/qzdVI5Cc4qQhILfTRZimqqzJDg0yNltNMH1qfgHhn+o8p+DQX4QixCRU/lBrLfISzRROPXfWIEZ7rTHUnBlKdgTYajI8Zw90QIgh8YvWveVQz4QGPFChlrMizmYZJRkRABmhFuQP8TxcvEfSwFBOmqvpAY94NjSKQoGjHR/7ubm5lYPSLWpYDvp9Mz2ZwbLF+EAbUksavz6MxMBDHOJQBl6+TTZ6UimNK35PEZ4HJ3PpxdW2fbP1iZ/3WiymrEGXDoVepoPg5f04xSSAhWmxjV9jyOOSUNxsZ2mD6AgVATr5NDVpjmtl/RybU58GKlFHCK9F299JAnanVzc38iveCdMzP+w/J8T8Py6ikc0urHkRycKcP1dymRw9Y6j4w+7Os/Ex0GBmvum07IEwU+BSeNj5/vUZe4+oD91X6qeAE9ERYg70VrrjkScurhSn6g7q8ON8HBBbyI1hgHyjs8n/NGMaWHPb/K+dRkcI4lvLn77X8KIec2gFYfiBgp4aHSFu37I7vjwZm3wAqDWsdFzAwnpNSVuRcuIpQIHEZI068eA2xtOJQa+1MzvlyhlxoqEeEL+7b8oK5NRtPBE5DCDhNUrSn3GT0ANVOXHjnfEfarHiIGuTTpVXCELziq/FkYmRWh2Kl/1uvWaIb9DLQfIAAWThgZ3OllvbBKGlYYQP2kXu20gxer9dBktriltcZ/gkxgkq0DR8za6L8MQYjQTnwKn21iKIEoUhniIW/l80m3lfkI5n0TO0qr38P4DRqpIRq8bcTy51dbt03TMokDGQNgykXJAeYUnQdLSEfiwNFHLvP7i2RMv7euL2troU24iy7tVsRhFRQC2rFPrD748lA4bbbYE2aDReXD8C/Q9XsfZfNGJY6zPKoWdZncdUIcp2zOzXr044alSyejnPcH3mn+uz2W8m5djBA104eTJ9B57sm6l8tUWP9fsMpy3731Shloj3HUvyZPFaSMtXd22EsXkWSVzZiPq2WjtWab8OjgMoCQ1rBWyeDdSCjtdWGkYiRtLMkmOsm7mUYoC3+jM9yHh5vjyl5XFqRsLRdgMnIlr65PqBBa7JGGqNrl88osIYRUX8c7+l2AUE9Yud16UrnwQqypr0Jh7KCe7TFqZVJH0zhlU4b1GH11FX78MODhqIvxd42pmy9BZY+Ige/17DCTVEQuWnnfYHLDOYIAdDOtfeeco2XzQaI4E+nNWCB4bbJbXRigSr9QMG+VZQVF0qwHnCuJKUtZYOWaAQS5Lg+T+z/QPA70wjeSuIo+89CX5eixjpZ5htJFVuMgmTIcBi4xKDxSqtbRq2Wjy+Tp32yK2AfllGwbJlUFcv6aF4ZbwvXajVLAQT/GIhTZv/kzgfnXAZua8rFSgKbQKVse20ed4gomRHVhNGdHrV31zCFesi8dJn8N3oT+JwZqSC59bMX+qQLGq8JWptTog5aCI5e4TfBrII3PiVQH1ytMsb0M7iFNi3FbxrXaKIH7ljE1d6y/24pziIEd30uFkRiFSLlyHGlOlAjUsH+XVCwJf2lBTe06DhASU8U0OpA2ECky0rt7EKKBUWHh1sREzSsD0RezG0p81MI3TLAvpRy3mMjKQp9jHWGlJECVnfLtz0oYfgK7eBRleQXwunMeXdlKM4R/sPhYH0oHYM78qbpYX+rm5zTatAn1+VQ4aFY7Cs4Pxua/Bbvw5CMoKdfwAUAtftG+KMV9/9/t1FjJKsJytm2iIGKqU+LH3J5WI1qNKD9pKPWOw+OcXHRzFOM1d2kLtvtST9JV97sRug0+TdSF5aYD/Av5jbf6Vz7pTgfjuycyq7SosR+ASvHb9kcZnN6eJmjDWbEReKq3lUgT40M8D3eh0UxpBFu44cfMdNgKTFeDT8hL+xrvl8Gmzkugi8WUv299jIqN6BrwDnmt6Kf6sta5qIUx+fJkqDD/6sVmoByGSwBRBRlJhbVvK1m5ANxMGmmUOWTHdsNQI+w88sGr27HgykMAAgmxjpA1VJtk+lqaiO1OuyWWs2WjHzN4m2BvSsvm4sexwmciXekFdRk/Hyb8zSt3cC2zfCCzEksjZCUg2+OgcULuirNj1eXeELzasqMX58Pu+w/aYgKxBPsU+8V04HY6toMYoGprYVvXH+sbhJhvzlcYcZBlrQTY9/JWNyxk4enmrJgXHII+ObCWKUW3O8bbgmKh2Am2FjzMXcWXlSWcDh3w/LXaZ+j+ye0dY1X7Xk75MJUAdzXNkOQvSI84+vxO9JKMMk2ai5hiXBozSM1wqaqqwJOjDF5oiHaHvZcRoMDEc+HeesHCIc5HWnJbXRsTBY/iZbQscUH9acYYJnIt3vTpuNtJj+nQbD0IwaCbzaAtIMcZlbw2DZ4GNHe+Tv5c74jHcmtG0mJ2NNO4IRbyp3cIO9Bv0FvzCG/IMsUdbUDKVynXPc8wgcj16mDet3OoRitKI/LoKctjS0GHIy3+MpRtrVi1itBM7GTy5RYJUPsSe17DTE7BPR801ss07QBFi9e0AFlGQ3AO3ukI22/BD166bAEouF+DEfHktroy0FlmuU9Rh84HQmnxurbK4OGNLDu+KRPm/532TQRKMQHqp5iLs3yAikI4xIHMvbqVMFAqYdrctW8TBy9z0gC8l+JphDQhaRrAGsPcK8e6y6LbkGsB55uBu30zYD+gfk1eA5TQRFQp0T7HxraH1PHgWLVuuWhNgi/SDSHS7o4mYreAl638qb9mFcWDvWimsNFl52n2UmnCP37J6Fock/3IE3SnwceRKLqu1xOljowZAUl9m90JrTua8DpOE7TUF7I1KCYNAdPGPIVKRQ+Z/jkPr8PvKIkkNMUd3PD2RdlrhrPbSC81xmKSKCKENfiSKDAjmJ1tmh7feyFePWsfBui320vrOMB/6rWSW+osTb1DjR+mtEsfaLavhCwU8U4AOEl23y/jJtESLIOdXgEl3uN3y3ouF7fMwt3yrttQwBb7hga8xSYFbzILEmxZx1ovvKn44S3s3Lps/rSP76kUbCbTFzIqBdz77HRJdErCMWOeHVyOnSf/I2ZSZ9wSC4Y+rHeXeIaKSx4e5rfoRx3nkHGlzNnK/A2c3ocXr4HIHlugJPndtvpCv0eXPizcZA2P4mKn4bR+8Sa42L8oA/HO0gpplDxmL0K2ktbqcS4PJngCgZCO7CVJGKLnlRp41+Z1bmI7FNpGSP7CmA8nIKPABZn/KPVZ1jqkWjrLrJsDLgbYdaKHCMdPk5LgU3KU+amaF4gxpppDMJuz+NVJPj4onHrSZqDQfgDVKwUbFFKjZnckGcNwnT3AYOKhx4+xqv6rmqy1XEPzspfJenU/aqDKpNKgFpq4BqUAifSPUy4AnCVAgzYkOZjnlv8AVM34nCwf/XpVgVuga1MMtIu00+Dvt2rbqyfcYcnYPYtdJJs+OOaciKtqsF5ExIePoaDuAFSCgOI0SNPXo6QSMiKTas0OzgAspA+N9JWFP0KAf+KjaGtQnMrqvYekhrwjTWxwBz07t40zj77pLDNq6+siOXLICGeTL1T0yEK+1cpf/N9sce/jkk4lPw7ES7Gak4oyG7nBKCzxpClOYJx8/ZwehHUUMY5ZW1GOF0BhAQEEZYmp0Nqyu94IqeyviQ5gm9C4UC5KCm5NuD88hfiYZHvibDcDv++o0165NfHK7R4V9SkKzkmvdSL8q2zSLPRDlkV0iGB/7PkDLztCz2Okn6kdKi0iC0ObPXlAA2LAAiE9gO97G17mIs6uG0875A3VmQRkj0mQj4TJbCMnhoNcz+2KuGM1VnpLpKTVG8nPGjBHdCStOUp1dSLe7ALPTMstL7m4/nAvq/j8w7LzJpcpQzxE+OjINxULsYinlJrh5ctg5I1XIANPfISWX6fD2hmZ5DoHvXsr+PzBS1u+Iro3JblGG71olUMAr88CCo/Cd0tN6Xjhd+Wz9TCegW/jlm/67csfHw1z9w/MgYDfSu79uy97h3GeVSYcFtOMqBaer2VqFGCIQNa8HENm0hZXhdmJFUAxsH1VkwMAJkKhWflbptnaPgL0UuDTA2YaOw8wblzMtVJYInI8w8Ca/2KwNeZ6S+2z4DMF2zuco2vfBaEoGyac2RaGl63EsnH0tXIoKKEiRCRkzMYx4azMoPS9oVXhrBrxqKOR6dpxFNtlXyIDdGyaJrEDQjo8XEJ/+qECiPGU24BsPzBHq8ftwnuuBrQADxoiDFGxFSRD//ru1b28umzv5C4nD9xip1ZrnkTyk9F1vko8H03mFB5H3CNrfBIeDs5SPKmccxi/jLArc5ituNBdfJqb1TlJsgpaPwjxY36XkCeI2cikrYhHSngVk5x77JrpABOJzyQO+a97ERComFxjk2bt4x6nBBcKPRa0Z7Sm2s3HO8qFOacPsCoyIoXoALHwCawo9xajMcfclCyaqWzJG/PhYn73A6NPulvh3NH1XXRdmncklGwI3InLlzWqtxkjV55I3M73C99r2P3ApESOH8SAwnEEUNzRVOefBRQSc1tfI28WQWWt8mpSW3RgP70ieLm8/vQKBWC0+GJbF+XlMEBUSBZzdPLTqZPuF201++z34fv2EOCpQ3U6f26ct5i8fw9KPFo44QdZ+05YN499KbKm0gMpDx8YO5ydYmHxpUzC92wIBSM8ywPpK3ULZyyzYRmb4+qclfo3omUICSBAqWrAJdPp1jxIbqXmjpa/dnWuICdK7dizX0V8HKmAN/h3eNGBuyrE/Gw9znLOGY677oI+IZvrnyBz70pG56NxtPiMztssXEjnfK5Y4E2rRgC4r7cB0gQnoUmv3AAk8DxkQweGVUws+TgM3MI1aBKiUQodV/Re+4nvHhLl8drNaQa8dmW+SUwBYIBURdIjc/OrEmHzwWt6KFMfgCee1KgyRisAL2TDqANmo4JcJ/L7ScQlcj7OzhhnT6bChVCi4UCOWkIszfnoNhNa8VrUQkQRx9fYwJIRfi3+Gqjc5hKyvIIW6yh7YYz5Xivl6dAHPaiJuEHw5Td1qOT/69a77RrMwdADLrjQ+kobZgODoFAp0vc+ahSS4ED5upROVEDAI7qeBnP8Fhw4Qta/IhK+CgoSUD4o0aHBkOpU1UmISwYXA94VIlMMuqQDqDAqK6xKFe3J55BtF9DZWHaYJughWmNRj96XGsWXCwTHwFIOYjKXZ/p62pXOvOVrSOAjJ+S83uaksIDQ+NQ3m6WDDCQl8K0gywYyPyKch8QCruPbjU0rdi2jvYIC8RkM1BscC/hvh/ry3qX8Q9SIHvkHKy7ikVb50Wc+MdyNwfG/xMunVfndQvGRzJmJtPH+F51eM7YpWdIbVBoX9q/49WwlJsy6EFQJ3qWESL7ECbWL6csfvCZhHlQkbDDh5an5qd8hTG1gSdV/Z0Ryq7UEgSGiGWCRhiOSkIMV0LdbxKmmPRmcvq/FDg5voehXUfPkP1bANn70RIeIdyvrXdzy4SPYfA55KMuxtqV7gwT/Jqd973laTVEsb3QIJ/nGEG9H+SY4b2Uz+VlaX0k5G1mw9rPyQjulhYmhOj4izhQ6TZ+aMTrQzT6YmicSlTAt7wRJaMUGxO/Uw00b4WUOe3Gr/6aAh04UxS6SXM8MRY/cjzy41HJfx4rGOylElHJygTolDb+SrhjlP5BYHEDL9h+mC9FLmLJYbGTIMtU6p9Z/fyAhAmpk+IRr+dot0zp3jXbFfbCjOzanMo0Eviugc1704pni8WRO2ka5kZS15CArbxWIpzqRgIXXMWY/0uK87R+9oVx3N3PmQONlte0etvhPn9zm+zOkolDvlqejksAPOOA9B/LZ3v8hVZMD9NPQ/PKnQpyT7wkXorg2o/pfKhW1F/kiz9lFcSyazxr6xJBQBeKgMZ4E0cbH59kR74RaVmoZlFQxDEAsZBgD2QTqvB8lJzvS37wxNqytqe9anxKIQCNc+APaHw75MliaqRUuotMJOVKUgOqS10zndX3fgx5QLMbmacyXdS3jWoMorpEw/uOxc8eHP1uwElqUCfPK0nn8m3NiMEIu94Oohfv0jfA/f295KbUpUEPt/VsdCIskshla4p+zJ4v2FL4wDSrojQx20TzK3AwWcpuVgMThjNsZ1Iasqt1DSpyiZNz4XOmLFt/IlQnHmrd1wwoYLUDq8fMhFUnA2J4UPqmlckjt/pF43Oih8BlfOog2sKolccqwnQh7cYlFAPzgq+vgKDDfbIA9CAxRuETPAwUHrTR3bQkXsG7C/WijdIC1W1SdhX6RdnuWJc4vzanErBYQiuIG0Gip1/N7FZCy6d4hOz/CgTfcqEy9NSsovPjag2prWVVq6NVQR02pnk7M4mOCqfw9Pen9udF2sqk8dnj1qe/0RntjOL5cqn1hnUwuP1372BFySKotSsQPKgVxxluXkfPftCW5Qxm/321sGOfnbcPjsifIzP6i7b46viAvziJ51NH8LCwqwkW+mOJxbaumXkpDBd1SsmHq7wsYns+z1ktkVgStKyigJaoxFmKenKW2pFQ5XTNuQgzF9d3cK4PW6NMVbrg75ZZ+15vmsEJMlDaO5rz88TsPa3lfIZ5YTg2PqtCmdfuciSaGNjXzXpK5PXA/a5g8yOE1m/avXCwlZS7w1LlWsBnejno5eAtxUSJdhSJ+CTbhMEhBQpb9rXDUug+bpUEaEjDf3i73EEpYUb7CG4a+ArA/3MX/kwM2i8whgZkFqHNDrjRpKvA983ZBjmtur1Z+yk/11CJp9Av1+IApyFwfYJ6Y8peCF0+ldCYO5zOy8GTyiUTEM2R/lg+2dPa8weO+RX5jnz5zaiaQjyYC+pnOVqyGR6Ta0zgUAZwzgsNbLlRji54Fg2kKEUYFT48cPkMs9CsxhAKEaBmEi3JPKAMfNPapFEsC/5c0c7DOfO/Bqzb5kj9aA6dVSGYT+xv9zUm13+3Zb95tVTpUIP3ChXrR2PyV4eSA5CZM/nQYicULlTy4jAyyFKA4851W1N+PlTTgcxk/JOw89AxpFNvnhv8gYx3TcfeXo+1uXyv3OuSLuCOb4PwTlTiU0xa+ND5hB53VSczdWJDqXYti1vfa2ykXaDBM3JPMxHu6kixExFAr+HnSONtNUtYsPIyP6jczjVMu34+0Gyh6iIJ6nyRcYUlFU2RGRSEtAn8miJwwP/SC4L9Qua77rTZ4vFKPki96EMRkoUOGhiWOw4KSc2K/MDKlCXAA0ykw7MUkpfueYXobCx2ch9/1whw5eZ8R9oF9ECNtktroYyFxdn/gAY69VMuT/g2T1Gcc2upeEe3ajMKtaUTlI5ktdv/xbE3pWDr7ovyFXVucmUcUVpfIOxoymiw+X1vq/vGXu4vbTjB65FxXAEbndHzNvmsc57gPDMmseXIEeUhlymxCGgKhbQW5uxaBEVLTC2p8aev8aY+KXHx8TbCaiaB4+SfOsQ1XI1wQz4rrR/JxWf8GX53x8SslHsgrH1gAP3fOvUopnIWucYdTJqB/EWODv1Mji/NgTQbmf1H0O6aUksibOw3tuat2cc4M/hkBDwVa6lP4tdk8yYCu1EN4p/Df9Kr/22rlB1KJvM/c8QHXgr1/1ZaTMF2O2OkSEx0hIc7vgjDrb2W6ZzADwDzC3KF8SSxBcFXy8X5EkU0L3pATjduHNruATmolGEZzMWbSix66MBfo5NkPj8On53WQlXJLt2pJ9pXZzBu7r/TGtkyOGOxX+SFRtjuZ3t7hlTZmW0dRltRVg2KZLGayUHbOO257POFg52E5RkyQmEHWidPc4jJ9AWxzWHj6lDqOQ9Tbq4+SQLuV1BczLjjpcqj2uvQF623YKOKkgpwuNlEZ3YY0TZnNw0Zse3uRFDLRFzFPfxyfuQPxJ5Vcc6DbIE4V1fxA8XZZ+/Ja9BK80XhHJlow86dEGAgYKptM7zHjXSiL8GLyeGGGmtSsTInnVui2T14TXe+XbSMBx6tGYKNNslXs4xZzlcuVyjM5/5SOTHtJC5blm5aPO0Q6ZO1YqOu7IClROVuTPjNdR+73gcBoL+gsZ7Nm2mhfbrXEmfPaDwiYTPAMr/LBcioLbBOUvmWGsV9q0SM+Fn6VtLIJUBoKFCssLmgBeiyae68WAuVu4ELwQ+C5Bzgf+xezaV7oHrM8vCK7xAM862BQd9QJz8qtb57C/Y4xGWEao59NSy+Dg6ueA1Y81Ymx8Tt5OjS20QhOnFIzZLgRHOJ1u5Lox4zu40XeumvJiiDp8RAFfEZGhU2AozVeAITAjlFBIgWj0h1k58pc8gtBPO7bWg2iADVfMr4dashGCOpR8gferEICOMLF0wUHWsQt+jeiZxUw6tTZ+gFeOuyChsk3shsgyyCJzX4XgXY7Zr+N3OD++5AAPw5E/6e3m9O+dZZoDFDsk3IfGTSPl3Jyt3itLGC/q9k09JtBvOK4SdFJE0U4KTwuOEHkW0upPHPaJjzNyi80VJfWH2s0qdMGUm9hzZ1rKhS8ibRf7pCW9U+c1ivsLYbKVz01I4/MWD9gq27jzhc4TTKcUSzP6EPKpcJbcfQddRWchofaIrbSdjtpMjikg9sEj1gsDPiclT/pcBqMsf4p0Tk4EqYz3FTvLekzG4NkTZuD/nLOSg2B07fukM3H/JvN4M61d4I8IH2DeNyCuuWza4ACC+64bhHEo03RQApkoBQcRqaSxIgkB+At0JBwroNpixRJ8GSZc7V7rJ8ctlDzryBjIpzjNf+U2oXP8jQzNHGkqjiIAVGf9D/0TrTdrQNbX3NZBHnE62QFNXe81iGKNQFyA5qTreSf0aA3Xxa6t5UF1lSj/1vVKB5MiHIDQOaPQ+QeuOd03jX7waV2LRZbgixVerlsEtKfDw7gK3IqDA7icQo3JpEMJb2duotBKtMBRPWDHtK1ETfeJCAjgLpmQix2bvnJgvwX+WQlU2a6b+ucqEhGgSlnlTbKh+rMOe501ud8bGwXsXD/VlH8YZQv5lZeScbuPFxpToGQylkCRFMsKl7KQAUtGg2/3VpLWPqqYYhLOmpDhrBi80dm0nprsu8vnI0hMANyKFPnt8grO/XKh4T0ujeBAwp4CIMPLCRKdoXkIzOkpzIUopc8FfL5M6DqqULkYGyxjRQ+igXUcirriYvsTlJdb5DDBfVmjmRn5AHYJIHpAMX+lUTIL4txW4kAiLmjReXRoNkOsJDDoP15/lYhZHHQmAKM6wkyksJSvcBiV80aoa4ixorTtUgguxlb307j5/+hWEhs/6d5HeiodYAS/E5uX/kGeyQE3B2xvtAsrnpCtR2ez4PZmKF4U9OJirqu98e7fs7Rr9y8k8bN+3SfIsZ37OgZNHw0u5v/3q6MjyfqPxr008TP8skFzIx5l7F/EOXJeH34FM/p6KFWMUsxbR7XtpTeSKSmjsMm+TMJ3WlkrTiMqzS5KgO1qRDw3o4ExNPAAAygwEsVGDU/DoHpoAAAC5fRtQFCQM5biABjzssBV+cF/GE1kJBQL12wkG+DK/rcw8rE2MEPXr40oe7w6Vib0V69j3Hq7P6myGtnIAD3qBRmetGOHLJPp8A/4B/BgDmMD7MzXaKHah8Fe485LXzl6vFg6wQFR+FJ9TGAx/XCJ385T0EoE9eYX1AkYZ3vzZ75d3W3RYQnBqiyNaghQf8vRYAjZpUWvsgR7wxm0tCAMwLYKSpZsJd2EKvBABxDOpQWi0APAdV43UPty9GyGv8I3vW/V5smyjqLoBoIaUiQE+40OyAZOI7LJ8GrgeAeh+yQ+gq2oi1tFE7zuAOmoflJPf5QCLhB7Jps+W8DgAAspI0bCfXApSMSD31Nd9gkrEt+dVfz0nWqJvTtA1kQ6gJ5RWpH71ysGpsQpA0mW+cT62OQgLEkJCtGSPgmdBLUD3dEjc/KEL+BUeZBJ1j3fz42cqSqx/yqp8yzY8rbarg33dFPsJx16uFC3d5twijuUtXyOLB87EZIJwr8mlEJ/Vh8VOnrPJauEMl82nzNvhqvuCQEGy7I9tztogHPcCfOyCCTujUa9U30EeHBdBLyAVstCkX7YI2A64WxMecZYlHQHJSgLOmbKi7l/ezP4ZhM3eX0vURvgnkcTtAUmBTvoSXICuB/iJku2XhdylKpMCm844o3F6AlhjsXwldUDaN3vkFhKxTFIBq7iYuFQ1Np/Izloc2HWj5Pba0bBl0qVd49NJJM4DxBwxnNcOIZ78uictJLwFbDEzXbxjdHFGyz1g/NnjeECqkdUy8wYK3Dcp3KS85FMw9eD7xmKhr35QXH3NKl/A5W5lWgLhsazURbsgZfEkTEVu+L8NaCJPUGinT5I9lVB2/l3i6AZcaACUpivJunKuV8BTTGoMJXWRse6pgnin/NWlj6rJB9pdFLqmclhVIbkFnqhaCJzFi6Ix+SxQNOdGrA2gOSP4ULAdVocOMiZh5dX2+rwdZ+R4taBjCvo7V9mdysgGX0YRmSqTsXyWz3UDimC1f6ntEWkXKzqPBCaNmvvyy6GFuKpkam9gUfH1wsOYrvLh2ASDWrLiRdVZiM0UR9t2lB8FUrjCvexJH+r5ZzY3Oq5HqKDQJ7ffQe7gMi/1nAPQx50gzrhHC2AAVdO1IWLDCGXYxIKKYLcDJeUAAmneV+YA9qeE8xZvFSrSd6ArGhPCXmsjBpqYueCP/WDzLMORTHfSCxC6W+K5ocvXNxVz0vaRhS0nrP+HDdUwoKwCmxffVAIblGvfGTm8SgECrZAYXlHAKNKi8yQBS3sFI9aX7jAcMdanZmkgzoSEPeJ4BGf4alK06PUwGWHREpJ6dFKJX6Wjxz+V4z6g9ckJ4TKYAuNccBMAZnZXFdAFaD3TPe8CFMMKgyQxq0dp/onpTbIkIDBTqMdWVpw0/l8jb/CNlnDzWlQ9uL0mal+n18tzRNJT3TsSuA7doR3Exnh5zc1ToCxJ58jC2Rh5VToC4I89hBgdsVcYbVJf25NahDGugNRemqiiqFaXAnCfHmZAauuEF2FBW5aEsonFC9QCgESj239aMY76CmBg6GiBqAA1pYwEKpt0etKBSIhhM4vbUhKd2KWeNjcAOV/zk4IvTcMglBllh92T5rFij3CkrPdGjLMfsRaneNHQCcg3O/DFSDRjXrqxPEqiS8+YNLvQnqz7kdUf/xjUUCajwXE7+UGxTOvak2FnUNwNMEfOAku9wOrpzO+KaindQKVwST14UK0L+WiHZKBQ5RVfmInsFBohgQS02oBpt54uIdnJv6JZNw2kz3G3bmOfbOJhhjhKxBSDRhhfDaZ1D0HTALnExj78IBBDxnbZzjeibA6DFjSVPkPoXRMEfx12wVo6es0EsVQDeTKmFgHqOi9tki374bQSh+iyehVvbqSidPveIH4dY9H3GWEQMs6svXPhx+WUZc2lRBm7JcYxlCD65HMZv2C6LCxyGNwvmd6s9VcbQhM9FnmAkLcsc8tvH3FObV8BBQRsdITjsivFcjyxY6awV291FkWKTJQ5dHFd9zN9ptX2S9eONyI5uvdXn7NqNgK3ZPOPY+a60Tz56K5ixZajpYKNaoAAs0+CLhul3dWN4z/e/1rjVNCzkVMccXJRIgVYR+TvA/mvcqsiFo1k/7OXm/1LgWMZrcgXl6y9mz1zrOHwGAwYbTHwCjLBKJRTp4x2FBgwIWBsE3M3eKu5SSJ+guOck8EUxK4PzlHsPZBNhZcymkHFhwEZiU6/9aB+VjPUr+vJ4jNdAzIg1wSLHF95ZEhqAOn1ZlNt0t1ytgjQV6CN1BwIZIjDlGfmaiL/U8vvjzZfuDcdc8U+xCx8Bu0LRZ8JABmDaa9L76PQk5gw2C5fgzDTDeGnuSXG1Wpi6m6PtSV8Cdng5wAY3xEyivk/A83/M+uaq7oemHMS/o5dEURw/8lQRbAT/GIhV+qBrjNA7TEACSWgD5PfSp44v+kKSN2te12s74LTYdS9U8nmT/OKTYf0tBqASw5q6TeggG6AUsVq1nixqlpsq3UUCnbRerwKluNuZwx2wGJLhSrDTOQh3BYHavzAo+ZhpZmOGojWwbIBs1JLJ4nPV7fJ00tl/6qXBEv0piyQtZWyXxAfbIadnwXMk+pDj+wh9+eLACRiuee19kvuOr7lvu+JfCGbREdDFkrHF7Ud0cxlF8jlW1HRhbAcFP2hAYswQlwgrAALitb7MKhQDxfepMJqOHP2DtbYOqOn0SNW1I6U+a2vVILIJ5OzwD2TvxADxQIeK1bgRfW4IPME2dQSjT4ubjSvcCMGtaAUX3Lwu2OucBHWzLCBZgd5kU87akS+hWyzf9xvXvffCaeAMFCI4EA31GhxIxaKUbSzxrUNw8g3esn8Dnx8KsM+MwBKuRyuPJE+IrPHFSTzFdP5byXkYVayodtmJILFtBLvveaWZv0A4ka26XoZwg0AbgkP3LoMtozgcCFzKG985HOD3WBaUbMqpXxhK/LGMNXFYoJRpSbIVHSFPTVeOpd7I3tXn+HxSjX5E/47e6j04NWrFCpySuTT8RyYFAX8dHVGFMx5TqWGWRMLS5QLB1IMDx9BxRuar44vBqDb+2HQ+Y5hgMV1fuGjCb2my6Ern4Ck0FHRZNpYV1ONRzgalXKUA/+VLMmlGpBVW1F+2lBdnsqamg0m1WSxR0eSOY4NAz0WhiUShmKrABjwQIFAcGs5oDGZqW1ujPVDSLM1Ein/5SYloAaWe8F3Cm3DxPRKnAtQU8Hrq3zKTAAcVPS6xJuW3btuFk9KuPzkkC3/XOLb4kWIWIMzMv7eVLRLAP3vMcKP79L6ed3P+ZX1Gg0wwOjv+G0rdgg3GCFH0Wx3nrsHI3fYhyRvEvazZZ17+WOSLMwkwOEhAy83TLMfyXxC1JC/8jvcDUgs5k64kaeMq5X0Ub1jjfqgHDZWP7EdJCgnvQ+a1jMqTV6AfYEPCZWie7pMr6pft5S0tJwqMHDxn04waQgn082E+BDTIYsumwnRkXpve6wGnHpnAwsZQt1DToWo0N5QSQAiFr4nIadQRft0ViW7IjJ+vHMp/OsoKpbB2VOCrKjDDzT2AUf/Wofc7lVqnT3QS1u736nkFxBiZXo1zTCHrkdSJZroqeCLeeZZ212mWSukoq2O1L+7ORNimKeGZ4a/hJ4kbN/nLEPRB+Cb2FDJgulwGv4s9vDkPcDuGQTw0ureGSHkK51lCVo3pRWEBqin84Il5I3d9xQ9mC5Me+9YSyTC7vhLC1RrZVvyvmpmLv42bYUkq/fQ5lnhpkHijC3ZN+qXu9/XTLxaxw47/UC7UMZy0F3jfuCcEZptv4jzvFBMWM8Tyv0CgNxpO77gC7fX8soT3R7wtbCfcRN7n5vXQVS2OuSi2JDvNzJ36y+0ooh3kCA0JJtodYpU77H3g0pjYkpSAfZoA/G4XXewBQEUlzJcfbWShA2Weq7HjgF+QGwIzTsOzgaBkQzvy0in1RNtXrBQoCcG/SFM6qzyhj+1FtPDrOrm0SW/4AVHymUqX5UsnLyVNWlKuY7IRg8cmfR6oc3fBLpL7OHgb3JljnM684vg2ayDptufa9z7wJNWR2GvtpuNGLs5hwYzgCldvfqhCxRxToSEdsZ1r3Dew3hWbL9THqOu8AAKViTYRNQWC0JeFFbkwBF1t6JsJCiD4MnKE3+b9SOqwLgpWAT2J7c77SuBKyP4awBN2WzKLmuvf8Upqtt2FY7Hvnnz6D0whgWuPWYpjE0qf4UtgPefjLIUn244j8dI5YJZIANoRT5HSWyoXflBLAYT0xexQOWzsVwllG3JDEPOQV5AVJmkH+vW8JGdqU3L4k74rXOc5M3q5fnoA5mM3gZD3CCooXz2nDcZsSztnGo3oOsob6679UK19HYyLcVjhGIISgvM4RySnSrF5+ImeIA/YF4OpW9AKl11klIkYglQejOeDxaMtRhqkI7Bga7NyvUDcwr1VqdKu2dATAl8isNa6TRegx6ECxhvmgBAyW93IVrmTp24sJ1imIgSlGQihkjE/GZOhLoIPdkbP+wxi8ql+2rdIu2vC2RJVlTgWJXsVNBP2naOJpR1iy/6g7pR8aDgS3xtX4oaJM8J3uQ3LBI5xHueX/tMQ3fCoW4gCCEEgqtYQB6SD8jqJG6RhvCzUIm+0KNPk7JHEY1N1iWiareUkZXBKZLJI6maomuy1TE/O16xCtaBXFVnEG4AweZdSXUDzl4aqbVFNAa8F/CkYNpyFhQpoKOLLXQDA95dC0uC/u7gAEZ4pUCJqGYFL/TARHe/04DAErOHsVhbClZAs26Y6kOuCm1JeWMfSATQ0Cs/4gtgAYWoPVAUT5dB0AcjnQVywkuRPc0RL8N1JNJ3za+bggJ4ZCBZ/vSmlKHjUarO0z5+fyEeNgTF0/f8oOetD0jizlvMypHWP3aT3tamsJeZLTv8QhBS0ePzKrIqZOUj5shqcULYb6gcEiVcDZAcMmu+LhT78d2HQG2yjdYmmd17joVM60zGs/WII3FX7Ks1EE5DXUwLeVJs+wTyhWkjkLv97JXiTeMfwQWFk3JwV1JqXIuFKP26aI+rjoRP7UwAXhnhMGIFtIcSXuHzwQSmjsBwdpTmS36iMKRVzGwHilgZJZXaV+bU2WRboLNjRGjcclJWqLWZkWx8kwCA/mI9S08zY+6lI13cAIXokeE4WxVX50JV3n38/GtC5Ky1fl31XzqA+P1tJ1n7ykYeaBSSqBSbvjdnI150lIvGq3noBZNKEXBhHYKyBIwI8r1HgSdCdYIv4jo+2pVOPSKPx+bGuGPFTt2n4yP03mrj5JMymiLTm6ZFaJTa/jvB4znkQUYj6sDLFimqeYZFXTV6H/9WkmOR8UJsMUt/PtJNzMQvZ5R7BrKBqTKEt6IaT1aOWcRdUTscphfbUHJxFhZ00CHIeR20PlU4atflJIkdt4svXP9Q/daID7TPC3ncq8xGy9CpTnBP4QLJZuJb/8MwIbCyfDFc6EBz+23Fcohl72dp7cvUJ3xTwGtrw0saP/C38W9yAND8/8p/6qLhdxzbxtuukSPcYLmd+ddm23Nfzo7gGrvz/11HldPAHnLApDpgW+xw5QyBWY3N+b7T7oftEIHyl0OCyAc3RawQpQCoIqzbtP344WT1BiNJqEbwJTRunvmqQfpVXlAjD+MMckopjkawGVG5IoJwR2avrKS7yq1GurInWPQmiIkq2Xa4TsTVKbUymGbosxuWcPS6ktAtKkKvPhDFa99yw9gaBpkukuiqsSwwss35S1j/Jly3pm7PE0jolkjTGyrHH4TtiNrxta+YJ0uwqxenXhXyPWKFIf+jOL5T4Atd82FaxAW73C+Z9wEwVOdrKuyFymKMBzBewmLiXAKQp9pExi3oR1w+apwjVGP8KWa5YlD8vKB22rnMirX69tzFhhoKOYCPjAut6efkSN2W1/AR5VZ6L6p6VSoJuNOFrr1tDEy4Ve35jsy6zDxg43dgvuVQu6SEeEMviNOYLBkul7s9lX67yKjHJO3roA6Qtem2XyxMKa1NMIzV/HbISJNRTXce/CjRob7cqGT3V9h/inQL4iDwNoSAWohLVLWgj81V0U/mZcT5+OI5OElnWN1h9Pq7C9zP88Gc00DdO8vhG/SMChJ6lGcWeQxhFQo2bP3fmtQWrYjrv8RV6HoDtvN7VWEDsIU+GxVlZaABH5oQUS1di7qhlh5eURObgSYyl5Anac/OUuTPtwyQ6GxGN8gM8XLMtiocZ5jSEPgCISduAqfAPDlWcpGZf8spYYStJ201iRicWlxM6MIaqhF7Tl/7wJbIbT3/iYpSPH+KQxqhsl6DayMnzfNYWdkMzwMzG9AFkOZhw2v6kcIXfNhLY5tqsrGLllOg4RmdUKhYM+ePuGvSGGWza7wPRDiHSMTl7JoXpuYAmd14T0oGtwOTaEEhIFIDhCkTjPmdUCh9fA/Fdch+VOMPKj9m03oGyIPlBsPk0Nirh/Ug8jOWsIuCg9+EFh/cd+pUDBHkkQfG/Z31MX5SXol+oSWHBvohUOsgofZwAA3QAnRVEuRGXwaiAAfydgANhxpZPAz0spwQ9+/8YcRtSo/nU+WCPjREr6G3VyWUZ/DPrgxQ8nwIJBuhm9z3GLUzBIo1ztFvmqrCtDFmeKWwdRIl1SpIX+XfZi5UBimoPUdVG0rRwg+ecx8WL/tp7S+yygaNiX7XiDLaCeVlWstUr1DMEEkZlPBNxu++/dVitXgA50kv5LKfvxi1OHHew4wiJWILKvl4L0O9fAT7FihYnHRtcvSsQDdHcInb7LukQKOj3JFv1TePsi2odeX3Lohh5KMBgWtAOaI81zi1jzUO3w0aiR8yKn97zv6BYEvHvSOg7YYRxEnvAd9uvsIWK6uhDjoOLlXmXR8n5k4Xu7cJqMB0x7Khsbtz34GI1qr55NQMrAgbVB6QW7bqMXmKf3NQvV6HfTv6Qg7mHkHYd7fO2M3sMBREwp/4PRu5XvC3eRTNn/f3gWNJXfednkTiMGqeWeHoOoCxhJ7+bIwETUECjLtvOymPZQgZDc0tGwvYH1RJGIM6BIA+OdoJhOEe7OcxLLAep/W8HijOek4kis78Wb046+zzWH+qsydrkixPbxvpvZwVC1kPTo/B8ib6SXbhsVoQ171FZe7ZVeMsgvJUbc5Tx0ZKLu8q4DPoviUzTaM48n6tXNEADcCq1Xb37Ab7I+zn+NqDBQcaL8h0wmv7NBoDJtnSow8HKFPBGgYzUJDSo+zF0ua5Aa3QrDX7EyikG8Ei2wV9zWtosvcL16PZbAT/JJWdmQzgZZtJkuFx0k6fTpVO/nZSJsn3/3a2mRw6ahAt4DSIO1K2FTWilyMUH8zKdL3Ya2NWtwL6uZ5AeR7eQngroBc5b8DxwM7+eXehj8ljy17hRLaBGOLIFXA1TUa3EAbCJYSL46DGLxM2SH/Rv+/6tvg0k+IN1xxPraHQAF/h25TAR8d+rpZJD9pnGUAXh3S0xR9ZnDPjOio1qfsALpi7sYTvcT6tK6olRfjArjEa6HtcIgOoAg2VnE/k4ZqCclqtc9ougDf04Co8QM27BC/hPd/71vh8Rqu/LZU8E7DGPXTsJ8+e0E191Lh5G+zmIL0RQm6aWI2Wa2xlUqlbAWCVQOH0ffXtgHCG/yWcLzcA5aCyOsr99MvHHfBDP5JBL09/aqjIIEDJmzyq3F3xuxc4A+O8IB0A+rXfHVy/549VTmmHSKoFdCfXZS72Jnurku5Fse1k4vbzZ9AVqHlrS5uc7bt2SmQ24mbwv4lA2dZtfgIIsdGKEiBzFsFOq7uM5V8aMpsaUHchXz2FSSUf6Kb4hvE25+LchGSSEs94jg0P2S3gfmEX7GcTFKhMhK5MzClLh6+pss3bciUPPA7pqZH2Cjzp2fr2KDC/7K4R6jBN9/7XKlAxtpgFwGUp5rr/UiybHKjHm3Sqy/wav5yeRZXw3f+f6WLyII5AcO0RVFlQoHZRBnL8tBjpuuzT2mg19wvJQ40bZc7ysWXDKijqzayNPRdmBhYn2WfDzBOolsSWR9yTGaTh/XwgujjAHJwR4Pp+FaRZIM6A3LUzs64oLBMAI4IRjeMJEcLCN2kBmtFEn8+LJ3nv76cHN876YtdMnIHAjHv8fr2uG0hLaweGlQfBv4u5qD+bcuy5w8ixDEP8+z8dr5Ry68fCXeLazShGoIAkbglnmIC6CTBMHV67UwJxoWeRiqSM/CxACyBSGtSKk+4Ov4StYESZttY8ogKTus2B0/YMbUpZN/RcjvsU4eBi5mn6J9M48mVBrcyo+gAXspuefE06qMDS5VNqoY8AATeRGxJVv6WsA/afyvLO37tgnozx5Wr80XR7OKnTjLUFKYVYYyUG8LtnE/KcNrO9d8zIF/djUzp2K6dBwXGKX73qcd1DHFe6FdmD9XzejKHmPfEvkC+PRP6Eep9Djp+LEJZVyc0CO3+9qlIViNs74C1BtgffkVjdWFM1jbxxZtw7OcrUCtBJaFEa6jub6zvm5//oLFAcC4IZlL1w0ElyFnmZPJxsZ8KNUUyL+tHk0WZJy+hFOpMdAruy4UEuwVQjfE2uoKO21J4bM2Qj1F+nlPWL3C+Bv/qNJvbRYVEyz5HDXQGZxfQBUz4PxXHUOhMsqLZ3Hjb3lYs+78I4kVXWi+6CGdARCpEjXtSlaol5CACOdGY6CUqL0kNycYo4RK3/cnpzwchHlMG1JGSK4B7oeAvyeca2Av0/Y/ifsUjQaQ2n4GdnEjH3nn+r84IKVPA8utrk6RA61sDECQy0FOMW7HE/D+trH3JPENwMGzfv6Wp4IHKHTgTv9Yfwy5TEebOdHMukSwbhdktU86wzWLfvvmdlEGFva5bX9XO5lnkWNd9DZlHDXcMpaAsuNvh/E9JYPZP+KwMhPRWM/tF3njs3txQvq3g3pE/PYwnoEQw81T/CTwPEHCKtk/r1BAY3zfOnwkP4fyYy2DiDDSBoOOpYgekfTbDFrZ2KiFGTemEG3QfG2Bo8IyF3Aoz8zSOqHFdlqXd633i5cLEk3LHkk/G7Ov1A0arQJ+jtWBC5fvRK8Q063CM7FVGkg+ZQED5iHBnvAGNtNzTW8loBqxiONAZ+mk4J8Iz3yGstSN6KiIbTc/4yzFf6U2ZRAOcu3/AJoFOcNAnJ5iNWTCwNNVJXq2tbumjh+t4UF2T7Wht5iKye7gI0/cYOOycJp5+S7YKWXa3hE7mb18WPvq0q7w0E45u4NxyuyprcyYwY6tm+EaG7eXDh/LB1N8Pym5ii7a2thfymHmHlCaiiazOvFnSOrpffMuo6EkkQHSm8sv1HusFxSi5tQqrAjcLK1t1+hQeqJRHSc0L1MOrPEN55ueJh8c+Zy3P9PhEgGIWb3aQczOcGeCIGipMAxBe0ghkKu5fES3zkVTHkONG9LDCxmUkV1ZFHJ6C/p7HBTfA8xNShpRmqFx8dHbT4quEkok+aebDf85ktpGvOCRGPTc/Pvm7dTSDSiKFe1aCvrrrXoy4g7kkyvXHWMEiq16L0qmQd+8nqhUGd/LVLg9CJ+xjReLxOnXf3KggJFd5AbYhvUJ/zmpZvN9wD6W/S2LuLmnw4HyL3FKZ1X16XbKca/7dMDUi9PJXdPTTxoJzJGnEmUI/BJ/e1vnGVFencu+KD+YumBQQ2r/aQZnbXp22aALme5sexup3zqCQNsd8D+2E2+bPVq/WxxpwTDOUJNwvU3VzTu+q9yThey2CP4O6ji1KOSjl0fGmzxKrYjxHzoiy2um+cg+PWnNRcbnnuL90OjtzfEv4hvrvG6ZCRbKR91ObuFTeq1K0pECxqfyyd0gWS3G6g05pUv/dvA5DOnfL/pBJ8rIFs6wHhSEU9Xw2/N7xX7056oc4xEapECQgBYz8X6aayDvSGGh2oH33gbBkL1HA1jp87+gXa4a2nFcqrreCgCqgUKNvsRgtO6KjNJsC18xvC5Z0+IolcDtCoHJCnDc9rDAEjaXYLVJgCEgD/kjCk52thtyCxlsOSeNegDP0yYa7Ld7OH9aMr0P8c+pI7BqzeOfMLPyenWHw2QihcbyAds9WO0Qjl1tsJ4wp7Dgo7p3+PEd6Zuku6BKuPjin9/nRRXDMVPr9k+3vEA11WlRtdkem4TY8wJ787uSIaDO04mjt+ezoDm4W9wU1OQfj8c9T2v/aadf898mLBhFORjSK8hbK4KU3rDGicUpj9TwWyftYKGcdQ3Fss1RAYLTYs8Jv3CNtnJMl8HV5Mu/l43Ulb3djdhtRXKLaqr7a2XE0X309AYJAN/BLc9xzRzVOEqyrGeqYpBrFbniGCQoNiK1F01JENKsUKBBIWl0pBcfevzKXoGwhXtv+E2wP/Q7hBgRp+/8UsjlrY8e5Q6SzDHH+GY0UUaMbxc438WDprqn3Cl0cdZb3pfectV12Qsw7fJ3A6+8M04sv8YxH/hQVkqeb3EJILEjaFrirhw8AodCLSg39WEq0w3v3uEPYrmEY7/u3OKf54JYawoQs0xeMyn7IBs1NVM+6dvMfH6DQsaZ6SkXq7jzbZvfJXZ4Tf4si3mOOayiYiudxJEMPSovEkCCutFaGTvznG64TxsL4eYI3uWmcwz7GK1Weq7iNgCKY7G/geuGASmAB+Nj3vFBGVnUtzPUpx4Ymwavp2o1xMJxMJONHDttxT48tD4yi75RFsY7TAvfOLZyj8RYL1hcxH206HoLMK3wovycR0Rk7N/+1VD4//bgOiSNQUaC/NUuFgXg8MNL7FvBecPXz8vyaqbXw2qX2FQ0hbYzeK9QklUgKU62L5ksTl97OfiJcV/v9cHPCKzpTgs3FSMIadMv+K79A+c6qinkRYSscvX9fG5GIYYdvZD1ZAZJVx4mXhVr6WEMsGRUiEJ0/G9UK3A4ym4KFLX7TlAp1ypHTnafvkVchoBHIExm+SkAiDoyCNsZ+tYs/oo2c5Jdq5tVL2UYrB6XkB8hKK0z7xfoKkdTm57zJcoAFj/OAd1nN/Y/98fwiQh3RfPuSoN7X2IBPKypOBK2ZX21Y00lGKGGaUNYcZhTq8gw/fBxl4adl8BqaD5kyiE6ig6JIjvr6gJcpH2ijIS7XwJWIY9zMxjfc88zYOlaPnnaitQAM3WmZQGMIpjblYRqp3l1mXmUglwPMGgeP5gIfp7zb9SExNMYypHEuQDlxiCtZUT0sYkWDAANDgzUQgVSonaFcK+1SZPDv0u/WX86Cea6xzr4Cmort0CC3vBrDT0hyoPnbNqfZp+LHAQC3cGN8v3hR35/Knf+QQOGOWDtcWYKtmY2rxRDUEOuokei15ylzf/7GPTJ/JQvadTyIOEVAF2R+Rxd4yCsLJ62eI2URDbMVB7y10E7JN8l+/HsYzSpw+NZB4yt5WDDkh+RjOpdMUveyJmeyv94eI790Vx5chi2/hplInishnfrhn9qyPEWLYKknbVQCC3VFHVhqJAXI7JZ3jZQHCvQ4ot4prpq5iARiiZvukLuS7ccqgy13aU/WRVHGsHaTaSJMvCExIgBND7YBijYT9TeitbpvT3zMV7vF3EJpzfLmPByhk0pTACELz7YTshpHIlAdfvwCFUARjnkbSskMPjlsQN4PtEZ1floHcKaLOmfLwkLFKugTyadN8DIswP+IYljZyyjMrRyuYhMqVaz0vZuwUxWeAryxex1ConqLTKgehp0MA8oAhBRKWM9BNSSR/wOcACinCUU9myTueIL7u5lWvEJssL6g6QP6woFA8lI5KP4Aq9l/6S+CpIVhpbu4wWE0sv8Kpcs6GfUfPKwj5aEXeFdQCyFZFzpPVIhJwpqimn0xHwsdm/MslPiTK/LN1X++5C3NgVK590MiJ7ASwduxovyADzpKSIdN4MDaYS7QUpveJvQIXKdaTjuds/mIarxCAi+WSsY5Ajs7Mql499MFvPZN7ds54pf9x+Odm7BnobEreIigDSvibt70i0BC5GX5hwN0KwMFS5rnPySbQKrK6SFi7kysf+xrcvYvY38wYGUHgsf3FghznxC+mKP6DPqbud0E4ZlcKo+69TB3QlH9kaMVcvUwD5oh1oxoNzvy/f/64BDGkxdElPkIk1+IIYkP661JnW5uO8Z0QNUonn82Eai5/PSg/tAUem1Gbdyrj/v7Cl898M5wkkv1IJG908Z1kx7SbHn8MwjIi+sU1GKcABw+ffxH/ri6+GqqBzpiV/peKd8B4mNktp0ymsAzp++wSnb+/v1E6oQXUJBKLTiSV9087tnitmaJlelPgnrBQ4WhBcnXfCYUgaRsGCs9GU2mhGQwKFSiWAF6t9KMk9vToUnc0ezGkbs9UkL0BDVwyeAkC+yDPIWJzJd6XU7rSQ5YSyEz7rJJBa/P2MWH/PROvvF+9VxMrhCSiSu8eYUGD/UQ+lwZMCnpSZYyCom9tN9e5j9A6ji+8xb6H/fZEIOkFTRIaW0NA3qkIzaKIlKlXeeu34yM8VdAzaS0wAV7Gk0GdmeQds1Be2WnZT55RrOBzX6ReI6E7V8F44/NWaSRZGFJ+aA0C7+iRskKc21EtXkuxlWE2GUMDhDP8AUCqqaRl45H0/MCzwuQtMufL5vYiFk79vnWO9mXC8NRBjSAiZ2ovFM+bYP6dQADu84ur/hhNMHibn8+IzHrU0MWw917ykGPD1fsAPY/HwZAJCexKNa+BIu8baTX2LvkysRjoPNlzTkiMyiuJvpUPMJQYBvXDOfoJPWj3SimMEeZGbZg/odTfm4P/csfzQFmp0xTl3onII1kBwTU4mndQMw5HVyld3d1epVoNyrhPX7LMbTZhDLyUAy21LR+vISqM+GjsQwNIsWwMcgOcOZWnkMerFV5Rw0EiM52vxsFbjZ+3zpRFH89dmcV6dQz9YP+R2vwn/yFQRFZ/N9Qej/ynDMIP8hoEcBoGFUFwsmHWzb64VtL9MRxAfqVL9LeCmFAsY6mnJsuofRSSBzGX5rRfdFK2pwm1aHOdGq6XdnBcyreLge703xaAHhHM41c1M1Ut3azwgf0AdTtPbQYCOUCyb9lWgpS0krCBx1ojdcetAFLQMkfIve/kgB9FrihXn1nPyzGTSdecE8lqk2N4aix5vPkkJEnpRkAew9zm2NVF3jSsKlSB7qN48F2WQro0eFX8gzR4orpONrjpL+xv0bEU2RcjIQhbbTk7GL3lKHlcvhdxD4acptQS6plda5poxwt7zuQJaDoBRfC15L8Rx73a8Jg3xGP0JPrJqAWpNwa6pKqPgagoijloOiOdFft+1Mo5lPQGGBra+lqAuMiDkwVgH4VZuFNgDnA34A3LLwunS4KgQuc5KsXs9tlb78GFhrGau9djo4FoIZ0+O0AAAKYB8lIVFt26rlWnYpGf2ezW1bvB8Vy+UFAiAY6IvoLuIIeRUTcOpH3DYi+zP4IkIL2xt7J+Z4+uxFUfrusarB6BX9K9Rz2MKXwG7023QOI5scnVTW8GsEATx+eQUf70bcbEOd9iU+TOesCJV+XlPWeDyJi+h1pLIfIOfk2heV9rPuxgKwRls1cz2pr/e5ZBhyrgQWBMuxF4mLR0xAO6ZrPZHwEdGwraa7MPgltxqF+KVdb+FTunkHxUnisbCS+QbHVLTwukwhAG7JqMYQocEveiDRkDSvMzsOmTb/xro/K3lXiL/9IsqyAC9yv3ecpnH2ei86tXjyDkboyGR/Dvy/iy7lOj4kS7MmlwWIcMkw8zdy1rEDCyJEm79X5VIsVdPTH64g5/LvVsmPKP87Zbq4kFbpg0yXhldOvp/TMlKJEDAmQ1fOO0mbcjXW5g1tH3xJCNQ9TvNTlGZ/W+4AuAkoiMgf3gaoWb6/cnzSVrxCRUWxRnOV0brrW/IYnexH8p0UAbHheAAWU3gaTkS9CaNNKmdjbjsKAvGlmhxA5NkXcrC9Z+Mv/36IOvEq+ARMieqTL1UE3Q/oAgfggkmyyOLrqCHYftYYqGialQJ6NkDxviOewiFiei/uARchDs1xFGkk39nUME0ahswUfWkVHkoaq3A6FvCFk7KNVU91NObqJCt010Sz/aGiVDJTZMmqeEnL0xkQJOocLnnq12ScS4fTerPj3J+5jEx100ZPaHAEV2P8nFmNGwabVCp5zR7Gbfx8VeJ3NYls7ITqAWrCQRDF+ZurZu9I85Rz3bqUgTBKa5AF0gmj+o09DGjSkSS5nGpEgREJuMpbRxBHQmTN4FABzefCKPFokieqk6KZ7zJb7mTcmJ50ej4YhiqqUGwo0rs+zOEe5LXAHDwXgfG/I922xpEch+iMqzzU/bZRfmtir+spRyGAR/ZWaTxFAg8X1SuQzLrxoclNJWxLYEYtHaJ5mBz3XVRoR7agOsnQUsTA+0Qb57CDKJkRsQhMbyTmGTfyD48xE7IVnt0GMCIRQFTEE8/aMamA9W0nU1ZMHc5v8oRG8QAhcLuXCpTQh0KUw13GY+Uje95QIvrXinzt2y/3f1uSOQ7pSdH+sflrglq8iTrj1jkb9RMEWccLmLABFi0XFwMoKWOdd8Me2bcrrE4zCN8GMyJgtjE2l8hOxemQLccSb+L3mgQ0KcCW8Kw00QYWS9qa4g8H821/spKZC6Xs+0PhXh0NPof7NhlnjtsSJt7CZpQwedJwIOOz97yPDHWRwerhSiyGhGMNAEQj4bexnEsbFoZZC8G0SRNbaF+B7ugbZIPc3uhikdTBGex4AC7rh+XFyEpncZX07fmf68fc6PqOoM7JNkVBTMmHXh3HHqh8tNIV0VI4+AMQkzTB3q2y6wiNK/L9hXqOmGopqnD/QCOI1MVe4c0mXpDxKdkKKHn29uNI292gjEiQrdqkkwG/9sNe9kIRb/vX9jazf3oRq3UoRQFGDCRn2rjBpED5KNfD6vQLnd5UcZgpcDEFMqm54FyqfLUKxma4ETrO2YaHXZOhcHFwxNW8EHihAQoOLhJOcypGkpNRKuv/lMEmLHBjqSJzJPQZ9McEUblU0onEOcjSn4JocJLFn6BIob99wCvu9iytLmFEA0opyk7ZCemaa43zDWp0gvwiCng851vbb8rfpPDMgJnSFp1nPH3sjYADLrG5Y2Qjbd1JnBFw5gkGrR/RRWi8Op0YC5JmlQ7MhsYjAALSQMH9pLOu8GL+zwsPyZ90cTC6ZsS8JLu0ElLKGuRzFPN5UpR/b8tcUqoCBXcYBkXp5Wr9jTN+uYaXMD0U3+k5CQBxfoO76aSoEY0Sz/NasfaNQB7KMqxazAXhaB1YKMfB8QbCIJKH4i8BUfBGi/WmHz6WjWXxPo0RXTWdBAOcoLbPNmIFdl9TcoUptKHQJtYq1H0eGFAulaoHShW66lNcATlvBlzxdAXk2JN8n7e9TzQc9odFV2DwZt424ig2qC+f1D2E0oOZu7hejST31Yr3A5LzE75JfGV3CLojv25nVI66PtM8IPWUbk1WdYU/Cf5P9CCwMNRPnkAXB0Sf+fq2Jr3BUvXPTr1ducYdDpZb3yDGR2loh69DcR39391VCsfbDH30PSjdOap4H56gPxTfPDmNg7/z3Be+OLiZfZUmiVo2nERqrA8BjZtQUbsCCgDX8+uX5p4ahjKvCxXLMsuZTqlChqzv99Qc0SM87lWHj3ZS9KCRfR/VZ0BVDnBFSBxAEzO2tEo3Q0T7OgB+QypK+XXok9P7r3hBUoHhM4lRVrishChb1mi1Mar49H4kC0jqqZ3P+XDCrrIk03HtDdbLxO0QRKjzdzBoUAkVflUdfiW+5EUYK8SfTPYyOjpQz81KXMdvt3bEoFHdIIUJfrSbGedJGX+i4B9JFtnGDNQRZHT/gf9fJxrXFSr5+ms5LoNC3Nb8R54+hVALjpnxwIYtiV/FpavDVPTajBTfxk16cJeY4ubGB2KMt9FW3BLGnuayP9quwrlKF3dgOO63MijNACYv89jCNyehRf/M7k3Re+mfOdSkS1aQ+MmqER5s49QftuBH8eL3Ve/WmB4lrczOvkq120BCavoqaHfgxd/LE/1lQJ6jlOuBefobhtxUd8poYf4ts1bGHYgfbUPgohd6sc6kMYcWGHU5fWaBWirHuDhOxADxyuwsqY/igsJkF6bCnDa/AOmTPBaCGW5pw0d4fJPSYlYiRKoqEGK8ztIDTSsjoky7+JAHmtig0TV/pfK/BuVnCarecSDzQKu9qcAgehOezCVF7MOwQ8O/6wt98GWryrhQBYQ5pl+mA1FtUldWx/xQbCrUJl8oxiMf4NaBC7xQM8tmJMkipM09kG3onuBCV7eaRFO4UwyuIn07IY6gqnlPDH6qBqyBDpS3o02QmldWttsg4I3lABA7RGB3j9x2Gu0Rd5uGmdq5bTBoTS8KDQpUqwcC5cjhKjxSOo/e4S5wTdHaN+3dBjfRLSPGw+nXr7INXwdngLmJiba9VCwidOdAKYKRtV/LdZwD7/tD6qkoA9rIs/68aQwEk/TxA3IiXbmBbcTQUcJUpcvw05/59Na+3kHvQTF+2E2IgEm4p35CZKOvvY8DuXE1jwnu7lyJbRb5qwT2sZDXyparmbtu1RjWPx+iT+tt+1RovlNRVJHNp1o3hHmVSM73MkZvUtfdbvUbExMkiZ4DhzsvhkIqLe8WB2FcAojN7sG7mEHnUIQyYk6CzdN7EIsvZ5jofsUqtDdG1hLkZcQTgKRtGBF+fGkAJuW3xv4w8ScGqj8kXEDt2MMzAABAZBBO4Vi+rIBQKPGl6kYQbvhXiYixKqSKADx8k3sB9eEqyUVa+ELJWEgQVcSV5wbiBVhDu3IEs/DXqkqlO6xbHxBWpgsUw8gUeNbrntP4VJHUKQd0oEFqhoNwLA36P8Nr16kDgvt2KFIgzOL2O8eVTJWqFRKpin45EdNpMvhE7pC99e4VSkUiJA4lB/9zt2nE7cqqYS9hd5w+3xRNDP+Wrm6Ghza1jfWT9Me+623iXCrjO4+cZlWIkZ/WCMaACm3/O5Q1AJjqVx+MVNZITmZT07pZCYON4pcacl2obP/ccN10JnFUKLWqI1KahbzObMOa2EK/wEOhBK0UcdMX/xebsi5Tl0UR+6iGc9/o/+cp/ZUlUWOPrzDBbARpB/G66yfDZe5CXxN52OjuM0yHKcQXuelXldLyLdJ4jZTPFac9f3SqeKl4G6F3H/JjnOEpjoYGTNW0oCOK85wsj4pQkcDKMGmX+jGYo09uUOpIb/qdqX/3s9xSz1tmpsmoBJLojxEWDdOebVy8QWH8v5YnkJIsfW2xCpEekTSBR8aC5NGNfIV5vcANh+lGdkRqVdB3hU8Twnc27vN4G0rb0gSxmo51KNpTN76KqH4Jmcy9mgYYDXATrLkJQJlk6F+FzcpiCkvSRuj1r/BRsjd7X1uJZu3AN13Q4hytoiNwTyS1c3oMzWYlOstQSAP5stY95CCHlKK+enl1ez3G0FckDilDXA3cfUby6rAKEXxQ+610ZurGLsZ0y/Fp0mnoyoKtMS3wlU0xoNNW8XcklbiBYQLv95KKGzbncRa006Y7eld3WONrtojxWDteZ6eCB147KmW9er66mpb57OgXf8uz/sRzfOQrOh6GU+rkrNwyfdB08fLry7a97PEtIfG7+Xx1vJfvKNwZsYZBTmeeqII8d4TBRAfqXH8tmngdJZ0CE0Q3mXulXwB++VJIQOyH7F7id/YTLRk9AiUM7ZpiYlwfwqHWXhjIAufmnO6FmBQ+zp1BPyoPzTUkBd09bD7U1XmGIMQvBclDseTaQrLNGsUnXB0XdIgVbaY7D+5GpVNqtJuW7sVcQsAczXcIRAX7rOBLz4CacSJXyuBcsWagtgrct2vlcgN5nNJ35LS9XuX1G6ZFy3t97newUaVYtOEqWQbmW+5tiKSnqyIVWeWgg6nTvZ9KfrwdQGNUIuQIPXu/glfu81b8atgQgC4letDpaKqExJ7J9g3yvzgvB9CQMzyljdf2S7BHfhndyswtQQbW9PiVw1UfPwP8a/9cPHNVcD+X/CynUBVYa57gqaXnEiJ575OnqncUdmy1x0UgMiG+K0738hKvCQFXiwwcQ/J/L9fniwg1NeSYfamkRwqgs8uDr+darYZmUnbTG65JYDIGA3zG94lyTnSpca2yjV8wCkRP1ng9lFCS7pC5Ru+sI86DBq0ngfvfzGocXSz0BkBjahSAMIRy7txlGT2NUYXaAmS4U/P+GYJojq5tWRHSodbtLoreSxtahcrKVySq9wcjwPcBRuQKWBNYp+BcuOFlk6bHpkroiCddH0SoyJppVMW1Pk/Y3tc3fQdkwnTLsMgpRAxFBp4DA/4v8wLv6U8JGpWmMFZgDxlvaqgdLDfonqV3GTPzv6qG/1zrF3VXgfdx+jsZqOogJKFZSqTgpthujEZOFv0GDPy0kNbCsiMfhgemxcsq+4PT+CMZhZqf2O7Rdqe+B7bZUc/6PIvdSahe2k8/sLljrs8/gijPlRTHCgCwdz1j2uYRPB1LD/i3U7/XsisGylzRe+YwoPBFhB/+FpDD5VTRygJa3pmNtQ2QKhYnGUv4HKSCEGNli3BRxQiHy8m1e9jdJYiaWIJ7FOloyfvRteo+L85ifab+CE43B+fstwAzb/jDlslv3ACKjMNfB/KydFc+NFKTGHwd5CUvVg/y4KH9m0gpEbBX3ZmUSn4XcS2SP+SGyiglirMAk2Zjgc9gbwtfMTfCvtN6a+PpWPCQIrC6tmPqvui2k54l6od1P8ENC1Ij/PBzqBTQ9GhNlcsflRdz15Q+Aj8p3MDhMFyv7l9GQ3yJMaRWWV7J/h750Bsn0iQUHCA+eIufC8D+i47bYO+9ZcVBS3Oij3J7sBQQuwF/ByzjQenEOUkERmA0VcgtYteb4qeD5EiFYXWIN1DegJxiMUtyfRhTuovcsbHWenukPST9kU7Ce6mh9IUaH642g1g5A2P6aYR5aml1occRaxIdFnakSBoZVYLjfKZMjbQ2sgMJEB4Y9RwsMF4hGyKji2GRAm/f4OeBXtTjtVSLgrr44v/lTPy/3XhzD+MqmHeyd+lCNk9ZXTsMb9McJd3rDZXeQyip0UMwfZ1BSqTfGMWoBzK6ehIZo8IBiWhFX793tbjaILi05ABzIPqEqgLtQ8aNPth0uC0hZ54w8ijwS9Rpsqwr/BHUmO6ObBBtBzo4i/n/SzVTuvkn3K88ljuShZxELmfUZSegIfJw7xMDDCYcIXnHhL9fPjIuLNe7tOADTgcE6nYJ8/yN91/aPIv4BlCv1MIukupscLIE+WXZ6h//qPzImlG0H6uaqkBV4H706xHzY+2CY54PG3VqdDdXEkcBSWTYnbU6EFsUso41gHc6sdwqoV8HhWLM7tyKGv6iWKnvQz7nVlddgYKedubhDtIAE+FK9q2Tovs1k+4vM2tCROijHcLsHU8g0IbL9nvVpnsi//RdLchNuHu9JvQGztr2lgCPxw3Ewe1jaPLnvhl/STRAyOYG6bZotW7729DDv48waBpZl6PmhcxYi4YgAiN3lj7t3iErFcVV5wsy6Ik/ngihUEd5zbGJpMnDX7OoTUyWTrrwilUiH25WPRVBObuEcEycl9R7eSEkc4mMbk8EQZKF6mxJErLfXJwfOCqCTHDKrjSJ3Odz/YA7kacTp19eoCO42ziRnZgBTkkj3dHK/7jY9da33dcdqlsZqFCCE2/dfb/mp+KtvdxtZASRWEPuCk6R0BJ1m4moDn7PMPuhKUhXDJA4Mx/6bQ7kTvFnBEz+dcVDClVWHUOJpIWOm2sDlQUMwMutwWzhccz8V/2vya2vdY3gTW68wMvbZhAdALHpgEXqNYOzO6Bq1R+IbvNKXGoVkSfjbH9/AcSCoE8iJm4UVYebUQCyF8btlBo/C7tWjj8uPzaA/ePLShe9qG2zDrzd/zKcLag5GrKxsoJuAm9zHiXUPncTLHYLeplwWGpzkpOFfZ1X+lul8ruxTsWqR0DnS+Uf8gHqdts5SevhciuMoX4lJH1BJtsf081AdYbEjPx4fqdwk+e8s26hdeiSnU8c2HXYYsTZHEuKb7RWm5/BnRJhedvZMHMPIaKi4E9nJpNep6N+5mwbnwc6Ou+TF8h3bwWPu//wKf1GQEXWrYmZlA18CK9s3SlyJXfLKtih/JAMGofF5LlPrzID15dSADDOBggpKErDccIMjp8s/1aC6bB4E6P+JX4Dab9ZN9n8H1ps2qDzKpCbxerpWdl3BNU9wUVZos4b5K7ElSpCcQtmwzdskKn+0msjzuA1hLic0ENukHlU6ydWLLtUI2Evf1G2zx8WI8KyE7LOZR9GC5ptf6p713LB/t1Jqsiiu1hlDf/R52GQQk2HpksdpzLaJxvNsb4AErJ39NUlCMqszZMZLK6+++DWjd/spkbDgSPc6CVtLJ9VhFSvrcUo+dTWbdbFRPGMLkFNs6C973HeAaB831DGryEWPUOCEJHVrP/XOF6iiQGG9WBmPbzkJhSKeOR7WG9dxtxXpTQZrnx46UXKO+77VFaeb0+e5S6OyL6D6WYpZvKnBahNlZspPofPsgJkEVS0mX7H+JlTpMt89emKepJVJ/3cfHA/9g8TKb1ybj543Car16NWvrgsCCJ+EW/YmFXeB1/+oS1zIGUpSHZY4bEWewDEmi8yF/84uKK75Av7az+A7070XnK3cQ+hxhFszq3Xqu1SlzNJb+urToCnGY6i1vxfOwnzzrVpIdGFhjSCa5iak4nWmS/ndjvYAGwBP7hwBuyXKK/oyC3MmOLblTxxQEt595TwP+Gvu4nP+sqReW3+J85LPAEdl9P7pORv9s0sqhy2/raWxHy5ZbrVJLYazIavNcmhYv7jKx/V/yfVvycihRmFeBbrnP1FHXEd2wNRgD1fAfQotNtiWwwXKBVXTW5BT1RivTnwJxVH5wzMqL9f4JhIkgsn6RW+SZLK/q7WBVmGCoZYIKgCjoNa/OPZmL9f4ByfFYXLQJmVgxJRgt7kixCIHL7z3NO292urD7HWWrSTwFYlRx2z39lHUvoRkbu0EX50PMgHy7g8e4GQprdZUWvz2UjkF/zvXCDFfO2S/lLP+woZM1RvEPlsA6+gzUVkvRpX9Vv585aFWsIq91YuX2kHMtNUYzXVaRpXzn4xYUsxwCdCrdDsAo+N+2gLtPvdqjFgRqwYgzrSqyyTV7kZUK9DZMoeVzSBNa9OWLKe9yXL2IOXO9cFN9zV1dfgys/RfNqdUARkLtbXZhUlmiHfCA4UuQujgnCECpNZGFnh7fnV3XNfgMtlK2hmHgH14zKDHE33g3nxDtjxvWI89hXXg4tsWpVYc3DATRK+xVNL9JLcl2C2Mgc7BuliTbFIqJkKqJAhopgAwLp0HG3xE6u+SJeHsaUpZCaeES9U7JwyXJBtUgTRxJdckIFENKLD+872yUXh6YKQcLH415k7dal02fwTQ+flWKDWgjVheJCSI2fFLaohgWX0f1DbSoj8UFZ3AmS9/s5h0hPVG90mA5YCLxTKuPWLed+tJ+6Cprkia43B+QCn2745jCaZ3m1lDHzPfm4lgFLx9X+//Ajc/4MG2CeSHl34yqIbwnC6Kz1fRBMsbww6ufxv3C13ODCi7Cqpzf7rGJpUDflRZ3D7S74MmctoEuqmpe5dgBqPvZRwp3jfLPEA5+oZqK2l0gNkJEIqEmhW42zXSSiEeoJEvJj+NTbqwgs7OfBwq0kC5blh7tiVVyZdJFXFEHYExcHm3Yng6QToJ8z6qR1n3LbIVd2uQzP2FEcpFlaAr8XY4We8GehPCk5fMWTG1gVR1PRaJhqNrnfsswDcmaOLjz6H+m+xZSK26SHpNKpe+fQGBxx3NSTxdGjGLpsxVRC1Kw/oJQPpAimgXwM3neG3gUfglwL8z1jybjWwBhTawqDQAA+e/Y6LcOhBizD0OmhIszbylVn9SqpXgMKI/yAm058r1twhOArpRBnQIQG3BTcsEH57k/UIKMSW2qXv/pMjzqLn8afI8UMEtVO3DDlLr0TJ9nvxaqrA9g5Bhjc3ypv2smhm0GxnA9dLQ4jCrCjk4X+Qp7UWbtx3DUOPVDmXqV7zGd1hVAL26fDcLiaTjTiiAJJmAXTZAgPpdS7ROqiRNS2pymEzD8E7dYRlhnt3nU57DWkb74QmsTqASOdzvuVjjGzEqmWykzodB3OkGYtJ+Qi/mUoeVjsXDj4U7f9cpmnvoGvrfAjRL+kkA3FNy2+8sdf1uLZi2nTe1OAkyokU7aApWXwbEcSYhjxGmaqkk4F02hK11nDXaoc1ZJR/TKL3lQR/uRcL01W3IierUiu/cXuIHXIxgwtmOb7hkQjAf6Jil54zcTvdQOPNJkhH3O03k79k1n21aK6mumyeZLmZgDDOTehEOe23+3Nn8OesjltCjmznz5LL+VH0v7iNKDOz8n5IrzH7hWrA2OOkGmfBY9RWf9OQLvtnoSyl7a9qD580da3AkJQyvEBLjTo3OExo4bbmbeejAcQqdr4UzVVh2ttqbHwd1H/nEYKuXjBHM2IE8+9AmH6dhW78XU4YIOgonr7zyiiImQsFRIf8cLhf2cUIHpFRmB18kNTfL5zaD/qGrQ1s/mQMVHQ5QqkJP2kfLm7/4YrCJAY2CugSKOfrL7HrP0ZvulrrYQFAOz0/1GRmBpRNYwMszHNrcZp80BMS7T6ghGC9t+LdlD6WJSMzifpHpWFgqLzE8NTvH0PChUC9RaARv2eTtmLJc7aH3Dtl8kAskFs19AFFvRDgWhEN6TJFQLsVJHvIwt7k/s3POPZn6Js+H+P+HGwkyEEJcgFKEIYEi/kkBrurGAC9VVSwxpSLPsHhkkMitOvNSJOfa5vz44C5GBBYfKMdtdsK0avjsx8+f+Ni21sXK009xmmnhiP1EVcsY1h3F/kMqnDr0v+vcYjTFy9YQbSmJwmZmKjHhDRK2sNAi4jDnORv/Mj8M+J/pPygpfxZ726Sm2gDPmXjybUIOGUAyoO94ebHhIm5EC0XyU78HYsTND1/MlWs1YqEK17JjYhjscoCFlXGblaVVjso2SnJmE63HESWxtoaR3/a0SMoXPlg9yxjVLdCb0Gs/BZT4BocRn1Pb7VY8DFQCx83myO+AmJCgaRPl+TmgL1vAH52SiXoIhwfr0gyZlx+h4OlGVV8v9FqAxLUbHgC29DKMOhNOXInKeLmVDj/3CtkZVFWSl32vwN7Yuqs5B8TYKYkd6j5jI8EBVv9Avq5VnJaZTVU5yWIW78krbBwTIiax3IgE/WSfPYFy/3sMtWteZkkZs3ZagZubCWc1sZy0Kr01kaB8QPVTC5G6QHxaLsun/FmZHfRo9R+oNtck19Io3TNah+eJQU928qt5hW5mjfJjxqq2GdveLxqZ/kSfK1nwQjl39EdAkCA1APkEh9FhliKrN7UzZ7lUTgPTYGZjCF4tZUjEcp51E90CL59rtUq9uF+TFevKZadJJmiaWwgvAsjiY97EslVzv0wDwDd7OFRU/W+G2yTLbsnMsxKShM4KjpD/LILNgt1BCjTNA0+hzcloaEt/AwdKpk54KpoJwJLSWJuKObnbATYdS6wqMh/9/319t5jurz8FMghCK/rE/d0hlXGAsAlg6VSVKxskBk8KXaSajUpU8qsPkyjgzhB/MUE2CpYreq8GacBtw41iMMc04+3BgcgCRIthxuHlJUxWMGpPhT/6gZ77Wgdko6bq0z4t1Xrl+/KW0wRcslliScbum+obSOoTKINDhgZPzltijhFQA1LY5XJhKLadSAR7ly/8o39rCG+/e0Kc0b3noiu+CBkEAUB3tuqpNfwHrjpxr0tULHFiX9xAV7N7ClohsQ+tfsZOe/rZtoujtAOUiFWVkzcncAUAamIbKKU0JacKmHVxb7UACjU1t1N2yZXbvbR9+0RNGgHH+7+rZVBvdFZj+lsvFnOzbQehgJ6Alne5XRFYdIzwEq6MLFQe12DwrCzCkJn+PrcQUrOMhp/JXoWtMsYO3eBJUZYSkcFg4QeL6YDNPR9kKTme46InM8sKHhRqaqDNzRWeXzcSfCUlFE59H9dB5aDiNqEPg9R68bxTcnN/WkoWofyg5MungPkR1wSudZJrTBmnwImzM7nhVjG9NXzqN/YSWKnC41tLvqRXWVWAJmwClgZ5w/7jFEHvJvD3iMWiLi03cV/gCPbdhn5xcis0WGj3PtNYU3T/Du2Ec6ckhED6ZV7+2RmxQ4qV5k0nlOTcP0wc3hfIu67mzMeRL0QID7a3u07nIxQwtna2VS3zjSnjFl7JDBa9YMPN/t57wHHD/OWbp//5+m+lrF4zfufGNp30yQRVck00EMyLiCe4lGr8lEz+NnPPv9kCDSN1NiF2u6namTOfIXH/T8h9+obNH3h0AQa3mq4ksE6vNbGNOrzVtma5lFnKO6J20rJE4fw8oPyMd94rD3FZPHU80zFKM9bZkC64jShsS7044R8tPiYxwL7+2M50Vp5v8kXSJ6u1DUy2LySOsRIBIc7CKtntsk6SeqJwlNVYJjoSOBQ8hk94Plc0jgsCEcFu5yAA9r5lOO1xX7Kezp2JXIDMGct8Fo7TnOchSUU160E2NSMoVgGgq91UosC6Ji2Hp2qUQzl9s/O2365wapxPfefMVERDP4NZInPa1xl0unxWnXc6hVN0QUoaxRltM08GxKPt96qaIzz7/RubzPZqf8oUsYeOBCs83Vs1iUXCH6pcvxhQI4WLg+h884LBmgoEG4Ef1abYpozZZbRaOzxJ0/2WgXrXhqurAy9Q4jUPOQnzR+J4sazjtxY5FPOONwnrIziK/OvCoflsiCe7eAWgI4mHOe6hGIYfTJW9/em28hsoXNsnLL/37UOLRXww9+uBbVTjuHPb1fbk3MLsk+ZP95GKYwOUNKwKctRpejblcWMQy1R12uixvrOdtjhe5koGTKSTsFpiJYuZ+g+04slnHOY9eVriks5wKZt8cZZtSPwP62WgMXHPjMjpOzoICamuFRzjq4URatXngL67G1cZqkxLc/aKIaPgCoYVo540jBtpPXqnQHPYWnYDMGlyGZYjdJmf1K8OLqIzYE1IXQY+tszBxX0Q60sQMaV1DcZHOSHJmcXyl6WZaKTxwnEn87AzObCrW0kQ4BP98DcrEsGtnSf+N3adYIey1uHCbduZXzpe7qC+bLbeFtGtI1wKSeZLZ+Gowrd9DxPBELOfEE5bT3g4IbnabL7a0QKtKpCCwgi0zac1aEjJAAb/uavfw7WJgNPU/fvGy9GtAZ8nMncoTot443nS05bch6bpu+2jlLCWGCsiK7PpNccGoKJiCMeqR/Khrxw37jfRvC8bXKQqkCyIZRXwnrbdgofqSb3lznfTuokPzj+MPXwOkoIloUtz8b3zfl8va8qjLIQZ+QM1mVL244ya3am9FIOt0lDbHPgMbiLxSfj9XC+LJPV0gUGupDnXVxUBVWieV34BmNlAVIUBA+BMK6Db3fc9PdFNJWsrXBgSP9MjTxFEmEg2NWt3GBKLo2IqzqJSagiEzFsYdaCi+HBLIwhnjMK7XUexHeJvCBQcvPC/ZN5kDTfGnD0iXxwiXVCngzVyVFudvCYtHycWR5p2n4EsV43wHC9D8gIHFMNltkzcjEIGbKTHl3OhRjKtquqcinovicNrV3/PhJ4SiKBF16wef+BCDHOiwF/qrU/SxlcOKBqEJokfJbEjrujtD7vZepILSnAq4334Tp2RPCqOZFmwQ6s++wLWaPQVokepCRvYDnME5HZUFN+1UiL2oDVoAWRXV1EGmsQ36z4dzJuQjTaBwm0r/eNEXzEe7RKSZLx3kVl57TN370I9RzJo+iWtDEBWil3cadwJ4oEXfZzExO0gfcjkYjHC7MWsNU2YDX7U5okIzxbY8M1+jY4711D48QDf+UeAE2pwkfqZ7rfIouQ1X0J/GTjzEmXhiE98fLrZ87CQsoznXTVdc/q43eNZgiH9oJ+zkTLKUtXtHZWVJFStUyP6Xf+PLNLrjJd89/bZQ19jfLIjFoZy6DM0aUr17mu+14gcJM2gQIV8uhoOAWbo88QOP9Nubv9T3DxhGQqeGsfQ3e6mQ4ZATTY2Z3ihxZ2iUaAL4vcyJaUG2Nrv/MC0q9GVf/AEGF5Vu7fJSB0ti5wE6o9t4pfifT1Ai2z+RbEnwM4JsIk+45/g7kVkCifBnun8bTTc8KE9e7v5CtQL3OfCJNMg3bRyi5jPknImrq7beIdbaPK/MJxPQcQyRX7+sH1aqbaBBKU7d6BDjQzaUmwME7XJgT0K+ICAkPnDBB996Ve1TKF2+5tXFqYcdl0AMciSfyi+ADQ429zoXMqn9AdOnQVtwNzuNStzENjbxnZPB0rC3fkXtyiQzGdut2I1Lg8HYaRZpsPUQP5ftHBJ9tPEWh4SzBv+6s4ZmdbRAtZV6aJt2qoXWVMQJpmS6WBtIh/tCtgoNypSE5aexHeLg5oo9GyfjHMZnadfbZzq1zyHWCgD+d6J30IzNDOynM6O7WgUfSavn8AxVTe3Tb/WeLZ55j8YbY8XBf6++sr1wBpC0XVA99e3l2IXmt6EpapgndyOlGqhzlmkkUYt8wulAxLxpZNyJPQn+dZhW0WttROwtatOHJ07dNJz8A6KZI8+TawNtWJXkt/BqR0z7oT72PnJPtj0jefyECezZohygOOU8RUNQBoG9FjYAtgFuxCHuyfeyXSBlMhZu6t+LtULyX11hhCH/Xy/mdYjsy4deWUWPPojBDwBGIFnakOC9KTATbJ2Vf0yc8BipiHVTRkqaYVr0CUyV8Q9roD4AxDx0ItpPXCFS2cXkAIU3yyeSFbnAXE/dw15L/ZEXjysuF+LO5waIprW8ypazP16QtLWHpbvvcTlq0iaC5SEv7Y8R3gwwUw28zhrCI0R5j/6O6i5ePW/G27VStrIgY7zZmH44MpP7eQWq7pgIe/N7sJkdLNC3MljWTd0orQaQ/yyl9BHSRDnxaHFn6XXBLoVmtFUtW3+PGzLJyOls7p3IRcafie/N6aaedGroXah4Ggj+gzLtMfqb1H2ciwOnbSPOEHoIcpabIfhwhMs0+nELo+Bbh7A4w4+sSi/81gTjK1pF2vzoLQBtO0tgSpdiruQJ6tg5hZPrRG0d1/LVZWWgiWYjN9q+PhtE8t90Nd0vjL0DObMQP4brzXsGJwmNXcmH+LvrUzwaQjPy3Ko38xVA+I+WmDDbvJsR9x57pOp01PlBiPvPo9l9/HPVr7viZnfa68w/0YEPTqBycg/myad+mC2gTmCGc1Yw/OVO/uEqQhVkkIaTuK2fwGBHXpgdUzbFQb4O7jxLgo0CJnYgJ1f7tDkVXBGlKdBoXSLRbAJqMOHFAcEmDUa/sy/D3N/lAfLmS1bClOe1h4ShGfJPOvyDbtNvIWtCpMh4NXDr2Sk0HQ9FmOC1OeRHXpIZASs4dniaLCkgfjRe5i9Tyz1kRTKAeXp9ZuZgFraanTLl4leeOFYQ89SAKuGm71po0HIgem/xlF+XtOKnOHEoXWvDQ68E9eueIJpAAAThNQst/dcn1g/2a1pNMb0vUFwSxhQwJxxC3rfl1/Uo1wvsuJsVhzXiMtrJ/TyGuiC7vHmp0ScMtvHdrRl0TMBaV32dxxXJDPeWAZXnXVrhhPpfkLD/ih7FeQC/4MV9PKxUuXrxV4i5pSXr+p8qwH7s9AaKrdN2KHkd+bZUXIxNoXAIheuwU15CTaPbndeM8GoHeMUyrW1Yg9BAv8Rs6o3XE57M9EmAyxdANhrjCRqnUIEa8DQNIez5Sq9kmm7bMml4nF3pFEId44GonYMieCAy1ux7FkII698QqfD1AGS5MAoHVsjclucFCT5KLMt601Y/GByYx8GBBYshpbcs3vGk6PLnbsEI3qrwd4W8sbqyP/vfRWOURwW3TLiIajr9qfxMbVaxQgUnMHPou4FS1XkmbEgg9UXE9z+dKbyre0iZFn02NF5z6XPjHlwraETby1ELtOd7nV9dZhbDGN8UOnE+TsalhjXcIkbGSgts8dygx6BAsubS3t/P47OoqC553QFLPgkMnjtyS/uyV7MA+5knWUeMfSL3LbRPVjY0lR26SVDEEsnvKMhqDdXAGSQC9k2GMs1ugRQnhJf25aURdRi8Tekk+nKuG2RvxgdOwqp6n+7gHArDwtRoQIL4Lf/ZACMbXHH3cAqlNhelYAbJal8BrCYfOHKUp5RwsIqtu+wYZricNJ7nG7Ci8L/VoEvDktE3Wap1u49hX03A/2soCqu30TUNStBaptmJz2ZeV2/v9M7LYk5roqAES/jEpGWAonzvDh3buHHJ46OTqyw5Ee7vas2uN2zJMA3OEPFYk8qemr+lePM9OXiUVUPJfabvL2MnNbuQNPZiGgqwJD9ZUJY00kYnEY2k9JbH7L8KNJJls6u0ES2551Pt5aYL2Id3/fHkL6aSfTcfZBBs7Pb7hkyPO6mFizwkKzm3qttma0Zu8sC90y5zcLgM/iZ3yvBfv9v14S/AF8SNMsNyjoXZdE2XEMkML+aHzSat7e+n7k/lXU7oYQ/UOp85ICRWJH8UqnbNQ7oM9LDajGyqaXjKqB1hHtKEmwzWsmenkTlLw+tPvM7bemcI4J1zQ4BU/MrilUPfyslXSfJUoDMoPt2dZSZbv8ykJ2QRL/qXXjt54Vm3XvR9vm4G/xZR+adVNnDzQs6HVbmB1A9qFVAP4FIuRceVmMb4ZPC13hk1GLSTsJl/ZvdTbMs8dPejjwhQEyX845WKce4kFV8DdJ4ZPoy4rs4tFgqfazJUTOa69bARzMLSAO+ok359rCpPgLVpPl9FRjlV9NVD9guTph+orSJwrcCTL8reuTvCgAhXo/4PhlIsTEdId2y40X9ppmkZ6KCUXMz6IdJeueLhg96MDfeIexc1iflQctrLaKu/JlokVemnbodG68/kUZ0HrlOs0/jApzbNlRCm5qhQzGvp77xTfTTyDxrUeH/4YyhajfgN23tq2Tv0ekwHtkd4wgFq4HNTnvPK9lkxPfVQ5XSyPg267QotCa48M8QF/U/fo8x6NKtDEu444tZzImuFGadoT+57qan/Ba9d1XqmPOS3B5Eyd3LqGLS2hgIuaizq9LrHMvzTeDNsW8VixHpT2KIxoFuziCaZOwmX4jUL9DbvFVMQHikWNI1Ca1HSiHf8b9PJElYVYXUIBx3UNge7q5L6qeY+jP0jxop8eU9LsS0sWoIwGM6Jr8i2Asvv0hg4fKQIzavvt6qpz0/2AgRBGoMksXMCyW2ZuH7AG5oFil8kuLTERBtIiEq/Sd95+Q/gQkZsHk19cA3FTkeu7bAVXDmR7NU+mK0rhY7x0U2A6swa86o4rmqTrRAKPB4C6BWtt0ilMF7K0ZRFBt5y8SPMlNnZ2q0UkDRMGQZT6zuqjOpbjZqZJx4t/+KBmNaLvPEMfDRWfSHMJcUBMhe0fIv94iW4nRnUdyYqYFOGlpjCgQRBPmA0jmoov5j/WG51pYex6gsm0hSAxKfKUCz8UAC3M6nrnw6ytgUV+oCP6DDGCtiVrmMtDwXZyDDwLlVdzn5t0NuwQDySWs8WlbyGavoOHvJizJMwEaenePELDWzNViAU1ruT8QeXG2R14UESFIS9oUrH3tkV3NhuEFqudH3TmuZTwgQ4G4/OXraCX+Vx/h2tAygiWOnQpI6CviA4wL8MTyhMYMjiKG5RIBGXHthXsAYghZDbCJIpQvM3GKGOOlbYYVxcMEkt8aWit6WHJLz7qgj+HjaFJ0NYstTtkDQmSkd9Jfd9vgdlFe4GywED2egIK4SuVzkwt7T3EQb8YvAdOYtEqarCfIYzp0wBLzvEK2QlIVHUU7oJavm4BVyGPliMoMuXeapKbgpAPgAnoXNzrG1a8De6jljnMfRFg6mFChp435+B6HSfxRbwz9rq+3L7ZklGPihGw1MpriDh8x50MUD1WF2f3iU9yVCDNRV/GzDZHYy5Klhnfah2OCKXdx6UdImlEAWC0XPhunEwrOaCLrCZDwJBvUHsO+jF5tOIOTEF2Tk1Ah0Wh4pSiFMqeDo111I8n54kejtaWqetVKrRZzP47hwDjj5GHmaChPbAzamcRuwHiQ/56tl7fvd+lUEeJCY9Ei5TF96ZOE/2mxoJ4yCYROHDfpOKinN36tlZhQ8zL7ERaHIkcSMJrozhA/pBdIo52srEGPMN6PZOEP2Fx/N1qt9veqEwF5qBgeiLCimlVSEe9aCOpSFxuv27QTIbOm+MRB27fJqBEEd0aPajFDiwpRn2yx+OxDcChAF37I/shmyvygBoHy9P29fxuZZCr8AJSAoN3yJbu0dbUY1Kza/SKd/fTNhnjZhQ2FcUET4Q5Glyg/tztvzbMSMJrbfx6bkyK0IZj/+OCPlDwlQW0Xiu95xYKBPPn49NM5+A9iI7AX0xlkRlcabJYZWRr35en+TLkZer/9GnjhUVli/aI+T8abt/bMcHTptbA/dXK3zRpL2e82fYKJ950QmgPeSEaarZmA4ZpVfFQF43ou35tgciBNpJzQqopq03SnqmHVAfxdPfBzz+8W+8Hg9fbfyjj+zRYRZ8cE8WIw/uLBCBzBgA1eG0z/Y5cUwoLK3Q5piMQztxed4nZtv11+oMNhr3SW1MTipSrnjn6Mbgn2LoXb+pYBuJhvIJqtdkd9gDBJ8e0lis7gjj3hsHu0BnjB6hw4HHosxlNcc9w8Pq3fYViml4maKBiRZvn9Wz1EfdqeAPia9dBox2RDVfovWPRe43gMSFTwADMI0Jl9ZhYv9vV89+JTndb15h7wAgRR/dd2+ATkJIumPnYhNyo7qNI+2EuRssyBWW1HVrArrV0urpJJloeRO3h0+Y1w/9GGPiSTKNkiO7cL6C81cS8I4BauyNhZAC9nO5YiazKCSlVFYKGHsUc5Vymtd/xPEPi+JazwOUlaucDIq2skxgdvRvcWnfpg7u82Y+9ToOcQTTXzIwYn/gAHgIyD0uTKmAgpZMbFGJTeRV5OBBvhiWz8s+fGT2qKCxzLH3CSkabtBamoaezLUNDWJJzaPhYA5FEa1LZ/25HO1/o1im40MoFUzj4b+0lguKIoo7NzV0NPpJlsrECuD0pjEq25FzZzQLuAlPu1x6BUXTSwW1YII8guvEP07ZT0po70olAQE+kWqX5E1bOhzveTq1yuEzRWBqpjqX/NjIKUQH8LCQG+AdaFUJr15SbcEmR7zKVyUVpktSSf8wDJ/5fjQi0wHxVorjRM757CUUKbF8ELAP2VgEHEZEFvC8nFV4r1DStcW841+Up1sT/TTKD8vA81Fje9a4UUmriHg6ardMDTWh63rj935tnXsRZ+T/t1OAXsirGxVkG1zSHI/aiWiIefWiwExFm+iI2bhOQig+14aL3b2pO2R5JxrGfjZiyF04zxirUqu0/S40IL6uDntnq6csvgc3ErgX7qtmk5U8evudXI5F5/LrYPBYXkg7gNYDxT7NY1s9lqcaDS7ymzedbuKS673+5la33PfvY8ufjqjQx7AWCP9aiNUIxOXMWsJzSA0UIQf8tzvOvO3hvjVfI839LRcBOVnd5JUSXiJ6qh8h6AX+1OW7yV9IixbuHlfCP2PQMx/wQlENAiTLwTFyzM3rVsjEPgB4mPO45FvNUqj3H3tWVPsBDrQR2PBwTOszjWiGGiLbEjayeC8tZZIW3rNqgJ1RF4MN5HTa2V1RoZ2Ad0xFl42QiiidKUgF+TXLPTpjyFusPhM3fBnAsX/AS7QSMnufLi2O0vbaA/tETzn07of2Xds4pCL1ncQBRee8npKoY11zT+L94+bTk5ovWRGNucpmXxvoo5fGygarUNBJQvzMTAHA9kJsWMRXNt/cqpZgpYZe7z/uTCuaGC+Glmjxkg1cVmW8dbBpQvazss2wLeYuuClPvRmA3aq7HANNNb3TJwImYJY/iTgsqSCuPWtBghdhl3/AQ9Z4FyqxlyYJQXmXVkn+kjXvE5JNTDhHsM91q+UMSlDJD8BK4SNCbN0P1ePSpxHEOL4ihyh5ZN/ZEytTDicLrcq2f4lzoHZBib20TwAkOd371JKRuZQQ48g3xYz7zu1HhmC2RceGqmtnm3T4pGMHsLPjfq254y4Gd6ovyusoE64k5DpP6KTm9Tbv0ko7iYHWZwQk0cXJneNaWopl7RNJvfl9e2IBAGbfO5jpgVUW2MGvzjhe4dabwDZd2hWZtQzTghi1DQ2ksYW7d8hT9ymIq/uSP+kLWkCA0I7W62z1GzCQIYwc0Jtxd1OCMG/rRyZY0efqIvsV18fZm9e+GHrKr8p8DJTreQ4o000EhcMxsTBkN9ubE79eEcraDOnIzJSmrNPzSLk0CMTUhkcG+M9ppBJqp2foDnM95jWiVXw1dp3600LS+m208LoYdEmyhCip3w9iThtdwdNFDdwneOxnzVCUfsCC67I86FWrlS088/DCDtHf0UlLOILVEPJcEOV8A4HvSyR6dOBIyagpI6UY1joqDRuNBuoqWYpw3E3EkHDRsU2DeQ+TD+YI0AdyfYCFxXexaMpuPnQZauoLWVZZOW6DeDLm1fSx/Lko+K19vKQ2AcCW5PppABaWuoWVZ1tB3ug3ZyJSTzA4YRrsVPqyAyc8PgeS6MiLVGJwMT6ZyVwaLzupZxqJWzl0nTNlEHC414IZmzWTjcG62G+1tGf6wk2+2gUrnGhEnLcSgYNyTxzJSDLC8UKbLFvX723Ogm0iz21yADi6QlSO3ShkB4MwSf4NxVMusXgpiyOFqp0FZp6rjUYnYwPlYPE/rylSEwOvBUHuZu5pybZQu8fxc0kRQqekdav86t7urWpiUVluxcYGxXjfG5/Gv70A9Ii9ABbdWKhF6y9sWU/Efpb7lKknfCPsJ+HxFHZk9H+Uj2Ki5U14O/gSNDHb2/QBYydsoEEEX/g9Pd4iXiXmksc5zy/L2Jbpkp3UgUjUe4bTGeSoCr+bbipG694OI4bPERxAvlxRIl78Vn3rerXrmVZRzIoBIjk+NDYI8vA7THULRg2wevrcH12ddObvXCVZT3TPbq/CwelDsjds7jiOJZNFgL1pwFO9g3KPjn4XcTYCcPNUtousD9MdnymKMrmQ9r149y5y5CZKJ0PdtQva0qW/mWwwf720JfTwDbBLh1SnePzYSUzn+kPK8FKpB3yomezo5GFb57QYGvGaNl80lbHoXm3uuN7dgQpDRvmNHnjxQnc4ID1i/Yv3f/e1SAaZ3MMOomczicGV0yna4TykEN/l29Al4yUrIBqKPVK1mv72oeb+mQ3/TO98F9wOMRnqRzwumxM4X60IsfZSW6WM8J8AFXEOfY28V7XjbUVISsPTOEC1+3oP52RyrkGbrzuP7XG2LEeh4sUADU2rpqrqPz7M0I7ziVgYUlkS6yrdX2HsHUnONVA0Ree3AaypZi8G/r6xhCoTGjLGE29CRw41rwIRL0oW1qZl5GLymWumheVEOM9WVz7dPpurtWdNqB7djsyAaygEo3Nzw6SwARBKG02ueTGKqiMTtFb/upvPOJ2fYC8QJvR7eAMALuqGqxTn7NEq2FwysYlVp33SuC7oB38RyEEG8XMZTzwxMnW3puBWZWue50CfJHMXJNg4zxQEaS71S2a8Cn4KEGYaWor9xbOIHWCsYNw7CWWpEed9rORmzc+AqvWiT7q3yKFV9S6itj2rwDghBcQW7VZgsMeX8q4bwzljsc/ZjatIwUCpd8+6ysfIE1K4QebO7bivltU+lW8L1pZD1CdbhPFvyplOPoz7cqF7sfHK6kiKQEnBiFrhDpGwV9fNKV9+EaKntbFsqssoxA3Q29+zSOsXYmChQ4A9RWgkmlsBuTagKNiCdWQXjLfADnqCrfhryJDlzCbK45Ag9SgP6xzSN+5IV8jiVM9CuGWm4XUBtTUzcFms0Skni96uo07ogpl4tTe5CQ2Bxzv3qWkKIDc6Lxhsjfpfny9uCv4brCk9PnB+ARGrBypHvHdPjX0O68YvlDoKIvVNFcbi5fKv5U9VZiIZ4uony3+QAqjEjyvvUFkCqIRgaq8NsbEiEv5peqnCZo9c2d3j48A+rJ2P1FOqIPBchrkBWlfolsmtjMTJJPS1QrSvpS6+fa0fQq9rmTu3piFfAhsFnDm8anvpgJ5hlOieR2oa2f2tuu+aaKKFyXZfhknuL5b8YPA9Ci6dBIGxvz7zBQ/TVNDergEWJL9doP/VDP05+e7oGsJ5RnMgLXNUUIq4AWIW2H9/krAHLUtFhcLN8Esi+Fxy2e6ezw6clxX+2+7iU1Z6viur3CN+5PvEyjmMz9+NwmU0CuJbBvmt8cggcK4ZEoYZPLE+1o5yWwfKX62AcqfFm1bEmz9uMF6BXbefBL/a/L06SclUr90WzBub0c5yPkh4+v+u4oSfJSsegbpfEwfjNh3FzBwGhgsTjUNKHHBWOly+Tcjy3nXcfMafiM1m31PQe5yJfbVWYiG6WUrSh8Vi1renX6/HCRVz4Nia5IieJq+C+8YNh6FanESx8NWDqPmKu0GJv0pFqcrjQ55ZSRo3QuWLi9NR1HaKlNATMT9m855eRoFocdYDMzBc+iyFRKdtfFiQ7v4TZ+Kv3uyy1LIHq3Zg5TRBx5khQ1kdINY0eNDlBjWPRBHwi/PyMVetrUDlhBzsAsQijSI15cz5ACK2A+5BscbaOR9O9OL8y4ClZ9XO4KhLjl9xfmEm61M/V4vYENOvJXDu7j1vxUb9/EXVag9LAh2Wn4hR1hrErp0UFuxJM3kiMsUlGc1Q7eT6sj43cyaA5IppUprQ2xGXgyjvkhaq6Ym9N6tNmtnZh3M/KL/n7V9qbtzrPPzVMO61FGWhJeaWVyiSGWJi5DbULBCxZMtFVKgl+cwe6BoNFPHwTrroWyGhWm3rNDDRAHNKtHdxhKOqySuko+XiNnpxK8QwlP9aZTpjmN0kTu+VU3xt8+xNQcU5r74PyUP78qw2d7ZyzNeNkAdr1960d5eUAFOGO57BpvMH0j3mSr9VcV9r290hbMhdW0iZxwDLMLjzUg4ChbDebvRepsDLGrDTBzkjaSq+twR9+yEhkEvI3cCwpDhPPZAU7OaY7uAN/AscD6XP0xrF9eUyoWxqfMrIwObCNFAdJS7VizEjdnqr2StLwXI9ahRG+8JD4Imvwlzx922JmAufZ3hCgwAqRTQWlnb0ufnjqjNBy5JJYGYk7evCT/gNxNGeA5kSEyTGVAaYfsGKw6SVbcxB6k4/4XcVAyzDbegGrju6SidIa/Op3ySsKetgatPU2BUzdQwVm5Q5WlCkJShhZEz3B7QHu1QmNl9nmB+O9StvnbKZdlroEoTzgdMSYWuq4kIc3SzyBSnGGiG3E5jCRTyb2Qv5zNYvReG/ZHwcs3E0O85HZWQOMUhX5zF85wEm3yHzsKAb9bowqFf+CMHbGhZ1BBvcSyElR0zoooTaqGUYyFofPQsykmXtbNN6OvCEOSEO/ERpw9EqPVyTXJw60cIR1A3p6KL/zGLoPvYt35Jd9duGINxieyvVf+7HdsOEbSGD/D2aUhuW631J6IqydySQCHyWq7DStixDBuFDDfA/RHIA3/CQ83lnjBJtu7MdLTHVodFAxVlVqKTOXPI+5S54wLbpv+Qx98P6alp86Ii6hC7bL81yiWBvZSDVmeRlesgFBqcLKWFRBR06OvZd8rTwO7XqLCasK9/hu40lo2qQA8yuUJovwxtz4662v3M2ZzTK/9+QOkGT3rtiPFQzkHB/sAPAmY/3/PghGKu5J6HFGPTxb+Evr4yn2nKgfFUEQarnN0lrDyjIEqlrJmUMrHg0U/US+5cTGQODVd8y3Lp0nXsMOZtMq9lPoXYK2AgV4poOF2e59lzaMv4OQYwmrQPD12t+LF/sHIeycrV3NM/NcyfKIFxHw3gJrufEz4YZX9W2jUdUB7eEHW3MQpUPOtelBXK/X2wFrav9x77v81nQt6CLNvw9t61KqP0KA+4OYxxb+nXzgXTjjuyEtebgpEGa3kPxtEC8894Y+hQ5gcfw46tjER++Rw9hcUG1Q0pWs7lUDqvNArIW26sHnHk+EbDwSWlzJpw/pfTIqrhopkW2cQ0R9swisiubcASYWrIwxs2GMA5O0FwYAfityh6sPaIrHMvnhjnLT4WGVEXvJYUsSdthjIyo8GiSwl4a8JjFWXALf4enuuv0f7DxDu5kG6l3jwYGl0EwFuHscP2SEYrt7xMBBn48BMr5B4vkZ//Z3OByoAp/mmgvz6HAVEkgsBDcubv8mJyOmBbZ3Z3AzvBwvpbukWe/JRMlbBVA/kiH/r8UM0TBdbyGJ8IpZoD21dfKA8PhPllVGn6nThVktgIdLkR3gcOqygdAch1fuoQWRK7KWcxIJJCT0aq35mYUCtnd+ggy65u2Hmg3Axo6wTsmyNwSt0asaUZM1mOBEaPyKKR2A6Anrqob90BuqFiXd78yGKddID857AnS/SPltJ5AEikbT4wK/sW0VstMj/URA9WbF0jKi5UrwpIZ6MhuGGARXmDtS750SwUD2YYRa5/Gq2/JYD3ROrRAaygzrWR8bt7CC+y/Y4aGgguqPK4f5iauDtFV3p2MfV2QkZ3qsae/b0eiOFjPbDnBhnOrZoSNGZhgPagIVu7EkSusC8ArNGhWKJwweC/FAv2gTzw/uRplYD7HYVBMe+J90B6Gmv1dblHYXYaO22XwSHXZFNEf2fv5xFvO9uwiXRZABcmHQV6Rxeitks2zPVKH9iMICSlEOF0DTyJGA2eb4yg9sXXqJUy7JMKQDaEteuv7HL+V8mn3qibYbvsrvSIZdBaUd9M3Q0uvf1xF/+7Y3047qw+nJaXPPZ0a9QLqSgAlSupfeiJq70YSdSsIEtj3QFTehHZ+jRROPEdMmzcrung2RhYHrVxqL9JsurZIMsKsiQ3xn2SuswFBQT+A0cxGpapJvNQcyjeL2EKIOXm9GMXVIqG35slSv/rQ5eCV/9YQCIQBqfHnaipN7GYsMTRLKK/5944ITcKAjsOwwIjjxuqkfo4jL+tejvn4wvHr8bUCux6bMu99m2/RXK0VU4MPooLc8ayVNPG/ZoHRBnJOWS6tOc58W7zFupM86J+DQrkqtL7POnSV36vzzV7x7O1DRdthqqQeMBMyWEm9RG3geF8+We5F4KRBHuyBJDXvs2M9gBonknYPTVGorLOVEPCeGyblsUcdnjw8QUU9KZMuxQqrXNA+0brwJkw27XPD1bpgN1HJgkhHMYAXjIi67DE/gXnIosyTMLdNgORyxTBMrv4Ed0zj43ibngqn3mYL0I/pDOdymba2Cd/iwD2Lhpqh+6Yy7JuacTzeISQ9WLO4uk1xhBO0B59Rfqg3Bt2gTPPT+Xmk9xXjPtEsCkmyeztdSic0EncIIjeoG+zc7Zi3e678tHeW5bWA5YSl2wi8WB3DVU9XrkZENEoTr5vv4QP1Rcpb9/srpEoyi34ndQogGLbMC3YDJJOlXJ8JMjBKKrxlioctXk51ETlCJm3rdDazR5nMNRtTs0nVhUGzXMesyB5/PpHnEnDdYPu6EcVxDGYsAClaMVjAJI4dT7/AmO8lZllAa4iAg0YcXw2j6vmhZrN02sg94zDOLsYK5oQmNvhn/10jFRqq+gnmrwTUMqOsTYlK//nFFJbPVwmPuWw74yNQbm0TA65zupPz12FvqbLXnFLOPUnsYIcls/5lwbbWRlKJ0Zba5hKnt4zB8hqoyTxJgLi0UcikDkRehmC4J0w72XXn3Yg12yzHsjLGjMucS6f5uwCMaqShZUfrGSltOMLlmOqr+TmvMO5L/HOZGyC5+eMwLLdq+HZwVZi5CXyt4ZUpOQgbB9bzS5mj5RTJ/UCEJLgaa12ZrF6Qhkv/xhFYGtNcEe7Z6rcg360fkuKCkJ/FlM+XAcwIJ99FxR/gR3kZE3GUOMzfjNbg3O2ILDF0ZJAjIGoM9rB7fVGpi8GV1fcznzE5L/T48bsgKiqbaIUbQGZWDCXHq19iWMFEiq8e8rD20J4StySYmdC0oCA5Dq8i3JnBUfySfhDgTgORNZPjhofWQ9MdsWrG5Fy3Q5tQzqCnWB+rVJTLxdbyInYXwaD7bbbRMVF6To66+kFBGHTO6o255cI+ydQ2cEH7p+SrG/O2Pyyr+o/WyrxhgdPdus+6vNWzeM3TsRJRxayWawnK2bAtwHIgl49votMvQgI6OJWQk2TX4KU3UE/6rwSQwujos9OgmE1sikULP0j/+sPv9xV+dqy2AlqXcdrbqiVm4+K+iXZm0Gof4rqPpouUtt4izM8DOAlMVvxzkZGKFqsWnbPZml3hoeOcYEkAvS8hHKiU4SpR53You3dqLCO8cezz+DiLJbJ7Js+EodQHcfna72RQ0JCbkiovJLPXoIMdWo7z1WFvHQQYskbWOByof0q3Q4HJ+BvPGowvsDuNyqPGPmNw8Bu4DixD5lGUjD3cpAwrqAGPJV7NbnNYJa8toSqxHu2TxmtQ7F411RY8e/OhFGqipi1Bfka41+vOtLjUzqm26FzE+mK72SsOR48WCFLSYXOshQK2WVH+qk3oKhxZ+3TbA1vHrngmj2TRsBIQ9ZXAVcl2OXTyKxhnIw+E03yNwV3L2nWlzOMxkjPuFZX3VPtx6f+Ppx2QFJjQ0wP9usLn/lYrNU4lnm8WihkcD4w1EWLSJNuZXk/1QzkF/2M5cB0tLtSq7jAbRVTu6Z5MVhheatlFcOQ5BeMMIetQAqxdZ5FnFjNOnti6Jol40smSKKu5rYIt1D4/bNW5Qxfbhm4qNjyIdT7pBclaJ2+dAt2yrCWeXkoACEGQQrlaj4l9NlIahLUlPfLG2zaSfwX6zMF2P942eX84ST9txlvswfdWd/hPN3WSbPo/Ky/dOfygFVr9UuwlLSoezdIKY3FpEMIw2hCegQ5Qw8UJAlXrGvdMJvHqhemPK+MBA1t0u/r4e4eKtDyQ0GI5Il3nE6Y5lwNYfDKy8X7J5S/EE2JsKUctGjt1vemVj90KVW4g0XuaQnbwIDk6jCwc/TqSzugL8RICo+LNuVehkRFPWls3cleDjS23KhzT2xMtT5miQA5KzZPvYZYJHiCdSAcSf+tSl4h5d/sJEyiCglglB1UDqCBQ9cuqYvPu1rzQf5yuiNd0ZvkKGhHoqYUQa/yWAHiLPURoXwdgXdyALqOiypLJbE5at08ewrOQ6Icgzn7kWag98zIws5CiZwvWJgg1+OvJ+qHce+HU/yqr5l59IUyh6m+OpUlwVHrG8Kz15FEquLBQ48HoRDPlrLXBxrNTAPaxVPVQKM2OaQRsGfKZ0qjPUqNoN0WGOXq/DIik/MvgGyT4jU23JzQNibygGr0x65a0Xt93tRmCOj/F5R8WjSKkV8kBVGHCsjRZVEuLGf6J/SA5QXYStZNWtWj3kPA56Hq1Ji3C+o5nirS96EwvrcYK2ueZ6ASB7I45NbwcTeifU/puPZE2aR0na8INsgn8o2MY/bO2SH3s+BXNYJflMueOtVumzVg+vqPWMFdTkbdqkIqstNPUojcoGZ+vuOfWSrrz/tPqrSlzrJ3npSjx3S99cLpKFFyYT/XX2Nydilik3SCDawdgxhMvuxhvXTFv1OI4NtV3erYh7Gqu9M3iMYze1JPtiPtEm6hSNM0YJ0Vg49Cw3GzumMpCNJJrjh4IbbZtKBtTdn5/q4lq5K07CdRVYDO+YpSS6PdKQQo1hPLzNy3D5ryy2CpXWpkyaILf0L29L+T+bGfn3cZj2xTGCaAlnL1YLkMxngYHECnsepovhDVJlNdUqbtzstsjwP0tFPGlqjLiFEAG3MSkg35YC/Jj6MSKE5cQffdxQRmHBpKKBVzXfAaWgQJYQv70FgS3Ov3cJsPwUXG/eRKPeosWV7sn5GTR2XWt3VQANFYixcpjEKQZz6T0p0MW/nAfRkf4xBcsD4qOTCsckQbbnjdGLFNo/mfKKcAad79fpr2qj/PZCR3Fvx2SBMTTnDNJCg0lydDkD7WdH0nfIbW6d4/+/a0B9zlie47jKwO7UEca2JeYBNXA9/OCVICvFIOMyUKzhl0FS+2dwVkyI3BuXAXs6iVJnQxObfwaiaAcAzQi+fXAtPHWa9sC9sB3GwYx/VQjoQ9r7WZ2EUfUEBl78AaRQXdhUpIU4mWAzcA5i/TqF7FQQImRPpR34uTdzdOeCYPxIKHchJmqgkdJKAve0koU2PyRhr4KDKZ/PrUdKsPEhk+xR+b3rHRtjWRISPgiaLR01nytMZAHHaBn27Kgw8aOI+yeZOkPzpWlLlu5iJ00MG929nKPvi009q6+n745vrsZ0uPVTudSCAKofiVwntKdq9mYEuAvmKytzgl9AVFye4p3J6LpvZgiUXkdtNahrEfTja7FrAD035+NX3EUTyQFt1y2MUtQcOneYKnLw8RgYA09NJ6xSb7ain19g82OYBZHGrimQA3DrcLFFyjUkaZwiNIY7kp+33nhmXxVoSvna4LL/TBrEBrOreDR6H6+ghWjtkzM5N8yBEYYTva+3J+jw1Os89p3TK+RaEywMHd5Wg0pq10tP3+pP2jqX0i3aj1hT4Uyj8/8eGoRKSz1hh/0D6HVjg141pn4VX7oBmu/AHW+kV/fWMV3hcTrYM360JTHHdFSRTd5Gp91QA6fHMk7TzADw9W1MDpSWinhvLtXpoAASrcNmlMLtOlzi8AAMQjBxfMdcni60FtwUds0pKaZDpXI602EiEsjAjJhkdP64P21MQyYpYyvVbQj+i6xXXKAFaWwYFS5dyll+VBJkHcPS4WS2tFwLjLT0mig+Czb2PrOml4x62ZQZ/YuiKzwxjxvbyQNcnBDhoKyshpOKeIh2ZoEmlTq/PPv1rLKwEB0by8TCXmUFNabf0SLYMcsfOiksksb+XMMEaP307P0kuyJnUF0Fk1rgTNkKgh7n3abxqfLRbAQdVuy3VK8t317IJaR/+fFIMtlV7Zn4mna1igqjoOmbzivPqpoo9sxu+MB7NjmmDohfGYOkvWcKR+6cQTfE8ZCh5G6yAVZ6GQBh9JQ2a1iTXMlB+q92DcVoeuzvfDVh9V78w4QWrIae7bhA3+SSeJnY06UPsHLXlt3ATbJ1B2qcLjRce4IQFPsZnkCW+KoLgJDGufdjeEqY6sebi4ClScUx0yS/GlTShxPAlv/TgzC41gVapMKcBAg7+wdITTatZiMkJHsmhS9R8nktit4Tryr16qV1HbeXpI0GIjXPOcZQFOQO/8ZZ6s2zMXbrf/lMeO3Xf7ED1ANcewHkt0wH+ZtvKF4zGon3cJAJOzmrugHN0PRoq94zPgO0Fg2VXcg63MwmjtSKIrHIdapglGJ11gMkPIj0j5Oa2lt+kqBybtjtWwdjTpjRWFDIpCSn4gE++fhHbNl4PNi4+tPchGqZtq9So+YJYJoIAXW65YCYLuOFkfIeHNQb1DT8U9OHNOq+4zUDQG1gcZxi6vIdYhElkOl/SYi7BvhUNkZ6kMFy6n17fgcBMVpVDHLJ9RHE2j0gvyEdN3U1973fVsVwIha1Or+N9rVT7nRh+MRaAcG12XLFLnewzZ37tuEjbIjiMEM+BgsCj2GePbmQfrANTOjVrpgZPNJNW0m/pypeGP/nJ20aQRrPT8ZwLD4XqDUcB1pj3fWK5gT9DQtvyesZKT9ZtqLHYlmXWs0DC+6Si2oz4WXKtZLwEGIhhoqD5RSU3WVrPjXSgC4TQPKNjsC0d+w8Vywk3GYAhhx20qgBMRipMIFDydMY6pRC4iq8XLC1EAu8oXtJKRUj8F442e5dqR4JpFkgrFBQ//57SXAUG3nYxwk9OlsRaoxyQ6FTtgYi6+v7Vte5uth4S4wrdxVyFIlutoA7srT6qZyp+RRy2eQeu8eOt+6VgvLxucaEdwps1C7gnGENSOYj3MteTEQryOp/QMoip8/A+n+Kjy/0goP5i7ANHb36hR4TC34SzI5z37+bchzaVHBIYqJvmX+mt6jV1nZON4PpCOnORN3XhiWbrwtzXiTLxXhRmIsLXLzqk4J3OBb+dyH1FJ4iM0fDhyQXoUtJVgyY/9C3gOS+7eabl+8adskCERLclnBFaH1U6UIjcqIcxls/VXhsbP+6sphMw8NUTRNwYoWP4XpRGPWHuuYHviqV/yaTz4lLkP4O4rdZKTpqsw91nq1geNXoYFZKI+8i58x19JVR8NTx1EpoCPSAknditbs1LWSLTYj69D9HV0136DKKfWtUAwrZ3TNFRuw4XyqDnm4dTHQSuC+Zrl3qaPmyaOvgXm+dnb1fF6800umL0AC/s5MpW1bgPGsCpY47Do60RBZDbB6twHWov6bwKknMT6iLaP256IaBITSWRcb4Jb71Bxb5nK/n+5UqZsi0KymW0LSPhT+/pnkB2syGeIKzV6/U4uRaKIgxri4+R9eWcgZIFjBCk59WaSMxKOqSO5DwJ4yV0vlZsISsSlaSlTXNV/w00ihncvV4ozU5VgfaD8GL2HRpGtcVHEtHqfMlOg43ExdtDqJGehSUu2yaemcJg6NJuF3MY2Fi66CBi8XELgh1jJxogVonfix3Xpho4oI027DVstQXYJnxeMzl2FU5ZV2J8hsV6CQF1Ew21IInYCHYKHgJsAfZdRpfDp13v42oxyMJs5ykbJYACE3acFhq97pAToeh7hKE1G0BW+VYcI0d0Hg4ue1roQICauqOTW/nM9GaRlIxS2oHQnjkDTm0PwhnMwOmcyca3EiBeJVYDPZL/gHAZO/bo2a7KACbygWuB0OnnBMVoJnQo2iKDYAM/IUvRGEsTA/h6fM9Zc0nSDT3B0lAU8gqSLhLIVgR6eaYoxr2yaMCU80Ap5AKbFNdHBwyPYZjAPc+p6QBkiQuNwjvug+B5acHckUL1bwF9Xx1oVkRu/QOT+qOGzn+qX7fqU7/+KsvAjOK9nUMtlNq56xz1PNFO+bAm+gBxblKEL6UTfdRcFXa3DqM/wsjvhMeAGhPVnoqzKCtVjouyMCwwFBnmQkD6jZKfcvyQvnLAcMwqFc46vVkKEBo3a8ER79Vokvg5jXXEy8p1sa7+plNkwy5TLb/lkBZOYHhCixC2OghuMBwhjzPgFr1/TEUWGPuWa+sC59ZqMFb409qNNErS43z7oakCMgiNckZBI5mPTAElnx6g0ttVtBFg2SfAoGipzIJ5r+gEBjKGpPyFbzVvkNPbbJ0uc/zucAYeDE+x9huo63NLf83BRy8HHiyuCczZAEZeCef2lTozOAU/IHZfY4BIkMpBvNwi4m6PlBAly6XkXuqYNH6PNy9A3Q1yvfWnU0hzKpq43LEglhIHlMA+UC37lsrrflz3jootPeD5+qUwctXd4X4t/KgJu7Qvy7utXPmftF08N/F/E4In3U4fG+CowZvuREx4L7J0wYHyn2rnIibJI8GhjeskkZBQifccq3oOmdsK5t2O2x178+KHAQzgO61LROQlXyc13TKLcznElAOngP4y+2rA4rlxXDYN41zm1S1/MTJqCi1CX9DK4HmMcU7eX0Gdjy7Up70a19b1zXfCVAFUHLH0/dq1WbomnA34/hzq1EzWUnE+yUzYa6XdwezRyzXOrD+YIBy7ZZ6K6Z4+r+2gJ3zPfTU48jEi+k4QoyQTZdOtQFOEoWos8u8/RoMLcwN/DbJkQRo6XK5hMzJsRwXfbGzCpCsLhNm5W7GZtkZtlY5TsDSYV3kwkvKf/54c0BGQlN0yBHbbEbsRg9vgJbKsRlow2Q+rNpnUiHWgAeH8CKDgvbfyZOCIVoYDRCIymNmF4bRN9GoCtWeBIlOnfaIwN2PuUFAVhV+/7eB8dfvM6Cw83s5Ty7JwBBair3eb/DJUDBMACqg7o+DlQo1hpGiUnhYM3TIc1eHyrrPBsm0mFtTdMHY7XVo8+S10GCJBcHZwsYtXcnXDTi7LlPRmWmXz5mt9fhwTj4VkPaoaXWcRWdcIz8vhqrer/wCvHfyC+tME1XESIM92xexi2dCvBPq60k32UswKafDf6uvpGh46yrrERfUKSsF2vnLcS9+N8eQWiiLmhzBNplBX47PgtC/FG//wgtOrPA/i218HpUk/YVhEF4ObS0QjIVasLNMZK2RGY7l1gKUbXa1tAvtetQzKyE6Eh5NwMiQnT372cz/DkCrgT01VgFf+277bD8Dd8j2Y7z+gAM8e1L1f3y5AZ6kJTBVVchn8PS1ELLhkStZUSBOEdAdZwHJabT7EonXfjPDLlWZkqw/QzhiAiZpLMkcW8+x8cmjfxvfjTIRTgwrk1PcK/Q54/ZsxRfJHCs9jl1aABGjdab0i2R/0lJLfZqBBsDfpQirWG1siY9scxhhqu75Yq0C8wGrt6p5lZORcVX9PBwQHm+x+t7NeZdU9WFEceHvNUyf/7ScH5sYyvA6r++N8Xrr+HTbC57j3ksjR/P/OLcYJ5+f8+/D5ESsNUYDeDI9PZYPmn5js1zaZ3R/JQndx0694tD2lpf8PmT3jkXrm8ujrj16ql+STfDT8sJHR/H7OK9k1DvOL/byRB9AMFOjfJ5htmKTWeT3MJLFsAFpEdmi7+g676AYjR0votEFYxnuPbQ7wTlnPokOhwhUe35NLu+UmlSRpbEph8mdLnw9dM1xQcrceWbObG1a+UdIYPgnp0S4wrFZ555VYoIer232uF7HXkbSF0gP2bZavaZ8HZVAewdghAjp40EnkTmY+U4eLdsKBQcZLezFx18daVVvrO1PkmeIAWviGoehIL1YZD3O+YpuOe0xdqxrAfFozY/V+IargSquD97mhLZdWKetjDCkKq9MeZBaDnVtCe4ruO3a5heik3ha8ElqpXbb1BR8ZMAew6sJVoeeWjbRtz7Fp5jN7JAC8QIF7WlaIF8HNZuOmDtqDGeKxZ/iR4Y2TEPFrFjA3NXunsafYdhsx3U0DX4MK+mHOF69CltGrI2cKqKToJJEJ7po3frBKboXJM9GMPzyjHxfu1td3uDPIEHhbFU5sIijASc4KSBl/C5bD2/HwbCbEwfHEhJdaWABuJdSVyQerdg7Dn1EA3tvrwu8mLKXqZUOQpltaqRJcM5ZVG9l8kK/ZypI605R/fp/Ig/Zs98yS6mc5dc+l7KkqnCBLdPb0RLj2o9gYh21Qa0iIx1AbjcLdcO/x9ZfOntFz0+DvVQorTnRN1F9M3JGCDXPoFKxXHm8FejN5wZdqO92l82t6fEPzadvEaCAMyCvvhjWQM4JBgjOO0kfkQYQsiOhNFCy1PNPH1EeI0gugKwrK5E/wkgIR7Oj/gTNClYZOULW7QYXdwP06mGH0K/pCOXBWZ1Bj4S2qm7j71fnRJ+zlUzwyDRkDh87BQ/CPIEWIB8OZmPe2ejZUP1C5KEDNZqtFxWE2TR36Fz2XHPPb+zgj5nvGJi6fwZsbHyDM7GejvN+jvYH8zR/yPPu4ToM7auPZZutgJm8be8WM5scaZjhGI96UHXu98MKckFqyuust/2T73uHKHwui0AX4FqlgUu/11ZWsh2LtgnDigXdZnWPtLtJPJ6ZDGIpVgvJjWPFFgPH0xx7vsQhF+90Wkp8XF8H4tb5XZx3OfdjF1Mbel7nMGfx3twmDEAW0CZlFmCqKVzCX+VWsHxPXbOFwiS2XZ7oeg/YbbDja7Wo4wpZW+d03y1dVEm3o0dOB8T2r3vmFouytjCJdqjBdY1bb6qhldAKyE5LI2TtKaJbukzsVFsPqTrMEv8l0l7vWeqz+zoSQiOR0NUUBStRh9tYvRk2XYu3mTy1JocA5V8G9DTuVGGJ/Rk59wUJEpaIB+a3cunzMdW3x4WrUDR27QZoolbHxge1clOzGokEqlQ++rGHCue30kpIpQ09hU+WrIri+8LcjR0O+NXZyHomuyNYJ72wdRM/C2SfPbNu2zZvEElEVTQMOu+mA+A12bejwmhJhPNyaWELDZTeOqhXZ4OHOHqgx710wnSNo6BfEARNj2Uwg6cshGHLGL3cxwv6V3Iv+xcgkYLHJb/ui4HoPNoVh5a1K7GIsrZCIJiRDLxp/DIgnD6QPtBZTD7zPKimXWJy0CceHrXYrXTHU0soJ0F3Txs7URHbBhYX4yBRtJuocrjEEATK5vyDerQlk/r6/os9sjJJFL7imcr1Y/p1vpwzO68nxwtglQqrmI1kRLIiISeBaZXc9ppX3ZwRiyggNSNHbH37ySyPFZvv0uNZkkGxxVA3OCkSm99stNfZLIXSOYz9a+6oWJPdYL8xswi+nkry7Z0H6Qad/OROmcTlRto6ZSMeDATcphVQ0IGruutuSa/Hb83kNo69PDp6rEEwgxp7Nwpj58cgxSGoBCeUE5EdMOe9oUfN2A16NIxUup2zjz/bjfSQ9RfD5eV+GbKqxjXYYvXNd5cfgfz71BmqF+ny6mLtv6cbA5PI5bVQr0YbeRPtbv90eURw8XIzh0xlOeuxnW/eka4kL3ezrTBSZGdr5iTvQT1ha6F3D9Ves7bh8Adjq8Z6uQOKm70WmIA7rJxI3wOO9CcKS5jHcGzkliFFf6+cpAApGTpGkI4Dj24rfzlD0QxXFxP+nlHf5BLRZN2oTLXj3MPZ7gqy9oLq2Aeyc43TWMTUnDRia3GidcOPViHD1K0OLH8+OC+WJeRzstffuUeyNSuImwlxwCTvp6QTWhZOlvNKyquJSG/hXmKA1iX6mM1JCdlIVAZGuh4Ht79qf/+BSIv3otejeTTP8MYEMoC01BL3hs1R8GAMpkqjpCFjp2ClL0pcUdYAGYE5UtFMjmA53oEC2fTk1K/gcGKBa24ScMJErCGbkc0HPBy6EWLicjXP/LsGnwKGOg5YC4TwTymMvgKHlTG1xXkO69oKTLGk+RJvzLdvpbFIMOyeUNGmIx6tImmqVe9NKbj+pwMUVmAQcYo68ARUxASfw6SWWWS4YSgczidYHSk/4fJehPsSHWduVuQbp8e4yoSFw1j02XvdCRvkR3EDiA6JZ/nX6MZ98C2IolLYjiuWXcmsNx3XrHq9Pr1bBWqdv9XkIDZhQAAyT1buGwglndRDWTpmaglpftnEbz9EFT8O6Zn47NzsiJVLzpncbxtIhM/DNeZC/+zAwseM+9pW52RuD9pU3ceClzoxZY2PVlLURI0gTIv2UP8y71AjjaTta11XfrKWs66g+z2uuZM6zuOD+nPbgFYx3G6mXGUX9CPgpEn1lTqXA4um5IdvXBkkw7mhmE93K6M3uTE8OBCz6KlnBJ9rn7A4sXdm9cRITxnqxrYrZmt/j0eeQPnzTlzQ4jWliZiNWRihjiWNs1mf6yEr6M6D7vhbvPMVo5D+Z5Xta2wtgvILJh+ipMVL8xhD5N3iazmFW5EzFjssCDwMYAezVYZtcI2jlqIvBfttbWli+BFPC0R2bq+UW9YUSbYiEG0zjVMi5nMLm30uoNhCtjjohHRlzxFIkq8g8sAHe9qoe9/eItbBYOl3JrRZ1d3ECFyyDuDWiDOC+gD9ThOnSXGXi6M0BJjM6hN8XYBw40uB5X2EAwK7elZZmEveXoFglTEp97CXMaxZrN0pcON/M3wEDZbD+HGU2AT49Z22xUhg2K7gbkuV01RAjUi4RW7g49kNfNAKgAd2snZxlKnAQ1Oni1WbszCeSwsk1oEPLB5K8IQZw+ALKNNxZWY5/A7Jynr+UR6nnfTfkHTiyAO905777OabEa/EG/REXqzdcA3qE3V8k3lhiJvsgRgKCyafqDgcNS38FcWNs503VPCnK4bU5gQF34JooeKCqybtAi1i+NTdFTVtrD3S3RalJz1e16Uwr9/91fONV7bsspsYIPp1Z19E0/uJJklafqT3+OOZ+TblYb9it7XTnFy9y+uNLz9fsdTQLLcba/jZcyloc1YgQyX77hpYU2wA62yxkjuYCewnNV+J2cXmvO07oucq9lWXPmw/fYMFHppwwFdl1eNbtfhHkDAwnjO8MNiMzT2RcR0/I45jquDCh+VgEOyrHGmWyArm4KreuCgUfMLlVPimDkCS5gn4c/ReGLi1nbVXOUTM43+lJLiFLuR6RYh59vK9DsbaPA6st5HWQtF1bN8Za3RI0AZJgbpu+a1+HDRGC+7UAcV8Bxxqrnf+R9RJi/p17M0VsTL4PgRunDY0f2qrLSDI/+NSoxXKO+M/ST6Yy97ia4kElICp102l+EHWA3caxELqQwjZIfAQVJceTh5LeTy94QzXr+2GbQYrXNNSfsmnY59WW9rMnMjf4Ik6/2Ikp6iQfCC6Ga1Jp+JEdogg7ssp0armmnteJzQRI4Goo+Bhof5GA9w60EBCmggLEBzFuePeyzWWCs14JgfeFPV2ay1y6JpYC0MrNzwApgPLeRqR7f6iho/tPKYxkYga+jc5B8z0W0U8ni5yBT3qQg3+DturDR23ACNRmrgwR6NRAU2pwjcCtWlzbG+Sf7fPY34doYJPfgGHcvUMPjTBb5R/mYX5oilKkgJWcI/Vjp1mMlAuY5hoDoZ2iO74TFoCDexdkgs+58m9Lj2tAtskEDKA2fMMif6b1fEregclpFguNgBPJCNtKTjP6F5JnY1uPEmBNftCQMUbnukWZdMfC6a3jUcaJ98Cv2n/b5yX4DviAAAfPRDA8l4F/7aQnW/cRizQcNgpjrgnm7pdAYI8S966oWzWIQdMPHEuGScrLhYSIsSHKHWFqvGrfzZVqRL0za+Vcx0ZnepIj1GQOWCCKrgpQCjD4BydX0uhZ/L3C6YPlwWmlcueWn167sjU761/OP9i38FJM0mCn2N88TqL7urC2rQHCXGTetdb8WqgX5rOBBrOM3HgWWoDG34GqT+LtgJYL3SFrrPiGy+jNJBmFYw3ZkE6BrnGNnqlIEmq1ZbGV4oy/tSUDhaEJtDSAa6EeE+XgBkGqVz54oQzwTVR5/X9C2Z6/MWWVZpZzvI7+Vu1ol3azmUQjeJEx5iJ3zaJHzVTgIJ5YxTEImvRpHYUimXlcdhLkXYvgSFQLLfdPdtgQErDKSDoD5M3CVDs2Aanealxn4peesy+A8L86UPl2KRb4pigfdxfYvKi5gUuYNaGR2P0egXHoNybO8Rn4n/eUhO/72JbjTuscXs8GpE/I2GZ7k9CZQu/L9a4utl2YaqtT7mN68FiH2I/Su3wimQH4LRZaoMK3pwpikKeFN2xadLuVMnd/2PnczVO8R76mutAL2/69AesUjHZEYy03NGdICyP4KAAkHl3NtaaCW+wcxXdWxtT4W2X6qbmA3PgngjPkAywnBPEhM1MJXdT9fATAJgTwcKdEk6aMBj4LcW+NhC+OkyiYOghcf1+B+SA1NEL6VwUCzYJHW2JR6zNS4r8OsSsxEA8Ozl3o75tCCYToLRV9RigU/KRIfmDMvyojv2+8/o/PAL/jJtT3WrK4YDD+8sI0OEdtuXn7c3Jl1EYWpT1XpsjjP/si7HYBOjDnBihO2PvAj9R9e/2EU7rUaeO7fGXDpwcxG2Ji/wDRbnkMKm3Wbx0t67wyEko5lxqzRVCVt8saZ0/2BXqgELu+n4FU3aGAcXoN/PNa17yQSTejRzthQs20MBHPHSAVT09Su8PHXO4BGGIHZBFPubu+PNwhzqdL/uL7UsTRcQhyYi1P65CmEaMp86aLB7OXmWRNE08ZlbJzxr+HLVoLjVTc3Lzpa5/cJpZ2qLAOIqkxe4Fmvc8/YJQqB8AVwv8E9R8V1iR7mS3dyOLxj8EhS+JDyo0tPmRDyDIv2dgkELcsRGqIQlmJyK6t3m4fw9kzbKY7JzUQOmKB2HXsZiXuSfUYw2nxp2tc0tBCOnvmKVfXh8fn6WziVoZF7XGMtE1i/FrLlQpJjNbUei1PyIrQQzqrJpgM1WirNx0+DLrKJMhXWoZW0KOdZrAW3e1zWBbE1j3NM0d0+eRhjs5HCZyNrT5C/jI9QLw/9qL6iE3rKtWVEPdT7CkD877yv45wYT6jOeEo1dfPvgBSNQ83NvD9QW89+jcEjmIJ3LigPINToTcv0dbP8RLieaphgkS8t4VWDuKr01qDlc4IKPJPefKjLyCwMuGDKWNNYgNKrXhbMoKRWJil/4d/yBzeap1ugyT21Gn2DaZSQBP2Qb1z88cxhAgwthCBAqUhX9xkscg2yeqmLHURy40EiDYSYA6D1dnerREqywAuOwPGikKyvTgbQAHnFx4m1l/wpYFvmjQVo2GlRx3HaPPuHhjAbBDURWzhurIgL02IIBTfvCtiuLDsD35US79i+JxHK4pRGaeij2t7Uz945AyDfr/68QtdZKZChaslI7mA2Cq5wdabGG2Ip/pmw5x5xekLFOOHEUPESdlVtvO/Q0eIamEzzYxI9UXhckHDIzF/i84nV9+sXQHarb4WEUkc+Kc1rpTUMWbCnhWciNsC017+NojRxlXB1elvWv18by8BXRVtMs5G4Zg9adwC82DVjVPF6ZVZJsTJCyfKuISCx/YFsKDN+tFz4NgCwlgLSqA02RfT5gT4rizJT3Ftl7PfRXmukIXvAcTpvW8kqTu4rKa7tXuKj68tzf0g/sDPVXHLTTpd3wl0rxoyMn7VLHZtKIDtyVdvzjBWIM6NVMeKIbKASVBWOiT4KB+jbJ7EWv+zxwS1evByLsxRP2WnJlLItBSlZ8wopnYqD1yKH10CJp3YIK8VdqBfKBZr6LRXc+6ZtmiUsE8agt4AsmNuHEpAKM4VWOWIfMWMuNSlZ2W+iMAZtg0gZP1/A8g0p1lOevoJnSv6h7ESCIdTmFtsGrw4Uvgfd3T8nzDLoqq8uVV5gzaU5uMkWiC5uV4rEJjGav9HKcSnJiTAc4aYiMMBaBVBsebQfxKqAo1QRNi5Kx6ZzWOtU4FMHcSWvk457Lrq4GNKyCBqi5K2mn8b2ksGEPer89yYwp6/g7faTMmibH9t0det2QTkUDdm1Vb9x0pwNs2Hm7aL0u742TCsn5uqMAvCbwveWcbplRa7gzH2lb+QJTz3F6Ufxqwb552jxzI1LL8ju0gabaYRV/e3qgee7+mI2QkNZcEeHs03V8XXPu7eMBJwjwBnIsvKL4zOAXSsROuXgAQ3xbURm6GIIuMnAqdAHyTRC5lycDkPJXRAJylhms3pYRC1cHSN2hpUqVUUAWugDWlqyyk1462NNUWC1W4C9mHlob+0ZJ4FEi196MmqbX9He8hsAs4ZG7Fl6gJxL7/09PabeRuZM9ELOKiPRzueagX/neyyuRhKLMpHOHmy7QYYvpHTJsOkdgFOMXB7qPoyAa20KxIzKZVdlOG4NqIm5uuYwoI/lnEhykP2vVn4xS8MZK/avCZJwhGt095fQe/vd6ydooe1NsQdtkrSf9f1SlfWCC22w4ABsqdhtkCI05eZ5vicIL9BMmSFQml0qcLBF4oZFuuCIzoSj7xG65p0L5TTD41+45haxTnJZHg63J90oMPdbRytnn5mFB++QPdsHAOytjZCte3mmyOfl7xnkD31nrY609dLxCBqt42/aJL+9wMkCeIXCPPh4GQBZx45pn4sq25jR4ytBv+vlbKfGc6a0ipSYi1yy0JSQBay3XN2PeIzx95O+n0IEhtlhX/0ysnZX17WRwfRPKc1BJyDCH2TaIbxZpxvmAc1SuxfT07RGOjZZJAtmOXX/aBnPshFwD9Y/h1FiNpJsEmDRQFH7DpViV9+KV7eha20bz/xkmX20v0fvTR2Oav/CP5b6vhwbJzptitJrbjaJoOBJHlzZEq3thslFO5tJEhZHxV85+9JDmYho4i8CY1z5z64Fcy+2S0CuKjFcLWs6GqrstHGR6YG8aeg/slKs6MGw9IdycFAyGz412BHfDwmegnW69dV6FOJu/1SECuvOQ8QSqjUgkQl/w2v/PatQEjl6ATJUQSp/CVQLU1cq45vJv+WXdnzSXSmneStBNJgD4hRXHkvn8IDjFKbyAGjIEr6G28mz/I4E20+G7nWHeMx/VE+W7SADuw6X6i9AaAaAEmhLUM7hB12dndxEH8gYQTCiZOhlnfs4eOJ+7MdLbJcnGmFs5REcze263MIPJqoMuc14ooXB4S6GuIn/e4Wr4hzJt8t40D/No4a2DQMqtQVtaw+JlFyPzd+HU8hgT2QiilSTnv91bFSsyI3l8My212EvM5Mk6YJJWGyKQtbYdDd4WQ2Pvxvvjo5Lyy5fDBAR8Sr+u7L0AaibPmKWIV2Z/VX2ArlTk0IrReaA97AHNyWHUXXQlDjV5FRbRhLsmPSdy0R1eTJRSCHy1+yd6oroVpXHAf1EXqUYE5BUNpuQlr8p5XXs9pddva8OmC1PPHp8pv1p7tW/za4XgWmR87SFhdiZ3IEor47CnxMJbLZYsidC5Q/jQN8eyRN7jDRW3bPmQfOFzEbLo8CsY4FrUpuIpF2GSY7mYUlcEK9mrKhFaarxaLvNgby4/ABDScIRSC7lyLSQyJdLeuUDuMAyJVr/SCaOayUWufutWBVjxumDdzBV6VpF6QmcfwtzqKJ88gMt9/B3qHSnW2KeJCGjSXczyr4GByI6EzSjIudh2zqm60OaugoaISj8ciSFhsAg9h7i0igKCa9EKDr42SF6w+BEJ9Go44NRIFn9jsyVHiDC57OyLZ7Edry3omfhNa3NdXWgblcrVnCxa29+I1vHYzG7nLrmiI98knTnp24d7yD9Y7ePKLDY8sn2xV/4kOOllyGtzRK5cor7L73DX+oTh2K3Q96mL6KyqUEi4bB4kIP3EwPQDgF72O/B7IUX7g1HRwpXw/ihVOa+oGaNweaXG22cGJlz3AofYRkQmcsTMjJIN2jmWUPUZojijKkO6Y57BNVYSos+8xjWe+UrxoOmrbu3jsMc8TQWXEJ+TxGk+FnoL85RSX/TP2g3GBJWxdURqLQ99EC+wjVZCvcTPOfj0YSZ6PGGZUZud8Y9NAEzXdMhfzLKGjLBDSnRc6hknFP4lY9MG/yP8UCBbLUJojcyVb8PBPuR4ur4vLtOhq4rAwui/PfZfPc9r/Lb9yhis7Ci3jRxOEdFDZprrePJhJojz7+vubl9R9rkbNaM2zEuTxD8Qw0AKMbLwm8M8fb7HhPcAXGLLvnA1mhhhepb5Y8ejEocPOnvU0zzjgAPEyrbmzCn6anQ6AtfqW8M6U0aehhVHpGmVfwMOy2zOaggAk2NXLvHXWo6TZxuDGlaytDAtmQR0bIPRPemR1wJu/Ly1h89eQaSdIV1Wo9scXq018c/lMZ/OFsmj2JyqGgd6mDEXO0nEuu1pyFmKpGndYYnz2TuKHp9EXIJjM7yit2ypA4Oj07Tc4A2xKiAv9zJad9Gvf32m/UedswCKvnfaaw/8+deI+SKiHbyGiwiaaWnWm9ieZojcJ5/vsGBd3dAo9VH8D0+t1sbhhs1P3gChaZk3PZBxBbLYwMhlwQMBaA4Ck+FEB+WxeqKudilDrfdXW0yi+ibglO+PjB/eKXnMNpYH/FIk99DWS4x45WFb4DW7z7VdLTkzL8upbzhJH45DrCr17riInZNTxQrNReke4tclk2stkolrKeHVnlhWp2bEMlpxbecoOykMnfnxhBYOaK8T9LuHhyxxDobmaXBxf06gGHcIwSfPgnP9leXieSNl6Shn25GSeVji6W91292czwTSxE8NeEmXsCZVzd18dhJU1+CUTo+BIGGHZRF1flOoUpf36bc7yRfhgBNImntEI9ZO0qz2Rxrf9novAK66S6kVtlcUWq21yEgquOCT6XsioUnlyIYX+BW9vlCQs6GqcRJiGklyY2bdYKNiYeAT3NUyyTSX7mPqbav4iBr0gINmXDIU4yjZM14R6yuqLsvHljQ2xg8xwv9bOs6XJAPHknXxTqodqaF2HTYk37l8IDKI5RgmMMS2wyInO6Bh9+UK+d+5dRnkwAN+xzK5U3a0CHrXZeTj9G92YVcmy5Yw1xdVt3ekH44F2n+MG7tzp3GAjwjvMbr1FJNIL4kzRiZ5dQXADwX5BRiwDubX8X32kXA1C7fRc6BZGbGboMIZpweBH1MOPGHZRMG+cHeXnkH9stmmAQVHy3PrRSm4VissLdHaNpZ7SWDQpECEHtF60WmwOwduNsV7n6UBp4y+Ma+EBEYcZDWrQ9Pw/WXyxC8Yo5G+r+r+5oyZhtT9V11Vxsx+31HafO2J9XOTYh2Aaz2V6X8vJoGVGJ2VZOIEDf4NVVOJTL76M4AeaVkpFDpf8RsCtBPVwbS0hA+RQNpH7jp6/JxS/Zgtt47CUNuGDq2X+xo6ikxMKnvzYwKJHmHi41DOGQhp+iIsRlApVcH8A/+kDSEqj4VNlhRYms6ssd5LM04U/dhkUqG0mg9Bx1KYAZ3zJOXJb7GPfGpI7InN+IeNmzD5ArGIKx7AjrOmxWQcxdgENzcPOIIOiPIivt9qxuZUa+YQYNbqEcCGg9gUX9Vnbwa8wjAAgaQU7cF9HO+7DuG8sZGM+b+x5yOqmqLx3PUWffdQgX40BWA1m5TbpKs2adHsJbmXh8l5HJB7o4ftuG05WdqDR0WkD240Hc4ewBGiQUbVLrl/PYAq6dvKMVk8AH1f7RBKcwK5qHeyW7TmVLNzu3qB8YZgWLgJjDOYBDyTA1ZbRW2Ao8yr54SqOeb29LjDMz3tgJx0nrkVEZlPToxwvi7VRXXdgH1FJ0+/p21ub6cF2FaHjuue/zPVijJUwco783VW2VPczLM5Eyu1etc8vIu/OM613W5nnQTPknYKR7y+MWWQdUws35s1saD3QqGVYhfQEba2JbkKB3sW6LnwSLRsRVlzfAcwXx1BZzK59m13/mbFC7TF3co5nW8ZqH6UNzKavUtLSYeYAwaG1HJ2jmQIkJdWnTL8uiWwFMBIkF6r3I4pndbnKlxjL02dRnb5mn8uDEszMjRUUA57315CFTWKyqLn2yJCfnAmDThEyhsmnN7v9HJFo46QxGKK9n8lXqyKp0MGohVc+LIiFYQlaHbfNzBaTQtn9kubmwh6tLJaSneoFwjerXVQqVRxlOzP1WsAwZKr6AZRPiSfUewcgsuQy0Ji0Lcchx9Xsg4zxdULjWQbwIZtGwFG6Q4gDEx+NO2H/H09hqT/6MjptBcQzPEn/iv4wzO8beGPyKw25Yfbt9byNjrRvFB2MQxVVTOT4W4GwIaOVfsKLWfersha8wgaNIHt406Sec2e2YYM3UYUAnRcQiIecabzB6y4uGmCTG6iR8o1kK8xPS+ZCCreJiQb1dgEjlx0Ov/+31pM5WAjMAHzf9NJGcdWeaU+6yw6qlS/5L0UG3u1jsk/YFDXAhMxbvCO6gCnKh4Ya/Bg1pKJO77GW6RSmXt6jHXtjPr2sCy688cuaniTw+auwIL7uqZOQh3Vv8Bm+cU81qgngYMB2ZOCUXWuDXmBJljolA0MrBn7hKfuT0Bdo0jfbYF9YvDCmaA9EfqNob6WdP0bYGb3WA1g2EdwKmN1F/+wLrOE6f+SipphlG72fbSeyvS51EY4Ft7A1GN8+HWh4MdPkz9zIhXEp3twS1G90hnnXkh+dIHyHQZ0pK3+9l9mwDASO54fNnKQ5swoBnvpKwTeCEZxwNEvWUwgFutL+PWugMuGjmnHI5b5ayNL3kCxYRRyb+uVI0cNNsqmR4JVq9bjS/wg9A9Ix4XGWNPqRaqnP0xA0sP+YJtrsUVIwd9xMJd3p+nujhImUWfeH3nEb8LC7SH4g9gL5m8kraP3QjUd/8H4L4TzyUYv3b+TMtWsrazUNZvS3dK8EL03+IxNs1gX3ya6OrX+EWwR3xWseYzfLpQbU0fJFmbk5mj/UhnVPlDdR0SWgNmZcvRbX1hfSx84ac7zbuRG28LSv0mPjjoWmAgT91AMHAoWOrwdX9ZZ9JIvaHvrf0djBu8y+XkJYr4yfajLGKHEVY/keO0Q10fuOx/4moJpWE3EgtWWC2JLaq2wXYlfL4INOUoD/hbEQjtge5DtSHyL01v6OEhNGDvt/lqRrDfR4q6r2DfH0Hi+/Ek4Lfimf4u415BNCuWdUolabw7L86GjhLUEdriRKhFgW/JH9uKVJjBbm95/6GtaqiMruC7uLKixgJ4OOAKCr4S527IWc3DmYN1semw++IXcfBl1fmKmNaY9QBE/qRt6munxOR9DOs0vnL5aWHGtcZVYg8efRABKYZS09bg2KPxhc46b+OfMqIcOUCX9kygW6zlRXe++V2dXmu8XqTve9zCmatX6a7GLoFZ1z5DdpbWsSuKOv1kDAxYeSmyaZIUo1eMzHefsCMGySOzbBghkehDx5ySXTVw2XuEZ37Vkbt1iBS3E4GJVuHc3Ao418VBZcgIgjG6KcJHwLXCVNHMCTOggOG2ey5xINd0hR9rfZCYSUOyz7BVcKbM/O3KmRgnJ6zDpVNGRa04wigCrp5xyXx4oNsPaOpdAgosLIS1zeeRtX9e3ItorZRCpzJ1vyD2CbLGCRRBQ1Rn3gh05lMEjvvi45Xs2xGDEN80jl0eKS6jaDs08hnpsHvv+ZN/pgA1EPYOoHmNS49HA9PPcTN2rUjTd4CSI/1/q318RGP9EWxL8pb43vXvb/Gn0K4ioLq0b3/oi7Rdl1BAZaMcql8uOz++QehkAKE48weyN6fTuj/g0drmVuhzbyzQ0rO2MNI0g5ViZHZgk9GBMUAVoPwTZJ93AiNVHMYlMsZ5PWVpogzoL3PpN7cADvimxDcmc/CfexcYDLkJ5x91QP9yu0TKd/2uw3W5oNIyzR6o9tt8PtHIHK+udNyV/wQAqJfWyOBTQkZqAY9XlSWQLQL64DbhvyrSQR/ROS76MRvJoH/evtQo/Tdgd0IDE1fXVHLZ5EFW5PazOlaegS0iik03cLQJbpgp9WmYvMCSzkR0DIyNc6/KgqwVuqelzLgPFlsXzC4/H2dUYLV3Av01qfL7s/p5wal7JctOIUxmLxhAVdThgn+RcAxV9rnosisuTU5/Jp6W9WQgtm2IMzDUEsl2N2aXPHgtBb7xmvPX89Pxd5U5XgrkQSYHRGEQVcrMOn1i5+SNPQ4FNmVXfIvLYmQMN30SqFM1jATymX3YrHBOAR47XRP3vwbyQreVhrxfQ7yRoL4Ji/vvklM4D4b2xz7K+1MbHYsrm/wlRqC77YZAVji6R804QpFyk7J5M6cRVonf6BhlAKhEOEcSD5OtFyw4EsHPofxV/F930Q39/kEseiUZ3ofaFuGFQVGmUOetnBIDJN6hO7s66onR5s3R/wJuDp7YKUqKHNv1j62vBNQ55FEXvxTdsy98rVqCakbv/2AZisucuqs32+rFn2qsSVuEmBf4yWZ/HJrjnVSD7XM5aghrC6UMXn95bmF0inUWNUnH8vQcM6J2Q41+JX0r0/YOt3R1lUh9HH3aELBCip2uu+cHUFpp6VZXOr31FqiGDSwzOtxlXCzGhSEAasnCfnssIL94XNgad6oSiEAiybAWHeb2ZibAwHlQmarFkkP5GtJ8jkGe1nbW229aAVtf4atLzcX74qI145A0TEFKjFhohV1vHoxXukDhOY99AZ1NUF8X5MjNdE4/qMwWawB3lYLexONRjs1nfq8cePUFzhSYDlVUINmhYgjkYci8U8JCX0NOrCgj8W9tSdkS6fWxSgP6Z9jTqbOInBgi0DWNXIGp5VUB/flvBL5NpBmi8p5bPcrlSiGPHeqvL3u9kiIQ2G3JTlz9zI5tLjywztuokCcCcdd5aV3e4Hte8wUEjbcMzg7kan6ZmGzmIrCMnwsxJU8FYnf0RQ92Y8S61lVn+JSdPZJ0AcRWIKXFtc14CqAxXtXC/Ooo4jz/mvke8Ib0HNGL0a4bAqZs2F5ngC1ndfAL8wyihrEt/8GvQKkfK5/sL/z5zTP6bQFO/fl7rpAwa3Q/2bR1f7QbkJtijoGX21tK1oU0/30wlmeyPn/rt8REOD2D0nuCg9OhwOIKBG98R2Wo07WHp45yhS9irv4cT5qBD2QdICLQurdvk4ZFTFZYbX9nwug7kl9jdaTmNreipkjwSW43fYZWj6L8v/9sj/diA6KFADVDhGcyumhsdwPw+0Pf1Jkt4cuQV+OzduZV32o4uflzI6KmzCqM5/+V5vcclgIeSH9hXWr3g7k+bP5dG7WUOB/K2Th+0aQCe+Mu+0ALyQe++9+jOMBBsZLdsU9vR6PFYzF7TPI7RUTRcxjf9ygXh+elnwp5HKmT/V2MaJ3DaPAUB6UMXMRkGzcQwfannX42+ycBPSFrvzm9XINoX5Vy+Cuo1kx0rIFN96IB7tJKCM1gbPzdpxEpAbQIC+Y1IrFWkZFEG2K5VV2Cn0D4gEZn6ji0Qv8xxHSpSOGcAsx6Kr8hvF35ORZfr9Ba6gpOiRmkCTpM8rf9dw2s642uu0pnqYmZMOpdbKv96RC4M+wGajbS+TYkcNezdJTj4HOYuzDJzicNHRAdUZktvHy8onJFAedyGT9vIUIHfm+rZ7YvxmqEYZoe2+cQGSSdlfGwDE/cQfCGZHm9rKgcG9bF9c+fTCS4gInCKeEECxTZZlImW9A1mIKDMjA4bubjNviLhSNK+pMH2pginyfhBLprDUla7bf5AHPFoUX2lAwPwENOGgtwglhzFUBeQNu/jo5p3xZOd3z3Yl49+Kq461+VAU+uYtd1k+eMIPA/mdFM1ZSBVg47aB+RaCvhLhtQhXxzCM7UI2Gp/BTwcwlESn1cB5uISvsNgQA/ZvuY5JaCxkRv5Szo8zOB0LDCw/SwOJVWGyudYI1t02DNXBZ2fViWOrQ5S/9qrlY2WCXtrz79hdlZqNy7AA2r4ZGNqrhdvmNbAFiWnBmXiVX7NtXdi62V+C7XXEokXLyd60oH278699O9c7Cya5q7lad8k2Sqj7v0u+mRGWVNX8awXfuHcIsrrr6auQ3vfigcvJpM4oaij5py8x9DKInjrUQaLvMkHXqEDtG92p3YlGbvX5hd0I51/ocE4m5zlrg+AaKsh/CvNWfjANELoDDynnIQMbI7b6Iu8s9rDIA3w1zonF3+sUZyNOhPAj8m1YMGTGBcjoJVwKkIWsfLIZGdgSK2n8kCJPwIz9rsJmk9y13gJg0CIr9FF9S9fwvtq1kVa7+ffuhYPcLttmaNKVfXljO1qidKsETTmp7RtfoKjZw148fgLLWhGJ+31wklHebG9XYFddnnW2oABZIelKZLtSDqO5+W5ZkoW70rCJsWxRnp3a7fVkuNCgRUQORbeQ7RYj6lsyscpGNyH9RbSzjnWmLdKj1D8rmnh2GAD+6R4mqdK7eXwNAMSOp3FxZUDxn9hTEdH7lewcUvFCKzzmbdh5CyjyNxjsfLkoUEgc7aF4ConNOWxWQomxx/yk8s4eHkFjeLrxHrJNwF6bCImRi/Y1+SlmLiMiuIbqSoDU8g6TuDK3rCjMMqM4xXQFVPk6l0lw2XwPKQeGmQcE8RR2ZVuoKE3xLnqjrygY+Qe99j0xYErutxpVBb93vdWakxlTUMY/4bSsi/fsPLAZiKOAmS+078E70zsjGhxnFpPZs8h2GHyjKXwRqqUDzTKGLBpJySxVFfvCb84KWiEE22oeQ92WZXMqZo4aBbwqQ9pj1Pw9mN+s+IoYyPtXkWtvazHl7YVfr6p8QXfaGA/+iKfryM1GSofDAD7siGw++iEvtqkhTfXq0IqnKk3Ncn3bJs4YOAQ5iYHGKNBFu+jOzRpUCndc3I54rkR3jba1ILlDVFsbdt94w1iUDNEwZrzhbnAtw2cYL1FBVEs6+GlS+r1cTkdbi1VNhZLUqGN9MyUszFfGHme3QFoTC+QZatoUjn4cyT6Pi01nlR20lbGkvrLXDDd+StpF9P/6ySnDCvsrrF69khu1Dgi63x1FV7pg6aSUhAdTbMDWR5QzyblXlvfr2fT4utZqOqcx3J9Z+lXUOhu2uAwZ/hz3//7wKcSMUgY5/lGCO+WDK8q4XmhQwkc5DxrmvfwuMXmGIkImOm2OckX/OZDYAB+pmupns6anmIELpN6OGwzqcpBqM2nO0eCIKcZQGKlE1LykzclevZSuSs1W93TyUIqZl/5cFKkDlvAMFwZa2ZhwI6p2KbW9g7gOG0UmJXAaKMzPfCr2fe+R7uQjTwcz6X7gI3OoMCIF5YR0Poa44mam61XPQcnHqrzLMadTkBGYZ8X4NObPGxgJzshZzl7rGhqIxvUpGgzynBCSC6zNqrLAaG0d845QeH7pCYQnUvcPA+LOES26y364V9VtsDd8BXMZlWpmNvATKaxN0IH504qdwmMgERykBAccO3QuQ4nWDPrIHU70GXrG4ZTMuPNy9DYLRoEEhbeOL1VDn5yuCy151/f+jAynt4gFH8BFg2iAKPmUg6olnbm1WL2MOlzgPaqpUoRa7ctZp1hWe4vwcGrhvPcyNL9GXWU2TZ3CWfOH9HVBg67xdvPNrKxWgZaMny0ymyby836FiBVNLZ2wjC3w4m1VLFf7u1iBbKpPvFXO5kC/G5G7JxnUnNYsrPmbBnuKbFTH/l3r4/pjRTL3jsgGZ+Fz+XWz74AeiCjvPj+2+zAnL7YE7aoDp1FwWnq8n27O4cb5JXTIjeIaR406K4VheRTnKqHC1A4R9E6mU/1biMfs8qohPSIoDfiqUQKXaiIClVsh7ydQDnT4JI0lnrjeYpEo3RMrYQTqhonKOA8EL+G+jcoFhbx8bNEsQCLxoULU+LXNNsgI8eZMjH7fu9fu3ioIa5ntkdzvfQCoE/x9ZrElFg+ho+0aiAn9yypNgJn9BDkDjQJ4yAJV23EQKctPfRrLN+DYzBunBgNvIXoMhFQtwVOlog5u0kXNcdgrzhtHDunutssePE1D5IA4SFcnhnUolCJEEcM1Mjn1aKs21Hm4jDXWHsxmDBkJ9jI2SVLpZlTXr1zjlEDvQvJ0qXRCdsD9isL1D3pedx8PhJ5ltqPp2nu4AfH/e0K1M+izLPchYhopYOJU1wCNN5LpBDzeA66KUzwHMqL9MZzv03F7IRFEr8T622/Bq113L69atV+2laItLj/2rOQqoNdZCfORI1OGhyWVjaLghYIMNNne2EhVf1fDuME3RaXDvp5iGXkFcFG7qLJRO8IHmis1+RWYZV8uIERIXI5SJAKhJvdqnnTlKrMsHcX8o0VDTo9JnyFhBVz6Qja4/TxK7hZ9rzIYO56Efz7K4uL/LmJrU3Rd2tgtHK8KDCfCxdCKWKUgsKbtsw7mwNqmg3IX3EQmmRdghZGc6ILO2fG1xI+Gg19Hi3nBvo2XMaCGKU+rHFPQ1AEwRLOvFVELL7z+jDpPbHEvNDqegY/xjy6sbO1FZainjUg67RHk9WAWt28P+0PAqZPXcgDxgeil4i7WmZOvE8eZS/xiToZvNRbwgUMQrgX8S++ohwcZ6RbzyiE3m08i5a0QKyLH7oNxU3I20IFa7Qbzv9FckOPzigtbvhSmDn30bvUYtqPIXWM+R5MQE8q+cc5G9iWMECm8W+bsXKGpmYZyFKEMdEIlrEwy+WQD8qDBqaAnbn2/KH+NJ0+UywvnPZl0ivhUMsCPXWIUbLgQyLWXaq8rG1sxojfyr1A9VKuj9dzqVF1XFzRgDwqZ7rUDdctXaZpWjfFlwBYTTJuBHV4DuVsIgGWRpRbWFuBnsaQY3ZX86JD8QojqZMV2YZh1VrZMGZrujjeYL+Oumq9QQJnlmtbuiEFw06HPGJqAth9t4yjPtfoGPYvXpAj1qQMTUVNWJRUaWz6p1KBgN7QZMtoceppTAESK64OfkiWWwVwhsZsVB8PK76QgqWrsb/f7sqMyprWuBDtltYjwKvf/HIBXRr5+CXomDrpFT6t0a0l749w6mDLWBZ5wM0SUE7LBEgBrhm/43u/Fh7BJBNJCxeb7Quua8uchfd6LlT4GMuQ1DVUjd94rOZ0sIs8WBWBF5jNhnDFckUl0oes1c88AEN29pM/dBgyJQTcPi2vPklnZpli+j7gQFIr9luE6Wa9Q/tFv13BSZfZOVecxA1nYrxyAnODd2gZJ/A69NRRUmuv9dptWRSULbWTRaG2w71yjccB3gL0ikyw+KUihzSfa7tod6Y6yYZrXvuuKpE6+QWgDOO93aoFoeR4LJ4Dhu4R8+aFuvpcltai0xJCfQgNr4K1T4gYuQel4k2lmAWp6nxOBbnAK0oL6Ee38KZDq/OHJpFVaseWpe8elulq+3zeX7vjHer0/lQ1of8/OYB+PfvRw0QCCpaleObvHBMrJH3R2opNKFAbUwxIrkpcttTCrEekcyyvoGgB4VPQhH29eok1wQiv/n51q5w0LQgM7p5vXPP5vY36KS7fCpxcXdrKPu6FjS6CsPqgzshF+sMZJ5pNn1LykEscSOFcNRVBZLaSk0erU+6GjpQENMPbxTf7LoRYTPd4ZxZpPnNsTYZjE6OKYMyPB+qjyFMkUft3ZyyO94nkLMjIRExfDZOuYiGzaS8Y0WulzoWU6oSMZYJZZkWOEyOU2k9Fur7aotaDbJ1nWTgqzgGTx0pJIUGqYOHsTCgY/McgEYYYRleb3MGrtQNqORlW+PvVFzaxHzLjEm6XURmI01q33v9Ua7DXxpv83Xs1JvtXHIStN/iVkOPQrCvJZdEPTMki3yGWA6PnuUlIelUlLEjqnPn02iiwO5Dy5bo0q48k8SVu1ybUwW3kRX2QAWx4HsyRQLfPNpwCN3GCQ5ADph7R1AXhGyQU0m+UPyDcGNyaHwWDRj0uS4hO2dIrueVhLV/Q7F27aRIROs6G3qvyOUrtYaaLUiH4YumhHw0LLYWnliSoGXft9G+lMmJhb6yLlgzYVL1xXgbT7UI2ttMglHNS094sBIxfEcyVayaqWFJkGdHsIdqWbgylmpDfoR7RfT/FMZz4HkI862c7s74g9efLwwEWrA9bJOXOD7srEH5mx/DJ6scQcABYiF5JVipApVIfJosiO3yPuO2c0iwx6Q+1FLNqHxkh2Q71cksIlsJLffOVit3qJ7BO6e2SNWIo+A5sX6qrIHzeIJZXG0xKimK6SCqP9ZKYQFYg78V0pmJd54Kd3OI5PAu3yJ9XiFMaxXpRyjnQ2iQ5hE7juZSGT9tidvH78+X8s8NgU9cWayLH4Z3XnhrOhk8RqQVvQTgvgqbFvLd8THcL+74OOo4SRwGSY4YiPaAot1ssHVm+Gqy8FVQmE+JHsNLC3UJ4RLFgsucFnJBE+mdEcc3d9UHctdFoDBp5R10uOnN3NXdsLiDMspURmVC88xhjX1FdR1A+WE3SRuxVlIq87M6zL7LAiTbJ8uODREJA7BEABK0U0dmtdXg6x2/lXMrd1eJ1FiNOMolXmx8nN5xRn32TDxsm5gtE5xRQJbFadDWWxRsf495dlXHsLMimaLM8jBH33QMrTMTzEhvn9aSFca1D3bPLxrTA3Vx72IgVQtHP2OLzUxXEPFHfHZvZ0bCZdX6ps6lbyzSoh1jVdb7ikn6/YOfnFj5H7m/ug/zlhQ/DjKNDlX8PMY/bkKpOcCbnKGUKxBhAtT9ZfX/3ka2KJ6wHbJXNUgFF0DwzdT/vb3h5WKpQUW2pHbFO2Vjl4XtAY+Xu4BoTG6rke+Jj9mTJ1z67N3k9zA3dGp1C4ppmGDgNqu9eHYGc7EVgzMdv9paxnr9Zieea1lErAjQv4e9nwnPss9fZalppBvgb6JwukSPkA4m3dhTWfDmaHFMHXxRnV52P6PIHZyr0A5Ih+7NpaqYXDh2yAWSjAF1dnsn3Bmi1Bm/AOBIpiI6p529zfw76edcMCWVC8xAYdTaQWehavCOxVm55UaMTloou6pwxPabdPyLwOoLYNfcg1z95DVtnkI5bUmzIQESiOtlSXxK8ZPhx5/J8tWT3uhc1RFV124ws/YQFkTrFr9qZ4P1exCWS6rsj+v9gIDIpwMUlRAsVsELCz6OzPV/eZ+4hfJIAUWJarthdGP3vqNC7ra3fAxGZ6D1fxK+baEy9FibjAgxT5d70GZYHIxAmSkRGE+MfSfsVRtYXOPdq7pszmGObnHOAk+XkrsNc4lXoj9gDEYoR94z3duyA2tYCVpgkqe+pV5EWFAxyosI3cRngdl/q7tDLDCJdHgtdqGKmpmdDU/jaVpYbxaYxGqvOp5qw8RQLgUNolshmx//tHWPmnf2B7vaZg5r/fLihmNvjgtkR94VrXsRR9DQlIbIYXzTQq+x6Z8GRmygkg7CNv3Vk+kDALpgxdV4udahqJUDRxNKh+1ROjte9flasRJmmzCLUA8NMgkdkWIyWj2rh4lt68yOScJctp/BurZh8GFlNDoiFJJaNhWHvwxjZMzWttbNoigd48OksldKBLAo9jqc+ul4TO84vsJoCfJlmqq2mRBBjQ4k29O94nyXtUOSXPeM5TVPOlPHnSo5tbIxwjEpHjrexIl/lRVax27fAtqq5JQDxRmuGu+IgPW5yLQxDB5CakmWE/9Ixd1Xjyp3Osjy/79fA+A1BpOU3dmLg3RHiOTsrIAwxh6xRdi60kDR1/nmfLUeSGEzZOaKsFMwPHKxgbH2aw96KFXmbTP0w0eJ8gelZjpHhZgioknw8ML4Jnr/WEpaBmaTBdpHTCfuUpzNdBNVdnMe+rY6xw1n1wRae5vP29RKhiRWzP24MqjLzrdYy3qs41oNA2twMi0/28bXrNng0dpwBTm1qawetDy1WCns2DKQtS1wDE0mX0zqQkzhYYPjZ80AD7a5yt0rTeVI47Fo5ZEXEifnQBRHAL1O9fyJfXcpXjGMWa+r+efoduId5ZlwryMgOCorBF7Gp6vzgG+s/6uly2JoMO7t7Z0l6EdfZfP+eVvtc8dwn6Qcl0gEfPl0n4ecVOdx17jgCSVK0FpW02e4Guy4Qr3T90lTQcRVGZ2VLGb2gOSf/DA24eWWla0wKOkxQu8uY/Y87fPsjufKGu0PeFGRqh9T8/YOCCgppqslGnn6oVZ4Kwjq++FkFUel2gA4pxu9maVsTNkT5dpb+Ji4i5VbcOwhQuhNDXR2snJdNkzlxsWC4AaU5AJdbaBHgQ+SwnF5jXGW04XubHERltsJEeLUk7jJwf6dAX8klrkaaZb+vgN8SGgndmoIxCimSRidxzZGVvDky5jq2YuryWv0kIINbirlywduncnrvF8KZn3esQ5y1VC5OKPP2nyKuvA4Wq7bY4QvjoKbONrR9y0Yg24npAoU8wmdnat89ivuIwyhXKTIcTGfEHgzlf/MKE97L6ozbQhiAn7bkd51ZCwn7bNafsxltd90tctwZpZmU0VGcxhVmKnCGvXqIzMolvxv6ABXm2qzWYz3HCGB1ErBil9uOsJ5MU+bHOxI3+yMvki6X1KIFeEQw+eMx1SNQuPFF4JuUGgrvS7At2e8nLhzHIbHnGsahdnnLSdCjjQYJbO/esZKL4qRMVxy7oo8DOtiMpv+lD0apnEp0rvKQEn4NEoVpEx7hpqWJJ3rOElBEZD9vfrVAT18VMibSIAvQVUgH4yLZiJLYcwO/+GwA7D2SO988xrwvj0Jq6MVPkJUDdUI4eo9ZSedIcCgGt0RXh9kLTBlcIjlTZsqctLkkW7XEsZIBKa3BB3YH2Ox7DKlJPw52/MBoxQAysAYPr7yGW/TY2W0NHNlpQQQBcL91S/oDJDI5+LSUde3I49BmDWte6ND9qUsdZvh+xUkIGWE4dOn4kT2LEK9gKR1KJacLlnEzWsRWhWKVDbafKJ8yVHwlbfxD5/Ou8DbmD0VCuJWsOZmTh2heEORJh08qj6/o+mzWePcU/EvxWkmfLiHop/batjROxvnh4zSk8/9jQ9iRNkKBwXWQ4KrkYv1INUS+QIrf2Wg0aFU4Chnayheiz06jpTKArAlg+7UB7kPI5fQYEkQiKgJCJeIDsnALIYtlLrHoH6Z+CpaMTZvT0fAjZ1KGSdtsq6DuOZIbIxktsrCVMOI9qWVpJu5wj7/bElJuG1b+BeRNHlErVHDktmtx2zK+8ii27mCNfdppzIeKxKsHvvb4J5I1iexZfXpRY1KZS8aMjhXyPJ9oUlNl0YySBHVy4eEGePpM9kq4gXlwIdsAs5mYr9RmfyVGLCQ8oG2ChphbVtEPJe8soaL5ci6IzfxhOCNGvyJUfDZ+kC0q6PbXN8RzCecyaDasMqHXAB28QYZgBOljl1lkmpx2JlG9PLNn4cDznPS8iM24zh/HN8ENl6SQX17oWFIEiAKVbZ8ht6V0T9ukLZWjYspR/4OlU3tnSA6Yi0joXy9pb2my6uKT4s+a7sUJHEqLy05i1Ne2TCLBkkP1+19tyQn4bVAxZ8SQ93QoVvn5Pi1yf9RqmytDipmoVAYIZZdknAm04TrrrAy+9i3OYBw14CINirsiFm3yvCWDmA1Qj2ocbxB3lw+mc0Ce0pCRcN8ibGSZNWOrfmPKq2SfRrzLzpLGoUMK630gEEA003OHiv47jVLvxf8ZqnED5/yjQ+atwQwgWa2ZS02tyHhh3UJgtH3uLlsA++ARK+6DWGM3bdoVAxBTOUqb+VlghdSAQ6IHxEpKNjuBifuWJFgO9Od61rsF0aI6yiiMsf++AoMT3JsxjKYuTl/lyu88WsoK3DOV3W+IH0v2IGxCxSQN91jgZnjmLMGrwISlGXkzB9mVqBHdALcCdIuKNWFePa28Nf9o6iveFQ1E67KJ4c88EidXnF3DA3c8bX3/zGBFO2d5HV+uF78Pz0itViklCYo7XYdZD0i9XH7lJ40vn2wdu5c4gBf2x2zWzsILMnL6BpLxjMfVxR9KEhqgXlbMBiDoIMVU6B952BSAEr6cf99+2ThLfypzLz0zODgE9XBGWCzQVKf91k0kDIbCube2ebUlOyeUkaAGBCtcNICpQ6S2+Xe2FKSpF+CHZw6YFFsQycRhRn1FbjQZ4JhDn68AWVImY419WzDNOlj8ye5bSFxn9CRxxdFCleXzLJ7tVvOY5y1A/k5ua+W8abC9F/sAFJoQaby3QZ6ZofTXz+bWozHc0v0gGpmNIRFzjL32fqbGK1jnF0BU3E0yK88hwhMD4Ys30piDE8Qc/r9d5jwxWC+JJm6LXl62GbT3WL1pFVaNA95FJyLyG2YTI0z6qgNhKIGUgDuNVpntZehK5gqhEoE+42f++t1ZjKTlIwxHUAffjHlemTsbuFfYsUtzWkNMGMm/gUbrJEkqqJs4OevPKaOmisZ015XsqWGPI+kYVqmZP0Ldz0JBYDr3BOFWA31j/rjM0i+QV8gcEWjbSqxGoZdZuZz0ODxsDoGOzKS11g6K3puGKWIdvix4iOc+k7pZdFFKeQlLx797gRPJHPCCV1M8WiCV4TOhDzWKOLPzkrmVxZIK76T8G7sqxgWBgRxtNUZA/zTt4/UqaUbZ2jYZBrBWPDcURWHxO5SfAyRpSgfHC6KnL4Z2wyK+Kk8BBfUzx07oGtCVg9nP3l8dynJB6bfh4X0qszCvXTR6LejgWm7JZmnDreQf/0A6zqn4fsaL2jNyOmf+wZTvWWlcYfkbIgbDl7ZUCbofX7dS1vVsCQ1i/JCpLwO6J9jdx4tLNMTNiX5OuXbujaajSUg6GR8na025+YYtto+9xJlaGLtoKNFhY8By7fZ0izsQmIxx6Z4NS9dHb7jxGa8R8+/wcShmUyEqolCjpn0PnDPzx7P3lbNpwESkVx5jHpIFOgIykJGToPNWMUk1x7BShnlgToIHGsZWheEbQdoAEYqjoBOiffc9AmxzaQj0DyA9mkttQ5Ce7yfX8dW8UI/BmdJyHtRZAaVvKxUeVugWedDFdjOiEy5k57ufic2aKe89HRiFtU9oBlpETARmMI2bSRF8HdJpL8ggHDDQQj/hviwuJyfJsfcdEEhmQ0v/Bphbwrz+DAW0lFHk78R/bpRrg5v3XYL/khLvqr0wSuYb/k84/20Ogt2qpJubfeYcP/xy8BGUhwmdFijFZuEKymDeM7EdWUkETmtXkbKguE2cPcVPmWV4O374Ka0aCIMeKisnhU4xwr7hbpCXlQuBixf8tfi1TVVzJK44qQADv8Gs5NJpR/6tQ/7uwN3TIqpxSSGj/2D4w2iylPcGchWEB5vJrq7QZh5LfFhEMyBnpfNMRyDDEthuzAFeIDu/HIqV7mnG1kfNhEHqZgJWfAeFyhebP6kqUGfTkCAvw5SYirfNHGg2l2bCQExgUDmXnxkXOlhv4Is4+ZDyeWIHJYxMRSeuhbXZXosY4PI17uHpzOM+aAEoYOruj/MrLE7CW7C43W2IJ7soOXwkQGfgr9TIBKHQDmTudGfHYfwvM+s3GIv/wQbHZu0ZjmQRjzWXwhDfct9Ltv6DJAEdErMhe0cTLo0MHJoLb5JPO7fU8IyCAj/znI/9FuNVl+8uXw1gFKkHqJRYzI1IRriHnUeSLIuV3bcVkdjFOFu/YOntaw03Z6jLFKUS49bcKj4oIwBdzw2/+fZTe3mncX2KVk6eMk8DskK9hqM6PZaDXZYbAerLkzfcQlEYnmF6Dv7Oivd6N2zxv010/4bJkPahnaP1hQWkNJv9hiZ3FJUWpco1i1W711POZpZ/NZWrjzM5edSiASfyOlUp4d40Grq9mQPgiGShvOjy/of76HoSlTZrk3G579k07y9IrmbQdmNJP+Bnjxi6QYt/B/rspaZa/cn8sQ9DtWT/gje422P5Xa8U9m3pOUkl4jlQYw1of7WEAdsckJ2UWsOa70/YymAfv/+FnzS9eCPoclNGZM+ITG5DvIw9bjh1737Ziv67gPUZvD9OBaV2Z34aNL+X+WAArXWVnOOIaUh0FGoNcaGnVF67mIochNuSqTnDi1rzcFFrfO5y9a/dYJRdCFgjGFFEMjMVKzT6zDMy6SEFvtb6FpKQfcdcFhKoNBmXfoc5/n2bc4obnn6SmaKnNjPRJsMFZoqSlu/9le/KeUPAg4E+zQGvBylRzsMrlBPRL6/8VhR+OiaXnXgwkFAAeH87rS2S5poS0NJjLfH3HO5hr9HM6zG7fW1ii9fsw7kSKDiwDK+yCI/zwqSTnXvD60t4aPx91AYNJzmDE/ItkJmV9n3ocRIPwc+f8FDYOV9eJVX1xD+wd3G205jhVMaDDdepcOEQwYVJycftxFBYTBs9rkpE6LgqXY9kvNyBp4pdUZ2MY5JqiTW9LxlcqZob1QDOZuvy0Kqwi1etKzG/7ribfBnNJ3/xbX9wm9qFw9N2frId8YuZl8YhsTuS5Z5csijowrw4bGBe0fkhjJcXIS1pm78IXl0EGl3Lwgpr4chSDfuLyi4dJcjJ0pCyizhB6MjlnSyjg2IPqLPr/Wk8RXFF0KEcsvoCrFG+imRANdqGd6fLGqemOSQ8PPYKhZSvABWz6b1tAM9jYCxzSj4ZQHwacuX/y9NI3xDUHX1JZ9OQGw2lwdSfvb0FbAUiSifYW+4f1Kb7n6/XUI5TjEuVoVSUAgvfXoufwfJfFn+wA3tYGUEwIytzua2YTnndlvvfpFNGWc9ZiRDqYdM/RxUeyhRRq7tTZc0jxjITToxz7s5F8wi4ZH9Vr8hkHdj3qQZtRHKsQyFn66ta39dH0Hs2PCHfhNe2WBsW2dqPrCPJzL4icJUTSY3fqfuFBe2efqCuLeX+Cv4wGpzSAWuMf3PHtePQyyiSuxoI+aBErmxYBo3rMfBOe7Zl8yuXG4nYUTxFYp+ZM8po98TWXAy7o5lhTBluRlaq+qBgoyWY+h9DFHBlCOTBgcl1mchB1slL6JzGy0ow2qAfAbCyZ5GvTLhr4LFqNUoVZ0p11XXJ9+KP4ctUjZAZmVzeOX3mb3x9nmPVCHDp9zYg/5uvmUspTB9KBwSOem5wcvcx8+pNAIGrKfN/0HaQyguLdtPxAQMQ7825XVc9gLVNLhHqPC3l/fhAg7X0Kz/A6UjVRIyLhZ0UOXbXblR6QKZl98yCZ6xkgeFcUyBwpymMZyWItw9760KvloDWK6TSYiFVIwQedpZJdCnJ6roRmjMaxN5iLVCQVgoTmadOHZ8pWKvXfr7gwhFVvvZ27ujVEfMsDLpRKBlBeRBloVjACpfzMWj0FUXWCwqirGEemMWAQGohxe9YP257uQSpn279zOaV+QFSXUvSDJfd+PNpgQFHyqAwcBTuHJzqrv2AWG5I5FAn3Aq9rD7ROW7e/fkO0H1ueNkldWRJ1qtbT+k2/MkBVsaCO1jssOLS1ylPZbTxAZne2I2/WQJ70inRKB5gxboSSemytD0XS6eeKg0ksVjA2DDPTA0cS2unRgHUrVvFkYZt2WKio/V7Hp27GpEBPC31siZxydnwcyCY+nKgnNcrxGnZcJIV8HPn4xaPx6YI2DAgHlV7gFS4ObC3rk4KS0Jmcq800+UcV//xYtv1Y8GgpkhzHmLKby0Lb2W6661ZFhaSI6cgif5dUxsV0a3kCayKykHjlAiNG0wkPBAICIzA4C326nohiU7kvwDfl2pG8C6RkqCZWN92D18w1RoHWWThEmXOnTZ27JlKMxLFf7HGdtuW//TRrD4HaGfjTHHoF7M0tBOpF4XlYYSSSGB8XX7OxqEki+jHuUfS+3D5HZBZTLbXxaHSk1GcBf+ineXKUWG6xlDhymjiVzAqE6aTlNStW4cjijzGzDb8oeaGz51fqUV7rSsIa3OzBGwIcC78FD7x94XYGgARWZMm6sw5/+hEHqF/KLbuEz6QyoZwyER9JzcAJ0DGpFLRLVfZ4L/olxEUdQL3eVlcU9oNRekA4wVd7sKJZ4M6WXzZA8oGyOu7lElLz9/u3b9pwP2hBgbZYc5a1tmQJr+wgmMljORHHSCUz//324wdvs0FK4lsM4POmuUY2etAanNsovvq5RIwjKaDJ3MFw6QC8B7P3n1aBz88xkURaZi/bgHv4vzBb1f760yjmDpzFYgY7h81iNw+a+B1DurBiKMNIffJx3z5DIG40CmLUpg/KR8Ptj15D0rH0hLEoZtgRqVtZ3a2dWIpEpZWIfHEwpvQWJ6ATjq8DTaa6sHVkykS1pMT6tiII2AnddDMD/AJCshY/IR4CY7Ns37b6yFnRasymkSYTM6bc+ZUslRysXWh3Boopnk3dvXCO1tc+714xlUvUi103CmjL1c5aH843POV0JcMcWQsft1x1LqJ+UXBnGQqFkrrY+aVlUDxVGq53cjkWmnlML2CfbXPzLyGaFMGamZLrWft177T+IpHkedtVP8QUdsf7Mhf85EojmXSQSjXfChF6qqByTTwkDG5dPcevA7KAEfqoVxsOo1MB9rXatrY4An/9aoDWBs7gHvvQxKp+/yn9NHV0sC2dwumJcF07dDzP90hvb91TZtAsek3s0gWXQeds9Ju5Gf54CeZ/27vlaoOe2QzMGs9N0oUy8OmQPVT7IoAA7uVVGPuGyPq51+U6HGvpP9fG6Sw12m5RfKBEB5DESZuDci4XFRHuXEAy/aL8Vr3nGkxPHdtKi9R8zfwMrh/NDJ9sIexfU+PVJAhSohbABxn+/QCEZklY0CpegAyOPrHRUKCB5oS58U8NJkWlKLZcOllv5ViHPLcVwC1649IGzDvYhQ++wTLP0x7hxT/JRY4Mg3/Nt5Qgo7l8azpYfzs1bq7+DVTxPCdYmWGtJWH51uSx1GhzxkrBEQCKX4Rt7j3N5L5s+1krcuT317+VsNhCckz5IlnGc4m0cA78VnJm12YVJrDNw2qE1jCY6aCnwYPTWC4S2S/WhRzV71taf1DdVrNIYYFkizKgpcIXi922GSQ4pkZSeYDmAv/976kTgms9eqH+dNMGVfaXPARyPxp6XcJ2g1KiEvl3HfSfPgo0VR1DAPrrKNZ3oJBHKmEDejEWPJdEn0QkscsAqdYd9waTm2Tsu2ua+puPK5Tz/T9Ads8AsY0E1WBDQOfxMjxZu+7m8XNzDb2GfKdRGD4apzQQNUvvpF4VBBbF1DqI1nTziBqolv+cO29Ad+ciTPaaB+txkyGFbYNRlRNsCXRCg3b8GAfmLh54ftAnTY6ACv4y6RNym4NCgyti9sIXqCDeDeBfZGpkd32ucCzyMurMegXdSSwpcihAF1oht2rrzLYi6E0mmLfMSYl8aFXm33ewqmSViQsyqd9qRY6xi+LYFerZfT8DQAWMe9WD+2HwKlKkUCkSNFw5H2UQs4OZ369ileCjSndj4CFkxuXBK/0CuYpPq25WNb9L6QOAGQpk/s2utSiDM3VFq8WuayK83y79e/ukf8rWMS0Z9DBXKcNv1t34LyZsK9LcT7andKdx7xL8bZ2WgCgMV6BAEZeRNSH2fvbflLJkUd8tf0UD3I/teVHMe5Cxmk0sSy6BD2F76JajvLobpLUJf4/HGEa1GngeLRwC+bgbAjMF2d/JuH0c1CEnXf54qaASoW8QVrkPInvChe1mzKhe8kPhNtd0og3JFzKdpStc8fbXy4fMx1L7Kv9wKvin+C0A0zhnUiHZRHGFkbcgIXLaa2MEmS3NNGGTklq4EhF8PIMEDVrp8vWQ3gBjFVx2F9mtESjkEXcR5Drcg36n7FIM/zQ1nCp+nW4a/XZi9TwL6t3LPbfq4JFUMsX+U+fsBdnFhVK1ca7uSNX1Spmv8oG4QQAsNsGWtopGFd1xYOaNVkU1MoRSASJ8iyHi6t/mLmKHh+FeB8dHe4dMcMkl00C3toAERDheiv8KJGLwhsdZNatp0eQx44yBCMXlWCStyb23/p+j9OM/kMmFABsq65wQHt/1ND3vIl8+P+uIi59edjkte/5lmapDP+6eVi2OeXjFP4rysL/zAWTaEoxd91oc8u224Qp2alCZRj5TVD7Bf0tdS+3rDHBvRclRvMWnaITPpZ2HF04kfv6jUVhzx8oCa5s+iX1OO2TXIZzgF+rpL7/+/ZCinDTDcVxZc6sg/pf0DTac23o3B+OAOBl8UiMCf7206sWshSx4cXGXUuMoSo9+IWSl40gcmEyV/TCglc6+BLNqi4K3EY06Hj+a1HQshV+UiorimjjijEqR4N/xcOb89d8mKmnfZw05ia3V5zfA6mA7Sf51LDc8dWh+e+DcnkAJLNYin3YIHniI6fnR7srT1igHeEif5byDSwVTn8ymzl28tMZFyww+gw5FATInU8jjRfp5WySmgyANH0qBOON77YLHziXwtMNgMfv4bgIvhLIP1qliAj3lMMQseQYCAUdGZbSpQ7j400QyMu+ySaoYRog9Lfy+wAUJG6nbB99wxXwJZdLVtw+BBo/64NXDQqQxIf5ywfDRdhRVSUQjo6kaezpOsdcFl/O57pOk4B9zgbYVIQXQNa/SOjCDG6NLXT/h4XosIJkHPPkTBWDAliCkUhZ9mPpTmODXk5vvaJU0YYjuild6OWp0jtE2+Zt+1Ob9zu9WFzq0mCwxXzzpLTdqBmCgDzfp11woquC0tQg0fbbCrmQj5bAMV3J/63WlrMUVNdDiPTbwFBC9tw48JLe6HcJULPY7fWVoX9b+unvrgWcPZIjaQVX+JPXnDABr7ErEBm9YBq902O2lAHKs0dNgEGZ07gBd+0SiYMgdmjacRPQi7pj4Mt+nM/HTRxyLhitDIVkTNvHALg5BcZ8eKzvHSGfmKt6e+f+Q1heFhJl5m7F7K8hpv1k8uQCViqrLx3oGgZYzZ5XPHlxNwZ1DqNFeSIfz+APq0OaGOBT1IQmKfIsO7ujQtmO7pGrLnfNzT6YMrAgdut2HWg7tABUvqE9SJSmdlzmjM5gtsSVnQbyrZXGLlB4FzAc6xIRLyWYGele5cu9JAo9HIcKwyI9SDmuQk40Vn8SVaZizJTAwPI0MJNxmeIAA8AREoxpFxeThVtLbac4z0CIbLPEx7jYdWIpCGDvEYU/MydZ4ZNEGD9E8RuJr9rZ4zYlG8Ej/K57SL8Ywie8p4r8ZpvAYCFhl+kCZxgS2aWQTg7mOiW3aRMA/MsuZ/S0EM7M6jWXpXXkX60hDjHLB8IZAa16P3JnE8B3AiVAStlWY04UEmlYt9JH+WIeSb9Q8zdFX3f9jRE9N/JKJfW3d1sy8WQtQtPxNOsxlSe3EKXUvrZpxdfAADqK1V3kq2ryY66GBqqEOuRzx8RoX1lDwLokjV/Q4Fsxn2Iwlaoq7KBGzm9MYXCTLQRuvvWfHDKcX5E2Y6ebhWXGLMxBVeOuvV/PU1kKzvSnVM3YT/4nvgZJsJr5sbGRorVxQROgz4UKxG3UaWI6LFscDyHlNAwzzmSB9taLoH+Z0+47BdQxQpJpH1TY8JIvDtBsk6aRDDVYRxqTK9m1eECp39lQkmHkgImBZkl5oKX8pqOPazV6kC07bqg9b3gG9qS5TIk+gzLJSaewu/Nrzb3CQjUEmDeM+ZPhnrTxHO4P+0LKaMfG9KXHA9b0MA1cNepXMBghhKB9MBH+qf4smh6gFUtXxd2UAjR9zIXk10zSfC/DK8rrFshTEBMlHIGU1z14LXQxec+aAD1uaO8tdV4A6+dE4qcOZfpPCMMIzpN8pu+dXFFnhAGtwHrwfmAS31dhIxDbgBkkBQ6pqgW+OULYaFfG3e3ii6w5Hku4gUrUj6LbG1pOU5eLRBI7VESpCZlntmuCJMAXt6ixUiV/CrJ2wHN5RuZUI7Z9aZz12u0gECn3Mu0zcVhxWqmOwtW75ANPYkq2kVh3cIu4Fp8ORnyqmZF5v9QB4zmyVcarSKMEf7gHXiYqVIxtZqWaa/Sow72iTxi6p3khpe3cGRFq8p9hkOfsgqA6si+eIBOK+0aEO0VTWTwTFDJQp8KPQFaSfkePTJiav/w5OpoBcwa6Tw/gcMV6u64198SMtQo7qd7LCow2GTG6tltnjC9o6HmrOjlY7Uevx1uoH6ZeuJKZSTeayqXe8WV6obl5+TyVHZhu1GarOg8FgQ5mkDtgGN0jvUZjvrM+y4+ERtQp7Qk9Uz5XnrR7nUNBI5XkA2z6QgBPjoMvLLQ9wohY9cPKylbA2CAXweqoBEJiG95kqKx5Tk/I5LZWd4bkOvNvOyAfoPjIwZkGnZ+hAQxV2bI9O1QNAu30OGfuFxMuagIdU2rK+9M2qhvii9xXzKhway34EOtdRxJmZ4s6Vu6PWsUYQc1iCGbw+ECidJwpKZ3jIdk3v4vJ62eY/gxBalhTx6QFh4T/SKd0SiS88co3VRrJMgdYhOkLcq5soir2YhaWAKwdmqSLIUBQQvobUuE8MkKXsNsvi+eggo9pJ1VYfS6ufzwUyeG5sxjqmfaXej6W2huS2Kfja8M7glBzJNKYA1viv9dkFhwcMwldj8EcvK/8XIYzre2RG04Rp0APqNQkm+Mf/biU1Yisa+DrCEiX3NOlrk0Rh/3FqUtCfOoZh0Sin324JSlnXY4cChOffyDbipjE8Z9pPym1PVL9XBXcZUsrliRqU/iiZfPLJOedgg6QhJPPLg76ioPc0o/WxjNB8QUh4lfcfXDcpSeC9wbDWvGDd25BFA3eznanZduR9WoAnLCtsx9cQsPuaijPjKYvMRbvfUa8Luu6qoSqduvcn2hmfEkoYWZIKTqPbuSzs6E4hFQKZ2EusVvLHgRguKw3+Y7Hssn4EWyio21FyHMvVofZALkbPne/vKmlkAcv5CFZWQRtQZpe5RU++qML6sreSzju4F/7PO5TJ17+C5IsBj4cfG3yoTmL61ZaKxCT/1hgJTqHs+ZaB1YJvPedID4j8hBHkvfL2iOHrnNAS9iAy9HyEMyaP4jh2Mz6wm1q11FEzFEWbUxhGXKrFwLZNHMqjmTKV8KNM3ZQUw4+ngplbQHvigi0hDv1GzdX2ondbwIBx7XoEA+0527uzDtK1Gl5LQX9K+hmwDDWJZfk6nPRP8wJlYP5KxZyCuQO4QVZ2QVrg9MYPIR3EFvhG9GjH3FLzXuo8Hgi6OmvR/VrjEyDHQl66SZurZ4HmodSN/fGHR49nyMde/kk9Ms12iFIrAJxQ0y3aKe6maddV2RuDXu2ku287F8/BMJmgNBMDfj9cCpLss20MEEGxCeDerWRm9gyfAmgK/UAY1QUxR8GEpp6P251C95iAP5ILEUQtVNbRS41gxtI8YjPNZUjnas7Ku38GVE5kWjvkfYDCEzNZgphpEGmFawhgYOwx+1WpMFAAotbjDJleRdQJwx7qOE+tWw0c7yzqj5cNJno/csc9jKO268kRym1zpOV57ZG6mGJCyryxO9OpnsUSBdY2ub+3xZ5MYDtSL612tNGeJgCk7twgclkAW+LWKH51KPgAkRhAT7aEjMmxPz5U6Ta04PDld28N7XaviopXJexKlEcD6opFV9T1Q2LnQoxoqPWWP2lCaRe2RXzy854vtbVGuNqtyMnXvdE6BEthLHFjydTmA1qcpUa9vP3NKf8kIGAEAm1dr7bUAq5GmcKMKfhQ5Gr11qYS7RXkSjZNu6IncmlOWCJgfCnbKn/eBSjFVn/8uIEm+uYPvUK2ChFuMiRbnuiV3MnF937XQevh/IHrKDdVi1e6tYZl8VNhOdP0J0jwkXbQfmgoWS9ee4fHQpm0tcBuXQIFfyO6ZcSpoyRx00oyOMCo/o9LGaoNxWYgMp5g2ghOnAjMN99D1IlS+S7nmDg7jgwMqg/uGep9tHvbjXmpY7jSMVHTsUO5WdpDiL5z5nT8qi5gBuOHxdxOs4yZRM33hLaJdlIX1wGYAbt6DcZTNbtAl33vXhr7TkP30tEQrnjUF5QIaENzYYLExOHZllipM8dJvAfQla+M5l/XskhU12yEV5DT+lBXXQkqgNDVTgdKkTr+Up5R/fk+5D8xFz+s6LFJCECqT4l63H5jeYQ9ul+zL6ql+agjDAlZF56GVQstsJyg/5AMwTfLPUBUtLkdXPUdOEWJTdBJ1aoCGs6TbzFAjiqZiwa3otbeY4gBmBdKowekkeO0FUG9VQZJC04sfNBkaPHsazstqkCQ+5gJq3rRxy4r7UJiNrhP4siXO3cqYvt7NIsCjSP1oueowMPkP4nVk6IgVM98i5chHMNxPlkbc0gryG2OgeNnEMCZrG5zvPADSmgOIYFG7HBof3qJ3nYUp/dYZDA+DxkydJ9fBBzInOVP4nLgfYezLhEsQvjRdNrslU7cfsQoql4kzc8n0JjnQL2PwdEUXhHZ3YtL8xx8iPnOyR2nRBXeg7JLeflXyVSdlJnpruNDEHcWa9ZxQooxxIWbOlIq6TF2D0TlTxUEzC+3iR5TqHP23bh85Ow0OX96u4Yj5rkOBomuJPiPs/A2Nl/yzhfv39HTyvn6kLWqPRyl8NHmLc93TUBzWZmb4JyUr24OiC1lBqME2e0v5pqAguDzpS6abxquCN0bBUqw8G7gb0XX5N/3dNHl4ytsvng0PVx0hbGF88LgAkRhvVoK/ynFb2RHv8YrOm/0s6kyxtKkvmU8GfSjEokuZAUvJm9os4EQQUXVZKOAbmeqgpCUUPfKDnOFyPNEwfLa/QduK/uNzO/KhLhNnThYmobesa4krcZ+WCT325xh3azSxbg6YDyfeiSFCXXpShZsHMirGcMhYwEnkPd9TLdYu1TWHmL2lsDt2GaenvQRemdGwJyZeycLXZcBhKsGM4PfSHZYnK1hCUZhkQ8DTO/NalSAp5zOzNnNKY210EbIp6SvQB2WLh4NGZhdyOOdfjYlNwkMcHhR9swJWynYhZgjTnvpL8FLzwpxWRl3Vutmr9y/rGN0YAMeujjv3HzhgCxM1BxMEAn8m5xbNGP6Dp0Tj4XYzqJEphgt5FxVOCGM/c8z8VCcn+H/q1SpQ/YreqqQygXj7vXWEM7aUdJ+swvgc1XNrMh5bTWELI53GoIkaAwNZrxlriEtR9wuUkjC1DwETuR8FVA+vmqnU2/U1LtYdjcr2qIUMpHCEsKU+UvTWoA9in25bmkJhzaY6IUXDBRErFPNE8GAOmWCPiTnCCGpHf1TBfO3Xn1zUum3zI0U5ic6grKnzqj61GG8E/w9kmseq0X0mHE4+do+Wm3ldtDLNtFd32ZLPCtQeyEG7X71jxBky84ZTbTbw/dMf0WpL0+zOcgGWc55zJ7pbkrTaxGo76uOiFsxRxOp6aoPPyHIMQvH0Nl/ZIek0Pfemqnm5TD/gOEiS6svHaf2vwZ9ysULJvpihXj3TvcxJbQ1O28/CNg9Gq7GY+Co4qpUKM0bgc1OT45+GhaIherlEWIknEhXxpxkxa6CPNgNx2rAxTuMVIkoDacv6h8UC+y+9PpZdzyC0ao8gdj2+ZgiTrrHmpnunPM73XI+WEOnuheWsxkcdHElKdZNKnZB40B7aBsrhnxsrA47UoscT7LOQJUzPxGngGgaeWx6TyjIWpdHoYJZ/b0VgFI+vQrYm11vhm5ipeZO1X0BP9n3tOFSidYVH4e7zahOfGVYLcJl5tQnU5Poi+OFHZlahIydHd4p+zDQNbkqk0mUVja9/hTxlACr3MuqzjDkx6Nax0G60VMn2GEdae8Mgu+ZREpBXPLQzZaFn3cW/sEqAoRHK+kfuoW5zFiT7iCGHj/C/RXxdhM15gHIAcHTch4nnZ970+bSnfRmeC6nHRFwCvwvaAV9MvtNiHnFWUXF1l04ygNMC+QTlmRMD97E6Pwb2BtBpUSQ+2qEfBrn+JICie0cMPcOuxbg16DItm5L+tOiXRzh2PuubLsBEGP8WGDn5OBaBAu1JDjY60A4y6dP1l33XZZaP1JIpEAxTI6oD95FXFbTAClXWwBPL3TsSoebftsbOV+WqTw2b1tayb+4ixJH8s2iPLv4YHd3B0dun9r9W0KefirIxwlAF/75cKX0Z5F8y+o5pJLbw9YJaVO8OM/WGBl1i2X+OXPXH/J6ZRq4/pSCdbxEJUcbNm/cBewT0cFKJgNTc7ECAQ4bDFZ2U7HEmnvY2P5zR6dE+/0Egy/8d/4CkE874aq/t+USDAHxSsFNdHHknCSWHDWtmsm9r9E2k8PKXL0e8ZO6avxWraNY8LSMJSaq6lAErYoeKWr8Tq6adNzIW4cSMB1u9X9hFBfAxGl0dfoGQFSLxqgMBoRVbOdy63JTRUP+A1qKNo3+GBJyvjeNlyhderRIs8iBEs9muDsNlWKIoS0VsLXy0Q2DF7JLMSth+ByAsy0F6ZGMFAHvX9Ye+kQJ8p67u5ugOHfAlgvYC4/lMZg9U1C+LcGGBfzywO3PQUFaLWg0EHRGULkxxPN+ND6wADCNDFW5nsZz1Q+lb4s0jTydTsfsdSr/G59WRn7N0wp394dCp8WyF389O+PKxj/FaNALkws255ZGDyOKV69IDwjvXR+3pYSAfJfL5D+tOXL0JhOhTYDmHs9XZ6NIdPLBaIuncsy4SVATMJglLLaL5Ppn3A8+mdhzCdLP95v7clHc95alG1L4yQn9ho6wONKi7gA0+WomiWENn1gWEiZ0v37VhCREtWL6jNon/FkTTZyrOpjrt7xQX5g5OvIs9shZGmLRLaHxpDs7viRKwqclMc4fdwUH8uZrCpkyc+X3d8kwjV8797jYowlkfBi6wAMPvRHuTEnSAVRyDBM+EfsIB7K5Ytmg7y9MIMx/jKqnhvJjZ72xJdOxLQf2TXsY0DJhg0IGoIkSu+udOZlEsEnRd2fuVSu70Tm487cbIV4dKwgKhCO93C5J8ZIwI+ULx/Pcn94w+fMw2YxtuSuQUNpzB2QrpPikh+EWlQzun9Y3sLMmV+iYXHsFBA21qapMLhi12fw2mil7O3h/fFxBOHsp7DKjBb0/Mm6J78ww2tLL3rrp69C+y0iP8cnqkcmVaP6ImSoAFN24MRjKNgQsMNsJWNnWBPcqn31B0U4gJGP0b+vPHCU7TKg9DI9svU0BsaN9Fd79hpcrrFI/EDvS6tMu9oySfi7Jf+cl7JftTrcARPYB0ZDDIkbLzCWcN1sS7J5jlngQJWXFiJHE0PQMj495LFfi970FH43h0UyX/I0vQGz7gvRCXU2X9PqE6ROu+IHQaImPApUhY9jqsytZkj5yyymTq71yJoywmKB6VwkzP8PGM2NEJ0gLbLvIBXspt3SpQX3xo/dPXpZ8LD4K/Eu1Q6753uNLSPZoRM8wlVPLe62RJhseFWvRKRhqkQ3Flpy6glQt2CrrJd7bXCZNtxiA3HKK3xGn9Wu5KTf9KtwYV8sJBGpKXjruwM17GrIIFANrZHyS98iCT0mBPkuE25EnWhuM1QLdIWTi/nN8aD5Cia6nqhuQX2qVJhARTkADehlSl72OUc82cfL8uH2GlJT2mmAt34CPnIV52XWXs9zm0W1bJSmNnN2IOSsD8IMNttql60MFcJgm/clX2Y4MgevVSZ4vjASrMFua12DakhISyV8Yzs2x7p06c1MueLVHsv4cMIXSsa+EJB6182JuqIKxc1x6BD60pSCAZBVaNlh/lb14TAwTHWLG2TiyFF0XzqeueoKT915c0fctUpnCiDYdqJB6rXKXsTbIDgbtOSOgVUWiEGtQgVts/IVBuBXyB90nLtH/m6FHb7OelEicHIhsWGS3ixnqNVRv2XuNe/e2UUjQ+YwcRK+bqe3qndTRkq2d+5a+Duanb/0UkeMlUXlmhfP+6pQyr0RprBoAHk6atrLOEPJqg4Zv61Oq3DrnWZdqdEXlfDKP9g+o30amTU0u2jihvG/VQHQ0bBWftkNnIY1K0ySndH84cF+R9Xl7c+kUafSM/NMKqieFLe35yVxPQ8qKpUj2Pncvkn4k7A5zYCNySr06hq5NZC0OQQj5q+gWh/LTq/EehOQ9RpeEIhMdOnnQU86Ru7yoVSnHvu4tJuY5AMIGmw7acz4kHXQiYSHqOu99MsHsyzOSfFvdU6MSgFEQopaksMxiF5BLHRvAz7iDGcnrEYgMfVfYVLqLuOiVsdMqVsu9w9Y1zbA5ooHCg6VLDC4vTNbqyYKtp1nfMTDnx17f2o83dq/XqrYHf/rkbD+NYDT7QtqNm5+z64KzLMkZCCF6WTqJ8URUrXu7Es92QE6ADTUF1LOovWueTeE5JbCBciMjYlu4E4J93W0NAsQygYCgNmWig8HASxFEjCObzA4Rxtc1s0YzW6nRcAOi8ETqlj8QBK04vTg58QUumBmHKhFeTqMvUbAV2QeO1nd/tR4pp/HXWewTqGN3EgyrUbbdHzMJICc7mmwnetqWxChGFrzlS4v7GcTLBkqK5HFDTpYcY11IDfw9EIbxu86kSA2sJ3M2s1HRtF5yqJ2cnE6K314dZr4xgzAtSV+jQLt36P2t3rQUuv2nFs6Ra7d4pO+eJYzJPLu05FV+3cw5i9A+EG0g6FCUw+ahuJshG1eMlCpToFNDjjt4ClthNHj1x1+7Osf8L1qVZBWDy+USOszBBWxjJ7KfPmkPsKBwxeOeslniqictMt5ZfZFJpM6C9jQHJzmEyxfQLmG47u6bm6LPHOTvjjHcv5NAXHhF0mFM+7Uxu3+FOFxKOMpdlaVcexO36lbdfyGJyHyUFGBlxNIyZ6X7xLlWL/kTBEmKKCR5/CF0b/Q6iV+f+xi0/7tl1hWjvglOWEcParXxTans8fXMV+iWGLLaeTuNGfis2bs9oCURQW0vRNdfgOEeRXJq+bqQIkLSJw+mJZd6xPDyZCCOCHjtS5P69rsJh6PMbPLKR5+bvmUMJCU0vdw5TLXFTagN9WPEk90I3cdOgTbD1hEIHv3LJ/1Yj2cWM1UWdGHzoSxTXTng3sXMYQtiWR2l/Jh2oI02bzgWpvazMjkXFJBJxA7kBPGyzfrNeI6S70b0nty1ljl1wUwzl3Sy8X1rvPh99eqrfjDRM/zJDIEwpD4HBOM8rF4M53GWDAnrIHT7BwrnqJ2Adnj3BR3bqUZecv4qfKfSDNtYVcrRAi157FP4q9CxmRfMpnCrPSRokx/sAVPO77PfR2JzYS6Aw3SyuYq0Hc7IqUC37fjWcUGL+yNcMfI97UvQv3FnXY2PH3wqlIceypXiRNZxbjQT0r1xge1459T5U1CdS1DEkaTOxr8vA9cVKcG+UiKvljWdfxOuxrnoRxJU0O8AOEL2DXshOOG4U932dAA9smp63FXPqPCjYxMpyBomp+kUfhKrdCUa5lEZ0B3OnmxhCP35/TrW4HHfjFzqe5Z724B3QrweHk2X6AnlbDuWV/NVsMAoYxx8fo+qxaLplQx5KAdaaUwJJQZbIjhgscc594Mf3sHwcKuNrlEcrAX9epQLoHlVjOFm2+/DR2yAwbZmpUPDK4wPPPw2zhoYJfOXXbfU1Rf3n8KBw7u5AHG8uvMP0f++BK1RQJCaLIV+ju475igTnixjJlYYysVZNVIRdxHuaHrg7mgeO3YknhOaWZIwtWxPCTJIh30Sn0AWEg96suCG4sFBLPEWYPFL5nzt7csnDln52qUZAtFaTNtsFT8jeXWELOTQ7hrFUwVnyHj9OgKLXq/StpUQjqpilplfTTVbu2S2yCFP5Ikara9Ghs4aF15a4Tk3dEH/VCJ5waGcm+/Z1M8OCTs5C+lAXVjUCLZsFTfvC2p+vMNnnfO08WmFFp86etnRrqbH9srmKQXV1e4NRjQF+NsPFWFkXn2o6agIq5iejHkw73NXPkQBp1bSVRtTuuW0aMDEEtn9UiywDaJw7piG0pxICR/sQM4iQ0wQB4W/N3qJRXkOEf2KA6H8sXkr8ozABlzb3zUiONgofPQBin9bblt82KdSfdoGT+8es/3eNaFTqbNDYpgz2vP5+6FW0/hmEnRSf+O9ruvjKe5EPpIOgwjzpAnR3oe3lkb/6lqtWYw04LMmCZ9B/ZHVX967Rj+Fa9wj3RBaEtQucStiW45yHHQmq/WzNkSMhgXbAWQmxPQLi3spGOViBQKEWll08K5J0uqqqbUioig4GOafhLd352QB9GmKqfwoJ/0e0nA/37EUoajGRrC0r99dKtW939MQu/J7m3Gff/eD6074m+fwfORsyUwWP7pj3/JWLstnb8NWt75pcptLCXSRxQkrCrzUJF/Sunh3foqduihE6+ezkEa6w08kRuSx/AUS88rPZHDY5uxr4sSl+OrfssHLa4bx2FjLk0ofvnCb1zE8SJRPez2nYuhVVclEZ/Z6F5BMSZaQoNoU7RpHdtRqcidouJAnHnlfDN56gqLMp7g23oue/E5d+yEGX1nThOVxfZFr3TENYAXbMB1whQfrQB/11mn8+SZ4SWRNO4ZDUSHwLuh6Zb/2/FiIfZZXDAARFi/y9ZZcplhYyLEJ5cIIoujY2ccgkq1gvO9dIt2ni3Z9saAU6JUE/91sa6g47a/kHNHxjtlvh0Iqunbu+MPStKRiOvfRAwXKW9vR0K9ymEGYdiIVRhUM+Ekic4FgC40gAYWlSrnqSG2i+xmxX7dHqhhstw7hjrVY3NBK88RTosDRA1DYjx1sttyvmr6OCJWe0VbUAl0m/cw6rB3BEdimuZ69bWjIqe+Grzex/yzzO8ynji8W0oBPEW+/bQ5o7W1vEF0+hDhd+F42IJqZ8yNfGD9bFu2n2mZHjC8Mj/q6VQvaoBpSNexdAJps9ADQmg3KFgH4U5XQUQWgE8HYPUKHL6MrLYBrbDdNkHuT6FgXXOzNROVmBTfYPP7rRAgzfzVVzXv11KSjeGDt3pznOYF1jZ3h3FHW0CY37JJNz90fz9Yav4bhT2U4c8MvVX6LSiVWCWCHdxnTazukF+xt2ca6XGRJAnMb7iioolwDpMDNAD3Lb7piHz1o6MJFAz+lFE/UrlvJyrKGIaOEDeO00LczUyVDFAKMs6rjrwq4Sc2oiNNhgdAhnG5hFsMSlRnVwHe7rsddpw6CWVSdzKkIsl9VsQDryPLdDKWFqGGNdq/AK2xFBCBZyOnLwLW2wCVJ7TryvlXQnpKZRKet1KkykvnqcZhvHPC+nFHVdtpmay0y7uckxZTaHizWYTz6Z0DdqAPCyma7mBzGox+ieLRhDwYwkFaH01R4ZMvvAa9kNdiydTNiISzYHkEmYatms4iMQNFoZRSk+UXja1k1JVsvefvS0HJ61ZOc32B7cUGdHvjhWHJvdIzl7BYXv1PIDqReI7DCbR2ncwUfxV61u2QdVZPmc/WB1AtpAB3+GMhEqJOtbWFhcpcItYiZJPl0wdRTMpxhC1UwzPFo0xZM+QCRXVT+JEyhQDSWPDDsio6JUMRO1t/2sVqjuTy1hILqgcgdpLsOqFtFcPAZiDm3Pvr3SqfCcozzSJbdaP1aNdc76E5CHULivfyxgFjktriV13imb8Gjmn+K2tGb/28LL0A7ZzwzWSKozf04HsCkaOqh69ztN205tnNmVVbY8WhtxRTLQux0ufx2eIobWbYKNdcbyPjz2SSBO/NvWKNw5t67d/2xXff0UsFD8Td4A1Jbq4qem1PrtLI7sVmkCl0hQ5hRMps1d//eTih30zl5Was44yhVFrfhvnjQgMqQ16BFfWHj8oEap5vTeNRM065ZaZI4aZOuDFGX9B1dh1LrJtkYsPi9ez07agveXT2BhqRFJhJlo7pchVFeItQRJoDQB2Co5cDs3yfMETvY7vfvmBKV3g5HhOXDxrMCXWBW2TzpEcu/KjpJ+pKW+GC3Brqbjvkz8Pj2mHgjnjv+IVUOqQ9D+Xlu6OI8uXzwskYmwYpCjbs2Y9xQVQW+8lzisdg1Fl4P+uV3/NPYG4C7RSg0ejYIKouTPLriDAHGvgEDPzk/NfNCdJEPhGeYADUHtib7zRb+Wp/FDgSOE/99mBdkbJibI/A78ty9P0itw5ZkijX/GumwLtVVMkPQcPDNNlZ//eHxJj/W855tTXLzbMEj1xCA6FvQ86hsbKH+kkZGlnAzVYvAkaUg1zHRu18LNk5CPo9kerhAsAFbB6O8dYq8zWhj6secrMOlU7rQgNBBxl5izHD2zXJ5TVlWyV61rgIP/K665/0pKR8mQfX/GczJxD6wQkVgbKD+8aB4Ab5P9yqflbUfcz4wSFTmEh2lEqRdhDpTEAsPHL5nx8cF3jMB7Pckv31uxkMsO63jcg+CY5VRklSpFdgxXMSyYDZbrkXxwxLpLQ1PQxvRl8SjweSEG0BEN7YbxsBqHzvwzU3L4v9NkRCMWE0OW+s8iitX/obtMtOZXV3LQLYktHmbomWDheHsqW8sLFsgYxHdrUNiNYieKoysB2rgffAu5eFrvy6mulpXPS8QyGTDs/LsBEafRVss++WUPqMED6Fy/i/TzEzvsavwU0V+qz8T3X0QqLmH/Mpo3cQrIKNfo9TEb4yFp4/hcyzpQr2DjczU6HTDGlwXwx4/uXqkcjHM0wE2rqGpI3W8qkAIKz5PgArv9vA+74UsAbJX/28aVJseO2r2xPttcLuioaZyr7dLw3APBWvv8vFwu7OvwbU/8GS1DWWlfCWuFQ+ByzcVR+r5k5tjUPqeOUanbV0AsnVY+rh3PiEDq7IymOY/tqNVo+Mw5JOYEw6LvFZQ97HZQgAUZkT9UgA29Zm+UqkhTqQnLFydp7FEpX/WhQGl4k9PaLsDyxnEgqXVa+8KfEXH0U19vH1IxtR18zMFqd51JPVAEltBTo2+bdSMJXT0iz1R644FjmqayjaZ8uKbNlKIyICrkVbG5YBS3iRpzSsVr2rktJGx353/RrGtW2YG/xSq1GRGMbElMV5rjgxhaKTQIK6NCC/bWWu4XDjdGOswExgF/sBgixE00MPA6jOOFgDBcW2p1BNw2VnMJPpiUp+m7ajkrXUHbOgMUhU9dbMf1z4CKVBtvoXq0vR7xeE/zBhhcqWQjOQjgyjgtvjulOWVQC66i8P3d3vJcgixy0CXWq6vNLtr1EvnEOH7fxmhtcEbNmULrzN37kmlJsLz6gu0DdipXiEMe1qruVz4vxJdvZZvY7+T32m9diXJ8y+5YvUHBlZN+/kvfdw01t5i5lGZACv1xREBhssHUOMnmLL36AEU9K9MOdC1wKro2OoHkN8O8jFN3obOVNNmlKeU0SogXsRJDAmHpvvmA1HxbeEYdk7I5ftG/olYodP9TkJYhEu8f+0RnqsZVAAPgUYue+DqIf2+xc/9B8/bNhUCvK/wQPgC96VHqBjnINwE7tDBVNkK43rsLiexVo1wCaFx75ITeD81bZjuPiG8D9btEQHYPqutGd44IwXyoAZtwmacbNZWlSsWf5V82VJd/YcUPjasWNQk5HVVeDx+0HHWUcR57HBc/4wnrwE4RHVYs+aeNI/gKH+EowxRgheDVBYKss19RA+qrQu5D9YA+EZrirMh8Rr3mgtsgPGJ0ALOt7MaHdhGrfxxU3tCW2bxDCWgsFi7XiiSvfxtfr+h/6f6qUVOJNpkds5DtUsibzB4fOoBGhgDGjmAzTUQMaj4+TywFomoKS2PuUSidQWRv5Hb6xZ2LdkMApnpHuWYYyq4jX1d3XyCnT5Hr1XTWgz11BIc6qbJFAu69qH4hU/RyZgtFql0DNmBcNyjNNz3W/14bAH91w5peKfnOuetRFD/MPlIruRdY+vgOyeTAWHh7ATZWLRTnptqT3e2JyDFCJ0A3meZZVOz/At1XgOULjoAH4MzzoeNc2AZh+NohQfkO2Z599Nz7c2pj+UmRyneOa0uKV4PXNyI+N7se62Owo5rrJd9PozfTX+xnJ5oJQaUQFnWzkyWZyI7viCcoycucHLr33qaceHvzuLEmIg+h4ohA78wk7mamiEMcrvTCtMP/okp0a7kBdzZIPOwBEQtL82BGDgG7yO2u5mVpp+ahDl6byWb4qjPhqWM8ToKQ91YsfEFAFpIcLRHAlF/PdFrnIMTPggLd/IxOsbFiXvSWtMA/tPim+d3E5edUD+e+LOMsXP4f/mWKEgbHyOGXKAAv4/XHvMFQTOUDS1LyJ+0GXxD2kSdnbwR6JD1N0oNZCVd233hTIsfpYO2hVRwdZWrF6aZFEX3LiA+n3mWJby3Zhh0AfQh2EoskQ8Q9cpDZXA9Zxd0fHS5yQU/eQzsnOH/fMMpFSGmvyKphg8be2n8mxKecLDjjsOM7AhW4CmMf4BqewsekA7sJEUqnc2XoF2rlgSkgklrt6ehyagDQUeRjKjX3GP3BUxnnB1dmP++KWXeMpp7a7dBvZr1Jvpr10fyyJGcVNEq6cLRxfbt9h3ILO90wuRgU8kTgelCEyinAW4YJ0VrTp8rXnhDmIrsuZq8UZLUbM/S5+d5rsVJc983Qqzv9u3q9KXVNbTvhlsxkcXUxSrTEeI4pdr+nhPkxx1xuLyHgDGV1Yuph1/Ir/8q7wLcJkcgBydtWXXth3ovTOHLm5Ef7MkUhJezh9mLmn7vRdvg//uEuecig4o/MWdSqgKbidJtEbIOX7NiIutsMvhgJE2oOQjALleL2pC7EMvRjvT56Ry15c1Rtzz3IP+P7Bb3x1UWjz6Ks7Cf3JNcd4PMA4TBXmx9sJsA90aTO6zIDaIVttfUoakA0s7z+Qhv3QuL7e0kcuCHF6BIkXNY+wqS0h84VXm7miV3DVn5b7WH8wsFg4BSYgC2jHICA2Wu9p4W2TM+1FeTlCjkqEMmK4KKDeFYGm2cnEDN8+kaeZj2xFfv6nxVX6Cs//OMHtxkRqY77xpEbSf2alWALLu4xsbXVB+Dfs+mcdOxlxWxEa8YISc53Q/MVOSQqbEBjIYH/1fC90OTDITVSrWulb8mOJka8zV/NfrFcmDoovBRGAD5bDj4neExmVWebl+XxQK8K4RzGuoLpwwKepLorj6pL+fD9sO29QlU9gpYu9TJEsCmUac5YXUp7E51Jg00oBKzTAIC0/64IaG+cY2QEYunG/1YkFx/ok6nd8NockSEfKbHKRD6Hu2KAJLYR458LR/76l/11Q1QczpcuzcodAUg/vuFVMuIIvRQ7CGS4W4pv7JOlbpokdXvzjTHzirTgMTOOL4WpZtlNBmHes2bLCKo8CC+XZ8YrlaRNvS35l67fVyssgry6NUxQwrSi3TPH1GY59gmebARDmFwEj1Ih5b1MoPi/o7IpZDr4zE2hVRe/kwKrUV/VV04uepduKyvH+6dfZppLJtagmRttYomskrEghYdRp0XPmc3XaBcnjKDGprOrWCVg0+I2pPixLLTInBBQ6eIEd3WnXm/mq4LdEJYn5n5n5UrM1fzeOhCw5ihDePHeIh5aT8ywuMEF5gQ7cBZbkidenfO6ofFUMRV5j4UNRIpsx6GpVS9PW3fYEhA4vkzM9orZtX3QLkFWmVjkDGECcfhKbJur2QJ1MALaCmxP9dKCVXDV4U4Ieqxv4YvURAFJAS8LJJX0FnEkQCHEWwYyV5bUS3fzhOiT16NWlMzaP96UBNtawLUp17+kBlMLh+JW3heK1T9cAAidkJR1JGrsrWi3nAOf0bwwLSGOxPFfEvG97MGlaAW0p2UufTBDzFbwmcHCaDHt7zX2xV3J2XkSIda3w3uP9Ha8TyxM+n8XCcVS6Jx8cho2SMGqwkClKZre4hilKgpVpO+mm6G59qBaYXbbi9Ti/DJ1KgTgKYoYsTZbMG5KgmC7MH5GphQXOkzZ5s2EUwihm3VZ5V1QsMFA3Hk7swsHf+vL8dOeWfgk4ksfdLmFpQFb8joV5/X9T+aHsT2DvnscGt2dYwV+P4duSh2xAyDhm79pvmB+C0otVulSpE5C05Bv8iO881zAkci/Vbf7C/1I0GqL101ct8+qdmKQ6nzTP9qUSYdU373dRGv6zNrcSZdUxVrTjJ3SqtIcHt2WTZNPWD3KK3CmQ6t12iczS4cwJO2OQUQ4h/yt6Z8/A8hacT0E9d5xwyeJjw2S04/6wGfeD75DETRBi/vQZdEkEIHzTFTAzoYU1mxlxmSEY95Z2KwOQ2V0YHCjR+8lzcAYaotzuzuRm+k2sTw3hXLokwwAhfogOS4Da91m6a38Znn5OtAsK27wUlGYY12WMzLNMrvt7AB7i1xV6kPM2jdULtRoocwxYXfOQm4JoiD15esRvdPgEOJxy6YuoRA4v4Ph2aRp4f3yDy81vrTGDrZvyuP+j7Z8LQqzW2ZMR9qi84MnRiDauaLiYegU0nQsZEaS/+cyg8IOC12u6ol+Qfr+Uk07t+w50FGdh9J74Zx8kKs8c6oU6U2KiN30xEoWogTW+Osbs4K6leY+3QJl0eklP5k9M30Q3rjKfeUyKLMLd24rG6Th6KMMes9Ayo6IGPpj1i7kR/4P9gBvk4Q4WMihE2CBViBNy4cGGd1EIT1Q59cJPGzzc4bGxFkUhzDoalf5HVXBiD5+WPqJnMJt9JgwInmji2Rvz0nbgTUzmtKr5xf83RTfW92B68qtPOLsj+ivUKXf/VP4cBbNeW1jLi6Iz6RdzJXwGxoni0EyzbEPT9acBPTNisQ1KEbqPEPCcSbkjWKwgHU/oF4RijrzJ4zzLvIEpvJq+1pDIAiD7OZL88BAzZ9/tGvmq5fGQt9yZl9s9tf3cz4Fm7CP1AoOE5nfrl761TdtoqVYSt7cKgMx158SoYzWL2Z/6R26GwLU2/90UztOTBw9370D7Jh34n22pnwIZAKKPINQo6wXDqucit6N70QYy6mkZ6468v0LKtTU7DHdICThLD4QVnMfy2HLGEFYB3n8w73BrwhXpN7BRbpozvDfIuLROiw3Buicr1JC9XXtWZisJyxTludsttHFQ82sOpd4iF6LtnJ/8EdYKQ2tvc83mUYyaDaBBd1c0wXhTEehjVfRz8YRwTAOWUx+O6PG6UrOzKpfurX2dvFesQNRJwiRHFZ4uDFNDSERZSz2L5y5trnn7E8BnFbkPJXNJ6OWahr9Z/HjubMDkIEcIsYDGbzD6ECgTD83U4v3VL5Ih2O7rznm18l3zOSVT3f52RwTHup+2DAfwj/srbocbqOVZ9PsTodps2Q0ddv9sOay/O9aFSOxGYiuaWyDF3v1LApjbn+W+b+42GF2dJZQ0LQJBCQ8SzbqnGas5oc1k8nl+AG4SusnZ+LPgjnzaDTol7gKwJ2J46j71WRcWNy9KSxpJxAqYIMqWnZ075gzA4wOdgdbIRcQYdRXXbc0Tgo9h1+xejQNGPlA/F/QFlall+C7Xh32EFEa4HbwPFM8d1hd/vLV2ZImaN/77NQYRa6fHH9KUv8LymFqqVmTGVeZ7DLO+3wql+cwfVoowY1Nb0ru2cd67i7GPqt7MuT7mj7czmgaKXXOQnugzfVprAMiFgfOmw1ggtAB+mYJW/Pok32AKc/AtX65TruUkGjGbMKUOeeg8oo4UMsZKMNFvjdZ4+4h5bKXS/lBg/WVytopIbLye6Bj8ZyPtHyBUfI+rO/ZBHGqFVLO9ZIC7vnIYVKO7sWZbd3YGlriAk05dxlKdstEA4z2ifIGIBUKqlWdCMS2/p4cdF6Qdgu5WNOwhVw8Vbc38aTZTj7qkEpZX+2z2R8pKVxvNoWUuomEj6ypUVHF4ByyoGJdfADmXwshlnWdgq1bZ0/vulS7kMPw4bnpzLt10Z3YKH20xvJhfudRR8yKFT93xjP6rkDJ83/rXS6mR6Tt7MKBGk7jRAsPUsFDNvw0bDm2U/2C7xoyuc2Jrwf2MRw24BYPlBsO9CwkPy47S6OGsyKABA01X0aTh2prvCCHCyG5oq3diajYMDAF4zbpDOtpP4P7gdshSEaAvTVxT2l9uoMqhkw3aBQ8R9OqfrvXv4sdAo6x9tpjBlR3nBE4AQNFcjLF85voeORRCjXAHLMp4wdAyNcoGt31YyK/NiAAo1XCv3TKAnKdyJ28TBGW0OpqtTwnvqwIwbC7j891mK0L1724DqWcuWytZrANjQZVOYz44gF9AZeasNU2ejM3vrn4cunms7lqOPxV44jLvVfIRiQg4CId5qpLm/Q6Gx1D406MuDoigOXvgmrcuJa77qi5+A6eGg9LXuV4cUd0hX3yiXaa+b7CYmNPYn/4Bm0vnXxVLhGCNkbDoFMKDZypJu1bm1PUqN3KSietOwVQhyL2i3wqLz8uz9Sl2WbnUs0vaujzib2m2whdOb1610lOJsmoh+8Jf938JW4v87akcPwTpqIHSfaNrqeR/s4kkaVNlXAMIDHOatSomFPtrsV/GWUSe/3r4zrAsjma7KfJ//whybOHRZC0mQ4H7kAFk7IwJ/OCGcD3/e4kt/2/k65wC+cSw54KSYiR7YZgZG5zSiLZ756txtQjn7ykkSdzcNyfZncqvWzCKT6OEfoL+VN2p+r5UuSnSI/nHrKU7vpjjQkSLgSiR2lmWe5eiLeHtOAwU0Z4GgQ25grFT5uvLidImc7AFmMQ/1Bsna7eLYeGRGONcdlbYKNWaWMu/ZfP/qfPaY2EY7x174bQdabzl8mxEiJ54weaTs7vVxiIPOA50h5wMEy41NGOhew50BtSrrwqwGjqZ3MGf7V6TayRBt6pEdmaGA2DGmYd+F5PUIDufjZGUXtFxz0b4wCEDd/WY47KZdWg65NL+LxS57yTGYBZ0WJOfuyWGNFDJyZzBlwnXWZfKhgMShF9pGQkwVCpQKbUrueEQ+2GygJEDrUza2g5tZ0u8BZZuTNO8ucZ29w7UBTdpAi9yRyN9VjPKIY6TFUvbmZX2oeOa0tk7+MamwEQ3oakhOOvO8MqVkVXj0kFpw7P9+ka8gYdD9CgY0kRS8KVNbvyXYbkDhALV1pA9pMAHqnHzefwI+lDPCU/8IzuIB2mNH/CWWk1AHzmLFQJMrBzCixzKBi9X3WSC5FDife2UwwMdMTA4PwoF4ySNHR5gb7cHxfm68vWkExqzygIt1+jqW3crskbHKul0GGuJ+Vt1c/VF7LcDaxNAeAJ4mv8Sy820FaGWWEkrwXJAE4s3mbHl1/AMAkqfwht0UPeyfuTfl4uLQnpCn4LSOgSS2imkWM+qN/MPm0Wmb7crTje1pmIsN414Gc+9E3C6sL4vcR1gDckforIPiXBI7+jF/vHHU0v/Uz4L3oKK5CvjmRliOJ+0vbQFj96BZI8weFxL5L21+mMT5CUmxcpUDKoT7BTM2893HrAD6XgnFNSSdha8UpOSjM19oqDDxXnl1Hz3oE57GQHY5z8nRpSbt0qw02OBrXcg/gknKss9jIuIxmIULvqHuMwt1F+r0oExFeYlGSe+OT9XpAm5VhIZxvphM+akJA249cBi5cdxwYu9uHvX2vb83/kjQ2u/FjmcGlB7Om4rxdc9CUo/B9zpPy/QVp6ZYdJKXUj2+wcfy7EntaLwQEEuP/LJZuWGvhG28UWuhaI8VoxO5NNDfu2KRxDEFqvq3Se9/HkGl7BnzAXC7m6mpk2XeGv3SdSz1fBIuWSRMSqVgVILOO6F/CRPK6OyJCm5B4jGOu75yeOVwF+iv3W3au9pMyVCIfsO2cF45Iilde2dJNnLBag1dfhmPs3GUcuFHOgS3OneXFnU0aXqnlYHRb77aD2jSpoMuu1fwwmfYlAQt13dLJ2rvbBr8Fafwr9oeDD/W6QrV/SqRgExK3VFRequFvkoDDNTz1LjcXS0v7ccS4g4fczXy2caa5bhbuCVYxKZJ0I3AZE1O76gQDOGvJ08yev+ssFWVD4WKNL6ZZLrUD9EDbrEzLtTsG2AD/Dy3OBAZljPbU1OaRCND91brBpJ9DDyNkJt53+7CiFSxiN6fn10U2+DUuHZZmneHtdD6Bqgdq+tTOQUn9ZVzYl95eItHNrLhF3+VX8VMOF1GtOv16G3D1Gm/QEaHRA2e/x1wYtGbrNJEtbTT9dNPO/6X64i+wFTbuzUJVsSQXbc0j4p1XnrBK81VfF40jl/3gKVRESTFAcUtp4QeCRdt7cTW9NpVhb0N9P/Go35oNW62lVj/9PwUaqsOCBB53bUVXWh5b2sp5U8UvigZP92U5ilMu4bhUmrKYlAlmYuaRwqsR3Tqc7zFYLiy59S4Xm5Tt/9JpAdYcBHzayH5/ZLla4A5FvPF8B2nH4RdzMgy/AvYPTzEatlfy6VOfPZyAnmFLplJA2l7SjfpunVdZKCe5PgDT/n/JbT34T/wEaZA/glyRjbeJWiS0lbuh1OaqE7fXeT1Z64JYT10BI1tEmWgHmV9sm+FLqcdZHQ5BPjdAgG5rDIlUV46GjNvPCthcwSLIA9jblzJdAdAts8mLMT+kxMAGPeyTX3BE/o9/1uwgzYODLLdkOLRfJmNeIKQokYpnJeRKpTR+bVZDdVFu/LT/PBZWmOuYOGTcStr/krEapSz5GRx2CoaD2yKcLAdY5isYuKGa+h5WLINDKQp57cGZ2BJjxKJRV70HpBdQiNSVdz5AUJU4ZGvHRz6NM1PLYZW9JLVP4Y+QwDvs6qtp8lpwzNWl4KpkoDFNKS8PlRDWeqhsScQbnQPNFpZ3PxUF0LdW1pe4pANlVYr915zONpEL1bc6ksonibxkxv5Ms5q8GlYXdxu7uBNpeokf+hwz2C0bwUSXJ3rDnMleEg6OiuQ9MUFWI5zYzXA8GmdSZX9drGCQeqOe0rCf2ThiVx2bBV5r52XNUiZrfQJ/T8d8cl9rxLnbBIRUEaUNP3FgDhorzG7GO6uIQyyqoZ+/90eoyvM1sw2SXIFDFD5OPw04WBNSs+BS6eTSNHuBA+nGuYiVtbk5WixXpC9IAjMzrFcGApbW0SglXBcL08pZer87U65Fqm4y4UJBuw+0OX+ZP46SYBwQ7DQE8CWS/L+nr6gMnw9scALEHokVNrEBv6v/zHkvD8UMvSb8QEX8N9nZCgHyK92YNYvNkvcGkJUEG12634zkt2C5WuHaobZZ8gAscvkjiyitHCI9yUbu2TDBiBc9RFYgreVFHCOsIqSEwvLCGfMgwXvTLHui/V/lyiLf3Y46EM3UO6B/CjhBgs6S84PqUpkqH1z9hDMmYvu6YKyjJJAeMIu/RVXtl3z1CFPcknzenD+yYih5ICyEpg5d/lYHwUE9JMxPH9idOQ43cMc0VC1MDRTjGtxdNSORH4nh6tiCb6PWaO7ZYdL9phiZUWbC6Lt07RGqYbBAsHHTdGW03j8bLMyJ0Go8PWtMi14j0+zHGITWI9FR87fsEHTTOLfAdrStlXn0Deb0L5o8Id6BmL0cS/snqDHI6oWtK/Fq8SVmzTwbtwyopWyx10R3LtFOetRjtUWKNIQAdIalzArqp2kYtuoUIx8bqvnkEXyfe6mY2MuGccFOwE8BSkfpOqNDLjNHNPZW2CULX/ppGbET/1ipwJvZBKDWfoTgtctNpudQ1s3O6+XrXJXO+Rmc8t8Hkr1e+Xns4GE8fLQ8b3fVAqKfDG/Dd7L/s0x5DB6AhhPF74KWxkzXWWHPhm2nj1aOEgtb/GECeZjx81BBlIAe+LMeqrOL3TPxovuu06M0d6WGj5JgMHbEVr3+v2r6kO8b4R6fD8XqTSRFf14/tHfI9SZIlBLRb9h+l4yAHusnUcdGoncB9f+zPrsKzr4MW11sHNGjeSLKG7ZUmwMkmJDHRiUWusk8ESR5G2nVr+WT1Cp6Pg0hOfRl3Enr6LwjDE7v/DsP8IJIUSo0HYvGs/F1maUGMKPGzrktNku5pmlwjXSGZEmO6ieB581Nj8FJB0hJmd9tKRIo8jeNidOdO3f1S0PvWuFSmVvn74t14NKg1Ztjrn85tm8JoX3/rcxkucfg/I1Ley0nHTuc5dwvz2gALJtLsnHRjHQF27YOuj6mVyYI8kaVV5IoSRelpTNdkK+kddKaEK5cdqfNYdEHHuoRoEVTaQQYBCGkHLmTwCVLA4B3RF7xP+umJcqc98cH4QyIAJOlzPFUv8jvmpEj/8v4aSrQ2EBcXP+aopoQmvXpsfvHd4LR1iNmzQHH1TvHl8X3kBoUPdi3UtVPSWf6erb+KsjjH9V29xgw6edI7fqMAz0YZWqEUuBz45cJ4wZKAbKC0ttkyyPPkdS7bluDrTJtvIwH/rVP+d7Eh6SKvcXdYfdAsz/uz3+6Ykk4euT4awP6c7gT8rP8JdQpWpG49XgTJh2Y09vGPUGR609ZKK93JZLqrf0p1K9tSajvtkeHHSLiUgRLJobsgSknd03YR6OCNRvNLbgUua0WDDsQf6ZL/v3rtHzvaNa+7MgLsAgXWwu8r0QQVBNkTrm0tb8BxQb/BqHPEkYsSbfFbzPAhGOwYbr1JTm2ppNx1UgNIUYCz9UNYnPaQ+hHObVAVGt2VmSYDr638ZUJM5bLaMN/vOmctslEnxORMTlA6Ze3Nc62HCdjvYt71Nk3c4ZIEfclxat4X2UxwWM5lEroao1bq+My0aVUOxglX0+4NYV8VNUABCmwHQNRSW6ztzeXLucB3EsSJCbmuy1pwseb427F+J/RdY+kE8XB3mSczqnfrWMzxU3Xlr1eh3a1ZgaJdDvI9SzfGEu6HTWmeu1FTPOMMkgJD2X+R6i1Dvj1A1cDVBFcbD7e8RNciX6GeVRIpqTE1M26HBHpOZTT2/p9+sBrftlfEpc/LyM3+PtBdm2fjjQ5P3jLMFcgGtEIIzuSbjyus5feEMddc6pqPO5oeQZbyo3dqKOnlzVmjd1eyiaW/GvAcNKKxm5MP3/7Eiu9l7xL/lrfD+LnjeTFpI1u/YJvKaNkBTBM2r98aN1ZMCIl3fTd9bG7KW0d27S6MpKcvmg51swGuTaFoAgH4dCVAkdYHMHf/pWRc76tn7RHd5crfCK7hkTDa63r+zgzuBz23mdBC3C/8yZ6qXcE761GZyTM+3vUtMRXsMjaK6UW3YOdT2cfk4RAZydQs4v2sj9tevYYFmrNjIErsd1xMEyS+9POy7TGv6D2Dnp94uKaITtEGFdgUo5DZZG3QiXhq7C1u8V5wVEq0Fr1oVP5S3lS9O3v9apOfp3Is4678im08DykCrYJiYxZW52KbtXyM3W+72znI/zKPI39+GtrD+Q28mxhd+a/BvDTBf95mSq0+C2+7WmhTh0HCa1ozU1Ybcmd+neCfu3zMmX0Be/Tk4qTF1vFWm6UaouFQwdq+hJGs9deWpTOO5s7fuBGTHeKhEmKKJZyCyAOEZTbIr15Im7C27YaGYS+Zs2ueHLmursXo6TU86gksLxiJoK37fWATn6rTP4iPr1H/p4795GknyFx4tHikoS9Loe1J51UzdI0Fp4mA1hmxk4LUe8kXRDvu9jQFrmIJJA4JiNZriENurfVGV5rHnp/sm87xgEovxO02Qd0ly7i1x8KkgBxPoG3brUOpBcV7NpUFq4wdpWyf5NoddqFJo2flPaYrTpagfJVg9cLl7LuXGBMcVslR9S00JrsUTcET2MOexKkPe/9xd7t8CkzPrCgx5x4sBu69ipzqWPTmYrwAPEIoylUSoPYWMR3rVfCaZBiioDpLws+Of6CmjBOhFPWIgWFUiBvnXENVocHkRNhWU+TMA7AtskNENJ0jcTzZI8vQyrDTlkuWWGKdmUm1w8q+iRpTcvGu2E5vQu+HVgUDDpwd237rN7npictv3Rzh6+a99Y2xfjwsVc7NXMZkvdHv/D+r0j/IzIW9FmyIk6Qj8tTtlfVt5Mt8yvJJFF5vnM72tWuTWnD8W/SsOLOKgbeuRrgXGmsg9zKBiWeGzIYB25SJE3H8IEwPr+RNWUJiiBOkJt3vTbmtdXuZhSsX0hnQ/woZRzfM1zXoB1DexcKmXkhJhNiiBE1bNUXs0O8Zh9mLcfVPRmV6s+EYGTi+45hVRh58kSIQrCZP1PRr7mHSVnT7iZjCfxSRkOLMLCd00Vd5l4ILXChlkLPTYgoHCHYnuCMaq12kGHiHHHT5PPvkOZw8Gyh3NoIO7DhmONiLZeO8CKCkWmKhLDaBR9j/S/L6pn88kSjzM6TxmyxTMLCMAQLHldvW5xm3d6VwY8uVXdmIkNelv/YQ2mg4U4pi6j58sq94pY+0dyDY8IFWtbxnHGmYFMHy3psdbkd9aqXVVyMWUBQW56NsToBm5QtCbdJZTJbS9l268hhy52eRmN827u8Bzl4shO74AVgMIVtMwkEkZRAISXSEb2eRkDcA0C1RhD0B0hEPfTj5gwP4Dqlv6mj9sQwDkgbbPCK+7xYgbY5Y9fjDMTO/0T8LN2uRXOpmAEFEy/d8VKr6WKCRbyaLXc+TwwUbT0BYdlHJuylp8esGjiUaUHboEddiLGHfMdWnY6phZOIMhCFBWmlk/ugg2heFybMmlbL6RYvJaaYqILS9+gI3NELqMRLFq0Uclh1LxycXVm4+UAGqZcHd5IDyPLXNKuMFH8LMQlll1nDcQVkgv/Q7sFnDaW/piPVmaExL5xBP7XwfoiYy7imU9wR4j3wcmuwJ/8P0PXyTst5GSimUSUclfDTMw9w4XbFYzLh62q2JeciKK1YClSdovKQfraQl1Qw703USNv+kdDGVe+OO7Yw0BhDXQU0VzvEAKfY4G7ZdQJU1GMtprCMsUun4nixN5lobqoZ0IIc57kmuzuQs22LX2xMjDFVVrGpr6C7M1BK7GcdwMwyNZM53cRMntxcF2dIUlsg1VvWu3P59JmG8TRdJnybq1T7GPCG48cMdTptvu5zV77BjLm0Zf7Q/VOBZkBsJLI2VezcE437VVNawa5onNrwM2DwVCHHaswuuqvWMJnESyIzjHrWjt/V6/YMGXaAXSQuk1jn2B/sUfa+Lhr0RyJZIeMmKBWoUrRbgZ/VzbyOKfUcs4hVgGwZxH0a4Myg46AGngr4i3/nE8KPUwK0o1QnQ1XAzJgDkZttzMrsbDIQ5TFbXzbkr5b1QfRW6iXz4S+6rZshZsG1iLZYt9E4H6JnY6SIclka3qUfYVOtlMIYhnBDIAU+7d03+2dLP0MIx4jOoyu1GPj/6TKVY/VS4gyXWeM3rE+2Os7b28j2v1MrqK+9TceCzDnBvT5mAJ4Z4gBk/3fV7TmWM+3pGEZ5b9QnKWHC9psRS/dQGlnbVnsogppdJHP78FsWCbSlFpo3pXNZcXeBuBlqDAuDkiUhc0BijhOZq9YfbsZFAC9bxgmT5d+J50WzXvtsVF3/1VrdC8zcECwSqs9z77WI2y0s2jvwiYze11kw/KZTQ+BVUNop3wey/DVzMHE0RNYlcSp6NeycIQORAUcsrYDJ157WaLUM3aKlti7hKpMP07FW2hyMmbtQMMib6cWHOIkL9sZ3uzwvC2HlloO6NkLuBWv0AziftpR6lb4kI93Ide/IfWtU7COXpcuCYoxyrbfBA84tykXfhyROrOJTy78pbr7lSAvtyGhbS3Va3B3aVDkPSIoz1kFYdwlTXQSF9YYQ8RwdaMHwz5/StlQoaaD6H2ITBosm651e0es6wDeuJuyG9C07AEK3eOaCCdUVy2AXqCnTIdRjfhB3W2TNBU/zF6G2i5n4aRGBVsHDlf5Rnlw3uO586JvrB9hiKqNLHduPPFQ8XWzMLyVy3H4Q5Q6qv05Pm350IloRKB4vq0SfwPSIAxa/PZhUUYFsFs8zv3UH3x50Z554MLr4Ehm5v+0xvNsHxciTY026a1SusThkQmShpdIRKJmijgdtGv4Tiw/I3ZJvZpFAUwqVzum0WRd9nXrOLUkDVLXVyiv0om+IYOgsaTexHPNLiROA27PBINRuMHKMWfrwpF6gAGtarYAHIq4NawNgEc7ZuRqzKWdo0x74wk5gIkG2cVmlXF0BtadfU8BX8gB4j0Z61K5IDtXwt6qgAenG8EO3J9aOGllkkD+m+h2iARPxkHUB8M0PzfHu/F922B+ovQuQaN035Q+VMLXd77tJp3h8UFqc5G0AUrIuqnlYIOOHhjomxDu9SMdRZFdcd9jcai64LubCKTAvQdakpawVLXR31m8N1CAKDBBqASYsLeODRn++H0hfWPHk0E7AHka5MykckNOsf6j745mZger/wZzFVQw9VEVMXouENwWV4enVvMmPJJVlpQI/j32fPjG9d70pZaSMnDLDI2SCikaRZAzL6tJQoNQGbd0WM5cQ7e1LMDhnpMYUaCM+Oe66rOi3NHC6OELWNIOxQ0tIES/4T2WWmYG4Jzy0Ot9j+nqgsb0FOHhYOMo6XOA1JQAGCTX8u8Bvtb9MU+rMO9nEQ9qi9ZSZPwCLrg99fU87HiOMD+pz+j/bEHqbI1SuDVzFy5xAkhOe35WXLd2qOAUZISei0tWvPJ0LM6eWnz4ePERH19OnS0a7udqV4KgHlWlaZkw2z1iiLGCZvpEF/11qvaZrnRgyJbXcO0/kTkxyfalyhxZ/6T8tGu++5GF5c9IUHL8Z7JaniEMQftlBCJCHX7q27AcDUSEMWs6uPmhFWVP0338evfJ4koIu5ZedgeSxQkYaistB3gRmuaSopJ0sa43v415mLE7nENy47+z8Z7XSJK6eVEoduxKAWMbY2hVNWWzZPxa9KJ1J35P2WwTt958RkUfsqHc38YIXAhQqUeT8BE9+VxMS9TTLKLzlwZ7L5eFp5K8lBh8SaEQYVyoocBg/hRbZC6JDP2IDxA5hPnw68nE+WX8AFDg0chPmmcSSHQfxBUc3ThM0ef4tOD5JqyLYnRBE8ba5z5u+KhsSuq8DUbrH4QIB0RwSTUPnJsQPWMgb2IPs1neZ3x15Ge9Q1mjZLu2JQSoTSK6ZH0d6UNqsBZzQFsXhvv5HvGN7yLVO0ONLUchrzf5uqS9saYjctWByaUxauFaUbHsQx/0VqSynHVWtmwTisTxoeWeNc6EysB/t0fyDH601tQ8JVhfndExCWN0hJMdblwj4L3MKqt5C+8GnG1GdkXkuqWLzsj/oARIvEaCQktoXjJ/FVh8gzQpU0mfjZDWxhURL6yexpxmF2z4X8C4+XQKu2d1csHg7McddqKmZLRvor52AqH9SdW7xh2011f//sTl3GvJW1qlLBeDcqRNYZBU+41JtdfPInf22G9JJrv0Ayq3eSRX6k/APxLd4yaROqtzrZRGOICCP9i6FK92xkSWB/tQhMQ9Nuhm9kM61RB3E5rjfc2yPR5GqJKTZe6pD+W35oCdGwBRjgS5Os8jTLs3TGfp91yCPxbCz6I40ktOaQk7jODuU7CttCED/jsR/DZVqWlFyB3juoxaDSqndcIgKDmNpp2gr1bBK13zCMTTsPkRCXSe4HIBE6bjXjJ/dclvQSo2CdGQEt4odpWxwFLb2tMQXIz1Tr6M4Help1XqDvioMiGBPImySG/al+vYJHB0eMU8KekXZ/sHBcI4eW1owMBe1bi2KKOM1zkiKb2o2WX21SgLXkncaFB1pZMwnxTICD82Wj1VlbMFMYhI4yzha2x5WWx9orEViQpWZp8Qo9XunTONHLVsyzxGgnzPXkxtjhWoFB9rgXV8FxbJFECbG9o2LdeIUjb2L8+uO4fzV1I8fXsK6dWd6EDYUEgRF5Zyk9Z/DzgQQFiol1GSM3nxUPer4+6FNcsEgBaJr6tDnhGyQZCJoHWai6LW8jWxDxBumieNkUtMKEUGJE+fdI034ON73bgUJXdDO19uVfzXPZ9FfuO93L5MqF9b6hBrHXXKmP3Z7qFOpFbSRsSRPNj1Zo6qcTD05g8zLjBYtAuqRTbo50sQPONGEazT+bSs4IfWz3WptAEuXeSJJCvU1Sz0vI/mwHbLIEYPbsRhaP94YYknGK1636KrE4umU/Ii/kK0prD1cLxi27Rl7VEUvuuwr2RaNyF/AoUjsUi4z5WxWSxF1Yy/N9KdihQfpdh8vbg/2dYuhW0t0Hgh20il7V4Bc4T585IrF6SIBGVRwlOYL8mydMvAD6pYZCgJ3rGSUBRLN/rDY5buWe+vmVkrcc+N7ZYQbN1hoc6qOXVaSTcqWAuDSwZJQOs150Vo4TQTDftrY5xDgTrCXr449MAfoOM1m9JbjIuMGyW2LZhyQRFDPdeLkc4wqntHvgAP3HiQ7a8TpcEELTqIeClDeqRmavHT/DeH99ifU/kN+FWeAPnDnMFOIZ6+jzxYwejtWqyqSS+0GNFXBsMDT3Ujkj4TNAr0uBPEzkhAXUmqylOgwN4BdvHoS8JGgCTgylnCaNfCH0rkwVSOaS2eIfPCI+w/BQfpehfO5+2gHCwC8hIzP1PRbhY/sMIGEGRVnH91/etYJzyUU1X0kQeZvk9l8JroufxlPIGpHZwwnwh8R/zWC2uRVOYrv9qwdbeymn8cmLU1XxGzTXUoaEYi36nqqgr2KpI8msze0rDVrjTocpdVWSByQDrtRaHZ5uEjEdocVZouq72gpAJX9OPhrgukM69EPwpZM/XTBTU/MiTZJvUfi+U5PVTkzkdcXOP0He1+8WindQ0P9zLYhISlMDmlRF3D64OjHSOkCvCRNIdJI+SoWmmLgsi6UV0flFYRfk7dyS+YTeEN/a8QJMn1qKevA7ypGX4NvpSG4O0NXjAY55Ev/wKiQ/HrFwUFnbS6JsfYd3P5OdesoQDyIQ3FPITS2wLDzL10D/kxGgUO4OYjv2VgHDBoBSmN2fF6wLlJPQMKsofwXgAkB3ivRcD/JTDrq6E/9BZwAXBqT2DgPflz4Y+0CLHSGhIGyA8V1YKJy8DTy0kSqTrwKBCZcbcBBePR/ngtsvsjKvkSEz3ufWf/vyBdo7/LQz7ojo1w7zvs1VDsu77fGVTEOTynVoQfvJCVlXIvhTz8V4ldJ4+dpDmGlm9T9fulYfV1D4Jv4LWmOSaeO96VXP5Z9VFmeWEEKmcOHYGtc+bo941RpRTTBMy3u4pjZwRSOp/rj7CDYAK49fqsECgpQoHFAy9oaHE7EmJ2JR/SN4prAHq8Q2sCgHUpc53xbMRWrvZf7GF4tAyBbYvrxP5LKdmpx5C51L1YODgZeGYbDpDjFhcldN4ccW7eAbhxgGTensjBZM7zo54Yq8mlGmZVih1y52lTJOO0RdnA/J8/3nEGvtG/PC9ublvfKEwvH/jnyC9Q8/rfy1i1+j+tTXA+kibEy2aAnNheJqwzMEf2WIHKTPXt9zww88he/O1kFAhUD+vv09Ba2K4lbrwkFqFXL/DrPll+XS9srHE9oGsWQr1qjXHSt0718+/pPNeIdtZBNCc+FWuIuoaVQUzKVulzzY39AWqXJDmo7dkc4NuQbogOa9X+/0JJ8FGGPuVJRyBDDg38aGMzgBex4zYYWogOp+TxqUdXVr7nI2O2qBxiLtZGJub5+fUDDyM9Ce/TlGLPAnXWmv0p+jX7BS6U/RNLjbaGqLb8wayY6t8PmRfeaFEZcf4jTcP1TaA3izFiIGuIL++bC7vsHeKqHie3aoPZsVF+WnEr9YSSmk1LoLWRL+Fu51m62WBQHgdxSwoY4ifCZr7GoF2qLQsWPY3Oa3RVI+8ZTNwTo1WubGw3V4RY7BtBwnmgGvj1imo/CckF85ka0iUVhLfWnkIB3nVo75OCLReLjn+q+eaqprR8R+zRXvfuPkomNThScpdCSidvUYrZlZnrP0y9ZiTHwzQj7gcdsRkpXxlQXlpfdA/3QAKq+lGRJKmUGj5xNg1/GwLdmUZqxkDnJeQBXI4QvJxY0oJoYj06cnNsW+uxWlq47BwoC+CHToUCTwkFNz6yNb+RmmAql1itKq3GEaz668LJCMxk3kyatc0yWFctqxoH8wIy9bSLDZEqpaTa9Hh5qJ0lG0HLC7SoYMUJ854x/pnCmjBXZEJp7Pb3ubNR1GDE0RWQO2OArkguKxa+qvLzcR18f83NDMghe2Ydi+N4yypt3y35SQUHNP/XkW4u7TbJhqr1pkY6owtfMMzraWzs3+zBaCyUVQMXFkwWJ4InRnHlCGjfCGx/dYyg11eYqLtI2s/3VlxbTQwHj2VUmTiRh3ixItBp1xJwHXA2HwCBfI+z5jfvPex68IuaAtZ6a+cVCLO2lXxUH4PWN+AdWqavG++5GsEV4+dzWaTd6w4h0tvmghr9Gn8oaYRtvMChWs0HFJyOXIseY36uTRLN4ZE6VWGs8M6OkfnC7cnODId3dnVXRAsoOkzUNZck58RutJ7FXtGeHpzvIOAJoM35TLj8gocXwre5l9+Yhm5gWFQUTzWoZG3w1qmAsLepQlMTQbkBRMolMCsZ3FsKYlvL6D/GjuFuzppSVU21H2/y7DxDLQqdympqdawiVvqwZXuRWyMXPsP7HcM+O0dmmnvUCVm6YSrtSZnMMRih47QYb/OF71Ufe39179qZyoX1VtZljY5b5EpVgzz5lKAFBSeQxdyFITf8fLWMKF6j0saAs20vhyYHZhSoUSdVMcmPbsPJNSYIOuUUFu8tB1HpC/zbpd6fb/v56tmCQ1XxRFajBA4x6hVjlMjN3Bti5YpmB/Q/kSbnXvTARpMM+sjqVf7EiIz1YW/XU/8+emh9N5nSnlRScyreyb+055IAv4zMsiOVVW38J0un3PNMWt4WjRWbaORlYbb2FhbSzUdx/E/1hC9rcj7l/RYfIg0cdsv8ez0LHwaeY2OzThHHRK2J/6BHLVkqroMlWSaL3ayB4DwxuusnadpZoNEB49azfG3TI5I5w0tTJgx2WqY8Hw9iHuuTPppHUQSRhC19SJ5nKF7/Bbrt79gY9BWb2MfLCgKyOUVqBOlNccUcsU+XbmfcgGdjDQWqukv3RVSfIwh1IPU2tPynU6biDpzz51Hp3Vcj/fN5+QB2SiFwtsFDAycurcywWp7GIRqgH+fLAgj90UOyE7bHFVVkYoTWnq/Zws1LIMJ8t3znSW7iwgHqj5+e3TMYnkS/S9TKsJ9yqIJg98AihdCFrP1n/ckwsHk66Z9HbNyFTeF8TWv6HtZvCQ+jciIxqHl2vi2qi/UAuwOr6UU8+piellQ+H93U7pI52hU5h4hVE0ODCO5X4rbV5KHy3CpAmOEltP0rXglmzob9u3VzNRQiQm2GL6PCP50nZQxllk5pbwt9pjPuVYh/bfI6dmxlYcTD8rj/2v6XDkEodcDpQWnMHRmvGVpBDnenJIx8ZyKt+9irzZOM7ibat5+5BpPdx9lski7ylqkZPlrYu+C1JW+/CEL4VqspMjAgd6bOiSQeFVzwVvzlX3ccUq3Ukrht7vBPB08d4HSh5mYBjhG58qdgEaakPZcd/e0aJvGAV0v2ngdfZaVg/l4+tENic3akjK8UIymEWh6xUgHbMJ1vbHFVWK9S8oaYFaUQksccSULdfhNV1twRgyE2eP77E3npLlvRkLc56+OCkALaHnjBozU68CcbcvcUX9v9waCtxksLhEq7xPWJtYsqBOmyq2rmUB7Ynz43vgWKXVpKGEJNNvr7SZfJQLUqYcDaXf9RNF66ssTZ4DIRpQCc7TP70vxbl0YBOQesfmCTr60CkcHBGUK1rg/6S/nkY46VBCHC7QhPApAeAu4Yfh9RxcS7qCiUnJlLYUwL5k7FFwcnx4/8RW5yQCkLQQxanbruOhIDWVjgJh/0Hf1R0ZuhqYSAsyHVX+uhnVLTG7clMIN5mrJ+gkUrtkt2pFRNdt21YoNDBCtdAsL3uIFauf9rTJhG3T8cm4iSTNVo11n+biOLh7kxDROtgwce2zLOKxWmq8SL8uFAezNQ0xmbJAJRnIktpDb4IF/gPXGaY7HpOuBTIClaerm2d/P3oNUsayfmSxe8nf+RDGhjV5GGJnaIGOzX5Lr99dLKLmgnbIH8dmyvY1Pn9bowGTz+7Doy50GtR8861r3YNul6KyqK5xRZlyolS+LROiNOqnhlqOKmP6gyNQHsVWWQ2nI+ftwMU4A0oefHT+1v7l5CtoywAYwxujye0OVlEcHcAA7s6ltke6UnQE/ocCCah8t0kPOCUwbnFaqe3kecHlmYXNS2XGzN0xHgcl6K9TrXS/qQXzNQhw0cNFQ4SBttHapb/oGCfpwIYG3EbiELK9Lo6k0GpA9Qw0dgevkFV7wx0LPs7PC96dZFOViddM+dL7IwxXKdMpcjeILorARMVJ0L0xBqdpCH1nrelnK1aArfkdrJbRRL51pWbtwJcAX8btRPqicymcbgzPsCU4b4xDLRtG9VKi/forQJ1g6xpcEBM8xQY1aF6B04oZ5y5RJ9XR2XyhaunW92Czc8RuRWToecJh9cqPty74k9x4PpEZ2aFp9BSTyjqCPKrCJq5fX122jkB8Y8EIJ5Ub9B3tVfcPt5KY06ApLVjlkMAQFYXyqdjRSNJ8E9ibv2ypoJzQ5IADGqm/Jw+YdGyXhjMR3yeWRqjulhVq6x2Kqdjya8feWYq2f2gpczacVF35CFjZcRFsMy0kv5rlwZo545Rw/4egLiI3DdVD32CDz8Wx8dxytSoJVdbGlUHL1ykl4BVsBv55G6fehRFFrgOejVc3ilYlJpg4jttXazUJi3geb2Pfr1dF0qxvxlwtk7UqJGP50v2YzwubrsCfdQxaXWC+L3kM1WmPNkFtMX961bJ+rTwzh1t5fYT8BCNxH9Ukf5ffOx+uBYQbAcJRfNOzMG6hnXr3J0JAFXXw9acBGyP+YCsfcE4R4IYREsXtBI0sfr8ynUpO2LCeKf7+8j26QrcllIbMeCfpIIDdDfqKNYrkgU+BPpx8YEvztR5Pq+QnZV9VTT4yySZYUvx3HhZcoqYWYnBHddLCUGcJAechpimGO0TbMSdOMbqrXxVmbZ5POq9XsmzsPPqxx9vVupKWSybKyOVTojdlu0vF20n4lxr5JpNY7P5rT/qnKvN+Q6h4fgLK5/S6a/J8Jt1nJYmOYrHzzra7+5QXw/apzy18LQ1ZUfMy0TEviMW7z2WvKAp6KqoJ25+4N+HbiiLrFKDNQ86TISJkQHAfJz3QmUsIrb+vPaNCzcLXIG3zW5JSSA+AN9J1/SmghTJ36upgXgdzUvRwElEjvxA3mu0lBEpmM+BtYdggL0f/BcED89vq63DRNNJmLyaYwKe2UBWZhZmXbkOAylcom2isr/32dkZGNce+p9UmTq+XhhRGdWLBgduA+p/ckCX/JAoocYhhR5g9yp6XbjezoRDk8H/3BeKAzJf+4gqRw3dl5i5NHIsGvtxtd4d8lSp+UIl7+xpOLz1UZdNV6nZK6eiTO3d6HXPfJ7PUBJptouys5NP5Ae93hpQ4oJKFZWby9y69bPAyyXo/Kn10aLLfEoLkIdbhhsYOn5NJwhbpfbclQJue9bB6pvTDy8Nd6TnqkXWJRUckKi9l1kBh6Q9adgMKyiJ9N/ZEtbNqlPm45HfDq8K8DueGlmWr49NxiCKo1r5C9awi4iq/M4iYouOm0wVofudR10AeAfb9Sv2u36VvyoKOGX3CC9gBU3zHTTppOR6lQNYdAYNWJLytRm/8R1c0QY/0Av9Fwh68aGkgrWx+f10X3iiO3IQ7kQTWvFuh+LiWbQa3lwnSAu8yMr8YxTu4Up5q9s/yxR9C3iarDEzaP0E3SCTalhlGje7TMq/Xl/OJ0dXhLFlU5tC2A8U4rQcl/MS8AzkSt9LOVqmDYsijRkUuJHw2b+oYIqrVSRJAcehAE4ODJOmr3CfPDhjPyrUScrqOkwJLjgfg0hEEqDm3tfkI0/2ct50w7SYRGu1VaybxPtE0jjzoRkAcGrY/gp+CyogFlNAMejOJ8mJgm7cXRL2xAjdyq+evjJp3rOxdygYUvMFewaq+reiaqXFBFCfoAOlE+1ONgDeHM1bRjjw2rJ3QkZ5hrkOjFAkepU0WN8C84BBcXFeigppaL1YLEU0ne3vqmChJx2fwDit+9awyNJd84nPUzSHIJ8Bu5YyklyVCp0UByHGHMhlGoL0qnQXUAyYcHUlk9usVolzn2Rp7y/RmU7ic4xkMUqm6qnyFhhy53X9mFAr+DwC4Ncjhse79VnkBYf/48yQh6Rm4rQl9AfYfI4Ur0Ix2xkeS8uWdDrs2zcUg2tvWXaA+HsIvp3CyZ7H99HySjG46oPmlKVaEvqo9jGGYlGcAijXu4DvHqWDRhj1/j0JZrH1z3IH/QuxnJGkTDb/d8rzwvPSqYNjCnTmxO5f+gio/N2yrt0bdatGlPjS4XTPQNhWiDGlZPzzhbITrxBl1BTcLCDfyx3WSaziJ2U7DE318xzJb+uiCBOCbAjMFpi2VPy9ziBC06mzx0Eq5v7KauVJ1eDqJaEO70eazz4dsZvv2LlGqQyaelr7DfGHa7BzWy0lLq8e6AAyVyUv2LFpALjNBZJ1WXCMtvVDBrnP6YnZ2ml2m+MBuOsx0shs/H7YFqDP/Godmg8g2hPJQqKa9rKdfd7W5rW33mfDPWz+MY/ZTvbWgpg1Y4eC5Ma2c0WnSfC95UD8BLaOYszpmXcMz9HUnv0cpxIa2e3mSBEzuq5OhAKuyaMJBAdt4xGeqZCvgHG/n4NDWUunwHrrAv/qMoDufg1b7RP1JZGw6dRCNMUecOmkn1mhTJ0CWLUif/wMUFnRhjQUXZVs+c+QKIQ8xHQWnDmMaifq/sgfR4xX1KtnPs/nRxUoMVA5NHXbQiagFJVQbDhOJiY0eQ9NspySnI9ulmp0/06cUIkTnLqzF869B5Vo9wuJtGIb3PCJTUfaEr/mc+psi3PyM+BskXiHmEkZhKU2SaOt8Wbhzv899ZHQ/uCVbmtxUyhV1X+EtnrGhIdvaWpr3c2Mrzp7RV72dq1WqAFjocRxWNSm6nIiiW66J1EDlXvGPCXS+2XKrkbuTfgpPOpl/pouxMtfo75gluNRSpmnEYghPWqqy5Hrsixh8gY1F57BhnJdsvkuTEkGD8XtEVd5h0IZ2BXiM3Ik/A2Idp/Csr4SOchcOvGo2iN8cM/nFfp5WE/6ii5w8ecr6tR8K6S5VvJHLfq+K3iY1sjzXpvytjWNcThjphhZzpCgU/8u60sUTFiFzyyNvY64HmhH/pLoluZWli3CqLCIQb69FPsq1Ayd26kyFTOFCkXImEO71PzwWplsHCelFgGeC8qMuxFYXqewn/TRmRqKStO2JjqbANNbbgi1gWhjLlRgjJU65GVRSRlkSkmdhKxOcpl9x4IJPCZchap7GcsGaCPYb3QAMu7wfcYhr2UEK6ovjYGRFQ0sDzLRP90PqO6faVHipIBtVhaeSbc+PXfbYB7Z7OHyHdia83X4WpAeTbVXVPKFCa1xCj86klzi6Wdv3fWy9rAZHUvVmFwgEFheQfASAX19DAQlqraSxECKUulgBbcnyUCCwVUCbDqZLtrd9dL7Lr1SLkpB1lwKtTryXfw3JTuWl3B4uS2RlwNfQ4iu+WoNA7r8OwUb3TcjdXnWePZa4S0xW4f0yYCSH3V8DLrCZgXYh7lWJVksBBrksK6NwQwez1yT0yT4kprOShv6T2+jIaNNOZ3UmP1gNyTEuSFaMu3GzDi8Imh3UTprbjV87klt4yQLA5T1rtfHNRwi0wtaIX7F/qSy5HfHwuLfMddiFHRZmdRjJ/kwl05vEDhZS4T+4j3LTXB+SytzO016Covdef7plxm0muz387bwcedIz9mREsV9pFqYkJj//5QiFU46Re0KepQxBelGEZgzqfIfbHVWAXBd1HAtGoVD6NljGFPOc8IWIR21CB0smcW6bXA9w4lWjlS7T+lgmOMjxkxBsH268SNH3eksiJ2A4job4tdqIpat/8U8857iYIfPXgk09rzJVcvZt1TwosG3CWUoBcjquvLSfer40VI1Rjao3c1TQpkrj7mMIri1HY8bWYUPtrFZx2IfUr3QsW6dsUerN+OXf8qi7sLw0AGetHNncpeKqzNJ0Nenw/kIOSHWWGm6+KIT+P7xBRXIf3lacC1HzhrmHkrM23SOyOyTi3Cu7tLcjDaUMPRRLWecWGdB1YOe7Uswh9SC9UrCODCblYhhdzx3IflD4RBPCb9Fu6o1sNlgp1VzC2TKQKWepA/zt5tj8789dmYRhCVo7gKQZz7A3PVdjRl3Kb5ZaM9UDyqHpH6Sa6xO7AOIJzvzc1lC6ddtzRAhbjMHGDYmf+Y5zReDh77M/9BFIGk6rcTpsUYYVUfQ8nEEJba0nC7Ru0dxmDYLaRgMDCkhZrptZGMDjwtx41gWwwfj1A36FNL/9gfhUHUvekh9sQSNXpYmTTFB/w9ueSHmsOSwuHzVcmif36DwNNDSupXaJv8WL4ntELWcBQYTUVBTUYZlYH9zfBIdMceEEvc8YrgUBitFCDXVgeihFM3gXy6UUOGB0rFyIlKn9Kw6ZPsGmQIFIKXKjn3VBzwl7ZABCQ8a3j4z7V8AsJocvpGR93HCe32HrhoYsfq3acPU4BMNST1vCboRkIL7NHkBo9PAcXWFr8ErybwjdhCGRl2wFTJP6Uc+YB/1RWMw8HchzhNq2aU6jWU5wIi7XW8P2RW/i9+w1sqbX6FZP71bryh/RlaYFVWnP2HsrCgimFJd0xwjJlUi+xhprPBdlWCb1e8Xv55X5NXmyBzsOoAhj/jVh5EM5QzC2SFrS5b3ODip6AmlBd7xZfs3WMu4Mep7SW/Ga+Wz/F5iC4US6I0SDuHupf3RS6m3YVzFBB3uYjDUn2M7BRCm2Rtc8/LjwRe/jDnLoSCNE+x4mg4NldjuV8A0FgnZz+fZiE+c253gXUlzu4CFenDuJOkv03MNEzypj+LnnBuglhPpm7fmq76vVmPESsehigdCyD6JtocsA7g8lZXr68ktW6kJox+fV3ff0Z6kELkurZDE/LLr0RvuSsIfsoHdnBlMxCBnovtgL8lNtpvidScEoTs9b9htehEScC5tIOMUzW70oZwL3islmqZXorRnYqFBNcd1MKXQbKhfKwBQyrhT7xZ7FfUU21tFDBYj02p0aM4NYkqk21LKUQr7p3MlGLjNfCqX92kV7wVGfWXBe55vyimOj+yYGna20POHkBZvKXp7Yn/sqBm4gFSVQgG8onYud1b61H71LYoj0XbYGe9UMM0KTb2ffqm+s1f7OLQ/RuKS/Tfv4uXC7ISOGIxM+MRc+9Setw0xMw0zBVCAC5FwIgp6LDwaZeZh6JfV0YvcrKg4XT7kBhBKEjJZMRtBjkyc/47DgWleqDcfIuBeke5utzcx75tu0COhS4JR9bAW5La0HuHB/yE1x3+2+X6lztxIjVyNoMsmHjQHEhBuBdkJJUdw0p9onK+ZdyUPipJcD1R93rVcxVc31Wc0A8kqU/QSeXMRIf+Vap4tYjjggW3GwVmg4bU3HGDvG+kVmUpq/QmWIved65S+j3MzPirPCDHwXuxGPuoyxyxJVSxCo0nR1S8WtcL5lECY2+/E23fa9oavV+iBs/zPADIIM4gZ8rtkOkhy8uNTvCGM8kXU2Pe0kY1ldfETpwI1F6anjpuXurPteGJeib9XZ8wDRCfJ7ndae2UjZV0VAQdXZ151hjyLI3VQHmUTgxu+IpTX+SMoV1QiP0nqmww3l6EJBtihlWR9hiYTe1dkVJvENtz2+o4qj3R3kF31x8HtiH/qHVwSz15EKgRw0YjnPoZZ6nCmnhJKsHYW5MxA16TrjcviXus+kcmltQPMiGC1lVBai1U0mOCtlUfz06RX4Ib3Z+y/g6NbVocpH9kNvWHYjnDe7wvAz80hP1+HplClOcMM6fzwWjjGXDbT/gSKIAJL9VJoZAZd0m7wnF9I1xwlbkLmWkTL0fHGjLGcT7S1He80MASdHqI0sjULrnSJAh6IkndHTRQ3cfTTPQ4g69DamXEHkEOPGaZCNmq5tw6Gl0pqOSZK/iADTvBlaTr/xo+VTxeuDcvxblmzGnn0F+fsbnb1oGV7R2TDlbuBMWQv3DZP5EjyXqi8V7owxU/4KQ7m8d69nf8V/OnfEqJbAQHEAC7vGRbapHSuiP5Cj1OXuK5AXYjjTivWduWAHotCp5g8gKqbmxtusaloYasI0qJVoCQ14jUBzmpSh9ZsUBw8lqJTUsEy2V2pFaYL61JE5+n4pEec0bl+07XiKZwg6THP6MHp/WQmPPkydTZcgxc2aM0kHcv3t8TaMQGE2bHtR71kVGMrdStkSz2jsXxm98A9SqCX3C4f+Hh5ZQXRbeWdzfoevivOkq4xwV3YmbRUrmuWgAkksDPWsfEwHa+MxbH0yrQczh6v2tEWRIs0zgqLOs8av6Zx+gUevyUgVLBcW1AhPXwch21hHGl2EB0Ug7ojIJQigXYiIYmz0SE7u0cEhdedQd3CnbTo3hND0WYZsnX1dlxLmkVXWnk0nROE1eXit6OZPRq3OSnaQK+Rm0jc/cQZ3LAqCxdW5VJ01/nraRwDHjU3xmHSvt9u2ot2sBKKaM1DigEY+Svp8fZjUtkMvV5/6pyStNRXdkkYfzMGuqQJdap1EuYV49FambwycVk3oh9F8JQuwy5HcM6YnYKApEa7E04nDTm0UorY1JivQBsiz4zZ9hIXesXc7cgj5cu2bb6bk3dW5B4jurgE0Lr4OlSUZFsWx9VzNlNIXK2J/ecCaz/XfGDJdgxMYHim4J3UOC+6wvVU4I3qh5B/kScyspsSsYdiZVMjW8wF1cJAcBn8Z3I/ngqksjjQKuw5xZ2qVd+mSpUpmK9g02H3sWHF0y4zaU3vrgJQSwNikRti04k7zbAp7LTc1og0HfDhX2QUtOaL8+qgvQWtTDQ6AYjAHskpaX/icJQ31rE729Kj9xqe2j2ahOxyH4Z+Nw1xun+cGl8UsoQZFjto/JWxxHHI4o98aYFI5SS233RsNvcVrlpepM5oJPpyB7i7Td8vEM70D8k0p9b9Yj6+zjViLidgrIbG5UGqCMlYMXIaxz+VfQospT+hjPPtNeqz9pHbsgbgkuGoktRS65jpLFvh2yo9m/JuqxT6KyXpAf7MwkztRCV28kLBppHt0sPTzGktDimCeQWmqiS1DqyWxtHRkbKjaL0ric1N7UGxWyQO/leJom2CJtCzAhZpPeqZT+DuB8pGTwt/gz5E3TBpj6YP7xP2USDy1yUKESUkSoXLjVPD8+NHLh8CFhw02LnUd2Ec7eXHSFB79kODQk09hthUO9mw2YMgGlaTyYcSMquGTVZttl/SVaRk70qa5GQ+SmyV8ATKAsPB8uCcjcc901/m54bva9iR892p9EC5U+G4ruiJVAIcUo2QqeEyw++ALRDakdE+DskNDmgTRNMmrjUs+nEA3VPYxq1hOzQqDceAd5G4uklqnY6TWsynoEMPUsqzJPxUczp1e2dJo7ixGm87GW7tH3/JkTetwea76d2FOK8R8WVqP3JRTUiHC4X9unatuMKJj28iyzs0sPdNRigQf2kxSfchYd2ybDqFtVlDjfgT6Csnq2vTSO9WzuNkAKZSSWdn5xXxafCY1st8XNTNWqTkFbERJUnkPnFIqCBwIdnBSud41Yqf0ftYnVf1x9g1rsU0GFReoMEY7vugjr28xA8VAeeBD2WZxnIT7IfhpgPLzCheU54cMT5WQGc10t3r/PGMX+eaEZ+IS+gN3a43JWSvOBhk3QyxI2qMp7jpxZmou5T+XrB0KkrotgEmdliGXwIdZj0iEe7pbwbc4k9O0fCo35oWmEGr3bA5nfDJnsFiC0vYHl68G5sKHRNKwZmaPAa9z0cwigy9w49FhoK/WkJM686LmRbmHo/0wFr6fFJkdrH6MsQCRxoKNFuRr/ocdITgAHgrNapM4dyfSUDJ56lYqvJ+kB+M3xgbKgtgn5FlDzpISqNENI98SGnSy5VepwnEaIlkczhVPPR7yWHZCT6Bhy63ZE+Lzys/XeJds6zRXTHEi6OyLDAgNzhwFUsgTpJkfaXjsthBpLipPqFTdtd5VtfHSzDf+ipxinDZO7dHBw6UI0PSXxQRhReVD5D2JvYcSScBlhWoiFxm8k/nuFEjoBI4JRM0kalV/lLj2ytgMCUToCVhrRV1ll7S3FalP3JOTXlCNoOlpT+anbCs6MZXsh9DNCF1zXOmTDMbdo64NE+FiVYGpVJGuTgF72dSJrBdaDxVHXeAqpFTuIB3fvXDTgh0yeuNjFgBqEGKQTx5dPrnDbxm26jqQ0ZtvxbeypuwL3aJaEMxty5ay38XQ8pAvIU1X8C7j+uLXs1eqzPzF6JWGM4CheQjsTj08IDhmx3VZZDP9oXd+76BE3HEpDAjF45Utz6IJJHTPDVFKQus27GzW3ILSY1TreKcKoU7kLZylvOrNHKAf8CiqUGNFj/lFb023e6elUgWeLbdKSNQbvzNlVloY2z0whYyikouHMFehu3MXCKQwzvFbhxWVzhB2FnXD1IoJ/KIPELr/vzSzbBIDy5cMT/Nc8VC736p9Z6KfoCJsUKx3o9MY9q6vvtDH9cKTUOnx+jV6/gBxMbCxhQxZ4kmz00yCQc/CJd/vlhNMOE+LwtAyF3PAvjbSkTpiyfi9VH/qJN16JzsX12RjhaomC/zJuqXRJZ4nYKKFvnzWieMn1tlhRqk1jlX8gM2qP3+3Qa/jm7iOiuF/rECwG+GUkKvHfHGZz1pnDBpYVl+rNr37x5/mvEcINNg1z7cJGZ5DgFCR7A8cUZVohHsF9mO514YGZmm+KWlibTpu+YKIZc22ZdJOPoUyH3pBCxrrMjLniw/vvKqrE1HlKricXfhv7yiclyvftxyjHowpchW5MxMzT8jZ05WE3yYaxHBmfsp7LK5+KYsHBNJHwcaCvLnVctXvcCSqxtQZY8TvzoZOE+JCCVGOCiXEPaUutb4hu+zsFJlayJ72GjdF5d4ZMij0n5CKZqi2sWSf0FpwRZVUBCBfL9q74e+7EB36GXJ1rp7ADc3SMbiRRlUlEM9/KaNSxCjwXeocwEgEbb8RyvFCMNEqPb91EKg+HWK2x+59rRu2x3jXSC6+xQPyDj3d/9+8fI0UKpBvFuZKlW6BqLAo2teVn+uYzf1+5GImfPQjo22FnQXzWv1Df7MJIOK0w1NVfriuGWx0duO7OivwP6Y6tADo7O1ZmtydHmeQKzKr0wfQa2xM2cTznWQnEt5JyfGdCFTew/0Qd3Nbvi7vt8OYvvePkr3ITmkVppgyBvg6L+x6QZMmny5rR0ugttT9qOH01MiHm1gwGm8XrMtimqVqfEm/vugtCTQh1WObocgqKm7gsMurJuJKQ/sE1V8dFb+KF74vCxOobtPRBmswjNkEW4ywm28Z2QOdFK5aSx/c7DWskj0E9X/S04my35bHtO6YQLTX11Qmqr+gGcskyP2p9DGJhXy+gHtkmazPAmBSKrWt20dmS9ms9AmZbROT+hhkEGzb5QH7I2GnuMO1Mg+6wU7UwK0NcofECRQ5Oc+bhA4B/6qa+nDEzSrfZlayA842CBfk1qM52aAhSK+z10i1W5VnaapOeqGVS+JXSjN1MgzvnPJnpRDzoP34buvjbOsXyalA9vDebc7rAD4EXLk2MKbmq/BD/2n0MIo3L1UMZLTCFsR8baE5T0vpbvBxnLKpSu4m3W8Yn3m88Fmbj2hmerxWrWo/lN/CMnhAMZcdSiJY0/Lm0mFvY4+aSPFykCnhafwzlIH1lpTWJaV0Hbh4Aq0Qxpnq+QyRXi85XXv7tPKBDLAcKEzQmyr8NVLCXfMm/MS1dk5zTdbzRnooeYJKZwtwMfCeG/45D8mIyg7DZrImZGiTg9hYb4cV2544TevFnBAeHu6Lu9LgCBqz7IEOLsOxVzFYxQWN9YKd5hOWzTWQ/rA7ZFCifTRyC4HmdKH0tHUFl0sD0Te37DrMTNs0ViUtmQq681ZVXyqEaR1iiFPKlxLAQeGoRHQSR0/NSgLbFbTeCy/g3hkLWD22kuvhakSZrxMyn36SjOmcvHfkATI0GJM61eH9DJKHmnfW4rlkepcqzJ+TOahF9kXCCDBVQEW7g8soMw9IDGcPS4Go1EFqySBGX3rZTSdX2Jv5NysytUl9XiakOHj7N3cXDOi7o3TSWMnbD/GGrIzGFWpoiJCOYO1JW/BM3HF1pzLhV7wizxeRfQXvH0Ca/c3cXJGEIHGVBXecuXFKTbbi+pGLTkb0PXQUiyxE602bwp36I8e5kWzgt9yluF9nXifqErhTX3sJnX/VBE0IyQzpJkT0HdBfuOaUDDWAwVeIo8+vrmBSZxWtMZ2WZsPb2M4B6DkZmYuIbg9OzcTRiNSF0guBp2Yq/phc01jqdZ7T4CMCaQm/a/Ix3Km6CXMZHp9uYAWGsG0Ohsp3g1Kn/+ow8GjKY2eAnvmu7lANoBwKgJUy94PFJNXfsYHAfAHdD1q1Uz64YuswXn/656TCbuJ8u2bDPhzsTPayAc2rs3xzygRFFc2BZjW33wPvuAC9qbJO26o4DRnmG3SCsQSprjKSegl/uSOm/Atg7i9rTPai/QGLQ+79JepnqFRDfL7/0tLuX1vnR1sEsAMnst/hEKQ0pwdPYobgqpur9DyD72wKoXML0Lv8Ins3BzCWXhZ2MQuO8e3tnJOImqn16wWkPdzYXrz/fpMXlQJebRQiRLvv04CC6eg/cpTW+sKRUehdtBTaL21Py8fcBJG+40b2iybUMFpN4wmVhV7QkdmZ4UXNAcpdCq2wBvA4tML0Yxg5y41MsEHHVz4rR4MAZalYceZ/rqjuP/ofHv3gPjuspTzdKonjtNmEFpkbjlELTyzoB2ghruU2AlEm//aCUe4eFBc4VjEgOmoKSITesM/KSkTmhQork9cIMgeNND4SluhV5rpdbjHpBiyikKQN9FB0eYVzj6sPt6RdPc4m/7inN+aiZ5i+fKByaWNsDaLOjzp4me2HCBSjUxXwZhAleIBmcNypc9DGwWWFYGNrwK2cPsLoOSQ1HZr0tQ5WbY4K71Oinf80NyqzRWlg9+Gb9y03wpFCDwitSpSQXejdcqXxMZZa18n2lzLQY/2ktF0aCozrs6Y/cAIp+Bdak8VAXurge37y+sXNuEDKAxUX6dG6cSjNf5wpQp/1s3j5YT425M7wEMTnJMTwWRURGp/R8tUwsf5oE1wIQg2Wp7g4RxSvgaKioXBvfiuMbccSNyHnDqRzqYeDedTBF2hdiO/cVYcdxodqGmRuzRVNL/gMk7bYHeVjnpuBsdRAGqMs+EOJQI5IsWxyfrA0egPzBv9mhmI+24LfnAJqzGWZhkG1DOwj5E7KzzaUpgq57aRRmP6ZnjyZFLiO/sur7wgsiPH8f5GIe53Z/PECefTRDThqdr1xr7oN3vruDAbxj9R2oek8B8/Y+prMBoYrGOBk7HRm0q5Jk3v17Ytq7ojCrgIx92bVN7dTcZ9afnYmZoAvBFKMX+GCngujBenjX2cuMQ4bZ7oAhhmpbJ9RVsNmzF21G3yjrS9GNow6miJGeaF9LcMBhiXH0ZfCYJHqhJDVvvm/Dr+Mayc0nK3xYvMYbxPZE8xuuTf+yv8RLXK3q9zdM8AKOvOhQSZXzwikXUo1sSaWGiSs+AcrJ4/kpdEwjPe71WXuwKS+Wz8v2qR/XkWLu82OjtlLsmfumpDzmOj4XaUv+9LejUoD9KorWlwvsJ56coFS3r8c267qrykUnnUEQXoOkj5XK+v7LtX90Wmc7kxOcMW2wJCFjSI09gbi5DRTZraejWYg9Wvar4BUkWPOJ/XNfZD/ZfbTJQhcDzGFbxDYP9d2HxT4K/d5dEUAYSv6pxJrny7HzQ+j8O3Rz8rGZqktDFG1BbVMitI4QCjpnmCmmTUshdci2HR+LKQE7ba8S2XgnCh9DkYCCKxb4rfVgqNEP9Z1ojqZd7DVJTXKBHRypWXhsXemUc8uYiQf1ApfmCgh9NXsDD49XSH6/dB68d04RF/JbBZ2mgr2+TtqG3LDhFuejRARhc2HE8bbApuFvxvMmnIjdnHPBzKGTEEW2tAmhJAgQhC9goVBqp4u/uzdUdwM9G8NqSV+pqL1yA+ULYT0fS3ojXAEDBiL1t8VZSznWUpsMQVFgH55+dUgX4A4c+DHPEPdbn2Cbe70F03oyRQAXrUijk/bUdHuGYjnMoAQMmNZuKXgnuE3DHInR1kHOiRUe+ESd0ImbbHkFy/4rdktd9UW6KbiD1nqJk1Fn1BXgG7WbZmGQl4TNRadidm2V0RAGwcbj8nCv/v3xbpFYOKmnL2uQPbVLR2EsW4AZL2K4yuoW1jcvqR5xRNrvJ2HJk6HQ4B9jwsMqFhZAmmwKGMS0VHzSvo5todnwmVuhxCH0CcJC//MtwOD/o3QQgZb8yo+pf5IdhsA+W1PtSXW7EJxENphGnE9IRqc+n0ZugL1bzfWH2M7Dbk9EeyJQAKMK2VdjKAA9LxLj4YZZw3RFHPnIANYdi3Isnid3uXQGisrGjQlYD0kXQcJtRifTLzUMcZ3KZWnLG3DD4bOgupG6uBFmxBNldz+umAnjJfivFdTurJ3xYwJyr2fT7dI509sfLjh7k4DTHLms6qwiM6DSSTHCA0M9m8aYZEerO93P78Uv0CVlBtDu9XxtloaYaNqJ6EFRyXxfT/YGy6asFUJsjtO/95ZbC2KyX2u3mUC+Q8c64qO/XR+qSPZoh4VyUPZfBeVDCHkZuOD9hV/6q5Ln+Su8N9nFYh/TNTN7kPB6qDo7rEFkCPhSHMyBP1GlEfDxqt+THJjb442bdkZFTn3EuwxfUp2krd309f39/vkARU930WFZQeCVt67RfpzkiC3kTwSvWgEsqdHXzvPSZsdiZA5qsRmKw6z1DoIP10K7p2OB1busD06yjgUKqVI6wdrQgbD/CiXCIgblAyTLK37jJEM0FwhZ5+PhEZmXfegrBF2zFmDJWXYwt/KyMZA83h3XiR8m8DGoENd+OIZ0ZnHuER1A837abrFOKWD2wuaQ84Q/95uPEnTb+6Oj0N1aLP0nWfp9HVhNLZdiJs4oO/t+Cz2ZAIJS7aMTu/eL0a1+4cbQleeIX+PfZOKK2t9NHijY7rzGosu3EXgsdIDe1xv8+7nfDCnqUv1y+c0EAQM315L/JJpxC+7GheMUudgFiAdtvxHOuummOdapccfgKd+SNxLYVTtujamLP5BGWdV4Exjtz1tK8xuTifMfpXqoESt3pCb+wJ1S3bkX4i5aX2Wr8scFk2/nuvhWcn7ugLqdmTAq0b7arnMK+0R8vUA7Gw2Tut6LQSLfUsOp20cIHMp6QI087RNror56kwYLianM25V+84UDZPjePV7YzWawpumZ4MkYo4GqA2d4JGER7FDkDlSXUAc04tPepykO6UGY7nBW9W7OOQATvJfeujSq0pOEZhahc155bY7nFJrNMKmSd9MAXFhh1W+OL+myht0hQi1H1eW5J4VJ9sN9bZu6/gXbxj9Pk224IzauD6jcxlR7fBEnGWc+WIsaQqUsr+xQDOGsK+gz1zsZfok1iiqqGsSRNQw077HpmCyDMfyasZop+u1EHCHrEGPXLXlNMYaP4V9IX6m2/+aU2jlzYzVz63Y7yYT7pe7V9Z4RGkpEz5ut+lxxkZvX8C+9oXzk5rck1w8XNdsY/Ch05/EumL3WPqy+nOJeQTxL1jTpuEpx8nT/Dqt37DyJ9FYSYWW3qMHCbzz+7UxEq06tHx0T9s0cxdL1JJSPu1L2wKOo9xmHvvEjFzG6PZ7TmdoxMSOOLlmSruGe7gxdcaFPMv9lp0yI+Li9dCa8ji98C2z30SyqfsZLWfRnPZ87F37ktdkU4EBu3HiyrKyLS6Ueftv4XhlLNpzw8N+JxEUlvNto4ZWTcusbYJgLVLCAeffrCiFaF1yK+XiOixbHHSWqHHdmfquV00LYmuQiAKZoEk9OsG/GvE/ryPMZeHpR959QI3r9a+BxAxJc8mbXdwg8E+PI8dDxlp9kdwG97W8sPVm7Wg/MuD+6713mwD/HYb9BgP5fpY5uIyKk1jN9++FJhyW3QN6ndOGRziWcKeZ2oTiMnqfJ6N7+y+8MLCinMTro9OhCK4+EIIGdv/hOazg10V3v5pJSNPIiIm0hmL5UrNZJluQIR8NutAF1HVvynl6g6gd5IlIAFNxrmrmdeFFA9j/obWOhEqxMKTWxZaoWoV/onYrzVltRoJw0kMHP+n3saDFjs3jrxKgVHmQ6zt/mPi8v8cS5KyAOeQBwuOd7nEgINubP7VjOqiEgQawYXC8sA4tJlfklPCIk+gBF+6GqcuD1EIZDPfHcvzkMcb8VMdk+vbUxEubRlUyJrXBqIFqMK4vzgpm+ELx7yk8LBzfZc/1s6u3zh9qqubtR9W24rYFOu5J7rODFj1ivcsv97rMFlXXizho52nKi6ebiPA4i4bTwdhkl8Hdych02ynt95GQiANN5863w/SS3Ww7H1ZnSu0i9Pr+D1P4JKsLrxoArOspaXx9DlwDC280/KNJ9tbd+VxG2Zgs+rPlshpbpGmKS1muMmTQ1dr5kjRoH6qGUu39g7QzSoHEaQ4Hf+W5C+DdrObHR+tqzprBayDQ3v6jdirbHJvLqPOrosfEoImXsv879iwGGr6xGMBpOhnpqso3JjG3ZdCEg0KawEyHSm8hMQPGKP8PFUeWiImslT+04P1XZ5FPS4LuZXZgDdwm8TnuNjA5pFXfw0o84G6+jwI4C8t5iyaJ04j4HVMhxuUSXlpwvdANS934wksRju1aAmrMmZWKzaNIK2yQjdmQ0vnpTaKFxzkoF4GWfBR0BK6vnIYtPmHSaCPNUf91Ev0Zc2d+WDNN/9B91Jb+jRY1+yQpkK9DXNOj1gpyFaEreSK/CNTRRhKwNPbsuHh/I2N4v+IISOND9cnW/TUAeCIIk6S5o6bGp3Tn47Oa9WyCa6yMxhBukW+tpyXVTl0E68+rS71lxtmNKAHdbV3j7VgoVbu7z75qNduV3ukBpeUIy7lVtw3jFwcp2R203Pb/Rcqx9bYP67vzcsaiQcsI7R74b8t54PceMMp/xjL7F6eP6LYCAMraSo1HtUUDQlg/v/l4XWjjFqLYlJlAbJhDjZkSDJscy08ILbl+nCuOfIMrB1fCjMTCV2IUIY18Ur5iD1opZukTY+/1sKBPOj/Y8oqlBcOPUuhVug1oOKAFr59qba4+/HW1kU63vDeqwLz/XSVRtEIsClz4cQhIKH58Bd4xMqwF8Y4W6HY2Sm/56S9WqVqD35mKexrnJGXwWpqGUfC0ZYjPcazVHuavPaXgzGslgUgDqIqf5JR1Por5zspcQ0dk7FgCWr16r8QLcz/LxXht2VCreuDwskc6nzmi5SAH2trqWPPnVUscnvepg3552ZqiGkodSs3L+zPoWvKz/U7ttKki5NZF8wtjT06LzKeXy1GFB0yhadNz2HB/P3C3V8Y68zJSuSzpdUrHcmSa6PNeu9Nqa9Tn0Qxn5PBB1tjt1NDLQu6NoNMQ6jRH787O5r/FOxCi/YaqiLZbTcygLcEQvbKIFd00brn8lnGVN/hqBJK8UwnHEsp4u7AMfxoOocu3GSIxZccOHV4KFhgrdn8t0Lo3940NM3jArMSrJ5NLA7WLMgpfHyhnuPRN3/FgCLvAm3b1ZTMpmyKuwi/zch1qEA5FGn+pPTCuz7Uewfl7S7dHM868BOkNCklofwkN0Hi1/eIGHqf3QpfpXIB3pfS04sn9IomsfqL0YiYEMwpYOb3Hz0B4TkDMDK81PPwaRxJQmQWh2gGY/jb8955R/b6z0OLrlMLk8iBWdO4pLpVO47cGeMc4xSwNMOAXGHC+CL8CaL9urpCY5abkqzu7R9bJ6ips82kqOELI4SyUS2wI62T3WlT3tQYmU7BgSbYtNywVTtTgUXtYF6q8j66CzRJE74BFL3WYTP8Mvsflff7NA7SXwlkL7UkxEIwaLGElFH2273PdLFmwVV4D3oS7VCosNlBtblKxjAm760zyuv0MWusv9fei+kL1Wr6uOTjwYa/y6FV71+smNMMmv8gZZ5S7yS9w4jCxAykRrXLCHF47iyqHi2xOyB0SZZtP6G5FpI0c9gbJ9hov8DgjosyMxVNgTmTihlfssqpewf1Bldji7hTbvG9dnuaSYvhrmd8mT7V6DyPkp5XX9LRzzOTeHVd24K8aqnFYQ9BtEBtgLSOJt2eUyI4VoGX6zhnVV283RWrVSRyoAypEee3Fnqke2MKQeYs2FGHQjW6Qf6YpXsYTqNdgVpAQmnUGeGCmoXZ2i9Mx0Gl6P1bZLLunY9PYXmkH/fNz+Ga0qDfdJKh1lDu1yoTCVf5CrDvSt8DyG65IYVube638R0jIniqAcxmK8Ze8xrPaV3W+LuG/ibtdgGMszDccCcKzTSkBxKeJH6wehW8rF3VWPR0XU01tFdtJEEQzqP2S8n7t2bkhLRHjiDkwW4u19HJG6wYCxevQcsVkSR7Y1nEi/tj7tUCrRSQzUrZX6grDHyAzWt6ayogbLVOxGXhNxxI/+Yea4zK3ySRcKLuKM0/B7jTDh6yCtSWBy+gUtxlt42OM0kjjRaEDkYITlzyfrlnGBzra893WbQNEM5Rlj6/rKgzXMl+d2Os9Es9fgCcdrISc2KmWf6zY2ogSRGn2eXRbhVdZcJ8V+uFFDC5XV1IbZHqasVTNlr59YZd5C7TSCcjRrD9Gf82W8CKOsKNSL2M9a6y2Q01X92HhZx6oKoK02LrP0Wy6cjmJlOPjfTrweDr3C1ejiLcJi2160EKxM1RdosBlKPWBt+UYG19vxrm+8oOxgsAm1ugIP/zIwM4lods3M756pvp1O+c8A845dI4AKX9uEh8lUCSb9uhjIihjYIpT0nECcutRR9G5GXB2W3jHuOHkZbdZ1VaJny/w7J4lxbaSK+Ggp+j0+FS78b6OiXcebuPSTil/GfOMQgvv23O7uSQW76ODme31ykvJZBLP+YnxiuFyUuJvCgruujs0pu7R9m7H1s+2WxsYXmQZL7036kvmTjvFuGu9jE+AJqdBf7mbwNh5+DMfg4F+497y8+nGcrlZHA7KecnBxUmLoa5N658cG6zouSk2v6PneNZCUd3BB/J62e76xmq6Gf0j91AQSjGHRBxZFNEvGbj8qg6bF+FPcCEKfc1fKU2LownFCjVHmb+nvPqZ44RTIlrKYVWki5jOliKEU+Bne+Orx0hBYSOsv5BbBv+6g6b3cMLkcTgq+ZaKx4/JSIy7Kg5Yda1NFVlqqm3TAweW1bqs3s7P/9H4CRnSPO3Y6ECzOYxPWHsLFoMt18v5bQ18c7A0H89JYulDEnABljI1mgfnO2uv0ZsDprN7o6PCZAzuwe8FZlkBrynSsjRLpRWzv6J2Ll6nvgmcAX/oQznA66Yj+2Nta5lrLCvkH661ENrolpgCQGju926T0Xo2s1Y6y+Lfi1tcYwBcpCoNKGuuaYPRg86k8IalLcAUBfySWm4kYURWr9gw3T5mtorvqw3rfp2ehAHE002kUPKBiWPtP5eRQ1jAgfNLl8AXelGDOfjccidOUszVZFA3x9VxM+prvsCulk6uxMcqbMT9JDzdWgVNzHFAHc+wGeSh2seXqrQb9AEkxKKAGVw7KntbXNz11UjQ1BfsLbDc1ILzeafSVnIDmsgJHJOevrY+mToedPMCR+wyhs8eK0ivXTgmbon9109y/QfhJW1EFFT8w/iUL8Oe0Mj/hrQdrpNrZEUmXv9x8MyJigvUAIuX7Qo/lnntRct6pBgGHXH4UvYW/N2vjYGEItJL4cF+05ZpicXRm2JRSo7HRU8jUnrMGUfZbdBTb05cd6fP0OIUXjFaVMa5dYol5Af9J9avC+Ccu0GPSGeq6Pkq75Yqep7gQBxXq7XjmNPba+WuNnvvj9m15s2nB470OeSaKvbtJqX+5dT399sDnlFBCp+W/mGmws/NeTLvS7a72820G5/e0UrK7XDhanFX5LDdYc0v1VxyFYdYFOYrGlKrQSaw44qmhVWouYzdzHm/Lq80PJiDm/ZWLdgXrwFJ8Iuc2DNrQshwzpF91eYoS3ODm7Z5KVUPvz1WRyBrY3A4CrgSJFueP9azkqgK2MUeB5Tl/KX1yEj72JlFc3Fy2giuYXv317m01oXlOQ2PlvSKKusJ6y6LopH7kuWSHOznBGCDgQ1J1I0gmqsm5pJpwtpTHW2Dmtvmt9XWUkBP9f4aCOEAkH30cxrgfkZCXhTHGeVDDtZsQ57wD/8QtcxNxMliZ0NNd7ApqasIYQ6ddZ9lnSLdOkUqwsYWtD7a2e3jxhuG5dPcnOVI/m1iQ87GdWvcfYgj47qd+fLgvrIkpRB0EP4+MrVZ783H9Tu3IKp01tml2OeDVoupO9mghJNc5+OuOeCpBcjTPibyQDhxRNaCjNWisdseao+uHUNvZFAOk11vd5v6pOvfAlR8YXDD/41yXh6q6vmgXiUOuCDNchU1hHOi6SziqRf38mn5ofRZ23HRRUkT/9U21Y1ZKblmx36eElvuX4gMiAU5e0NrXvC3DJokGLnhb5D91zVGULVQN07sTGJBRVcDLHa4AwiaIBYHgWZ6vj+3w9+itO6ypNRobpPEcQVnr3zNPAkdlKxylg0NNJBbranscX1PJRavVpv6nGfNTnVnmRbJdfHezJUj+K/gf/x1ua1Xjfi+iBaq+obnIe3oVZ8+mDEQSBhWVBE27e4Sk9UmXlwBQUjq0WK/h0tq8ZZlBfpLrGiIQB3bV33OPPPpVRXYIdXRTBBPX7U5uF4JXrMOsnWHkkxQk94+swjTWjeeQmhNWjzHA4j4O2UjgcSo8xojGyQqkRkR9hPmdEI3qje7w8Rgexsa3z7xVzzvjnHCyvTTrppVc5wSC2tPLoTQcUVtBIdrzT0h0JkeaVD0ar+vx+cvOMZl9crc12w92sTgtTZun0MCqCNXTx6L+yEqLUXuuNnEk/BFcpLAVzEVZhOcDreQEmN/JyZoz1XHaIwWEfcVADdDRjlEBismWKcbyqn6uMmvDjjEpr2fLDv777caql1N/u3oF/qx68jCHYBDXK4OTDNFWzCfVHn1Tgf1PVNml7nL9ltBycCtPDxEVD4EQn/i4lVFTgjRy4ty6SoObRFK5zlXVM/xQisFxyWG9mQR9dndnXeiHglfbXGF6hPy20aV2X/UjZuCzSzct7AZ9SwTIWpeAHZsz7grcYUy1+sjduEnrZgZBMrYqQtUza2VBa3PnYuvnFlb3TSVOAyAagrUgYMlw4NXe1U+R+dR9ploQpdlkZk+WP6FYPEFX7ZPfaKGXGiWpSThfQ5AIhZ+ETruyPLlkhcOHbdaMJxVRAPOrmKLT6EmeW4JV6fI3DZHP7L4R8OZbBg7sYv4fFLLQmMPKPM02GUPhUa1b82hZr7hWtoj35OLRG3195GzaB9bOjfpMKHUjOpH+0i9qy8tRP2liTDQCopskpT4bmPGt4l2YU6D/9RawmxW+bRAR7ekudLnibXnYKip4zGgEg3NcMVESCZ17jQ4B4ybtcChBr8T785TgHmTsYoK2Gk+cu5ImTP5L9dkCTGVXEV2qm6K64jhxQK2cWaL/Una2IWUSRBw/XcU4j3HRdeUhNs0NUlfdi9eEI5oy/MfBOSPItWxlvK5zEW9+H3DpRRHPcDkM44qL4lIKz7Wj3R5pJnX22nFGc73GqAePg3e39JQN24xrtHj0p/ZrFkG/rJt6Hq5ICwOxyzrk5oSSa0Zfsf4zZFco03ds5n+ejvcA9M1qdBlv4oIV0oarwnPefWWmCDDFgvcO5dAF4SzACokjpcW4yIoO72kaX6WYFz+p/aGdUtxVTZxHEBDXGiE1zxXkvDtITgWS3KD/AF7MDSH3eubiT0+VtQPdGaIkRNjXnU8riPCRTezpjnVXEKea0Ajy332moUNUz3HwU/SzxJzA9ZfUXI4SXFNOgUWqY+RyL1X5mGXI5LXdpTCxKHlsxsBhIdthpyOjvFkmewoyurvfuhinTiE4chih2E4bsn90L2OcQ8QxZP0/ZoIWi5E1IpvzvMKhu24KFXdH1cCFWoqHxpXvBaELWMev4Qmlz2rWpWnNuWO7Wu7cE73Lw9onO8GNCyJfAiwWBmA9H4lTrVFr5fnL7R8CZyz9M9rYLyv7p5OqyItLjCrNoUAreQAAx4ak74BCg4R9h/G7h3Cp+NB4nUAewuC8J/Ally71f22GVGNsXfzqcI0bxhIJ8VFPLR7CiVt2e9xFC3nIo3CZIMcrispao1mFlaDd5Pvp88pgxzhFMaoXOPGi8VGm2D50tq/KEdmKVqMAA4/M4VDm2X1TbbjlLoROrXAIJtR4p6ry3YcmUh9Qo3J3pinUQN+Y473385vI66YBYpGmQS9mPjV3x3reM9BuG93meoOciqm6BIlK5slb3z2HWnBIXDlx2jp3at4Eou0P5ALQa2zhMOagDLuZo8Rw4g27o0cY19uPD7p1zkiU/mkwbH/K+87Q7DUIGxZZwXvBahEY5yBV3nSVi87LPRX4Cxl2xevQM6Z0584gfeiYKG4pcMLXZL+ktfdvviyMCXoDV0MbT17XgcC8UJ0KRxz8Pb+j55Jcacy5/mHJCsPx0qg8j1OrxcNpAtUOs+JxcFlxl7Xr+fYy3f/OLarRKZ3A4jwZt3ll1kEJBFoMmyr4AUC43FJzr6J2cvCeDUcovUDZ73UoI+g2eqtEIVqrw61zyNUsThgSIwtrtgtI9HKQ1kbRRDHMvMkNuHbyk7Dxjk7Cgd9EF2mTi4Ed7w+pGP91BPsB3poFCo3gQZgkhofE5mABtRZ+Pkwm6XLHQ6U2xd/KZjoIsGRTXD4Lg4y2O4OFUtOqUmQ3CjyLTDhD/LsS8lPgHPBAvseH5ki2u+/Y+Dmk5sEnKr/l1zHcjb2+hE/t8SMBwXwSITjPh9tJmc1Ly13htcMqZfB/qN3whpxE1IWaaeGWxFCllHYUlkark3glHDv6VrJFfkcdFaxg0fnCXRJ8o2r8S5Yg/8atKVXtn44sK1kChiudZud5hdaJB6a0oRDOVIt3AMTL0Phs19OqMVdmYlhmVw6KWVEwTwxoQZUa+Lq9wEBdAp1yEmWFF41MgmtPz0/NJ8xVcAUTIzqT7MYhd/dOoLQkQIoG+HX+TV6Si1akC7mer4Ob8VoO2Bw/5stSx8NsjfKNYeNyMoG2NyPxNAGkY0NuxCZpouVN6pl5XsNBsY7rMnSd1KgBpZ4/S1m6Kmnba0ub3AQZdTwMmRUjIepo7RuosIDPCEDDYN5l6EbDl3gZZLkqmXJ+814SHJ9m+gGwt2kCBtrR7lpkA3Tg9EUqZ+Hhyi8+bcrzBvBVCGXCZ5Wpxrxe8UBPjcHRcVoI8qTV2OiXRyjlOiUHEl8uRi5+KFb/fMiundWWhKbl6sOJ6oW/PrqWgTExt8xCRPM4dLuhUqeZhEgxWXkeq5m3e9YpA3kK1HW+iNlilRDepT0QKtiI2hDY24c4rDrv+zzuVP9ASjY1IeIL+9F9e0CVRtQA1NT3h16WpC5TGprrE7S9GcpNKT0fcGIb71GVhOu84aKZdaO4PdbhvHtj6xQid0S8uX6vLDdx+1bOWNgwAEJZeT0DqKDUcYDFq5gOleL/IGJyYUDQw01i+UpLVYrxREd1TWH06chFvUoxNVz0f/+0DW1JmOOEwURePMZQugEI5oO4wtphlGHKwZElF4WpcRuG3URTvKcPPt2BFm/GFSViWx4sqvHbWf/Fp6QCyoNFrF36UQZLuG8wUlSo6PCCUKxAm7WTnhfB//pdHOA3DgQrlQCsw+iG8q+8HYQIJBYXSvtGgU52+VG0ZWE1xm08IOp2sfDCH43caKR2exuk7o6aFKiJ5NWLTK5J6vt9Qtw++cBXdaPEKfPR4fvPfZ2p2MjJ4c+OTqyXZFIymhk4aMWi741wjRsLXEGrVmE4BhNiNDXm+WbyqF7pk9dxnQkXCe0uAOS1JCt6qNdoXP5yHl4clI7PiE2tFojioZVTz8TO3eqRj8u1k9do9dBNet+dIKDg4TLVM5mMF5j6WP3wtfvaYRS/tjTPOiD84oMoN+Qaf8L3vVl4LJy9E5wVxgLf4UmkVO5kg/FtKWFGkr9e9Yh270+TPRun9DAGHGJ25Ezf59Kjx9tay/ZHVhk88PgPCwL3/jUcw+fTHNs/7hgGx+FCRcd5elQ2Lhp9VDO0Aj0Khkq6a4bq0ncng+bar6ZNZjReKkqOeMv/KETORypVkwvSVhBWfB/jzDmBldfJNQ/xV0R7J+cePHjGHtZ6XOO+Ab993Qj7lcgyhCGQ5oJrLkIBa0Dz27DKlQu9PBxC0txps0WTY9UKBkP/iyewvXs+aNyXgvNpNr0DUfJQvhDamNpaqyzB6WTDSBgqi4SM5rVqwIcGFM0HdS5MZ6PF3W9WTtCEdeJ6t4vm4FaSV63zXtxTYwq5Fd8pZLoT53dYBesP/J47o0ynD1k5Mn98U+gFp3v8lm6PAUDcVuZucuKFhA4z8qg7zcCiM139azzeuSO20kzyz/CS4X1dkWFjCa46h9ct/GZLkzzLl9CWWDIcnJb9rUWvdZ0VpPInFNXfpV7RD469mGOoxEUo18X4nz+K0LJ9wfVFinT/r+XFZ+7zl5WcR+C2vi4L1Jc+OfMk/pE2Ck7/+nmxvF8zfdSLhkb7p724yVcZfn0RRenlShR2sBv8Qut/rQuComoWq+QJn1ufE5gD1K/7ZxIehaiTN+jz8mmFwZY9bmhL5D4mUEBRbduBaZ3HbNgYt5JThp7edpHNFtyFtNaILwd5lgiC7Z4bGmrl3QIOfkebee/eEuzIy3PSPJXuz2sPDPUNknqUXX/yXRCl/brDb77XrmYbhJYoOFVzD7+1BndgEiPRLmL9K5TAlaY3W7JmZ6InnFeJ2zg56nLxzzPjT0ZMq9pWrmEL5CdI0XrvDegaQxtO0BeoC6inRw1Ako4sMLczLMgBWPdQBV3K66c9wBjCwXycs3n5l5uMqTz5b5HZNbeumG04zvzWkKyBv0m7dAqVElMENwSHNloHGTnY6G8fN/c/p+GvcOsQ1sazG8U1NNXfXILbeckRS/0qA37XWcPLEVck8TSEih0Sz5feV5THOheXXbSIsKTUsaPdZXkbz4U5yqrk5uAfoQKiXe1W/vOYYu1a60AEstmnXHASJMm/ot3zGc/Wrja+Xo1y9NX3YpbHj7sEa7xPZ0xGrcFThm3bM7jPe9b1etkX0f3RK/yfwvcHgueAurom35z9j868lWISiEK9LbER2ca7fPU9NnXxh2disMpUMPbJeB9kWl7tRgwrmUmHVzsCiDN2VLgJ78auECx4HBk7+pZpKWoc3yps5EqB17mHUr1DjMTuQk+TASB9lF76VYnjCfYuXURtdz57gcup/QFqRPuK8VW1yJacX8LAV7BwMElhVg3HakuCleVrqKw+e7AGLAwzSXjFWxipp4kgSr/4n7U72039ccVCeMH0pSmF1kQU+VeH2t8nV82ifBvWUwzOtlVBjCLcdz36Jfy/nLCmtA2HvZOUVXWTkbMQMSRfbaq4jEFbFufpwMDk7AOYAwzcdGpm/4jGHI/yDh1wd9frj1IF6evB2VtPm0PRZE5zUmYQ3tim95zBvgZFS7VbpxOjsSvseCiK453hr2upfIdcDlIcT4W9ifIhk7NWwbYwf/BfC1gCLRnZMU+oZmgRv9POpLuXa6Zap7Iu4JhxDtsxg/MwdbKK5cvdHceeHqdjYYSuQiXkRgd1v/0M5TjAQinfm2WACXAPUTQduf8W0bO6ErFITZLNsJ6NBuih1DccBWgtwfiPhTiQnC1wxAbEq3+evRbtMAPHJ3u3vE8MpP8yGE73Oe4riEAx4g7YvOKs4EmSEgyZ0TIaQ/e/D12gpmBZSY2Rh+X2wTU1RLpIZ6O121VFk1xZSOus2v4/MYl6o6T4a8xWx1m/VyU+q7zh8+NiZOIZM8rMvJb/xIdvv4X/ksDOp+XVfFT2y3KHTwuk45zRXehMlTRzsx600tw7rNXBkUOxZ/Q0ghCGkPtKfM5/5cuaSNCHewbOqyIONu/1Fx3nUdYiUaN9N5QaFFLu2Boib2wMY3Z4UfrInlGo2jYNrCS9PcPVHskMlv6L9fNk0Pgj+/eqrR9TYU8WdDDvmJD08AIwyzt9BpLU24lg6OYO3GtC778T0mh/HmpgM6uN0b33n5zgGIKBKM/uoRfhWcAABwcFEz5gHZNj8WmPASsBiDcg7zaP9RxEtDTuFUVFKzkwyhX/M/KY8EwMRzv4N9+S50WShoIu5nyEak/4X39jwyela/0OHiEnhrd75qB5Iaehomg3PP/xZbIw3wRiqFczrmm5tTquQ1S+qAZ+b2313ty3Tsx+6biIwzquyI3tlQ0Hp++8Qy8pZLJnzXnkoWo9kYmz+PS3z0DWgMbzkaH89XjIAXlyEWvLZ308VMNbnxaOiyWCPuwGePXcW2aWmZjN1hLswdHbFZsk9fh+zLAXw/TbdsyzClpO2iKXC9AYzsbBB1JwA7ipkg1dx3PTVixKAVDbkgIXyAJ1l6NveedrlCER7vzsFTtUXhyao7KPWTaxwyyhXa9q7pORUlVBRegBTASLT2YO9C0VbDoNALqvmHDAewibt8sb7tZXX2UxugidLL4Lv2Ez8f9b8bEOSv4DEJdGJomzU7VU+ocwZ0f8rgz30n7cMr4z1B2n0OWpWb5tISxZAOX8K1NHm+OPNNakHWoNgQP0U85lAcNwf97yJKF43SAGyhhkaRolhp75eRe3nHTOgQMF4q/HnSxivUxZhpO2/4NUepfajb0NeVYj/6aJr8makMAVZ4bEKXnVga1rtnBpFE65X7nqK/1XygSY/bU8bP1gLJFcQDUP6BT8rFdKutqiJg2Dzg/t8Ix/nTJqM+oDRy7YLxoKuuXeEfMJqZDUCC99JA2AsVhNgYT931jLlXo8sOG7SnV/v2HoWnomBLADl2NS9KTTYHQJ0ZMUXFMwkOxoPMegQue4MbcLwc4MhdVV/JvnjpgefnEFqG7kZKifgXVQT33YPsbZceKqfkcbO6v2j7I/1qZNpQajqOJVy9vXHVmec0ZzT8MXLoOlswJxSRyISvvDKtQYY2YngKSO8gAwkKxNniO01xhd6iZVrY8V00DfbgbpyvQeJrpzZGPjfR+/TAW+5xODhHr2XIWsBSClPJZweufbK/g4acXCxsR9niEvS0BrPI4Va0at/90uGAib7Z1ZxdZnsm+aWZxqMCy7x401hbSulMyrUhfhM+Tn4hJwI1trOqQ57PkaCS73xBk/5YnutBSnYkmF55KYPYujgyYskqG7EGjjgdQpOIvmSUnoSZGr360oNIxXaKMNhkky6DdWTbVJNgxmTRObsJmY0Y+CTdMUvr70hPHUPSinM3ONXVVhoaFI7xXXGyBlbhlGQs79213rD6Wvd0bBYKfUGsQPnsbQofT2gdRWDJJq7UGx0XDYGY4aQVqJSrSljb++HSxrHQTC8YRbneK1kk3vsEHA//M/yHQUJwkVw1ICT+Lsp7IEmA0+0PWLQKqGFZSod4sP+gtcffV7ZTUyUUAaCu5UKdXrDeArPYKEn0FndubQq3qwIWhW9+GDhmqC9nlIHIPJWnidRjJ8JRAnB3YLs7bmenXAtsqQay8aQMdWk7EaBF/3ig1a+Of6HrLaM2aC4+9MxR/1LfxRD/dkw6Any5ophKM0oGdrPEYPHMYfT91e3OS/622r5tYcMJSBPRaWxfsA121Y4nv48oIZ7RwTLGwmrDxMEH4bNRwzY8M3xTtE1XY/LQ/e6uqi0aOu/DoDYS9gubx9whms2f5pEw9ixsncoDESHZTkqIqlQhymV9Wk3506bjePydWDdVrP/RcZeSnO4hzMtRgQ2PxMxn9m/omfy8kefIp39OawSMFUyFLRdTmRH3dQ8Ibgxjjfkrth5ujocFssBb211gQC92NGZcskssfL+NL1hxmTnA1jYm4sRHXVD1tHLg7TmWfSlh9ypPPOQ4RAJYPjyM38GqYY8325MYtqktuCrd0dGGRyftB48RjdWDyi7mFAOEKRbPEHAL2JGGtOnfm8ZDxVWgt7xqrxKlROj/OD7e42fbLUqxHom7HUj4P/+Ba/OBujpFpahkM1xRa+dr0I91LeEir3pplbGKvU/2mbwBQmDY4QFsHk4Deq5oWyvy2WoJ/Kbz1KkCeDeGZD14BSUVcAGlbDRxeQ74PiaJiiZMyOLo8geEri5TQk3jWhF20tuHOf1Ud7zF6fsxQHQiwc1MQfL6pS1l24DFJoSJ0R3wPQrj2eP8GwufddWjLM6Cug30FV8iiDK6jhCD8td1+u2Gvi8/8bJ/Xe7pYrnrm/80UkuUC4bGjCIEeyfwSGEPswCY/yNSdlMXWRZGWK+1ciq1WpMy+b0wwzWv71TPfEWr2DMR57/1kIhYTolNaaL9lspxP/B80uioi1U7IfKbyXdI+okT4vDwy36dF8n487EbYiKbA5SiizSDp4Y46CJRw1vmzFgnBDf9c0Z5p+C9zYXN9Yfqs5EC+SdbeEC6eCKvobgCgk8JY2pwaxmWORBtIo2QempOSs9zMNrcXS1V+VgUMQLlH9h5DOm6VKNq4emnUShBKjAn+ZPc7r+huz68rNnTqaHSqEVWumI6s9gLjNfopTeRy8FzTKJ/zRlrrbsvJelXlTBmWnsc4rJC98cRUFzkSQNkfwJygmGY9qB8CWTIU4b7IBAQIvM4VQfT1R4CnZenXy9WAQys3gRALYLxTkNg3PfZ+zLecmXjQGJ4MLEE2jJYdom+EH3A0QKzrQ4Ja5hmSa9a0rq78uzBvrEERpCNn3CQ2M6H3TmPsMyRjZP/prvIoJyqAi06t/+5xs7EU0sWKtqT12e5EJ4wbz7ltxVuaZbZA+zwQoZABQJLHvMIM+nooia65gE1R5KfX4CQBdnTHHQLlQX9L8h3gRvfktKsu08vcms1s5yZuVvgNT6HIUDgHwe+Tuq5kwBgNX9wgt4CoxLRd9aOrduKrBOmTveGfBCvJVuYjMNVjDhSJDKop5XDf5/AaPN2o3WOYbwE/OwcGWu0NmhcccsWPsLbwb0OigoCepDtB22Xm+XQypj5oXihBXySHFJ+GgWz6DjvdPXzl3VNP3xefzdAYMVnuaEuXZPv+SZZeRxi/yV2GnzXJ2Io+0b0mwhg2sSUK+pFGWUeSwd8eW9pHkbNRO7tCK8KG/OZKgZrVqQBDhyyH32cmpUjwCk4hCgMemr93l1lN6bB4A9gj0eyTmvv6IkMvcNu4GyCKKWV9sMa+csadaOPHZHIcwAlo5PcyLWubp06VU6gi6tosQxLAmxvdPIvVW9LLq8wjreFm6h8ibmYT7iaLifGZbc8H4iEdk/vDcZRg4Gifp/Dt5otSpN6S2p5stEBdX/51kh/DJiulPD2CU3EF/SmKp/nzbG8xxxDJFENRWnOJjwJo38nJtt2cF4szAqcYGp9Iqw0Nha7dqhYRkOXkbaG0RjIgu3Txr1+9zH2TX70/DpRbCgR1RyOb+GP4QLkrtyve3BRwseSoD6wI+/oGpw/mfuCvxNZRWDseIKImYPa126lY+C+3mayhoplTeMgsH+SYgC6MHUQCSgBBAtmsI6+UZjnN/Q4knkWHc9D6A3iluZU1grgAHDy32j4egnJPivqaSNRtKzWEJ8f6daPu+VcGrtsfz6fqKX2HKRljwxVU1ExtUF9PRSYvz/lxeHwH7yAFgZlGgql8HEvhsUGKajhUvIrl6kdgPho2KLxQoi1vQJtn3E/ovWmES6UYknLgTz5L7rL9ciR4AvO7agjTbHsFo9ZcblqT8AQFsL6GG7TatfKaAYZNIe6ZpjviBX+HWlNAyURy0GuzqE+/FLoIcFx+FEwArVrQ5xXh1QPK4F12n7b11ifr8B8O6u6qKWc2DqkRk/9SU4n64cW1SUtHgfutbZCbaHwEhGRFWVqL6Z5EeKAYTSwZU8QZlUw82SnkIXVapRvnGoL3D4037BHrxwe9N6kelFVbt7ns47f9mDIl26OQDF9lqEGTYGxt6HPnQ+FIlRqrEFBoYUfu7iuQ7vMlTIMlKA0+agx9EJFtOiYlgWMi9E4wesE7eDU6q9oa8wPjXuMyljuVawQ8Sv/Sx4xNquGe5bDKxn+ta5ai33a+9oHlMzDizLlQ4B1Fb6NKIIU2S56Lz892SLtYyuJBXG1WC5TukehBZOnWTqE6CUA0ykI9JKGPhHZEDoYttPdKfkQe4DVFsiuqBO8QAr34NuEhbSsky1IW3DjsKYAJ/GSlo4b6uKFBzvej34KeI6vIHwx5BJLkuaOhBrZw8HgI7RV2xDJUddCFKHiaT9EfkKC3uBbvXVrAcXgaQJ8fYuoRTpDBg/clAqNbQvrW2hyNqV/X7qZXIkkFIieVzRVUCP2Qj3060hWuaxPclYhFkG0VHQg0EKZWakKUZHSM7expHAIKoInLqi4expIF2HR7b3ZUXE90uW43ZtXVRxRouOsNt+kyV8n7G9YuN74B3MGmh3b8RY55oBIMfZsoI34BI7HhDKjiFDwi8Vagdtw1BBBcRFQY8Gj2lWdR6ClW3fxkcroZhc2WbAKpl+adR1zHAv/RfR3evbE6CkkZz0XdgsikuR1eHCjK2NHRVdNoiPAKjacMyM+jLNnkGDPKqv+KYnnVKrjcgvUZjs5Lcg6/AtL5ZpE5589EYyQRuae4d3XF/alkHY3gFZW0B/9xXSIX6fVUPbqrIvNCfDFzbkeMR6a5PZc5aIlE/8HniVvGONT6t0JlCnN2ZbfwevxvDT1P1T7YPVlZTGUDcmNqObq1LZIC8vOx5DVE2BK7pMGly0WLl5rJDqC341oT3tjZJff2X42FeHqZDXTsYQd1B6v2Qc+cboGrbqfLZexRX9vxHrGdNCdOSGbyqeCYscm4+NiRVfw+R4pM2gjrf9jCl9xMl+WlmvZwOYDVHzuD6C2M1USLfeokLzMfzE3F3g4WbknolrURdaG/tBDfSkmjTlB+KAxBMi/XpA7vPqI20zTTWSX358Xz45dsFP1Ghb2yjpomKIs+iH7MvuuZOgpptFLSddL8ubUZMjkJg0X8inf4bnecTUKG4zsjtJytsI0dBK/UiWnXK1vCimw8B45nLB68nP2rnyzfh2I6Wapx4y6nxsP9bS2om/knmh9Uc1aVjIUBiyEyjUCKviZVZ4GN9U7ag3AkkAkgPqMpxh1Np7xzTSJj7TIKL9zRjLS842BHC0stPpyS5XYT4NGu/Yh70VkOLB4VTnNnAH4ruyBqP8k4dXd3AP6zZZhsvCDXufG/MF4Lmc5/LV/Ht+uj+MCywD/UYVjhq7eX7IzqC+JXppAPiRauK76kRkAc3hJwRLmDb5UOWuRkQeNX9Io6PM2RakIV4+pq+BTRNvl8jzMd+wD2rjqjLR0El5br54JEcX7oN3CsouvVIH5PVuB0FgXc5aRP/W2vIsv6hdgiiuB1giKnReynpAyu3zq6XpuaYTeyfcCMxWsMi1rGKRa4l/q2wRIzKtip2j5ByTZ1mMX2hseWyQpXJmuJQ5v4GKOAshcwDOOSnMRkVx9+IFKW/Romvq+b96Iz4WSvEc4QeWrUCawlm6759e311lp12OxyGIy9BUlVuDRL+CbqWN4zOFauP5o95dAc7CUL5ifL8ua5c7AuWtpW/mL8VjAfepcsetcAjoUwP8GjZk4tg5rhBGONBgy9ejdLI21HuThd3pWa9WGKfjIkH6Q7jghM0bsZyfkjnymoFzFf7DwDmsK7YbqGNILV3NowZCOYNpZlT4JG6ld2xYOSUSUPh0Ll9D0PhC7gDTU5rICVuJIVgjuIKsSpEkFOETvNcYofsPBHfWcuwDDcdSz4ea0oUHNEkjX6pSxL9Tn16MpgqVzTUK/gcLua0EseQZppl45n9bdndQ+IpnbT0DiSC0kAUgBGIDOlMJGj+E82yclBEcXb0Deb2xigS8wDw9SyjW+LspFTnckNvaRirXFr7kpiCf2vS0e9eOEq+yHH/a12pm1KC/vR6D8XYJu2KdAGEIItD9lg1Ga2aQQZ96yKtBAL93HxkdvaR74PuXEruFzbtFgGHzgNN1XjEGjhN7o5pAD4I8qcyRxiELeyDEVrL7mMRQwd93qylx/kgIjwdcWjgaygx4SnT4K3nXbWViucGj1CFT1/u580bV1UW1f8S+9EbnJu/7LAjYRKRLUwPk8BEZ6Wq0t9nEL9lzbRhdIhVgEhLEp7czK9VBYypRaG40qYaP/O6fl6F+TCh5Q7GC+i1Hu6nYDZ7HZ3ksUR5LM4eOcIMWwDytsZr0qz9Y/W+tkWOFqZQC2L2MhtkCaofWvbl/WW1GkCujF6QCWGgf2UkuW2xoXJRbT5a4VTc2n7IsuiungMT8OZCTtNFgRspCXprYcpDPvSqDIbqvgdmDr4fULhldzL2dD+8q5ot5a99Z+ykt38bGs4eDQwD8DgrT1xvQSfUGQ/5DqY3dt2y+7KdyloCfOqW5rzAEgujcQJa5mmX0i9x71KTNKFSvxPxl5ZGS1NszeFtMSNfwsRW8pZfa1OC4EVcttz/8Vg0t1MS6wrW8ZE1rFbilUOlq2bHUaDzR36XX8bnuEAMbS4aGRFdP4oTafa6sBUxilOcvfYFWNeG6EMFdrD87WbZn/RXkwr/hc5TojpiL88K7VlW+r1dyk+niiu5asyjk40Iyhg+EZZN3Vb7FLcV9JGXtMUIno78prYUnlBk31ZB7o97Wk1CYo8wA22P/LTuAD1qWFeV/aciaGBZ5t0/UmNiWjwBCeVnSsmNULLBDgH/yYof7MdnqlwGu41ADvbpadfCBeIc5jQmr5hVWXtKUmsEsybocvXH6tnC3vAFflMNddzZmXtylfUA8jjYSPjU8PAHmptJJS8rAquNoTOdzgtwKBxMPiBOjdYEaex1DHsErSmEeMMLliPpwaM4jGU3v8FSJIrbECuyUUZbHsEp/VimZ/4/oMJMzf/zB2YgPZWlsv2/+43+6eska2ePrkSLUkpqZQA2wKIiJJZaIx3RQqAOKdYdkc6jA51Y7M8a6f8bccZM6nNNjs1eXAfaAO1BtpekE08mEMVksVsZlypKKCyx/Zk+AlcvpqX4RUpBDvUDuWmZG2xGDW4GuyMJldsa/iSFtyg14+xiikW6zhsNw/zB5vzu1qdR5H+JHKD0kC2zXXAbWpP7V+/E/F5eXDiKixMFEU3h/RZFcn6qC/VAZ7mIjVXmC9akAutc8STljmbDiQ9tuK9v8a/d2gAun6RBrRirx06Wu79iFBKpM7xvoNR85MNgpXtt85tLSSIebNs1467UCzR9U41KRpmLP8iW+GxMs9ToAWFhJjW5ij57I7N8MrnTaR59+XNR5c1iuC5upF2EPcez4oMTy2LsX6aCkYXcnijFsZ6CLico4tjXRZ7pyGfzFZw96P9xw5FrbQ2Ym2t9deqpRwCpad9+0AWnikhxfflJFOa48k5/XpbQZKyVq8PxgM3NVIrecHgg0x504EvxrK/r4hTObhHQfcv97hC195MRElQB6iKvApBMPvIuQFE3aUIG/SoyRXabkuQE1ZeNojNcvbb1+mYNZmrYY/seQC9Qpffbdh9QIq78bK0AyM3YQuS3y4k8G14oaXDNbZVCzIoBrI8iIa21J+lLLzrOMf8Q9jZGXFrV5BR+WqjOhOHT2z3b0+R3Y5gn8/1s131LUnu/9qa8TSFsiMp4XWr7Io+BfidpVTGLuKB3Whk05eD45NnugcgNAVdk6DI9c4g1b5LRpNzIo7wAvYLorEMEyNbiN1Q7bH7cziWjl4OeqsQGsAutCAli7aI3E52Re+cfkdpcTbsnHNZjwiUlrP5xgshnmcArUT0u8R8mNiiptJxvCVob4bkHUqaHEzL2q5PLviZKPizEXTUjrZMKIJPsEOV+DE7+CaD1P8rJVg5lvGmNYM2SUemGRUUvajyvRfSVk0EmUhZTtVPzOvUpfud+f90m2uHpaIV0MEQANB4SNbkOPRc28UZIjm13J71reLpNgo9IjjZq0PMX1MEZaiZH8DWJJ53XNHDnBmPFpuuL7npaMX6/fGwC+nj+19Xpg8X9IfEQZm2zPaKLJwU4l3SG6HntmaeTmxKZ/Kkon+p6u6wYjjUNE6ockdFsm+gMhpMh64h+cz8f1bCA6MMjRG+bwZBOctU+9Tqh3deTvYfKVfHJK83YcpdNmXyTbPISKybCaG7729AJmiLrpMJeqiaT2s5ufFvB/RU5wHJf2BRVF+KgKo3yPAYmbVWbutGSw2uhqxmOBjTbCPcOoyfSWoliCtRUJChLJB2UV7uqMO1CmGrdWUyDBtroD7Wg45B3lydbrjv1cwnSpcLnXGZuNMqmNYRGHNgTCP8UwcpxAJZxdRcCkdW73b0WYruedS++j4pitmT3/X38D/Aejl53xafMg+mOmF04U96WRWvk8tEU3hRDlGIuRZTt6pH7yLTisxLOarT+1/jhxBiLjKGubx0p7fTXomT9SY1dW40gBwl1j+zmXH8sYpEVFv/t3ywLbn8R6nfvEtZpqz7c8Vwf65byUhTMxBACljXaXLfbHyn+a78zRfuCaVZ5w+wQh09DDa/DXSKM3EF/voPwT8SWdanofGNdO6BF3jhYezIAO/Z701Aw2Y5TZhVf7POnVa+migvrJmCd3QVBUCqfj0aTAElSCSWR0/r0fImLIKRVSjn6tuPYMCMgcAsyfFcTRWAc12xm1Xb2RnUUw1qyH8NZsbNkucLCGUrFldqdZ3u9oKs7MBzPX4P3A55BZdud+q4rMhhYeiuMV2vOP6YzF9PsFMvK4PPEjFCoseRETddSRoLpKNKLBniMS1DNofmAuDBBjMG2rFy1CcysH9+H5kKkRCMZSlu+dMIFogdqBFLNyO6nIMdYbcIxIi7i/Z9B8l0M6y2XoOeS3/k5fQ9cbZ5KfrLV8oLG4FaYsbnP9ck8U3Kl9gF57Y4qEYVvy3Q548hPUlupUN+9ij4TfCAjV1Y+W41wOCJyIjcq0zC12f7Gj1JX7QINtLm9SaSBQy4xrvDRCmU7llFcBlfo8Zm5pkaZ6lE5N72RKFDgNxVrwBxn5YJDu9r0oHNcCFX0HlMouydPbLoRYoxuUB85WE6MhJQY1tmWK22wRRcg0JFVRWxeDHblDIxhwlqYxk5vRyk3A4G0WdQAP+njaCKgGfpuZDA7q1XN8ebq41eprbB80zx1+F+ExpMktnwEB2yKuzz8pDaE/BGCELff8bH8JMDpRs/KZELjzpse03RtwVoZDAJiSsCcYSDXU/DClr8oxPxuebQasGofsj59+XqmQxA9Lz8XTEDtw4Pp2Ot3wJLTFR446EP6Q2vi4OCc73NCRpuZFav4YiSjHrWMllSZXcpheL5mmhvbBG/5rhTycNc/ZLsCl+tyuN27EbioXF+mPkjI/6cUx6lgCF6XtwZL4PRFW/9QKySn2aQhisi8EHE8W67iT6iL5ELXgYP2/F1wfFS/SNnqu5/SIe01fTHU33OcrJssWn4k4me9bG5KRJhLAlCyExw+1kYVn3WCQ2Kv6N4nL1E+jEqEhcVyNyH0yW5IF36nhdfMRWYjh8ZdgaJIwvpNmvyIWbo488Jke6wbKWPnQc2c6aBi2qorZXugifWJd6c5b8N0FYCdgkN9HKullhO9wc04kRGk2mbHZFE/EGbOiPV3pG1l2avBw1+c6Xyb/L6e2y5fZRfyGVvm3i2vQHr88f79WJImXGD7hS7Ld4C4NxB5c6BpYwu0jJ4BQC8aoqOWiFLGMxGFcKBmWPebLqYPwTYYMOgNNuPJyH4chhZHsIU7XX0kpxsnPyM2boVtAeT88S89bW7uCUXu2rpMlvZwGaKex/1D1CG/Zcim439GCteFfcn7rjtRA4t93DbvTMVxhEu+31Z13mQXWbUTFoDkABne1mzbSN8Y9YAQ87i3O1tCERxoVRsMBLa+CLUGwgIPosbLK8ZL53/0FrT0FW/BKS1dkFzoJ2hSr/wmsY3OWicJIokYQW/kBIDwR444h4e4OT60+YtOeWK04kYULFHTnnMGVEim3OqHkiLRIvjue1NJtbsG/Ru7bmkewhXFTQBBVgK071H7ymoUCy4EBMBOt3zI++WAszXTzrYYg7EicmevkwOvSZNK9NxUyHhsnPfjspgHQK/JcfLdnaW70fit7ybBtupIoKtS7D0S2xU4HDZtTKYgZCyKpwnGPnnhG7d89yLWRknFVyhEXEqI+7LnmsusczscJamxgT6e9xSj16fOI04nDbu73Z0v+qnYfiDz8WMlwSElEzHHQNVNocTjIj/mSb3/RFL+KzG8X5Kjfw0iBQjbpvyN5duOje3DmFamr+2I1cHiPdlt0QGa+w2e/cpdXXaMKnYcOTkdB6RMCAzeup5aKq2Z2/tJSRu5V79yxC7i7ORtoEFE1XGfPOWvqKJ3xjbgJ9nkXbpZ9EBfFCp9WPuMOxb9j02F95QeuYMdOt2VYHwqKWU5N5sBxYTKOOep6++6F5+RbiuHYXqJqq9gOs/9fqaiskF321yaKe+b9C0ovbHqdfuYBqV8t4jZ114VBWOPPtN2obgEmYq47Bt9yLnliokSb8+EGZL3DUoPxqQKYcf1b+ymzWfBkG0ECFAfZ5M/2cLUDSQ4wsGoZSN9sVgW8Crf+0MwC1bwQ4UYdNqAFTYJzv+CVLtTHoObpbgOUVwhzswMemM6Br6cp/aKkpf36pFWBz0CRX5z7JKaYa45t2FUqXuMwM6Xi7X9u1dhUkob5BjXsW+7wd6uNeXJRvBw3yvOopQ0jwsJ7+4b28J+qk0KNAj+mUBruP+sym8P2w3Sr/GGVeO4VIfBxemWARaHS3GAuOvcrSrGoQfMYtXb2NmBI0iLHeLMcNMGZuUAEsPmHc+7Ab0WVCpKRLQWEyaJBVvpR0cFK0RC7TArwLwdXD9gUcYQTmB+4pwwX341FAEOPKeCEaSTxQWBCVdWT13HvdU6ehAy1ak2fXPzfyFTOJ+rcRzrvaFAsBu1cBR+8gX1uVZZ/yWapMwSrBUsL6z/oa5GppADwkFvtt+97VCNTB2Lv8niI/RaixYDpFRciOQsay3KSvOtlEI8R/o8cpAZGF/VPjDONrUYN5JgWsVF0zquNrXNwJJmoNEXb1jn278B9ruFtIvN9eEzrN8l4hlXxrQhBblZO+1xCWX39eGzNUIOS+MlytL5q5CRy9A+8haBblpAELYfdxcMJchctCw4J07s5yOAawvDOuu7i99VN7dugrDK77TZWnPXijfRQBtZIN5v64soX60OG1eUx18gvBm92xUbp2RVgqEWYFf6Bky288NZvdHQS0Sw0Xs2OpwtiAcjPzGg5PRuTvBQVCtoWpAWKFiHDEpJ6oX8+OoBxxAoIhx2JD5tPQz5BT30162axU9wnSgcUNK9B+F9+XtanLN89lHm9QT4Y0kuSTu1B4ANWnlMQbnmZDo2qi3yEbAIiSuoE6AUzdt/Gv1qzdYKt03lqncAvlPC62T8FN2yL7VaF9RnxWzTUah4loAUR8May+Lx96dH31aEX4xr/B3Yx4bJAV0Vy60ajCtAh3q04UsqyYx9SjG2mHX8xBZcj8cBvqfBqDkY8GhUGMoDqab7YJAKyvlYYPvr+SFo8nECQ3DFYxax0Mb68IRDAxbg5EptM49eHSpxQ4Cg9/sfQASAmOuaZIh2kT8I/SoMnciClvOVl/L+zD9924z9Gbk9gztNAFCNJTmICymN0OPP5mZKUqn/uq/27vlTsV+u0wxHAcvqKsx2c7uU2vsRIaSnvZrRGEMWEcfJOhf7rjmJCaOxQmQnZS9LazrzQhcHtAPvPFf+tI+fifTuJzFQ8aXKhwsrvMzlOcZuxEPURAoFV/oc7AhBulhCkHejxdtOpozAb8tOQC4mndyfZ6NEpoQqM1L5Sk6SMfK7mIO0rUEejg+G2mmTxFYPrvfcX/6gg2h9IdFlJ6220B0n9hHgsKkCPaqP0Y0Xl36rj457wvio15sMviLMBOzeLNnJxGizGaZs6gB+CK2MTLnMc3E/jFbCjZwFRswX6nvKSwNYt2OHEEmhKTw/6r44vvVvo5Jo6bS2GcADi9XoRkIE4LYfk5UMfYXZNNFaqPqssebGpPSgFKpQN/JEuSAwo68xNORFxMn2MCmxjPVz6mnC9HCEoXEseofPT0E7IgCP3mji49cW8ROekKPV+daOzaGLClwXH+ZqYq/rJLHUANvAQ3qABLyY3dvzGGYHGh57NZ1/MMh9ZfIEn4R1lTrBT3U/mfhgiuhN1P5VaucXCyywoSXMluoNPUiED/AkchrfBT/2VRGFRqLmoT9DfzA92/2SvOc4oqfqkVfS3IzYvYzPWVsf89Pgnk9HMRSB2RwJvyQS9cLzBjUx6lHS0U/ArEj3uY45apoFl3nozCat19aZXXJWjGNWru4/DKI6dorZdxDB9wB0lG2IEMhPAQQiO0zeV1W4MHlSMaQyKAOKdXXZq9CeTSOs8RnQ9fM39BELng6+5NJdKg0G44O087e7bT+LZgfaYRNGQGeOmSetfhulf+E3ZBt+UeJ5pbvGrC1f/Hxn9uRQjTNLPZgnOP8DdvkSk2hNaOLSBSu5/MtPSl8sS97u0oyj2NTwTwZUSFTY7NmK1Jq8dPeeXRwnQiIIF1VELQ3aH+eGKJb3fU/2uZwDh00RKoQKnmO1k1Cteh8YJVdnd+2GS1SGC12/a8oTSn9zuOo9b0zsOJJaDFUTQ8dyrHj33TzHBCCTgyrSFIuij1OgU6eom0BYznAcvDLklzrHOST8+uSEV7sOrFUpf0Tiv1mZvoDWt/Z3Td7wUz5nZaliAjX7kS0vAhVFCEB0SHd08gH1zPqK4ltH6tM/XZTxnd+kYPy/bZhSdXueSFnhwgo4EcwdrfkAZB3RX12HIejXUgUpqGFxDZShCYMec4BFzjyKui/0z34Y/5+tWHyY/OF+3WvV5ZGY0LDdTWtg9wtna9fnesB2QPQnb3HEF18WtyjcHWaoaAiLTdwDIpRdDsqW4GxMazOV7HNqdadJfbr06drYG4jbdr3MCQWKK196Eb/KTlIgVAg4qb671UhufHWTuKO69yiRVNx0ZQvr68ReVInIg8HPp2+dRCcQfkNJyj94oJyOTfsjyFDTn/TEswRpku+2+D3YVuq0BbucjY2gAgRfct+Cdjs7SLMzs7AGFi/5bbar7Xtq9krxx64BJRG2raNL1DNIEYOQ6YN9aI1txSpjSeNUaTaPIeoP6CZmmnVyiucpkJ8aLymK7EO2H71C2kLXNAQuW7f4z7f6wYqjb9DTAHgDOg4lakD/740iMl0fAAI4/ASCGYRShc/x+Ln/q9Wv9bwMxY2dbkLV92aLsefW6LuA/x1JD+diQoPXmJ1KJHS/DzzWCdE2PZp/8kGsyn+W+nlI6IAKnNqxa6fAzbMYtHXt1EMjjdb6FULRMqawBDE57sepx8ydmOxTygKiT4Ij24eUS6O1n4GsbsopSRx2Y+ghWl1E+tipBrpgNDBVZHpBOq3Xp+ArpQwsrxO0vjpB0ir6gFbETIFc2evyNMaCssR4UHdJerKo6ihfK85BMH75LM4HT86qtr3aSlh5nE4Pmib0IWVIUdBWUP3g8sNBo7YDxEU5z0jF9uTwPBX7NxUCNNdt3+Nzxokg/SUxqddz69hsFts2TJODuNXq/6vwiiTDEF5T0V17zUvoTrskCLyL8ivnuXVUkJTNt3h/M+41BeU/Lxu762qU4NK3zH18oXlB0ga80Zab5Zj/4A4MwGFI5KxOmDYDEpdViVANeA2MqewUXqqo+5vOP/JLqQHktv6PxbSQRDmqbKYss3Rvt1FTfYXvjjMUyLDUQWN773BHboDiprfER1A35pruIMMDXSRf7jt5WKb0/mQ4IS/H6k6aQoteWXywBmQrSOTw6pZ1xqOGXS76vmQnoyzdbPlrSrbEOgcTQ5cQpjxOq3xsqqb+LLcPrQqix0sLbR82ckQkVIeqnB38BO7Ben6uqyFOLI+5lyHxUKL85G42ej6GwhSMSKg4M3LpMop6esK1RUxdkPG2+Av6bUqJOJi4Idx61UJvHetunBUN8rIO59eV57JOFHSOj83SjUUQsvv4rTwnE9AvkqbDIm6yzs+NxootTKyk5QpambOSRWRuB6+c00ab5uPCtUPav4TKEvE+bYfLkJig4XOllLf6UZsdXkfAriWHTVOg3VKKQ5q8K9bwr14JKjRrOVssl0Cvgsgy6nu3MJk4nVF6lnQVwTDf/Hcl6u7ZsoXz/tFGJMObh7unxag+RHiG6GMBXYtij++VjK+f1DFzZpu2ApYz81V2Vx5r9zlQ3FJu6nm9SYdYsNLOVwJ25QDfLPSBb9hwG/uYbvqumoGBhnYQ+HzdbbGSPgjZ/NtXpnWZk4DBZIcSu6zYWe4eLsemMHH8pPLXgJQcbHrboreZIejRPc5kJ9uvP04KnY299Z8yYTFka7y4Q4/O0MfE5aSnQnxctr70KN14bXWuTdzY0f3rMX9SkiRGtVAjyB7NvLb8i4ztR2tdTiFonETNF2Lh6/6I577BE628y4z7GDs/Wudwv8EAoTQZ/FOJ7bLIFOcqApxV1oTDaslfm5S2B7qwLR/mRluFEvFIngsFv6se0BdArUJJ9mfBlyI7Wbob2LQnkmyYImBleAHkSsVjZEcOsl3cP772RvqiN/xUfgZ5GYy2W2Qe/P/Qb9ygfvhDYI+Yr/IohPOEJFYkxQy14CD4iYDI6SCjXpQQG+CpfUpS+XrVaLi7g0D/vGg4y9JZkZcXpXPa/dgIMNtpb4+guL1aaw8LMxD9+7wVNB+MwVE5kWALixlCFColKTzHWa1TiKSYDwSC/MUeeO3Z9ZmiF5wRKv1lEGeyGa5mZ/C/ljdwAJJAh7Ea5KaOJLnWigDP1zw+PHNvx0vcQVxuA29Vt5rTgFrAaWGTSyxAhDKEdgP8K6ufXXD7dy6JK+unFwT2kKEU3WxaiNtHFINyx2LyN8nuohRkPNrEIc52rl5XOSoej2MmIyAEoP4efrtS/Lxas9gKPSBpqZNKqvmPiVhFYm522AdkcCHvhhzQNVSM5UD3vEKtnOTq9uFQW+TqzYfBldy9CMxzgE5pKmNwURBzmxZ9CdGW8lyZl1J3xO+jzsNYn2DN4SWhYdzzaqwFpjjvhdPkeRXylG3r3lqOhES1Y093mLPJ2CACUOgoKxJTj85N1T7aH7k+JO+K3htP/KK7tYvJqQWuUr1ofHhqHmUPECwSRytmmeTnsBlE50kuL1OzFB+vmLwmuI9r9/Rc9VH8NNrHntOuk12JuRkj+76MZ4g2bpprZdWo94HUAh/9a+618ems69jZbCKNxzqyMQeFsxQb1RF+KYziaVz7th27ESqbnc4SH0lJAGNWt/hddkDbhXvYZM7GqALT74ztnNYbxu69IfrBxlMNAlt22nlbGUR9nxxOx+XV8aQcYWm1GjpmVK/SYGCIjDBnF4QSAuNoLYPUffPekAYtgbQ5AoXQdqzGUefnOBTpKYA5nfdgdLbMb4+InBcBXVXeckmXh2QDg5dJFpvBdbuGsCTXfbRHKXQblpQzV/OQ3A9gXZBUVsYwBWO0SSoqsWm2oZtYf32+5AlEvAgz7RBSjuSxsohySJ3jSAh7TlKQ+jXzCmXWkditJnulni9CJ1n+oANt8OqbNmkpOQXsL571Bbs5POKpnUxrS5Q9oPa1avrNUXVegn18i9fL/EQirPhrYtWlUdn4XlD6j2qNtENXOqJB3T9g30GNZNyRKsjW/Sp5sciKurdaAn0BHwm6EsG8PB6Ea3iQGohcHfdc4QfNMnE2tq+N56R3WWD/WOosihXxxkjKZe+DVgnuqykl6tZrIrX+ZF93FYO1ExptbwwZSUhM/YLhHVbpPI3IUKRrKSrxOestVOjJCJYC/rOMOErABfC+6V0rNID8fK57DsqN9nazHpde7QU2qB9i2bf32+Ke3Uv95hDqaaumiitxDRiOeTl/FoOIHrYCxvQLGcd9zCz1KxIpjvLnvdfFKkyWfbLNnPUh+ahfPghh1sNC1nK9t8rgsDEGjMQTpEmZj1UCzcXNSX8dtrLx/tdYvf7I0XQxNXcTTk0nnqlqMPyCUSdTWwHpmP4drU8t6nrbcyi4o7CpV3lOPxRTbe6rvitJSgPWAbYJXefLo9fnCUP/kk20hYQGcP7oLh37ku/IUMnomyEV9uS4OUhndKj9OWVDm16LpylVkv12+2KFW249eOLilYuQ2xLD4WlCU987FqBGRqseUQpccnDfcAoAyFLdPwr3vYEPzXfzDgI7MRzvmK3lM7l3wFjYtR2ZcJXsW3x+OrLIIQ734qq6TPxuuauCnxHbgH8FdOImxrHFpBRk8ZCY5vjCipqCe0q0cUeHqvttDjXPpCLEgbnTexO/DnZ9LumsV/2rpOq3WHltEJRnxhO+ebdcvhN6M2R2+K/wAh9U0tA+O2MaZkZnm68YvJV8U0gQCiOa/HUDehogUSUDVmAoQ913zh7VtJpyevVgadUQUPQy/QW9+7ENQZ8XtlklVEzHMGHEDy8IDaGJ730sjPld3TtNnKMMRHgXvBl4fgmtpP9hoxIEnDFOLat7mE2G9QxkFoG/hWJwatL4vU8c8rB9P4wS7sxVvZMNGwxZEYjE58wNFojXgHGSSxxQI4i0aiuCsksG4aUNmev1xM+EWoGq8vU4eGTZdj3atyIWydizRDN7fggIzVz9UoEE9oqbLHdXbATkqQahbWXidSHUzMF0YKsS9rD9wZ2AZ6Gogwx/RsLCCmaGLQGsAnGFh2qsWRV0lJKOl1e88cNI5O8WZCMsxKqYs2mLer7jIFniQy4IqrYz5VMXR1SWxlSIZzhIOoL0ElI3F/t1Khnejtcwk2wbVwOCJok8BhT4tU9cOsxIJUMlafMoNRGAdKcf3L/BAINFaIxO6nN7TyOt3rNv0nylqoCyACwKU/N4iK/+qK42lPXGG1XRP5WC/X8vRlzQyAAagLIW0GLd9UcuU58NhIpyjwdVpK0LdoRhzTYi7orx5nR6HVys8DBOGk54ZkNMJ779p01YVF/B75q3qzWKvyg6ZgYwCFv4INCbEaQ667Ulas/DBEbrRnTEeNrf8Q+EK3JJgOBxw9uA60W90V2eZlRTlzMsL+lmzXhNn9+AXemwNwrQiMHcQ1qH/+cPPM6WaYans7h26mGB/1Wu/eYsyCX6rvZAddBPIQG1rpmlxwhX6nKaedRHy9XANKW4eAgdlzYTyhKbxyd0T3cP3RLJbENoRlEBMTflqNG3wgWrTuMS147d/PzQ2FpXS8mNzFjWDG9KB8veP82rMdA5lQihXbprwzqVq8Me0XfyLG7LFc4BDSNH4coUnchItOmQ3mr1l8E2n9mpHtFLfjuchsOmqzMaqc/PdJrwiZ9yocy2IAGDwzyQVlEr/nIZNbLBkHZ/O8uozjQczwAxHtpoollMiwvQzoON7jUsOr6iZ6gaJfaV6ZkIwSftwV/zzS3klpT9hvEIK/oNh1CeqJG32PD2UjeBvjOFyuQ7wNY4ynfsnmdO4bzwhtEJJoz7s8GqCXP4lGstHc0+o0JnHgKbAppj0CplCw4RgMwT6MRwz5sUe9sr37TnkdJVzYDVXayMZ/cECAzsh/921rjblUjRgq3Oc3r1uKeuYP107P1hB4BwwJJI7ndxuwFGMVEgAeXhzg9kK5fE/iuZ07u9lm1vbLRideMmHS9645NB1DeXmFM/hk1jKz9mzdS1P0ul7KVdZDYSR0qq8NbgSLgwVSNZBwZJIbCBJDEoa0pUSeyUeRjjUXhMhPmpXiymq7CZewM3VIfuztGZz+9i2C3fLs8g6bOX24eMOGt0QTaS5ZbgtZSAsLrjO7/uJe8O0iEGy65y6ilxW4Mddwz2ZyTUulYkOgHRWzq8zegECAx5B97lmXPExIRxAAn6k4/1Ym0QAZxXAi9kiZW08fmRkdyWdf4x9CqfXShMaS+0BhnbMF3zBS+VFYZNO7AF3j4X07+semU6ji/rWbTyzGCyB/isZNt4XrSEH3S0/4THTH2ysmiTluVzDes/ELkEENqpLH0Hhjm+s62xRsIjZo+73v0/4QkxabRm/SNaTTigdhiY2W9hab4fW6p4NN9Nwuib2rBFGxpCvpWzrMZ2gyoNl9K8oPzyWnfVKIG4SwDp0IMQeIq1HewmzQ1D7yl91ViWgy10vZHEAQQ/4AEO6xY5Xk2E76X/sLENxTxVYDDaKPtB2fBFQI46PKwuj/8OVihNQDUI78w3tFze5ZfqTbMO1liQNCmxPVf+EYEdD2uC4Gw5Y/f+FZyoooiyS5KgiEZE8GgXWV+B2ElQ1FrBle1DAj6VeR7HP1PymW8Bz+5wTZF1YLeygKbVWMIMMzUwjHIGTvQMgIl8ckW4MRwvGx6rcOAOHvsiMxZ4wKz0LjhY7iYJh9fCP1Y1ESsEvDm1aJe94OFxHRaMdwpc2iaW8PvvaQB7d2nMhUMFwOR6/MNHDVdjy6iXrBNLbiHNbEmrP+bZ/4/6k0xNyzzucphn/9BBwKe7KBnwsKsAQ6WKCwTnQP/S5T6LQjPD+PcSuiYj5inJ0YJ1Sifdy9uSYLApsZK2NFTrDpE5EVgwVzcfPyyBz3Dm5BjhNkz7au9Aqi8QqYaP6xOFP+lfEKGwGZbkEuK2iozmeG72+HqP14p8nP520cmpdXCrAyaa95YGMcYPCJUjOof7QiEvJSaPgB+9gd/lzEDikhg6ctduZ7sQTbIwBzUgvtgQahnpccZIzvzpUYClqPKHl8NSnPzLFCve4lpLplqBAMQvh1tOmZNDaLqX5OzyWlShVWfFsSj1VMKW4U++3t1nEPsRAYfZVGacES3R5hn++ZHwkZKVENWV4yBk6LrvNbBW8PiJlNWIts8wbcIVi9IU/kFhgXtPPui/iv0UVTnn1ve2ydnbPQv15rSxptXGeB4trVXiuAZ52+6cO+UuEYUIaKt6HKw4t4QmSLmVmAbVCnj+ONXc44NAkcvWukMC3tjJpUhQt1Pq2nuGAvyV1yxcKEC7bDxhFNW6aqg+TRADR9odsPiLQmxvlxMRGGEJFaSVMiJqYB4G8m4lcpnCnzX2s4aynDcW/4lt64nMu/xxSLuSZ0H16xX6vLVGxNPYP8VWxKoDNRrtBn6spvamuqA+flcPLhANNf/PwjfzWmom+QlaP/5YfQLJM3vvKph2Kt2xHrT1ZTB/BV4qR9E7tZUjhNe7tDjqgBbcocEBTXgpXgzX18kVzs9ZL8XoROc9jKzRLAJLSWSQzGvh0o9kLVoL8FZdwu8Krsdg3UYuC+g7DER+xchItRTCtCcz4DgsQJ4GE0raf/er09oNG7fzEfotf4sgeHPVtQLot0E4iTA1KEmeIpcnpSRlrNZJEanJ9X7+ZBt25y1s6jwV77vvh6tIvWwl2dqA4uXJJTIxoMB3Pinp4qLlYKI8kNbz3uM0YkNgxgXAwQF8OqEOJZDPLiAVf2Tm//2hwxh5J2JHRObEhF8XiCSdDLL8G+4B7eYJRoLLNM5uYdQ35H6R+NaaQwS2areciYL1myoCIpX7OLNCppv9iQPqcuY/fTokkQd3urN/UwBcQNAdi0jcOISSB8473W/q52UoZ8ex2N+U3irSxmJN+FGJumkgkt6Iq7qPk4sep8EeAD85UvcLEg4Z5QHs+iJvSCQmvdXqppBkP3ejc9v/aVJwEUPCuT5pp4TBmH6Tm5yk/fhoRhWQl+G4iGu1hlqDWo2pwzQFsneweI7U6oQADMePiBM9pubJbdm+GYpIsRjZR6TVw0q0XIdgBq0aThGbIKGjAyC3tz5++aDBcKuCaxWF/i1Wsdj4I7QD2Jwks/C25Dqr9CpbepXC05pXVl6ULyqdMfD+gdZ+MG1z3J1H71fZXtT13Z0PrLnUhKslqSbrscW3c0m9tOMtOB+KAoL6z1gwyOfjHLMveJCeuefY0YCQltw6QbbyAM6YayWKsN7I4UfBFViWWKzCN5wSmVJVjId4A70GxmQnByinBUUFYmN2Q/UTWRA0gmCP4+bqzyxUNU1mQrBXtxlYbt0zTcSsOqH/kIl2PPQY15hQtCoECRZs+PsTmo9goV5eC90Bni4eTRLKnep9JEif0JpsxU6FL9B6Cvqoi1Ido1sJgEEK0QoMrGh3K+v2goY1OkS3it/NIhmarP7XVgudxMCZSOaSUhnOlnFs7W96jG9KdgDA7q7fHxvx0qWpgEggKyvwCeM/gD353ryBr5ZN7nqdV07lq+4bJVClrKlI4GFiHleteAxxhckxlH/WSJmpZorxg6VKJDkhWPfBQfQ6p5UhlTaKEAOFwCJhnLGOUP49ovkGXTPjfHEQllPTbadn5vRlecZSDLzQN0zNskUlmUMmQ76Bj02+v2/GxLn5dcval0jsu71hL6Q4js9lN4OoMkb8O3JkvR+rMBkgaJ8uJTJ4gQsFIm/olLtgFBXd2eGjWgLvuEHoHzsf5MXLdeKE/KeB17O/prf36FYDnvg3naU9jZiwb8mivvcMHQKHxWzyi4RIjPvjP22aIT3QAM1Hxz7I//HirV7Kj6sQ3BUvoT62pP+yZNjD4K0RNaGaVlHjdv8vQs1JxH+4nwEODjhoGMCBtiTorUDAGdXZ9YpOe0cmqAdB/hZXCFTA8OXhjXd21F/Gvri21FYANqxQlQRoCTDF8TZO3GGZVu6cE7MS9HCJhU3w8g3JHW1/cHPKumI+aj74TAZVo7Wlu0yAMEfqoTnhqVxIx8TJ7Ox5oU2afDGC48qDAUSynvUZ91dg/TUiLv4YHEnp7w5nIh14iztfTLYrrLUJgy5gYv2nP4WfAZwW6zZgOpLHJCsVJrD5VWdjcexilgKYbzePweQnavqyV622qtaDB4xBqpGnbzlKpJetaGQ2SHM/c5RtXJajOy+6rQDwOLGQ+6tQlip3IvkOO57HYVNNHA3LR1HgqHR96hjN/QIU6R/vIQrrrG+KwVQAB2W+sziIlT/4on2RGexb3NQTfdafc1Jyz5UisMawIsIHkaRTkdFjpILwxYbzJzf3xTVACYLTEFuh79b0M+ywGlFvYsehxrirW/d8JWtxRFl7y0mKkhyxWFQGz4m+1GUBATT0fsfATmOT3KL8Q26LXslY0zWurpVV1a/t65xbOHBVic4F0ZHMS7kWIKwe4FPA3dx5YARaJJaxKH3EJGcljB9SXR8SBVLnJ8Ke3OxcSVmf9ornVZ7oSic8HtsItntR2r2Yw+DF73vJpX5cz30lixWcU8isVUmddEWe42b0pc0sY2aky/tbWS5/9H39wszeQcj9PhBqYIv1I70OXxU+KdYRBt/q8/2PNKlIKg1uGO9De7DzcED/pk7ZAKcgMk37PCZ/xllY8YUVKnpLH55e467KIOgKTKPYwKkIoyJ472s5DOVka+OsDR9wYgcEjs6cas+u9m22u42FRF7qef9rMhucdadSCHfP7ykg0zsbmE7FLhERojcbcC3g4q9C49lvz2bGJfoSORfpp8kABNBYeT+AaREa+2SXuIqvnx8ooV5Lwbto9dQzeZYC73/ngN+l0EU4UiLscFzflWL30MXL8QyugzauGpl0uDhkUVlis2UISs29A74ttFnLZCf9kIPKmQxTwuP+PKUdfP6VAZxniXeDWRS0IxIlfoWnrbsbzpKGDtZ9nFWBIrKkigmun09+wt/sXdONDF46EYfQI4KrQiu49hzLXGrmiHjHcYp0TOWPSE11AqnRfw1t15wbnzMpijzMO1UEFKzLMrFQG6I3JrSMqOGnAaXpyuOTm+THhVtuqh3wDz7WYFtIrrDJiCAyfJe8mVwxrAQSXkUQACKa9aQvgbH/42seZqF2h6SCkKMd/WDxOo920Jm4v8ixTZ9VQ7t6SD37wAGpXL4k4QqH0KMI1eliijmi5Fyuxla/JteQVsFTquZqAaP7wOQbQk9L880wyzlyY8NzFoLp6xZpAUNakiJUbR1pCtP8u6OjSCVXbxHRcV426yLQML79FxcmnLMjArMTsOCxsj/t6eG714ipMbvvcS7n2a9mu094qDO59EBrpcOY3Q7svdn932IujbiI+oyWunhvKc6CoIM2Q4lwtoODOIoWOR74qQlDrQX5vnzUt6TBXeGHAIoO1oyrigp3jRMZiJASU2PKxymM7mkZxqj2A6JURmJ8YqPt2CZuwcd+nho6ozkT3wf8khYakcxoxlfFjwfOpNcuOqUrBM/Yq9GK6wuj/QttytXbbjnUuX9gWUXKPLsVMzYavBst3CpBeiA39+J0lo6OiLDBA/ThLH4wlXQSDB68aY/sdpeqnHitu8HLgB9rSQEu91gDhoUP5sVEAoamPB3hqyo3Jmw33aW/Any/GcBoZlTbwwnHm+c9ba8lamoJrg/1bem0qXHOg39pGqgUc5oMJMrKlrrmvyKkB1ZKFZUnwQE9RSKwhp0DkX80jjlw/bQxDWXmQ/i4+sSZtJqa7AffVM9iqnXNCvE26N1mMV0k6Po4iT6bNtsAYJYVgLmstAN0LD9jmS+eK+UmiBC/ip+qm2j9ppyCo1NhXZ5ZxBDLJsBtsl2KtsW1ywLaojrnmBnSsTeo/FokZMlCbVWO2LzddFp7mQd32/rXtGsNH6sznfOEmzgtO9vL/Q6CcFD4ECZxy91HWeT6RXenkvbtm7uyUupgiEKv0NtFhKnReOZFygA0SXcIhxM9RVb1DIQBpH6uyKky+4ez31sCkQFhTx0m8r50j2GxFnFmjXKNfnIfMbAiBv1SqbuJjyt13fr2elJTmtE+TvGVPnG9aGm6N5nJM07yOHQkAfp4SCnR+CpSmqLAJtlDDPPjCED4RbMNxpLh8oinpz2O735AIIyyB/KG1pJvlAK0NC9kJNeh6uP1PPMNzNOJpMghXMSNL4EuFwOaQnvlN7CUGvL1ZeAtpKC0FwbfsLxWBUROhrm7y3vk40bgYZrEjHq03lIBkvCVWgfy9dhzr+FNczuyjj78UPXX+f6kaRW5Z4Hmc8FalL12aOZsAFb5Z7LMTbvEsoX1I3XhaXIdghYqoIKAoEB0Vve82nvs1p7FWbC2EgHQdScsGmSdiuVJzeHLU8FJvcqpv+vfa7X/qZtXWOVcmMpW35G1+TPkv7H7AOCMbCT5wqCB0//zyrTL4APJTsEomuj+WSyugNRZ/qhEnqE/Ankzaxi64jBCWwHAgn9nuPSWD9fgO9hBx32Qo9eaBqQ+tRlAQOKZT34zxmAODMOPVLbkgkyjQb1oNLTRFKLreykjY0/PNb0AH6X8+Ve9BYEBScoelNi9cmdyN7V8IJWmBaArPj+Tc6YQ2AqEItZr/yNe5UQL5Y7J2m5/+kmuSaWU0u2sPMsG0IS6wH7gw0FsDEK/HVtzd5ZSibdfw6MZThXzZ2+7p6/QMGsZgCQmWO3yFLfVkwqZ7K49OvajoOl3I68o6XN6MjtVwtE6rrTooF4goeUUCGFnhlsl/2P35YVz37BJWHPbH1MVdZk7QXihVcqGBFLhgPFIKthw2MYhYNBk1kcaHEHKkQe22MmguUA9JFrhzo4t76y/OWsC9f+rfUPrI72Oj50vEKDQghthzK/lvuBWL5vNDjq5KiY1+WOVWtUNHh4MwE9i5eKvqJhsIBtBNxLRmF8wB8GAjwp7QNEg3Ez1ddisnHLcZtqmrcIP6lu3g750ikxnWCaRcItdodjnXL41SgMcgrvdtchYabeHT25V8ylqQfSPLVvSmz/kvwzWKYIfgyMLDlx9M+mzoFjQAp/wO8WGcujeYiE+mZtYG25PAVUOmyYWfUmKKZhVBGxGLQC+ND0EFlmP4dQGvpNOEDkLKom3H0j1qAfTOJlFAuWALyeZZ0K9902OzdcrU2T4QAmVwx9c0ORYY/ZcZny0y6wIKwrQErUQUzHI71jxF8eCQ2Qi2VKIMQ0qwIWxrkDzt7KQWt2jP2JOJi6+ZF/OVs4AcJA03F5mpWgxa5VqhuOoFzdubTG24DntBm9tPFBMDJ7/cTZwVaHc5Os320f3zE5N+X0NWLoSiqfzE8130+jjHWdpetH3yzvwn5aVXe/XW0XUfR5emDNFh+TrSsHfCMZYAWMPQzhbFci1DKcCDk8Xoa48jolegSRrxGzunuMdDOeCTJbO9KjGzLIAMvd8jbiZ+LgEkAaohWctWi4qjorgUEWVkMgh7wyLQGu6c/3VcipMpcDBfUBjrOKvaoG8YVePXupFtnaIIkNBSxhxfQgKvdIdDF9cZ+EsC9JB046UezYt92NL7x4tU32o/miWc5t85Sb5+6IstR4W9GotT1QBnClKGReVWsEsTx59yomXK1upu6bU3mMzZ2e9Xx9BK2MfxRWtDokub0/2GrE/VJJW/ycqfeZrqd/LdDFAxgKL2RiVzjDQVyOh1O6gG0/SiJBInEDTohEVsbHjWJoHQnkPRyo5LVm7QYJeRIoXNOQZ+ipUXXdxy3I8uNj5yV8Nb3LOLweDuwUuXa/Qqdw2qc60bQZAFwVaeEj/Ibc89ymU/0StNkE2e5gEIO/PQJmfYTakquvZjC/dvaZ1Bg5dDwiENGC65KWMUgkhieIxtySB36BKrJ+IST0nO2Zf5IWB5i0HKp6b7YakFotw4kXqQsICJNPHdqwRZHpK0qnsa46BdM4uMbR+4+l6KUDnZI722BTbELpEEmcZWzqtDi4UUaVMfHRTuhqDsxqWi1YArSQimXY87IjMpAqbVXyTd91sogf74R9Az8iI4OUktl9Cx871P//sUgK6gSPJwAkl9h7DdQA50QmlDUzjZVXS8rBGKWf4UJA5oCNCflrrjPhCZlJC9x7Q4oaazepGXYJ/v9O2EIzdvNmdYTSUnrS3laYkzeKnZVvMUcJJdPpfH4p/InjCXZQ626hKf57Z/jGY6WRr4ZMi/oJJF8TPPpB5W8jlASJkFJuALbUrn3uNT68OtTb3FgqeUDJt2ion6anUDSLDc28Dm9M9vXIcXRgpUG5NA5AmWeVDkoms5Q8hqv70SRBii8aIiWxmRcATqwdeiBcZfCJ3w5S+adg99MF2Q/Ykr1ofXSA3nfYEdVqzaklfXp3o2kiQJcQP48JCwrUe0R5LOBac0Uv9+Gxx9uKd+D6BndWtf7UBB5vczuLMQZ66t8zsnMEiNk2fRPCjiaYvliIlxnYoclcsdQsVptPuiwYs6xu6ZID4y87EZ0eEU0FVo+iuG5iR/536EqqaGXZ43GKGUUui2vvBDegXmEjtpbaBiVUg9lV5lJYIWYP7PRiQazCP489l6rOJRufT46OrIbdO1tPN6S5c+Vi4QJGVBJm5fMUul0pryiIuDZdWCn/L3loFrBxomMvq9JCsrxjyJJ2RUR+rbNTDwe7ajCm5c2xogRAoNy53K7CcB1Gxwbv8E/zjcRmmQghhSZr2r/0PRwTVwBTfHfVWp9KNGjLueGsm9ktUZDQpyXPwj5U3exs7fAUUGf7tur4vq2KyVk5MQUgdx0vb1l+D/qtKyzVgzb25ISMpr+13SzH6NLd/0kqaAmf+5B8JLfzr0i7c5oDO+eOrENTbV/4nJHfoTHg8Uq/BRM2X0dLWFAIMIfZWw2rsT9Yu4X+mOC3+OlZ/G/dkSrIf7OzbaqAXxtsw8HSBkuPJ0FwgwNay9/4by54HTb0yAwXs/lEpg1KJXiHcADnsRep7b5AxXOtIWP9pF4VMzec80a9uclw1CK0ZRHPJHTEusLzpiV2jd9y6/chq9aQvu8ek3xChLOFnuFr9jrz1Hyge/1UcGM1bUBdf2GrOjFfb00QbG/nKfu/XKMJgroK6NCFL7/LzZqAKLKBKQl17Q3nfQ0AFbw3drW3hNEFCbgsl7GdzOEzEJqDyA3k1fAbkoeiCVhqpW5OCkVsh23mLArohhrpVa+G2J6HLa9SoznAKdy3sgIfGtPLDTC+AZgT8mcWuovpu2qdTKy1wJHK2kgPe34VBJVp3eB4q2nB/MDMxAcslMkXnx4rJk1XI9EYQzyiJxSuzUa8zCUgofPU3ZRM4vaE47+2p+rOawu8C7Fl8qRkUEda2sepx5b5albRFnR4Z1j8X3XmNICh8p2kzso71e+HDRSoTtivE5Gp0bz7wHONdKsZaKMQGhizubAZ+Z+3Xxt2Z0QtctgebF1hnifpFcZYRhhIngsdPGWKb2absL14yIYTzqmSVP7KVturCUgqkNFdWxfpKsD5/sq7c5ZRAfmNn2zwzwixIggti901b8NGFt7JdhSNU0AKUUPybDfbICvxfEkpIRvtJVLRVWbnPNak39OeXj5c9kTMt+vg/mItHFm8EVFKTABfawt4d+1qS89g8DB7nGKa/Gz6V09ph/lnBgIqaFCDlDkyXifG2DxDyB36Y/hZnONKTT+AJh3sN2zdkAlu3nPJ64F5ugHtGmgL7P+J88E8YM6t7JsCgI8VXRln/Kc9tiQ7bNfHGygVecm8Jq/LwC97SbW1yzYoRlG+DkReSQXvaarxu1wyaLGu520LnzfSuxidpa6v1ZxdbfRiX+a0l/y++u77q3yOvDCDRgiEyta2gBYxjGPAzV9zKZLoct9a4JTRTYlLxTxvuyCoAUYzZvoKouVkI55P6aSgoIFNYQifW95ecpAwmV8Gn2Dks+K1MIE0Mtz3HN5rYAXNU2aH66RRYQU0UGth0rgeD2TPJ3k6J3pRHyNLnIFteldANhCdwu3tMQip/nkvbMaAUqpTJtrgx+jxnJcAojqSI08UPqw2oaRbdyYL1HfG4L8ypRK4NxAmSB579mRA+9VssKcmLDDzYE6wQtz0VY2eDb4y9CQOMioF0rd7h//oO65ekvzvvc0e9RntFXl9maKWHfPPRYamblZn8vPLmZIqQvfqod1oe6WYq8qjj+g69BJd20a0sM/O/qs1glJGG2enIgvm4dJDTUwqJZcyK2GCpm1dLS0wdVu0BK4xH6ARtUkmiUNo442evyXrbenCdZZX1DkO3yCbxQ4lo4taHpRQrLXId4g96krrmIZKq5Z1JIA0+bqChNL/xN9Hcr4qHZPcwps9dOFAVucO+Zp0CSTETngceRgty1ebYPr/7u9b1JJdzo7b5wsZf0459RBIrbadyHUoHpT2K/VFgNyoVmoIOii1X0uRhgmEe56gyZ58BB3MvHxECJRJ+bIFA3Wns3uKpMwTIwU1udSOjdtHniSDXvrgxJFikgqL99O9MNf+cUeqbyvLkrj6dTBNN0hVy6PzXCRVlKrQ5btORGMrxYHn/i9zlgAtW4i8J54DC0W+FvdNQUUwYwHCjBfNydNX4TpBFwk0he1u/LX9p+EpfPTX/pIJcyBJ0yA5KVqlFsXJqGuHx9spZcxjsnTQvmIN9ls2Ytud2Kd6BkcNxmy36E8CeuPaoJ3FBMPuFvzKbV1hdXB7CzN4fOKBjkWhY2E1dxIeLHNrtgn/RWy/7iqXEPdJ+fd0j+TXl8JQkLs1wvlcRI5iVpkw0vCpmreQd8+z4QgVcaa5G9MrNDaoG6dy2nGN9TRKXLIU09ykfMMNj4x/WaocothgtOmLSBjISYJIhS68puAMRGDJDhUuWLTAwV655nzXRX+2iW/jqA1PU1zQ2JkXvvGnQLiGIzUlbLvlbqbiTRvLqzqwIv987SVSs5eBLxAgbqyf3iTf7uvQT/xGhj49pIaruUj4zyPxcPHmrWS8A/FwRkiOuCKHxft+/kuaxf9D/u+CXDjvsayu+uWXveJL0AReSw00VgqObT+OXn+FVbeIBS/d8q/mv2gBAflTmbkN6mfN/vM67bWTM9uYfvIpcpxe8MdlBhWtLCO57eFfF12lNRgZTUjH2vLeEyvqjjuJadISF51tma3cNSQVhNnABZ2R28nP5ckxQ4z/G+Lxy2JntDXIin7udZPnL/IUF62pcw7jbRi7LTZ+zRdsEn5IBkExal4K/vFcBUucW6sQF+a3fnr9D5Rl30H3S9bp2rDzXcEx+IBPIZYaMXW6O6PDLchfSqAAdX/C76FSlBkRQq54pa1sVe/G8pjH8scSa2KRqta+EGY/ng47Dhj9M+C7V/vnziEWWMMO1zlwft8Nlu3I6nGJ8ZbBdDSC3vyTYCm6Lha3+TX+cjkfvDEzStBLhjK2QioyC0Yni0kkbZzvO/uTBO8wM/kdb9IdNbr0pf+bdyZZdB6lcIhvowhviRG7QmZM6M3v47hewIUuy4LmFdGf3JIomOcmDJUkJ+wzTwH5MZ6/Ch2+NF2asn0dpy9OeFG59ZgzVnw8smk8nuc0ubHIYnP9pci9ZtisDcE5bGz+2xFfqYCqYiuVu8XJeWIzveWMjm4CTZA1Gc1OfMfxpGkW9JiRLMHbbtaVNl34ddr0F+mcAEhQ2vvjVbwaDh0LATIwNIFTY+GXUpm4SpKQP069VD5hS/uk8EacOVUoH/jrNEOsvbMRHnxCzKTRHJ+X7AoPpUevqUPeA+csiDBdVJCK7PuUWBm/yz6FSjngplJyaEU4ZUgcds6wXtwiTMJLpslOYM6eCB0A9IcWaH+U1Z8MVSfkoHV4sHIRFW1llGyxSeYfsPShvNqJaGORytwuOfVJgNeQbH3pxi8eE941atsAZl14O4MTRFHDkSPSH6ZSKcuJWtfzughFLAvoDDvQL66gEI3tYeq3bANxrLoxU+a3obDU4OAYAezCewAXK8HkOXxiVwZMOHa9PeUNy+GH+cDiN8t9bxAf+I6hESWl0X+E9QlS0fi2q354ZXA6QIZqn/AW0x33b0fG2GoGNZtClwvwKHrLtX0RBlCbWC9BzM3/DFYvc5hWBZJ6N8rG/dK096Ph/v80kcXmqJAgfn0sqO8dmbjFzXXB/VEfi6rm8u8+vM7mTh/S0YXNJzww0nuxYc2PH5q+YSizxBXjqhk6eP6YmVP/xz3E99eirDSrojQk+EOrww7vFWiISS7ySUTRWRwUgBOynnJ5HJfVW2SpculovZ9C55wOYrOXFojW9M9aD2mqbJezfo5e37Fs7SUExrufyfGefjgK0y/7lkdZHmqd2Id0kRBB47O35zOilcgnaW3ln3lSUtOU6wMXujYxdOrwWUajuayP5wtkpf4nm+U1T4cUfKpbVwItcWu4OMzTQ5T6oU4JGAqjVfMiMsmoZxoVp9mx0J+Am1BhEoMVgM6ubT0RHTXoRsLk09kX6yX8iE5E1jQhZbEBLPsn5sr6zjelcDJJR+4q/0ewJ/Tt84hU8Pit3hqqVGLRpwLh1WP8eiuV9UIT4rnN7Xu7yoMUlyWfMauySxbiZTI6s/clzy0cpSqdryFKo17WQk/b8LcwJ77xvVOV2ku5oa917runnAIhWlURDYVgkSsVCy+paRb822lS2kglwT0vDQ8pzoUyMOMf5GiUX8N/rDfm72F+jChq4cjbBit0OMehK8KSgpbdlidKOwUpvgA4Okbs8RmQkagqY5k4Iz+DVBDfxLyLq0MVxDDX91t6pyBrSkc1m4xkAOVoVeUdt0jyMbP7LK8jcYMuoX5NM51a/GTZQsK/mUSb4B+HfhKuVC1iRNkLD35347zHSADMWTfaL9tehbLELBYyUIusbJ4g+tjHbeSgFdAXTYz2LtTUNfE+zc3Rj/AoB30087IPJEbxDVofepBcTsrAsYXcxNnF1Q0vaJFkN5uq1tX8VY0/4TNSkZqefvm7VdCAZvRpLsKahS4qBr95wt4ITmkYAn/CAhNHy84JlyDv+jHuSGRPoKgT9am6uvRcdEiXL1HTfvqk2HMLj+H/tw49fwugvq1yWkxZRuFupo5Ra8tWc8aBckk0HysGhJmBNAjW4bz1pWSik51oLn9a1RFeTNt9eyHuTc7QkQ4y3k8ZNfPsGzUuP4z8pSXcWdBoGFK9mZruZRmsvSDPUq/ZeAsdLaCE9kD1jNoaVbA7NIt+13scLmo91nbSL48LQuewQhWWvF6jmdPcs43D7pvJxQo0QHq7G+ZeDJnkJCUkS134jjyyAJUkzh+vdebczMIhBXFwHWRWKWBVlgVRLXvJWs5xiKxelXMdDiFPki+hCYk9GHIy1T+sox3PUCJ8GndA5NFdISNVY0H49fmZHddvVE80oI/nQP7fhw4/QfRoEhpjN5oA0ldfMci39iWII/5PHihD+crPtwjXsSteBRu+31+zLCSf/qcX6B+1hKqxfbk2Vi8NO+1OssQV3z8Uso6PC7CDcgtlnUR+aTU1MHzCvLf/TxIHPvaxDmYGGSs5ii4UvaqSQW5EirbiDEV7quObKv5PTyraP7VJR1kUywG+Ob2gdh9JU+I90v3+ExWMuzKAFQYADsJTOcK0CeDo5PXgnj8XrSLdzH4FQjGZ5tvJ+wFPNoTqk3UJRuHurn+0GZogeINKHu2UhehYsmOu7vWiK8FwY9J1xh3k0n6YQyPllOoz0oThkDEbN06wAE70vS9PXWToTCAi8Lc9VLK+5YVz0w+qP4Zw1Vjn4qGIxvV6GZ3zBXuLH7jTfAXEoX7+mBco5xm2kivmXpPlw4owUdgBplp1Kf9PxI8cmYHYmqj2ypE638LE/Zb7uonpGqPDC+pvuuVetXavyEzElqGPQz5ElzMnbXzDgalSurNUqVvVlafNPFPjDpNV5Yay+YInk2zNURhF/le6myqCtBR/1m83bNV/m8jK/v6IQhR3mEE3WaK+clIwKgC9FnPv9gvAq2XBcvBbgMe5MiPrvDDnG/dbfxTl+aS51AF+2YijabB1onN+itjlSZb8TiqrMTPGzgO2FCoee0NhiYdHaDsRDylWnsvLsrArXj1VniF7N9eQ5RsbNge8nww6wmNozj8ylj4uVT0X2Pwivfg2RMQ5Q5+8dpa6s/kHco13r3cRn/UjFiDDwdrdq0gEEr8011QUZ8lZBGxwAAiu60NgJRyhgc8x5sIPXh421cmXjhpOKcc+iU1l6ZX0OUxsmHn/fHfwX3Hqql0XQS/K9mXFVTKcshzq5pGB6aAwPeRahdp+RQADqSuH40XnMtou1DwX8MSWzJCI7mDtL+ARrV5eIb99wN1FTkZ2KcRn1Anwfvsz5lappDDNN5OTwiYPxQt/iiteUKkhIYjicJ/kg9ds9OfAOk6jqkGQwYEIry1kY96kI3+hTQWzKo2wM1WWltGAg/8VuEcJVveM95ugR+pm0RdvPcfE5SKj5ENQ0e93RNqsCZo+USpHJ8LLn88i24qfmInrkzhz1wTjT2ayfCoAg/3Rqrd1uVYNXfXowY195KNsCyLRBNoIbSRYy7szfkFzbkWqWTLV8ALPpdptd5xyv5RjDKotbsPDg+BdA1lK6+LOr0+9tZuPV0fLAivqA0oAzyEOfq1ZJIMGn3bp+avmbIRQFTCcQ5rzsmoCnAYOjmB2Jl/7r6aFcUX7BEMGLz+szuQ+VEmt8VkLc9+ofQUrq593voxTsiEUYhFH+0cEbBwQzfcJ4jcq801x8VqL9VxNrqa/R50Fm5kJHj7nUv3PP2MKNNKI5g/WjjTkskb7Yljf265PEV0eHgSBdDHvuxdjg1euwuXVlEAMJ8+gogU/1JO54f0XBJsrbbJeNSgT+spC2e8r3dTTLITFVFS976ToWjQP8Z+AYl/go8VJRnXfwVM5vdVjo+XFrm4QtjkYYPfqKGFHH00dD77dyUPHZZ1IIrXVr5lYWKIq6/AUpiH/NJR50AiSdk+tZywthr0o7oxpmVk3twOn1yJLci4QBPQxBj0Z5S0kndc/Yxl1x4iMmxzJBagCidusRub/Xx8y+mPrkoDjjE1GiAZsWiWB6n1XpPIVmlWsstxFH+7dxrWeGGs2skJhsUscVOzHEUVFt1OQrkRsN53RGIn1zQARvw3UJbQSL4866u07jHiwvILL+nLFCrzvaneBFxt6R1B4CtwD75IziXAXZLth38yxcGUkJ/39FcJgJSo1Zve96Lpm5MQQuinPhvtnkoS/SwHzHseozeE74QnGMDLdIaLA3kXRB/DrsFhaw9THo7nYf0/SfdLVgcfrpaPFx4GhNdwQ0JMqNcwzhpekD+sqJtFBwBf0vWTLDdyL1mpYwxR501QUapBezhuguLc3AJT6/RCDr5lKoWmaiyAB7nGShiQ+IGObrWZU6ziqyB8XUARbeig+HO6TtO50Q8+KNLBjDT1DehPMGGX+aH3Dznaywde4LNsG2oQycSWJCmiCQX+iOG0eigKnXP6PZMVN1Vwl8L997+LajldhNDlva3gnmrBYvaiGeUhk8WL6hn98BPPTdziMHsusRw+1/7GYQKF6LrTc2PIo4cYWj9GhlQUR9QL40Ziw6FxEL3T2AfueoVTNDT10xomhy7/Ls4FrXUkAxQta0scMhQdSsiL8dvJ7auNcyxSBv6bFcBoF45H8aqz6hzdbXyGUWUcONBi7GUMlKHQ+OzQ49ojLVx6xceV8cy3dymKLvNEmTOFB7xmOpx0ETcaP+0iO4DpciuYMvRlyDuZ2Bdp8+2ZVf9gyKif0yyJCxCEGsl8ooS6RiMXtzxA6HUhbn5YJk7kU6fW4WboLp1k1xvITKyNm5p6gZNVpKc5E7h79gaeuIHX074vq7QEQ7zFnSsmJiphkk47qbkM8F+OSUH+qQgSNLFOo+c+1RUjN5wv0vEGGokdS4aQRlsblOVRS5r7aQ28xgbwlIjZ2jQ+dt258SyFUDX0q9vqiNSoHTDXjb7BYos33e9mLAoNPKdgOHlw71PhePT8yXOVEBkaE68cKKiUDIC6oH1RyWWHzYdBA2ipnMEw74d/odFk0f0dZOsW9B6HPA+VMYCFCidLISlDjV6MRqMudbAEzhsr/Xbl+Y+Bj86CGXZP/Xc8eiAPOfjSYyD9YSz3AUSik0Peddb8r+dx/QyGoaCj0tg3SQYiOEuNe1b/fxyRzyPreqRbqDhyg6XfD7jJkaPT5B+tWd7rNA9SfSwEsvN1m2ij/zvC5yo6lr+4m6OwgDWymXsw7r8/ax7IPqqspmTl1qO5+3fHU737ttFN5KD9srlPyO41DlYDAzquI47id+RpflxzEaOYlHp6SUmUT+DiPw42uE9RE1WNd/7fmYxZLvCuSbRPQm/pTAPiWDqjl+Gyrqzr1LHUNc1jwK3Q8DeEC7AOLgdrpLK1xkke35MVoqyKWLPri6eDe42IHnngx//3PnEiQu3I6/CwjLvJNfZ5xHVuCvvdKw7mMy8f6ZfPJ3C/rgOKDlpqW7DNDNjD0xylPEA8XRDsl+IOwFemU3R15ch6Jbwyk6gHG+VtWCvAjGydvQHuI7J5VcwnLLxcRg+EljI0ldamFQhIiBrLovOSgW1ocqbyp5x6y7HySVCjrxbfJIynTvYWQyhn3poE0rmcYVcCbt88ZQeX0eF7za0j7cg2JD1sgs60KpEpq+vVlMCdepfqwZFsWQg8Tb9htCpjyx2pf3HD9b3UmhMG/jOGdY5IOcDXsN+psI7NGNtBABBN8Ou2YTmGkA7iiA5XPQliKk2+kZj2+G9Iikb9nxsB/dTkakxLfZOqEm2de0gWME4nqRSVmMCGoNxlM7y6uhe+c/IRuXc9xLTYAwtTbZ1mzbdk74FUx9KtYKxq/fNqP4vtcL68f/d5k9y5b6A2kXDwCpDG2QjwIG4b2PLOl9U8ctiAv5pXBFhusjf2FBqDiuVQhWFYB+kcdWKzvSB4TdleIakBrgz3EqEdQYqUjjKQbky9Dm/zkJ+8WVihVaOziPJZCrtwBarFKZeXum4F2rfMZ4gzurC2lJsRlEM9CZA8+5MHpONdT7kKDS2gYFbkj7pPLYURKCWxg6Msqc9ki3YEiQCdBNCEs7+IE6ijQ7Apnj5PlMrdlqUPW2IZtqhv5jkzuxTGpSR5bcuF52aJbSmgHlEP1GC2MC4jnhBlQJbqPlNL747XGOgQw800V5NWy/8ytvs/q7706CsUpfqka4j+ltc1MXPxYQfRFT4oQrifPGZmS8iY1GzWwrQSqvo9GvYwwR6tj2yJvGjIGpY+xBhstKYXVu+kX72H6asEAoqUOoHYvo+AFxKaV9U1nBA20et7Bm1IrHsEMpuq3J2ItFWO90i3S3k9ThwE6+wQvsdnOPxcEewwtdm0Z9ePrJ8H8c2u1tXWCRek7boaT5l0Ue4iHFEfPZ+tx+QpulaP3TcaOzxrD6URFPHgmA+pND+9nVm44EDBfb1t2DJ3/D0aTitg3GjLzExjt0DH6lQ2HYMryjpVQBYcp8pGnfQpKaP90ZFXDg9kUlKjYSAw5j5FUbT3dqdoAEevGjK1SqaadWkehDfp0Zb8CXO4hbYCOeLjZhhu/sYi/ZJVbanD4RS6XhNAjvbTF35/EkmufdF1j/afPkcPXZw4T5KpFJGKjo+MrVntdkL7xx2MWSZQ8EGwZi8DNhZnt1nirlilWxZvI8SzJ7mKQR3fijQfz7rZ0JoWK1BAcZuwV4R6VlPTC6SOZahu6uBGnThttdxSDUQyMqI7tKHqTfpXKcTsHRtCAfIJeB9egopb1v/0r5Vw8Yxb0ENhMJCdo+tuMcTD0wgBo8H0KVf+mLJ6gCfEkj07+oXZ92DHVuH4Bnyfj4IGVltAIyzrSKigjp1Te2tkvygtIMOPKa8rutp6dzROcyP+3ndD9DcOcvzf4QALimQDlHMqdTBTELn8pOZuPB/IBZDQc9D5/ZCjE4Px8n5qm0uCNfHrhsBVI8gl6t5ZTFRCY8+90JKe/ZeKRuSX/94SdmcVfTSHp+zibPCXFIvpXOuhr+xWjB+sJCx9f9wY+ZDmcj7RHVY9T9BkF+OLd9KLjK4mVkFjyFqryNN21yg0MyJY8PDiAnnZn/Fn0VDT4Hy68j/ui60f3ozrm1+a6cecUUcIAPzJwGLdxmRaUMABmtDdbgLpXLKqn3InixfWCsLBEr4XxUEjZGfsjFN6cb/B9wmaRWJ9WDyjEPhm8Mgn4uuVmH65dWiqolAkvMF+hrxKkXxjMsuZNiuQCv3Wz+iH7nfiYMB72Bv3asK4LxEBZoL4yYyEHhJNPkpyxo578PmX1IU7D3xibbpo2y3CtPFGBfQ20WtRWzzuhmMNPf9zeAqPhHu5Vw4W3S+xrjcuYUtIJuN5qwAL6j+6N3eNiqXkwm61d1TprB+0DKZUcn0J2UvfQi+VwaKmX52L8vXkYUdWSJJBDTG8QUhIyG8faMwCv8pBZNPQP0UEihyQwj8Ly4DwpbPwumDZh95aJpvNT4fZ64NAmvT1V6ofc9Tay0iOWshQrN8qMBY2hZ/oTxtbGvtXbXf1fyk6vczvp3B8czYYXgL3z3o3T6qdOTSI6eIJhA63EwcPF/btNlTcrULkOtNqdRREjwI4aAwZ/9fn51rlJ0hk0eGA5r1FViMxb6T2giRIJPsEJfbQZTUj7R+40+QHL5YEr5nDzQbmiCMw0QPHJxXr5S08LhtPQ/FTUDaiN8K8Seps/Nbq3ZBZjhmW9wrnTE32GdaNY7GBmvTy5BJstqftTXpT/q4YR1yz2WmWq6eMn645CeBXzs18jL8YM6o7juJ1UeTzVzsgKoW3UIAfVh1dpmxdHNXddbpW2uMoirW0IYPAzvofjfQdCrDsNFm23vqlITERiZfUQtNFdERlWj14mOj1beH4/UcCBYrgxLXKL4GKc469T9jp84VGAamZS47IW1dhmRwjTOnL/g4pHqge6gJ1Tf+vl1C9IWl+WXkCgg2uH9YKKf8uf+kyqVZeY9LnN4X5D7z5wf5BoIDvUGLkc0mFsbhvM+dING1IjBbHAg6naQCH6h7j1iZqKHORvZB3owwE6GojJZcrxeNf4WXh4vcRdM+s4belKTnMN9zddXkBKl/2MnubNeMf0tPuvbo0epR69b72k1Qt2/u5AkM2dV143jZmCGVRI0knDNMbBtGuwOSUVPAWqxn25fciq3e32fz0w4zJO1AdKZMzP8tXlUG9fAch70Rb5TrNUWS7cOrhjUBB1KmcF/y0IE447jlBOMaoqeaXXAcoOeWd/pxC3ZwJj4/GpDXaN3JpJy7YSHkA2GBtESf7NCEFWzCVPGBolwqCwqPJz6zSYd6SPGakJL4Ej2SGOsSe8tzC6jH/B8PVx+cikd5LaRgmEcmGl/DDmV1C3EalWvY9HW3vZKB0zCEWWZfFHADFdsV3YvGuw/hfIHp8cPplLS2IW+M3NsxGmHAkJwbrSMn7nnxWEjLBbxpfjul4hg8tXkHS4t/P1cTibqJYUlWPtzUulEEYU7bv6dI/MUxnGskLnOzlHTDovumq5ulwbH+nq83XcPZKAkba0A7pbAbBkCCrW3A3r9U4MbjLCEudgTmJ3cunh0mE1n6fqJMNCDymk/3QtQR6EFp234R2mcTeungj/NZgL4LG+M4DkkLIVxH3iQXD58MocFJiH0UhTzC6tJSi4UwXWs+jdo9SsDMMi4iOSK9fFtuEJMeHUeJie9WEs2tzTgJXSUM/+Pt+m6Rlwb+CHlCTb1DHfknu2sJqxWaIJ/270/6o4fWkW5zr29/TwWSaT/675VsmwxtwI3EQ745psA/XLNzBflHmLEKOHHz6w41ad8zD+yvPix9S3tSLcsZ+eMVhXnmxfy4neyAkl7+AyXiGubYLd96H2sN95YnXbss0OrwQ09MsXnfmP41GPQ5PA+WvaIOWHMnYuwFS8oYY5VmFUKso8QL5+dlh5MCo6o/k5fA9LGdg1DlthrE6Roy4Hd57tL6dgDKqA2lTMcOwbdFRMc5ElrdhLXXs0UAqYLs/Wf9C8/CZFy+BErO78FjA79ufeBQk3Eb94IFYp3jyvquHc36Uc0mXIhD+w/eTx4hejqs3ruarDgQr4DgGqRS5gMMgXMu7tpALJZOj5X8TpO3fcdAc4DGOnPg0Q1ObQTuBEjR9rSMPdcwV6m8GLO9t8TUPN0OV8VTADyRzpVie4jM0rvs2+06lUHkAc07ezLYD9+Shytj0JndTkkQRlz1sQG8DRdW7IT+wrZs5R9q+GFXVW1DRVrFJV085YH0m6LmSJJGwpZiKb9q/3isZuUsHpxrJbzzUujzA30Qly7CRkfM4yj9QpASPZg3yru7XaV8HnAvpQCBWwfqG8Lc0znwraAYR0Xs7+g/DcrKBpmBy/f1ErMvlhQdFT2033se4bz3Utx1QT7U0DAQ/O5UNOa1vzeK1xZU+iu37j9Pi1ptfd3/gVjpBjc8n8P+VTN+vFS0cOmhRF1VYJs698NOg+Fkap+2DdmNZnXeGrEkAtlCwamaYVTnd8NKodYFCOQY4aIk19KTIH5biy2Iet9TFcRec2g4TgXsUo19Ym764wdEJWVm/NV82Dyr0tfnj68Lw82DGUdg6Exn5tl3NDETF3dAdH13Hoe458ZnF5nPhP0OIDS+PhpABf7941fsNZTZH9qpah1CE88lXb6Jue0S8COp4twhgQ4BcTOHCAuKmV450Lb4Lsns9bN+q0yrh4iWuspILRY9qmsgjc4RI4QJAHoCDg6E6gHnboMhFoEjNduyRXlpkmDrCnn5JtohgpvqvwnTUqR0fPiP9l2CLHWHTE2rkEmHjS1TNcr3HXBvjgqG2i+N5wDvEEB3MTet1HV1PUTtXnztk5DQCcxdmr+HOSrPhI6vsfZiPTSyXtw8OQUdJtvFd3XLyOCasLu24F885KTcjG0VzGD0RvVBCS2Wv9d+UkAZQlKvT758EHi622mmpaIFSyaWl36MjNE1tiulPWTYN1TRGI2lCUkBx9O6gWqtfLuRgfNTwZ17bLxIG7CN/o/YJ4BHP99XLacv6ojBNO3XbpdNGuYb/dA3Jy2ttGXOrjphUNPC0/ri1Ur9u/xt/NDM1wIn0qltnY00dKk+Cr2a7V+PKnW6B8NKOiekNO9PNJOzEgUuwQnR6n5A6ZJSXkVPsai4v6lf5NP2ygt+G4DK5gDIK41l+I7MEYYs+V4JA3WKT2NMpZoBY7sCJWHdegkzJSdzKxeAcTSm73t+FVMODQQswfb4L1i1vCnWZsl0FCJMHqSxJhxgQADMQ1M8cF/IapdHWcQtrxgj0VGkJm9ocQlCrCu7GPkJ/iw8hkCBy/oVVMJOR7VzuadAH4X2s7a7x1xwfi6FiPBDDSDPU4OCRwZhbpJayb8pyvHvA9vr8fxEXZPpZNL3YAWAuPDpxUhbEGtJQoG1SRYCsbzjF2MMmKqYKrRdlS4EyFRxX0uvVDVIDfa9AA3u9zIF5dkZhte9zNj5d09hc41l9XSS4jDyoIWLA5JVCu7uvLA6XaLFRTFM3+W/VNMurRJ4hRzgwRXCmfHEuh1IB6b4KHjqyQpU6lJZkZsFcdGLscWxbz5BOYhM1bEy0XwA2ELfTCGuvYplWGBiCx4LAR0xLJYDnsf841zyKKLtyzTw+PT6Evc/568FaLayaSbgl3l7BBNfhqJM+dAFabP2Sj8xQAyBB/io8NYuU3aeXgICQYOx9GHQJTw8L95L0a0Rx+ZsfasPGheEl3tOwSST+Tc4+INq+hxJjuBp5pMjywwxUo35o1reRe/r0UoGjIgQKmRiDdnsDn4yDhCJextkI1MP12iW9YqnYcNXiP8Aik7vV1n8q078cm+k48zSRpfEUYXlyqKruiiK/ZAeXsjq5l4R6l4BTvL4Op2UOj52vCPQ7Ad5qvi006oJEFkPpDE4/64pkMP9z8Mnij6251IZ+ol8OUAjWYZaRywJpe4QyOITjqx1K4XwkCoZBpPMWNnS+nXehByVHWsH2Dx4419gpuN82g2nfl0MIg9CcIzaJk9Z1ffX1H/pVyvO4z0e9vfsaz4iRtjDvVykCffUDs52BKS9ykwSLCtUxTQzYnC6I1gu2bBjHhOyEye+arvfBYxBoCXo5ZL6mZIWgYqSTvXlrLqhSr+0VIgywEYJjiWwH+KFZP0EeMSrummwrQf28CDBxZESw1sb9m/YSyF8p+boxz+00V0txSb8lf84upGGScfVESH/ae42GzbEVj7/lp5Pwi2yhTVrNqs8HhjlA1QA/JRUQ92TQQNi66AZozXuWSUm2Y9Hq/XJLlTepCoBL/N7xsIe3l0ynxFPZ+ZVYDGc06ch6j63TeoS832lEU8C1nP5FTa1A3yY1j8ZxtqLBdSB76T5LjHfuGCleAMs/2kexb0tgmUbkLvajSkLDfogVfrcSyTgwhJYnxJ+0HHTGvMmzEzFQAvZwzL0cPdWjhX6xFp1aL293qCrqxvsgeagm9mxIPKBs9P4d5OisJGCESQ2gpX2Kpt37gOM3bYWuVGcxS/ge9dTcDfXOCtCh+hF6oVja4DgFM7EcMIqKHm5cBwnhP7KwoIs1y8u30JPVT02/uvfMm0o56UssPH+IFGo+Mo5eWQhdifD6QGvXz6pq87Wj5hwOdnFauRLO+bHNX92S8QjQq2SV1kHAZEMJl2rLCdS/3TCKS0QCH23esHyFvsoxDy3TDvZY8PLGU7J6ccpn3FqeN8cwZ3hn3+y30zBjrNtAoF9It6xeCEObNtTxXV6YQAaBOKjIBdo8AB6O2/DXO010pOB54Nbrqo0aRVkRYN7mUHfGpwjTAjxm0nbVogBzK0qvoXRKNwYi9/u5HDJTCXMTADj/PXJYEtvmHFKituThYWFvppPn6Cn0bv6KyuwHrSdW14nYYJ/6tpXuPwwhsFYeqXlhhcFP9HHa02xAt5MgDEVOfLEp11kEkJOrzobAgAeIgurWKSHCUB3RsLoxCmXTQBkUHU6edPFWQXyetuQLBGqrIdQCRyTuJAo3EVn2121/grpXTLisct1hRRG7sgFIelFh7EUY4rbSGRRGf3iwOC8hZvhggb9qOtSnmPU8UxVeqMYGYA8egxi4gugtrNTxfWjYEL0/AfzKE69Ou+UlCMYEF4Rywfqf+FSGWjPwEJU6jLbo6MkbbRNv26vRoogRjZWTSyXC2VwrnmBpjgFD7KL1ypyd/HyTVCHjsQFBUHrJTcKe2X8M4MzEcwGLZn3c+xD5ztexlAroJrs1F1F0x1kUARjuA+0vHV69Yx/NmGr2Qeu7cBb+5xR2PJRYwiykNhjv9FBjGzQftqB08wn43kZpLfJ8KKrbKFvpyeZ1rR9XndAiJQQ4CVmW75NEvBc4XjG7Vp4F7ekwnMuyfohgA9G8N97oiCYBV/cD6IBpAM/aYyTSYs+LQ0DV+Z9B5NiPtDWuE7SLDWk8+grj3s3pyMWfeElUur0JskJPSSZ4cMhnDfIEyySmCEKRHhmC0ErKlVjm2BraCpYW2lvnzHpun4IxFD+9qzZDG5ZpptXSqQwbOE0lGc8aF0Amq8J4rD0cY26oJ9vQpFdC/zqq8s96QdE131zErezOOPyCjbH1AqukXPkqLKshvO+sXTh+0yOwANtQ6YVXG/rq5xwu6j/KVw+RLmOw1Ph+8mt+Yw6FmuJpfMACLN4zSbazVxwPcMdlxWu29Fd2rnjscwLWj+CX8zG1IlT5/6ADu0abFiev6KI1ya+Gm22BiRv7OKdyDnLmUqSUSe4IXtS1O9O6hX/t2ZQuU5dxa8rhY3f8iZ4khTlGjnSFcA+bFyS2RVHpkl8FwHW+L5Di2yojgde+U2e4w0YtkqurEz9LFOrdjVt5DKgSciMz1reRainEHjmsbFm/5mRO6dRrrty00iKdtff7Um90BeuIls6tNiDhHE/462gGkxj/K7ks2sNqNorEd2mrUfBlbrAcEe159Qkz3c+Hp1njBYos9P8g121TMbpS3jej6cbHqOLfnAyZXnLjfw1rx5/NcAImiaYh1TkjCowIvi91MzcPyQ/pm79er2qoS5Zx7qWMycD+mmcLbSye5JrAr/TK2sazxQOsnk3PXHptwGxJbl7ho+owEG2EEjJCr54adz8VGEHyj32+mG031lHBrFpEL5P5TChA3edf4YYYCh1vpOrqn9EKO/TkbNw+Nu5jXLXeKLpnvSoKLlDXYvBP8NUEY9MsFaf3dQoGz+lV3KowiEMFCLg1wR4QYsgmwwCQ0ERwUjyaHrvgMDjdhigWlRxdVW59UzKP5M4rcMILWbx7ckAa0bZX3z3fhvKwqNcTiod3tuhPPdZIpJqc49/CZWbZkC5PmeuD3Ed250o8P7FqViiHzk0cagNAlnrjcbNH/DvJiGAmpszgHVPP3eqhvjXuEFhxsF91MJPkXck4GiLF1fyJSvgICDuq2n97bb/ksfAPnhGVimRQEX5OtIZ6qkS/wiGPId4+3UaI41zNv7zvpvCd4uDphDfJsyDv3EunDjsD+OZfNhARt0gl9N9abtaWJY4Yw4yLoum5SLTKBX3DId8QuTZk2Tsirg9HCplrzGzXYHP25Ju35/0o8uaKR4l7lWY1fp9PpmuoLlDGR/VwGWdxCbPXjfWYOzDI5glkhUzO4JV0Jt+l2aXO/+107lQZzzNiG2iDvyyXHPia+Z7yMb4QvF19s1rDtN9nsZd7nJ6Y4jnge1TtemruMhIpr9V3D5V/xkjB/9Jlb36B3ibxqyIzQKgjvlSuwzLRezCO3faPEmpWVoPGaEfYyjkOnLF06U8AwigNpdjWy7lY73Gw+h/g/G2vtobzzVe2C+Ioo7/zMt/hfCK4JHXsHBk66bCk/D2ldiR+fPTZRNwW4SAe2nlHHGAt6Mq20cNODGj73PmJBHpJ7rVYVF+rFQZcg0Zb0BHh+grmzOaWZQMz55+QijmdrzD4HuAyt6cFa+0SEOC7ckUXTeeMM/M0Xt4WaR2sVqLTjrIO9QTxgOIv2RwkcXQ+tyYjbr8d5aCzlSdgbadAr613W6hTfR6BjK3G0shwz82+oM4g7k1+nM7iIWPqf2e0C2OYSEGz6sCXm11Ef15aWtdmUmt9sWINOiHZgNZ8jABKn7BCPZoUq9gBGFj5n3QCjEEl6hZfdJGSXASXkJ04/MCCrxPzE+/VoLQVHDMQXxFK5SAlMvwyB+T562o1BO62AEnXEZXF9m6zMlB7CMn27Z9JL1uY7pObLsev+zPpYpRY3VQkZuK5sU1GOnis3hPeONOSILfACDz6yaqarp6pA5ZlEe7vDBOP6nGa5VFqWUY8MhF0eW9LXYNHqU+2xEJFsMFpdJwQKDL0io2LS0/fq6idc+ljYCcCWyZmN6LjoQxsTz+jPs9IywO1LFomPok3ro+aJG8RAKp/uHXL2gBkS8s5ISPv7tCS0xmdZ4o0PTfhIqWlAsyIbQ/I5LiPkzRQdSkAW2px4dwoBLMxXk0AVHSNDZY4HYodoBuazLevUaeDpk0cB0ZClHE0wu2pEJZoYcmSdzHx41tXLfKk/bHAFrQI0amhXWCWBIueV1Lh5z5Po+447zFtfBf5uz1e19uZrKBWjyc/7G/vpdnTBVPxcC1mzuqtX6S6oXL3rkfrffeUQiTUF7CNCCcSPV9Spp5/MvSP4GUSU7Phb6gGC4L9q100k0BAZi8ZCgKIZA9+Lu0w0Y9RlnLLfD3ksALF268kqEVidZfNH4FuWE1hF6ggwWL4yPyp7el7iURJ2YBFuW4mAIrjWxAAZjJZIJIMFSj0UJvEs53M0nD9aBBtTn7hEBLQUZkOiNRuCX5qFCKDJBxYSlrY7l9KZObn5sRuMwzG1Y1sHpRYFZpaZ4MJUf5PSJWAQ564EbNBmjZtuS/a4cBhccmNjF1wF2OPESZPUsQ0RvYi6tuZn2Dt+8EWe6OeoLKk9qN6mjNVZoiaP2WqPziK51gRQIlN1Kb7AO0QjWoHEKYOLLG7FIU0k3JICNJJUgk0pVjgCzE3saADAV2O4ElJh+AKQjzBICfrY6IA3m8jn2FgdsrtgmtnrppQpyVow6iIImsrRS5WlyDyNgBCAwPpLonWFv6K3Vh8MJc2V+To8IwhqAvevOimzpKCXk8SjEIwrvc3t20MCiL8aSaNu2MAGdKa16KXxQiiz6DukEZOg4KRuHu9Aqwxe0jQ+ikkBP+EPmxIQQY3As1BmUr89Uo1Xsl0UHzvu13MShycapklRgnKdbWry3OAJTlrvrkv5vm1YC6P0lqVQzWTG9reB4VGBgHjyb/i0vVq5KtQ4qAYE8Q5eY7GVV7GEqB9ip9XXFcXAKwGfYFvJB2q/3h/9IISUQe0jaG/mtHPgy8oglfycKuACDXiv6+uRm/odR+dJ6gnpMbbtKEGSOVrxPcXawlbPvG6kqpfIKSegH8/vbuV6pGT0TqGVS9As35Bblj/7T80RY9GhsTVNHP9Pn0n6vgKfpqsRceZcDF/odpBBU6sG/p4JSS2x6S67uGCmU62o6etCByAuYSSLNfTYWp4kSzhXzr67jlAol9oUXaZF1ibyxb0/0I/+zqtRkOwdqmbPoIIgiHjQLcyjgANOUjiZ9/+ElqkqAKrktk3hRQ3M6duw9j1iPhmXiJ3ForePDSdo3bkN6iYYDBSQipxkO0IxAr0pPCQWPACKYySzUH2p4ZbqDdkL4iBWJs91M+V8fAI0anFlDLgyMJI8+YzlubfCir7DAJm6tJpRF8RBPAg/HBoKGqPTGFPs+FqC3ue13tkaJAA+rGikmW5AoqTmMhWy/CvZNcmdjimI4aYk6LqWyKBE0H7r7GU4YH//UjieduTGsxclwPvHGqQnm7FnzuIiqCAjjfU3musyqTfaPkp66tuAItFXWJlPVErLiBU538Kd8OcQltrysgLwyaRw70eZL7o3vixqyDEPba6VRKkUM/MPHld0r/+ANEJzf4mzRb1WpsbfwM7zGoETRfQVsn7KNch3KAsEYAboGNHAYtm9fJNDzikuZpEKSQ7TaadMzf49mGQLnKrl8OtmowmzLy2+zlObMDOFGtXR2ax/x7K+JtxUVGwzWTU9AhG+0YQi+083OhcU6P6ecJGL6GYtfaNbWkd941qXYqW/nbQ2ajIRVpwR/jELBe/tTGAw1X5iUZDyT7tZzFL36hmVOWWjBXOnm8EvL+07alTFtil+D94EyFYQeyEE2aRunomIWTcssvY33AxoIWUk1zSBwS6+IT/QIFaUaz3yw/TMUbDh/CjOpNBgVb2nLowLf7U8jd4TqU4Mf+9+jNLsW6zQc7mhpGfl4n8bpIP52HKgDGPkfvg+fVAw7d6ftDBOwD5Pr6GBiWYWc7JuUhspTBnB5sDZIj9mxi5/FtB3VYvPICebXZCXn+fPWCU2jEc728gEl8wWFRx0gMsO0cBwxPzBGdoT04bcPOSpMARABhUruc42tsvmcgRFUIR+d4aElWX/NfHoyxpo/nJmRmxXA+ytW1Vbht9RkQbwP+hlFbEkcmG9Z+M8d61e+yB1h4ILFHVKFDNvojgy2BY8MerBd9iLYpqjt37CIVeA7/VWSLXqYJsBKTT0eEM5XI4zn1NlqOiDR4bEt2THth4l3P/uVV/nVBhQFCNdwEFi3CSWp711NARumI/fGjq0tUNAyjFR4bTpffdMPSRdJV7Qs0btMKf2ZywzQVIcwg7RthlxDURplahbLAmEX6MlFyXM12OMInVMGTNoWcwXZ7sl1dyZ++MM1YP3avO4qOCBJB0biQrpXZ+Yja2Kn4/iC1tS257zpxfHbAHDeAF56b/XyEHl9y2fjlwSvaCpGqv5gn3cRev0kNhhzuFdN1Iy6vKrDEnvg8+TrlV50jhiFXQZgWivDiUszIGDX66L0j0gjRDA5tdqUBunx2RhAx7ow9hUWpbEmaymA3BLei7CutggZfdX7Ww1Qm9dWMGXM7B5xxIF04oNr+NfkBNHD9z2sKHSF/olK6+wIgggoE3ZcCJess/IBebVN7P6vb+DXvnNPCjr65s1veAJ3+h4+8UoJUaqKhK/qaftUoxo+xYbgWVsPImsZkolQ/fSRgLwimX9hW2Gu6s9Ue1HLvjvtXivA82y5ZlrZZhFL0hVi8cPrTh4vakZISMmiMF7mNxOJilH8J6mucP4fnX9iDfK6D3G5cE5j/bAEk8qQsGnGuzmjUy7M0fT3qvTgiykfgzvHO+C4ODZZl0EA5fZlyXOlO+GOqOsOPtuNHsUOM/XCgitsH9dk2Bm5UQSfFiZxAWZpEMwTFhyDP66tGKEYuWI/diQsqI8hF/czCAaQBT4qJRpAtAexe7pTXN0FANVEh+arnRbqkMJ6a4qBsO93+VKQNnBUJQpd+p2puZT57cjGrD73DoKL7x/wNjO9ZP6++G3W1wjvzDiQE/nxJUFPdiXVTLHEj0SqaTuXoBN/BhccNIIUZg3BxWON4UkP+hXOjGT0a/b7o/cvoMkzT5P5yo+DkX65ZQ9wJHE4kx6eeaFAqnprQbffn3oXGUOwwsBH0DFxhVYqq9eN26CBUTwpK2fPoJkHB4rMWDI2yHhmI1w0UdY88hMtWi3rJ0ow5umUy318fJ32yej7DTpNnZG8iBrlgdx8HZpO/ikK5m7RRWC6H8qLeI9bHwgI3s27oxlgoiTBIVyMwCOOw+r/YBPy/AsuhKlq6vgraVO6bXs2Y9iVkOJoaUbGQvb2c0iqDZ4aOrD4QBA8Aw4YBwLTSlajRiKszOI94qyVSaAEXThCko/CG3Veaki8XTLH6RhuzX8QLC5vr5hiSKdFszPrWCN30fDmk3zlizAvD1yKFOa5DoRBtTh97GCG09yR9IAPcNjBXLGNJSrLsxJoi3ZiO3TOs+BLIO0RODjLXXK/za0tuPq5Dj8o4yesdBG+yvERvOzfiyRMxN3kLuEk5FfyEiTg60iinoJxL5RsL7e0o8sPlLYk5nqowE1I8sy6ZUPbso9Qkp8VRsMvTpokLqVCsrNKc1BesGCtAyiJgmMqvgQvyMLLsjJ+oaBZWYefv0ITn9s/lQXy/f+poOcwINufvqK8bTlKTkxA15PrqQKb2RqGj9RvjzjSewgLnauJ5hLZ+ar5kq3OBEiF8x5TCepitbbZdhl8onEToh3+cK6sBE69iT6VQWNVePDktwIZRF3km5XtIiLSFXYHFLGkwSURk7GidyquPoP0k6+JD2cUdQxcwWRZI4eMie2TFwkdt4m1QVdHKg5VKTsSVcmLeFYtYSmSUnYB5SR482vqy12zEZsZ1qPm6c6Uo8eDVRa1/ffbg6wfvMJ07CTYouBODVhbadOnn+315QbnbOalGoBT62+W5eXMfLX/kqdfyKB85HWFZ9lVlFJ4ZMT3MfYqi8DdvfKFwAyeaSoBt363JQnuVDWEVlUMgQTBvvVJWZOYWmVm3AfuFdkMCZfXx4Gf5n8qtVxQBYMqO6oJG2EUSL6GSCWkKgXFHZfoAuW+pTTjbzRouJo12fUnefAIISPJXkjiE7I1k5BZbC/TZQNJbBiUpL844c8AjC6KLKSxYe3pw77m0JxAz6xdnquIK53GdxCe2K2i4IGQBWOjtC/VzzxGI0WcCNSAJLdSS+SnNQexZCPfeACOUkhePKHY7+W9pPsI8YVBT1CPi3osqFBqOAJYRS1dn+ql+75AeaJWIM7vIhAjG9qOlFPE32r3LXsk+9qBbWoCJVl8octcZceKaUBwQ9kkNUe1NxmHOVS7nZ0xtlKh+6siEGrarIVO5V8BFlXUvT62yHZvCuPc2POIbayBeCTUf/tn6+IY/MxuA0IqiQLbUZJEVbKqa2lF905y6ilwfC56wKlT0ousk2krv6uLu0IbyUL8KBf99ymikBmN/Ji3GkItXnT8iUGTtOc3yW+C/RIcsoiN+4v+sqm3SkS4zJdOFQjmMvQ4g/Q0wSbjyqoneMSOtkZxCoxIyZwm6yYeP7w3d8InamUB65MAEcrTkrj03ePgW6SLSwocWGCy/t2g5WnY83B11toCfrf16wW2kHEQY7LogfvIXAjACcF0HNI94DMoy9ehxfsFAFnZWTuISBQyEYJ43yz++AzjzqToA4gMVKdjGM3FTXTIEC6MdfxwYULTWPNA8YTjFnEG2a2TU925Gdv+dn3t8pVoRYw2y67YLj3TVMP0ObBQryQLvOUQhdDTECtZEK58a4grwqTCseCIrlLU+A6u6X4vwLfYkfBqlMpxbA6igg6kjKYZ0xhBHNv5EbIPCyYagBA6Zx76ZSSSd23AL1sq20CUn1Y4AXQVZep1wQAmNidVCl6VrJGm80iWN928XuxN0iUmPhFo/08NnSqI1d9A3RRbq8kAuXGq92JDBiZ7xp8sx4KeqizJz9HkUuy72cLfOQVFLPtuRDlPyLSc8rwW0G2xrOw5YyhBTsJAlURCqSDwqoRSUNUWvDNmu3hFoz1uY0GoV9cY2K7dUEIIzgHu0AGSgQGK9AKr+/g9Qi2eBWFLSp0HVeII7LKDHGEEZJECD1Jyy+iC6a943FIHClq/E30vaxGznwwhzJAOpO+ZOQnD0PEJsjCIRczjwc2QkqJEHgKc0F0URg/tESudcQfONscBrdINozwa0SwTwOwxCmCeQqD3WBYtrEkMETTjr92wTUI+TH4vMr06/u6VNZ6FTzzcLI0VtUHmOXneiFWJACFw5i4sC0uvNLrW1Veq6ajsUpD6Fue0Rjcm/aScJgynNPQ1BcTkXjIOOcFTMVxmqfnzFzVv43BaiU2lSGaR32urcxWR7/byZy1pTN5AADsyaoY/Fngk0YruiRjWcqxTg8TDZEkzuTxAfz/RZwMs0XS4NMtM+raLKvgpKbiPhuzJSKu8wp553V32dxLM9kQzcPKw9wyH1MAina8bIaMM4v6/ujLHQcVx4+RDUQqZL0mxYxOKbpT/EQqjSwQtkFBuxeOvQr4DcIyD+5jkfB3e8rfrT5sW0a7hPxgUfJHj0FwbFgFJ8xB9ig6jJxuKUELOS4RiLzD1AVv+KA8WG6zXFELhBJyopg1T+J1wctT+iDfB0Sz9wrqi2p3MTOIl4ERqL7gt6EI42Fq8xvHW0fpjQcehAhpy9993HkWyS5F9vEZpEAw654R2YDsycRjk89Rrk/9wChxxvvCP7p8aT3VNZMPiwaFO5LW5BKv97RdI0SqYvu69LTkQVlLpO0cv2Au0bIeCgY85Qi0DCIDaNiILp3en8dw4JdBvBfRnjk4Gqjsi90+0SdEnwJVPRt3LklQMJXZ1r7pOjsLxmeJE7Ysl3/ZB0BmAXqdNj6vfPX0DT60/TNxdRsN2AanwKnSwMEywZq3rEBZN3hIusfrgaAO0oU2xysgEv1u2TJaTImcgUvG7JxGkYRJP797rY2AkFgMGfbkRgKiDYLeBBy0ahT2uekGKxlmPBVXyzrBBkFduoq3kpNWIRsrvHLMs2WkEowOcm9N4QnUN+5lyQIRnzEI+rPgDWiYFhFZScOCZngjUQ1lOj75maU5WENCHIyavmCwxz5N0goolCeOnLoNM/mYggZDB6RV14T3r+LBjaa/DM5/t4HUvas7WrFVVSGWhTyUC/9kc1ODyQqXHjuLt1F+j9I4vc3cCgzclrG1rReiYfH/9k94DgbCit3wijMbPbBcAOb8WYO3Tai08Go1KXsS9KpatWkrjbnKFYeIdXm5soBJaIHQvBXUzvjUdJSGZ2qmzF1ORR99Bo5Emn5AfBqT0JYs600+QTkiy1LtVgb4o0twheZLiSI/ChHO92zHvCyzqCONbNb9Bah+CEFKeOu/qKa++o18+E0n/U0ezZBE9q93RyVW99aaTM8fiIgKVBM9JJtTDi4b3uXfXzQzu+SRa78YPP71ZD5uoqH1aJh4Gw3CSLpHWsUAu7PppZs1GN+GyMuAB14NCv1Bm1VjXr+EsrOLyLNl6pcJE9WyJspXHZJICZMQJLEXnuacpsOLlHDtSBHsaXq8Ic2l7aVo/Frjh/jrOdlFeau/5/TzDlile9gVQgt9mCcwhQIZDNmPdIxaH/3e3MCfkilDQ6Ydk1U4ENgh7cQridHdhtws0icb/ReB08qmamc5zqMJfSvAH0iVLZ6igu6scL+/0FIyzop+gBxSQ32hVWU++0vo2oekjR4Jnl/nvHpQEs/VeSS3anQKfXwBqKrT6YR2UWXip2WOXCcwVzTFE0H1rR1PbI0AUNQIEHgisOD0y5ugCkyOgbKKX29CwD7aVF5ZmC8MixLZIZPk5bw3HAuEVJvlS05aNqt14icQTAcG3nAvHUgt/iUX0dq2k0MgSSVQleMSY7hnGb1qVJtnuZhlHayvmAXMPUQj+fDF7Z4xxuueEydkacequdcse6IO59ET7psh8l4AoclH7456cZELkdF1KQT9t1VCeIDndtKbCRKbj0x1vfIeeCmAn/DRFvUF9VZQ6yOSLJfN8mk1Br3j5Sf/3lNK4XRVjBdBCeRyGZ1r8raMPuHFQziqVpU/js3RGP09ima0ogZUGGf8AYWhHZgfNjf+hzbHQyOtSkaDhWwJryy6DsEovN5Y7kxkL4Lp3xW9kW49eP9ejF6MM3Hl9c6AfSLuSQ9jdPi4za/6adPO/i/VyvFVntMrJjrHMz53CXJBPgLyNPlOc34622jALSAv+be4BlO3u9OYYeXNqZ7I/ZnXCUXTx3PVaSRhsde3eg046+FSPFHhXJSKyOZcSc+dC1rGtFtu0uR1f4eA1WDpjPO9fxZqdVDgnKEoo1PKIyr+d3nK+etTj+ZvtsX82bWk98n1OdSeRoOzWxvVzxcq2zTxmM/RmaU7eXHmSQRaKezr2RcJyLVHxrOkipka+qUM0k6z8y+y4dWDlM6hFAIXQUgL0RQbFMLnxIvUP0xS3OL20h39401phecDCKJYpM0O2prWUCzPbwpLk3WbgH2jPpb66EMTt6kzBc0hLmZJ1RyeMdTubiu1mKy3huhOQeaT73CbYmPpJWV/sCKpmzisWjU+cEla2p138cRThmf4mdMcqjb1es4BMbO+zEhJJNPA7xycT2MkrsJZNpKcPUgwmanO1AIlN+WMK5OrOYuqZSOCQiN9Igq4W027hMkjzAve22Z2kDw3pri43m6SaQRuIPOC6c2CuNirVELC6lmmAwOzftb19fIemGuXxz7Sq1mpJpRE7aLZaEyGIqFs8vkTd1iVGm4iohJ7rsTVnkyGHUinRQGN6tFZt+qb1sPTYVNcgwqM32K+k9eR41PltHFV7ZegnPwc65C2UzKi7rzD/15PqU9lNNUWgcHxdmPaNd0RGFtaMLHssYEtXalX+OVoPVLQdKcFryeGP8OtINDL9QqgcuVzeG0gtMpqkeksLIAPGrEuzrKHKj/FJkQA/KXdEreqfX/M8+cpQvRrnsMM1R0Hpatgq295vMFhZH6xujzoOlkvpnKX0psYbpqx9ztHJJ8Uv+jGqvQ27G+GA876mFUZ8G4p1+az3OAt5SqQimiyfHKcAKAuJpAGJDThMnxoRTZnAFuPgtlyOqaMD5xz0bCizPN4A0kt1VqVBM/55KfJJTUEIH3CwYWnieePEC6HCJFVpGgABRd3z9CfwEHlKb5uRX6oqaj2g2Qxgsr5HWnvVN60ObZUVf5paXKPTAbb4sd/vHw7gQp8lKTtLSxO3YN1chBWTq0Rv/LiMmKZuf1+3AmVmcBlAAua62qbbIagXvVbQEW7SYrevJvhtD9wW4DBX2fodoGiZhVmrSKw8nsPnmYDn5bjquXZfAlyuYOFX8vXXQSLP8jnjyQtIZwxHSwhbdD3WgEu70WbUhOIirB+lbB/V0CoFFRq5uhvoSU6bthlB2XUiFvcfKXtPgpg/5FjcJrUVIIX64xU5zB98yrOv7wivRXNVqUoFz2F9IAH//1DsJLjEGz8PF++JkOZnMo38udVMHn+C6CcuBlOuOtTChqy6afc0FjFWeWf1nS8BJWM8+zNJ8qS9c9nwbmfrvCOwFERWcG3tIjHyKX/ZR5bZNE4CFBMLAmqmI9OOj1hbjWksgjuPUweb5JTtzCY3gofbgsSXS0SEWeDtBjqDjbf5eV4uSo3zdCPekiMNo+UBSIkrt0+EbNSj6Fj2u4/fqbyCEAC5wuYInj0Kb7mJMYIY73SOwpu9OVj/Wyos+q0Uav/8RSzRMxa/5m3CBjHsbo+3wTE+IRJgjmAqBAyUTITCkn16AKewdpo0BgXe/jclK6yjxBPYXMJ+iMWt5cuw4HT1/8vvjaNW79vJy+izsYaos7rrh/CDcSCnNtbSybqUT/aGcTYChLaxqsteYyFeGANfaEZ5GnAltq5gxgI0l/mZZu5aaCEIm0CSph/RbhXemb1OQJfdqO3xzx+U0eEsHL9ZOcgIgHIWUwJSvEam7AgXm/dtAwX0tTvfKkM31kkyZfn0OzNNIKt4ONpqBsa+aYsghp+VaOqOZyUjfI7vqfReM/zykAKmY7CuzTqoZAT9iLGBKkDpiM4fDl1bv+GXaB0W98bF0N07MYoOWj2WwssCOpjbLh8wJNlufemmrQqalzk+gneWxnkniezfNF8iR3pSHUIkyxNiNSrucRrHfDyApVElc4nppfq5ihZjKUtORD37P4XEgcOJ5lHNTBOOdv/2ZjtuVLLVm1IC9TTyQ61TM4Eg+lXQNd4zYdquKBRLxeGTcOmCh5YbK5v17j085MkDh0kGdqbJgAh1mrZSs2tru2UxloeNYctHEja2t7vtFZjcUekTay3tIT3qCDn/rzzmM8HR87ImpWrBNxKkp1uk57seJ6KoGMrHqp36W2jJDH/KJD7Ap+X9Y1Ij1SIqdYF4TxmR0oW0+xl0Sx2OClpVJpJ4Qn8W3fAhyc9uGk0+oUlQBXKW2KEAD5D9qdsQo6FiXbs2zUygyl8EmhqCbF0p8DPCD1uvoJStWrAHsgz/+mNeuWRgv2HGrrVONwOJrmrpF9pt/b5LsszJeygi4J3Gt5855dVGWLecpo6OzenfFBPykErpJdGB1uuUTZix0phITltCdnRTbUo9LEO7OuyH7CkdcJIzQ2l+xdvjFteZ1ZAgRHgrFC8/+qCwh4gVIw8/JrAeYBCk7YVbajiO+nAiCajV9Lqybuc57l6InQd/OH4ayXzmpzz0w5+txkzpYs8NTCGeYmNB0l+//W2PxEBb3qQ2W+d1dQIa4u/LJhe0dwDsI81fAk4nOJHOrklLO4rhEv52eiyh6/HdYZesYnl9VltDZCqkgwWpp3QZ+GFoqqCgsOFWXcsuPOzwDPR22Obf+FmkmM6zbAQ7xWqROifGqHN8+jQsZMQqzY6HD/HTtrXYxSar5dMerrXmrvyyC3WwdHbv2WCeLNlahLoV1kxeY2FnvhPNleIGT/1g7sAanyU5EQu3Gd2ccuj3wrK0iZtaKujlvhVOknVZJTlW/sAAnhgBeoTJGaYLhodAB1lMDXh+FgCr1tFS6oHKzg3nC0nCjbYPtSW4gfwdXzY5UAz5NuqetTRNt/btD4MJPwqHCORC/gMqP9x+mF7phgZbRBy3IN/M8gcz4qBIpH7FfHTQCY+zpss0ceocsPeO9+CBT4vYI2eRB0kCUjFMuhqqnBKK6BS/6ncahpRbtBIB8vE1z0VpYurJK9AQh2RlAjAl/EEB/Z4P27iDdO0218m8jqsK6SpSurSlWanjmxm9yPE8CFwaK8UshJRCjgrNlRkn0sBG7GkJB3hGWp9LJlANbOAerlAUDWz0a57MpEgl/AtHXWZzePqhHfmlxhI44abfKVDIvGZxHBm9yTdenX7+gbWRau3eY8GrzLTCR+IqkB5R5BsKUBM6WmFN7Ab13g2Lw+4nP0it2txkdBTrZEo2xRET1ghOGLvTPH7LHs0hSIrwZnVwXlXudASeRf65kiqtkwNve+BPAWzz9gBh/9d0djhZHsUD6z4inVnzD9SrQ6q3M6xvceJwQYTvfzhpUQYxOCSInlOXAb+zSoqPymsbdorLT+gvon1oOwSA7EHk676uRP4vQ8wK/r5gEGYhfK7jcHBSkNr5uqr98WlCZ3MWqaXD46CafbXu11tkJ91XDgOPi3/1YXb9deGEP3XcmPhfUdUBNyN3bTtpuZ3bAmYDu5p/a4Jr1NnaTzRfVxaWyIEqOpov7epkcRpYnByG6lcT6UlVqOtYUzstQpvXR2zl+NmWyIFXVQH9oGbGSTEMFVI3EOcVy9D8faJEO+u3OKW4VmgituEQHoIcx3oXCluoPsnTqM1ZBbownoVCPsE3Nlfx3WKaa2K/FKp1EO7PNk7PQ+KrvzRtDoP3O+Ab0cfcCgR4ZJZowUbqDy3Pcj1ytYTXYYCNpWXYrfk/VdVwgoeLKfHt1GQWuZaDW44m5Pf7f/tX1Zrk6oXB93SXO14vLeuc3oUfKYNXkOP+oJnXKp9ikv+UDNMCYgVW8386iAVDxQY4LG6YbspC8j2Jm0cVjpkr2nHqgVWQmkhas1uIHilriC8LprKkI7+MRuV5vuz5JoNErUQWXBxqExdx1uf1BsFM/Lk7wdTMnIYR8tQI3H/dvs1+K1dJzTj9VeI8IllZLacNhAxO3cTx3pKR5pS8yd5fgJWgfwRQgCr/mrcgL5qR+TWVQXKRxkDc5oI8f/07WxHzJ46g5KEpPFlscbLosdTYbJKn2PHQTlvwCU6xjF1+CaLahaKv0yiRH+RWnaljPdfRt2mabGQ2ZwSGSiSSYf9dvMA9nmxdL9jPCSgteySEXiQwRafPqMO9faEcv70LpmPFagm2vbfWFMMYTVYZJzw/wpZlaPZI92UQQK6jR4s9JJCJA+lSTlDEFiZ0WYyKTb0+m1FMpal+ifPCPQVVozZUOofFOAx1bBMJ+j4qLIsznIKx8OuoJg977ieZpN63X//fCFsFrSGA8SuAum7BNvXhIW4bERZE3NZ36vOLoWR9LCtk++FgyHvxluCrucV/Isz2ATm8pIm1TpP2tkzZzhEotnLIjWkttKEdjGCu4KA5gdvB1RfSyjGssqwT8CJLB71HiZDxrTWoftrXeWX7oVlcU99RTKOyMgyB1lEiL2LUMg2+sYMWat6bPbl6yZfh1RFzhMgCAuaE34221FbXYMPjJz96Wvdnsckcfc11GT6YHLpd6FPH/gwoVOXvNGwWY4VQ7U3p6chE61z0T66Srl7RU2y5udjW1/wDMNErpM+6lpGpORk5u8LYcN2T4UkDIifs9nC2oP/qTA0PGLLoXwdwQrIvLDCeGDOFecg96r/9HsdTjnPcJ/ZzPN6u/BFtjoImuhAkQeKPJHFvKMLVVhwXXx1TGXZJls7ZjPF7gkwtkY6elAnNMh6JQeYOeSXRM1LAF2lcmwERv6XggwDwQAABs4mXwYF2wcDXl7t2k/nG9+EA807XtsTlJjsjz51TDjSMrmL7S+T8QJ9Q1MHtMM7DevDLQF7q1IMwROlWDuVpH3f33iPf8A8/fwo21YI1NihBw5fwOZABqJzUwtGGveTQodn0Vo7ResdEc1NEHlleLqM3oQIP68Jrs1fnlZFYBaWGLIgbIuZV4KOcROsM9x43SCfo2wBH3IFtTn15gUfHcPoULPzrY3ioqltSgaqGrexfK08Ex5MqR5i/4NH851oZzXbDxx+gZcvjOdw/1TTYHcu8b3EV5EMSteRYabA9SAfjhiqtO/R9luE8NS006P3bXM1EqZLRPW3XYnZSm/9h389zLnwbycejMiFDHJJu4NeuY00Uv6l+x8J6aS4AnOPhq6qfL2lfctPAD5P1nLNcQMLdgAtzH32Wmvnm4SLg1Z2KtLmHZvJnlRnEzoXswcLPAmhJUn3MfiE33EcRI/oYFxCQW1SoRKSD55pqWNb7POcbFtKOLk+EUoQUU42zKL3m1EB65tjc4tlN74hWpMkjXGVzBfoU+qjGtEG1bNRZ9Tf+n83LGQM5le8gPd0Sj7oeO0MrYZ13sccQ36DNlfanNvOenh/yy/kgVgvJ0V3/f0dkWI9XhgoTCcYcZFgN1cVMRDvHeQ5zinbn8C3EB+NBBlfltgWK2p4aD531+NJo2hheXUVephKXMoLpBsqkBndYDvsFRlBgVF8kUmukOuMDEVaWm+E+KnCbozr5JV44fu96na0TU52EndPqOuctW0dWpQk65kFzdFVwoN5x37fF0eFtnlOAx90On7Cr47YfTrSzC4YXdk7quwDkIfZQi5Xvl7/3I7EMXdo1nx5r7RtuPuQJRGFXJpb0VpTcPHONDeS56W+RU85+3jHozONfF/N6J15CF3fXpHnosRZ2B//999+lxUcQXB7LsIzwwIsJ1pK+zxv5hIP+h+q+AsrF7LEVMJxDHcnWrjSqul0e11qwyoRjsXVFpIIzRF55uRZOyrOqfovrSl7aqcwaecMo/b8UcUoRKLeDo9pamg2/i2B7xdtDxtXoyZR41L3OBy3xudE2H6BDhayunHiEcqA9J2hc/EgqzeGgHQCQEaD31ZE+KBU09swOfsJOz2+nFrIbiEjHZZdhum7QDfrc4pxFkw4JsWyLllww8k1jq7uT3+NJwHmj8961wiMFqw0cI36l+oePjGGhNkQTLTYkssIxBPnATQjpvJtxejdoxvggmIvirwYn9W3z6TPQiIZ1v4VGyPIrQksGl76Um5FUL91tBefvZKVPZVQKcZ6RaB+f+PHWG43LfJ6Yn+uEDrRUbYifNLc4NBY3ngMFkbxMhFSzaEqfHQkfxRqDEnNadcBBC9VLRan5XCii+XyBytAMfQEezbTDzfMMKNqDca+B7Pf/5/LbT+om8L6SajDihLXuQrBbiLLDMs4EafMnZ930b/Nfdx6YLJcdY1M4D/9w15g77sywNeeZ8KYQIpgrMDqTkeYVZD7tbABud+d/wPfoY3X/gmYapnpGyAanQcTX872tG7Jl6nimnZPRz9WmuSmsxzT9btFaczqiv4IdSxNeHR1V3d92WqIrPZfmrfG6XqHcPaErr+rGwjyKX7J9XpRd6G2vdpZpHAhc96at5ZcFcoh3gZl82OLdW8d0svYKcizfCejTYl5zB04BoQeDY7Xz0Go3hLZf+bzGs6ig5lOPXxAAWFgU2L/JeNovKJR3dTpYngbuxttdk/nKGcltEanQ3akG67J/Ua7ymbIv45aks79ubNCRubqhjZsiiX9TZ3GfglHB1NP9c3+Urq9x6kXX66BZQnpx6iEhn7m96Tt5gJ9SaoH0OkfLjjBNYY1VZxGm+FC2xPs6k2yld2YdOAnkF+GdgidibjzcUt5NbYvfDX+qaNYRB3h8cZ9sD4ZWlKAThkaExr4u8K6vtEvJlyrgTbvVP1JT4IfXhm6CNym60agrp+C3qlSWAUQYqOpz6nAx3jzCUPnLOUwSS4U2YjzT/xe7LW88IR6esu2BI0bGpkfm6Q7aDdcQ89npJz5rlFuk5Uhvw6AHcWulamBmgfTJ8Ko+/minWoDa3duqXt94wxv+qPHeeYBlzdEvX5jKEAe4L40xmTwzBd5XfBwk0LagL1hQgaUdbAA10OtMXRY4BJo3hH0JxRAoUrEac+6lPSKjKCbkxzb5vZCLPeZMK5gY0Rjf2a6YuDbG+fK2p8Px73J5rd4UxNkQOY0Y9bzY6oJIa5/98bC+Za5gfMdmXjpZktqiAH/jPG/mNDSx9RVAO2a2IAQC8Ef0a4S4Q4LovYo8SWZIZnAnZkFOILwd+MBIb4D0fWjr8GWp3JmaHR27ap74q8CJCy5EISDf1ZFIom1UHAAIyZsaEgRsune+zjF/odSbbu6m8c1LztYnkt0RnOit+Tx5h6WdIPHoActAI4K+UjYCvi50krGWeqfdpUnQKt5lCWIX+yyR6KDmpWocAVRi/ai+CWDD8N2tyk9O0A/Kyc+hwbIG27wvlcsBGwxVXOIDxqO+34Hh8Qk/6eeR+XtUeUUCwQ43WJGviK3NVoeYThgyd89dWNzuAesu5Qr38x8blaOewEmYTcfYbPO2quI0DFv/ph3wfltiS0TVPaXaRVunxksKNeO8GlDdfXNn9TWn1qLnEL/waKZPQdedZtlLLqcCXNez2c2P/nebirFeGo7MgOElItzyiqyzVcH78nnpiUlIRlsYPjvD/Ta3/2GcFJ5VCaE0fntYFbqYxoDLU5OHrzhx1bJDR3xDes+CKOOIwGzyOgyTr/3sL1wI92id6GSUCtMnPyWkQSsCM1Le1Uxq94N7dcvvVqDd/hqgsR/VrYF/Logcj7ZA4dML4HypXwF3xN+SdnnstWjRuv+xvDac+OedrCjl9wSGh2wGDMkIRo/AeUuLorJRmuvEe2SUeiqHb5GGi2UngtL8FiAISiaitqRRR6SXPnuxgViLKY0t+MWp+eH2viX1RCIMSVGAuUCLY0oOrfZzcup0SwJBe9RxOXSGJZIFCh5pWOmdd9AgwdlxMRT5O7BhxLZczEHzqR0u4DobMhulnnfsyinoMn6fatE1wyfuoHNVUHwktNEl2veFSBXf+xXMK5Fw7gxfdtZmB9g2teHB6NfP1UaEVx8+kD0UH6R5uQ4cLeLaL4QKD+eXo2KKDum/6iDyC8+gqQURj2wKUpzlW64IqGMOZ3i1EccyrEXQDW9FNhwGCUINkaiLlooEHJ+4C0m1gYBnmHxWeyDx1PRqOJHHhtsxjhyv0XZ8fjIimWEcp1KDU/GAXBcjuGbiNcfvwKcJsqQv2TmQJ7yMRM+bSQzxefSynpSSzolpguGy2x1y+1BNAB9F1wh1y4ZnDwYiiBQWRSc+7OKU6kkq4Zfu9V7vHtrmZS9lppDNLL9kAzxI8drQi9qiajuSvwRqtkceD4yh9t0D1wgZ3egZO6xQlaLKZyuUsiVXn9Aqji67H8JWYLgH13jfVMLUd/ZIvGS3mZ3iKtHKQcoV58Hxhj+u9SnvTBYKnAEHXQE8q/CdKjqmNXgX9K3wdc7Rw9ScZ7qUSqtgEnMnSjaejC1dI15EXuXN4dT/a8Czh946MtxsvzpMVBSgDdesQnSsRNsV5fwGmcITED4MOCameJ3bcqS6RtQB3k0ZULYR7VzllWMG2kwignSE3hFQo/huWtbJPVHGuWKUSDgLVNpDTDgCJaAzuADvO0kQAM8PjYgz7gmu1m/CWy7gbb+pPjXWcdg+2JZQ1vmQZl/0+CIPq3zyE64mL28bT4BhBfCmQ+yyD7DumvWXUMeCXBkwFY6cXwI49inGqRscGsmRq3lVgOYSUWk2NdVnLrs3uBEH1yPUOYqgo8cJgM9BF+Ve0txD/IzxoBCipE/qgEglWB5T5oSjFsnYCZbyQxF6g9PvyMCruzFlfRTfSCT6BHIzdDKfihFINjof9Necm3kJLHntLwlX8Q1TbHFwMaxEI5RilR5jv9qyOgctpBo6cU9Hik2FpEhpo2E5Q0u9Mv0QSS836UXOLkeRhBI5Ysa9zy3GAiB79ym31bmV8TNQIPIB05C2uFWVFzMKQU1dunYi2SAG9isdx68rSV68jkG6C8mkypSljZBzSZwPhpSL7yd33wjN5ERnYUQ60A9N7DDrMhAuCRY4KpkFu1/OnQcwim+fm0jRGWMU5OSUb7FG2h49qNAF+bAEwdrlqxzbCBqwaFX/G05DRkFHMxlAD0fNe7qU43ZjbaW7htauoDgwI8MLLRCf0qKKR0+xZUDBerRPlnW0grrSA/7YKm2Nny4hg/Vww03WSjbjOBKURua3iBXcLEHCmhPMrraowfXyZnRIO21VrPBJdvv3FsTcJq8zfHnA6wfjV7oAzZ1GP9xIoivRvJ0nc7Y62M2BOgpZuftzlCDKQsz0vx6ng5CzPDFBvDVSUsWT69kggS2yth0ovRuHrYsAH0yMUiMWEkATV+aZcur1EjeOQYa6K5SNzaGSYvv0oilCcq3P80J80qg4dHXoJoY+vhpb8sZurA0ZK1rOgwBreAq4kBPat/KM9gFsHCmxoxa5Y8L+gmoRsVwGtOkVBdKWfeRUYpw/X6ttGG2apQ8ePWGu9mGt8u39awdbTjKO8dGDoprGscrSUk0w2mORiwgD2Cgnk7UkDvlZeyuIdGNechdz5lBUqJaM2XhAgpABy6bpVnbFev11jRCEwJyKxtn92ukH0nH43JYcNf44OniovBi5kn7I393szfcjB++uvjfgIkOT4eV9qYFHG48T5MVeO5PusD1mfiEPRiTi99yL3KP+nh0eXmnrt1fs0yZh4Qy6a1kfVkzZ3XkE00SfwJjEaTYJhSGh9G8plcC3HDE+O4JDNsYlHi90v0cmE/KG7vY41/5OeS1ux2gkBr2kYi5Td32T2YPk47PyMQtkNwPddXY+mK1zllw40tcB0djQBPNkwXv+b0fx1BPxWnIRmf64/nMjRRKU93wEZzVav+j71S+E5Vg2uWNwLi2PDsxJjKEuG/AC+Es1I1otuZbtaAIfK8g0FGo7rzRkQGqGYAcl+rFTRTuEBWixazFshY6jhG3+PyL300gV6ZdRQPK/0dkdk2Xz8meP+Fwomy6jyg4ef3igTCgyv4MBVFBIviS8PabuJaoPoheOcHXEQ9KGcLs1648dNS7WcUoaBnKWpPR3TWeIuqaJCQk1UsT7vTuT3ACeBTRE+mbHSkl50UznENrYPLRCCwtQfZDdyTRF3E5beL55pVEq0EqmhbIbs2T3AdfJhxE9OUHDcTVoRBiypjbSWn+kLpX7xvE70fHtP1Uy84f2jdXE01lMVej1vKILAuj+/5U2fXr/X4Vr76DBlpb6Jvc4LaBLmFVjZN+kiMgPXmpG53CTzTUaRepo1VY/O+FmiOOdR80OM2ACCuiWZbnlz3Zg9nD10ExJVDp4vEkmZub9WZPemHVnyimSS2kXBPuT+j+7kq7drqrAMQmFzoHBlknNabCMocSf3dCiyEvJoD1FUsqWxy7QNeCG6xE1cS6ZVWbwoCjypLbV3cBtGiz8AZDLCAz7Eqst57q0y6MrgDG6w2P5ifaAxEDL+QgrcTmCSmj1wP1m2R7gLVrhFgVO+uTi8sP0sDqWvCrTOhxW/CuXjAygD0Qd/GhzJvSF/21wY4hOIxdSUY6/Z6MjGakxlqNSwOzOOgghfZ7OWy/+1FZEOZOvvs3AmotJZDKLItpTEP69fPOw39B7Zn97vDJBh+gIHpCTOQzy08XHA1F/Vv99uOwnx5KE13LMpt2Y23K1mdLF7wZ2wXoYreGt6eMg7m3uVvUXxamUCLpvVz1W6xHcyEI3KE8M+n8qdr7OdeDQHYmxc2zWIb9h/Lo0ELMJDYWhedY+JS4GfkULer/6F9MR+DOGx83FUUxZ5PfivDhQgH+teDATnegKAx6ckvNkkcdsCWFtjBKemlJj5zDo64NjFKoZHdMJYHhdreekmXzbXPLKJ3h1ZUlft2xbw0XsU6xlPJ1JkfXIz9ufAb+ZvvrQv94lS+b6G0y5SPom4Iw9j0WSnIH9pxXsLDF55YP4nh5+9hY9uDlBF7Fq04M0j/xeJFHwD9ok9cyVK77vKsPt3NWHOqtP61yJEoZXM5oCOUG0hHtZx4B9Y7z1n0MX5SNXNOakavfMFE8JeGhRkTmSqWHebsbWPzAbYrudl/a0pdkRMqVcbMbdF6sj0TQX1INrwOfJfXdssakRMle2hUFPdSUIK1n16pVxO+L1pmyEDpooToxvVYw8ZPsQiMUvdOcWEQPIw1/O7Yj0UvNRSa3DjtAzLQ5DumwL9e+YWEGfUbY4zv1XOBGW2El88aquIuF37nj4HK0dnjHOIN5QXXo2GjizgNU+lI9L5q+GjfC1ToRVkh6OtJhSjUhsFLqmjlcroco43/poJMkkSxlB9cIDO1MXKFxMf5EaNsnjgBriA7sjzr+VdG2okhV8EcUQPB2ijwrvndq/67vuVTLB2185HYWHgtV9dQ8Mz+xriCfmo3pCS7EqjhnNLv4RZYWJvSuqCRfXT7IEGO/YzQC/G+pUqo75srXT6i3R0wN1F47x3kNc9cwBHV9wmn79pH1H/chn6brrY+SU5HM/m3Be8Cvs2rA7ac8Si8BkHZ9bCy0ccwNC1/wGi2qMjVOBa0/hWcNNAj5L8ZJCLr5Q3+kp6jXONMPDyJWTQdD3xfxE1oQ9mQNZybve/c+CQpfcnVhHaTN5EXUPObjUvA1PzZa7/yogy3sMH0FOMTOEYGq9hpGVDXNULMFFR4VMhBgsCH4DzlhGQbgxkkmtDPMTxOyVVXrZJA2C/XG+EMI60l+q0T0G7XTsxMM8c8Qzh7ggL29v+1v5C6aZM3FuWUOETXxJbD3Ur7F6V3m4CYoch+wcnBTxBpfGiJJtgUtIRjepqEjO6kZ73Tn9P5OXaTQBQkXjeNTNylMFnfVEp108POWENeDgegAFe3NKiIO4ucwkWeIlAyN/T3F6R3pGNDk7QzzNOYJGKdstINs6yQU6Nb2CDvNThoQhYFOG5fDWsdJ/5nWdLaeOh4LJlutdvH/SOnhsZQJl7LyYRmOwBMUSuPKoPs1yXMdXvfZagUyEppumGrjuqiC5giCn2WUaTIKLQU/zomrif1HwOwEN2J0jQv+3cndgcCZmFcImdQm30iH9fgYZz5J60iOuNIwg97deTyK4dpYeLjenit3UogP52hdDjNM9UqT+MyjqSSUKYxU51U4LgcWqWQ8kZ429x90HsxF857VwFTShi6EPx6Gvno1d022klg2f4NKWdQ0d7v7ECYdicF3wkcg+IelbYMvXwjeIDyB3SNk6ZInINMqkS3paAFIpAubDItkZYC27SqY7qU5g0ANBzIVSXEeTG8EYtjZkCiDSP0VbSfT+xcBPdp+13rQq+ENDszQzknI7UVcxzYY7KrHwksrJan4B0sxMxB65yHrL/i6V8nVu9wA5uF8lqFUCcAbZvEnLhqD1leVMOlh3yoX2cdEg/pIlYfvkpatYXQXbhT2ANA4H612AJ3QFsDPUHysOog75olZGJbjb7lv/8j18PTovLLmf/SBnWpinY1tClGg90SzQr/zC8I8m72rjcGI+ybbXvUkL/NhGdCOLiHmjrYLBA1WaM+rk0KO+xPP3XC525NHXPFAG7xGzqpkXrPuMVAwx4GT3WtM/tZFFaPlm66TrBsojUlbvDdSQWubQoOGdq2EQzMAiNCfTHPte2gBu/ylWNI2V1QrKDQD6SkufERE6pHZqYN7jr7OqZCGlbT7EoeuyQEMmWgeUyZhmLvzKNlnXrNv5SRJYFgML9DUfQELHnQ1g29gjWT+0oBwnUeK8Xmyk13KDUn3xa9U7JjgXSLqOchX6qI/Db25i4YTgp+ScF3NzK2vDRX2MuNXsBstYM6oVwmjyUexma5NtLqrbpVaQehLVc06l+Z+D6EcUux6qi76kfT0/gqEuhLP6bLMUhK7DCiWKVFqa6cCzqNcUPh0RWMfdapMzIrbOmIwQtrArESwT2eyc/qz8RPb+dkmSRvc2kIKOkQPVlBTKRxWX8MPnWOSdDDskmc1pBbfFTMaqrohj3HxlNtA6hObE5YxO0iZcWAw3v4CvrYidaKfbpScs6zt1F+2Px4iz6O8qX6zmUTRFM71vJW9ttw0MEx620vn6JHH4d+/ykSeuu9LkCmYg/yqQrVCXwLbdeQxDi6IqaMeDYRcJOPQ325bviE7L3XLdz3kP5eVzQtkrP5R9mezaH5l6lIsYXj2iF3JgvtPDk4ilGtbAFKLBP0Hz1FcCfNdlqU/9TzkDXDkOmi4eRjMFtqOSYfJUzG9aEuQ++FhCvVAGMTjw0y1HjUIzZt0cQnmymIl/2EFwG5amlhzGRMUEIN6ftbXzmV3jK1GuOUqM8gjbTj8H1YTPeBFONKJPzyN1LFuFXN1xIRhBUBTI4hqt90cj/BbDkE6YVZeqE+0qVd4/NdtezXoPiB0XngaiqI7QV7kUlTNqtAAvG3L/FoxEIoxtEdIfHzrtiY7utTDNpNgKyw7mfXh1T4cwpeqxQjF16do35WlzZXqniXPzt7dBSga7Cu/jwCrMv978Riqr0x+vkazmihrEUkmED4+L7qcYXri2+xNrLm9vJE9wpWZTIQ5RlbOa6/nIF/R0nEwHcWWNgcGAOeWv2HI+2G4z4DhIC89KhRT1W1+zClmfEfxOoBGTcZ3is9R+iKeCBtddFdwCPMLaDHF/dd76/qJURFYHlkL9OA1t3b4w3er61sfSKxHC8uEwwm9EVYu8ERP6SPbliZKaQCwGuW9WQvvbNpGPMiwMep/yvJUmeC2nAR2z3wMZTLKLfcC/ikVBosg4GFZ55hw4NVmCqeUq4E3VLEdRon92I7lIxnMgqV7f6XOHhw0qdwzW++4R+nJ2WM51hP+8cpvwMO3+GXRTo6955kfXfwxv384VOTjSAEGw+tu/SiTYgLpx/1ue2EgVr5MXYyGMNNAp51nPjl+EzIkO4X3scZGky43GCnvmfUfspPoMJtqpH1zKyCa6UpvcMCWB5GJVNUT897uzQ6cyUXJX8QCyC9TB6T0FMtlVNHSJ2V9JfLwjlYOGOo3YpZ3OuLgMpyOXbXr60uEIefj5q015Z5hn7F0oAAFCVpgtoUQPK8Y7yd4mXshr4BCpvNVdvfrXlx9pf8ZNUrsAEU3yvahndH6u5nQj1LVcjwKjcW8fkH+iNQg++Fr1n+HIO1v26yu1vGOCISjFbPfxA9gvftq1BvrbpSE7iMZOjD3HgbC9e18d2lERHmISsYHlU2vlX2zuhjOYoE/4CjilfDIE1yTPKbzS4RF2P2vItpKueij+6ZeEc6jyMq/8zTx+HYgVF6L96mUyr2FQRSq+44+uW00zpgLFBIJ7OTK3w2smhAtsgPeezIkqp3qGyjJ+XTDlvZBj3VKb81o5ENkCAMEoqxLFRxL9wgYsDePHerp/pjGSCJlVSyrwXcEZCUL7sdFUIBYQF1FNzkAyLUINhukHbZWRKmPLMNldtu9DkaAWDOMJbzTPpAOw1CWfcTkj6t+/jNfxhDbyyotj7XSQAbRaefaUeZ+wWyZ8PNN9mWByLOYBGbFc4VW0PhlR1+qyGsxUR91r/bT/D4j1o+W4phFKSz+ShxKybT2IRkdpuAwpCv3m6ECSe5wOCnfCxT2psbQdPwZyX1IFxxg1K8SdkZYJ3ufHnOdAA8H+d4P+8rDGvH90sEFghrpbOcEm+W1c3hs7jCuC9havjk8BkBPvByDH+f+J83WbK1vJFkm5w/6wky4CW5zj4r9k44/8ZTL8v83i9gE7CRwvVMi5j4SyNyqjpDMTGXa9BHzx4LCu1c6cp+zODfFAqKCsScH/xVu2Yt43RtY/xzQJ4R0pXYeyJyYbZCqDPwWD+yhgJ2L4nJyWM7o/GRu4V/hkuXNZeblf5V813/8H1+PrHgKIz0MAI01ksFnG+0kYgx/kgMBB4HkRU2cZFkOwrO70j/lXIwzSf2TPubxKVucX4/BQbTIePwVKei8Kr9yOlbT+uiihVolZZbMkmajLscEZfMSG0g+a/RKp5tCCwjK6RxB88lyEL5/rI2zUYwWFPg1J+OWfSoHaODWvGKuFmbryVyAG0Yy5dHW9YEvSIQORJGRr2NgAI1E1Y1NGDR2HYVcZZ4GAZ/KRIdLvWUQOZ1Lfq7En4YAbgLikD4+Q4a7NyMjfQHbGtKuJ4WwlolG+Zzc6WFsZbD047UfI4vcX0t5OYMus2LIxXCUdF/TsxN7JG9BytX2AEklRzSDxveEDh2KufnqXaBw80VskI6tFUzPjorL4ku51ifoYI2KXX7jMRJxYVo4AVHxG81HclK2X556qlQ8gshHiREd1uo348q1SkH/F/4zu5VltCKoZlFFs9vN6cR6p1AnU9ewffCap/MnKZUgT/TA03o99zBQeZYJJAAVDWSaivUU1XoCwJR+fpigYaMn4GDl+JCrLeVVxcQ2qY/LfM9hQzExBHj0WMk4jslHsM0i813Tt3b5PVf4c4EiiAVp9nXM8wNXu9FJXqePYBCKIgdRKTPQ7hhDGlg6OJDERmjiorl8/aA74bTlTj6fiw2XWZ9CovMN+odh9B1eQWH02JIckh99bjjjfmaMTlkcFfE+N5e4Zyk4yZOgKqI7jIu2tK8AJKeQ8WVfXCtX8P6IdBlsV2iVMZolRVJIvdo1b/pXWQGSrYaKmiimEAF0w5YzH/pfxe2Rc17PRfTVTHTCVeogj0ewhpPUBZBTHXUc8s1H3r4OWUWfHUweF0Z/x6CfBjilQydGB0RJ9A0R21DaXDGn4ObumjC6gVUkAPqTW5FlB856NdJXkEkHSj/N0v8zVBIlVN9KSiVltLuSERT9Ex6BrM65TmBZJpmezPlhQzWTyN308MArLwbxi2TAiMJKp8H2H1HTlKGHIlEjcoUzPpzyFIfHegEFVYZ2+ME5/VXZXPLzOYUAANS3oKzqmYwB44UWopdU4mdv3JoJlvNWBf8NH0K8ThDd3kdapW/a4Dqvr/Ahe65eypLfQgQwXtSelWMI/gWqNKpo31m3AqEbDA8B3YJwdf3U9+Oji+1MzpSRQVLpGoh1qc4xLc4o8tcW025S6tBYM5OJQ/h41/aj+9vYglO7ZskEwXjwHMS+Kr3rqOdXcLkT9C3YmhmMDnBU84r2sdm7iPmA2djUE/0/gXyHXH0SnGNWEJVKKSe/tNtV5zyKIoXNXAME+0YWh8lA2AUKH+EnvJEVyZzli4vLFBOJ+6u5QiE9NVvEboh/lQ8NzuiYNNlPlznuyesqxrBj3hsEqgJNLaCpoJ0FnZfGzHlPhQxunRuBm9vJhaKRI7BRL9jpnEIh1aSs442dY+PrQ5z0JlX/5PkTgSBGAH4fUJUHU5WXzCqH/bWf9W3KDv2vCcuDZKLCMe03R8WvGnDgs7NHlwVMXogZMdhXGICw7hospoTX8QBqcDKaFka8iKhd5+goS4ouDRQh1bkfbkrFUsMls+1OYCgbtPkx84sbkK6s64dPa4x8sKPg1hnl2Qonsv4NpD5ZO+0i2iTQQDCLB3R7zk27ylyEtoxpp+sLOxj6Noxa59wHF6MVSaDj41wy3gzIoDEv7kN5gXjfGFlXTfqr1eOPYGhC24ie7ocMBFYbMPwYwwKOqHEqm5nvRzV5WSUrQOmcnBR0gnId1RsIUYFIwS3aUIgJyD2qPqJCctQGBz6Jyh4JLrWULc9FOsPjg4gPi77PKKTxE+6QjfWbadD5IJxmywKorQzjrzVSAP2WZP2ekXhtsrCIk636zmsPEkrxFT9YFek5Cmg522LbcPPO+hrpIgR5CHCe/MgAAKCG5KTSqlQY4NJM81/vyqNjGzTb/zI35z/SPd7vrfqeZ69WnG0pTHnAOh80S25/j9SQetv8FrPf03n5Zvr3/3iyXjRBw8FVUT1jo+irQ3a//B2gjLJtWN4PmUk2gXu990n47ZkgH4pQTT0D+f5TZpexXdmrpFTYj+zRhBulnhw06K2OdvQeChcx7stst/m5B8x9ugn7Gp2ve/k81GgMN/q2IL26VXaGEgTHp9/WI5UqwIKr0TGYluVpoNPiaA8J75ViV5nk465br2X2BGZCJePzN/zrMCbdHbxb/M0ls7HfVLgwqPEKjsSJuGL/WLBl3MXmu+PB6kzA1iw3g6vAip78QxVft+Xuud/464JAeqLdVYfpSxaKZ47g7RD2x9WBbndVCFqW7qqshMAuQ35HNWeIsgm+wojap0y+jMCc/Nbn5i7drDCgCdwl1xz46YprrJAEEBOvYHQIOsspi2ZAKngGqbn0sA/am6y4S2SK7f2Liw7kC4byhpy1Ou5p0rdaE+Qhbk0LOvqaUUuvWroJZjpv7E897fW0zkg3XRqnujteqnpaVH7q1o2TqVB7s/Kjtn+N+RBT6uXxSatUNTFix9a1tGYfkwZH0xtuJSWMDdgqO7WPC73yl6/77fztowDNPyBK+ij2LNIOE7P7mcM97XsNXp0Uymw1GzRRQKJxQB2UOHZkx+mBmunBJg+VlmGP3zSQnPh/qmT6A6T3JGBFtL85EIrcwWeOUKkrbqLmjRD9oGJdKo5kKBFuZugTQJysOCPXKKSHz1ROTQA2atcZAkVXBqcCdo61nXSAWmwOhgYWJEgDKWklU0f4/6ptj6+EPsDmHEnQlUrwBynpxnqlPgwJCKj/9sK52cEsyp/YWbqlssJP3jGNpAhncZty7p2LJMrMWZ86ho5pRqO8/baeJKuGtW/+6Dya2KnvLXnABgqm8u4NIuU/USoGIa7DcEt/nafACyvLn8qs9KS4CSSCQmAPhFjrYQya5viDFX6mNFSZsTWcjTiqTmC0jOfeVMeHvPPzYWxcImIW+k3Sq0NVZMpHbTxCsTKXdD4dtXcDov6qMPEBQ0Lvjz9s/KKNzkL/EHxpnRi3gfKaW5Q1J094nwtxEeIs22BuBFEjg7d1i/JTC/IUlbbWPk8HpPgIjlZyPug6Adpqep65XntzSlKch4ADztWy5iXvnRBOMlpz8LFOjwd9al9pRf5Oxwzm26m9KCGtgC3iqLrUAv4PdN53mV47y/X28FYJYccLYJczDuMhvNRKOtwndYJMQsw/iWmtTbD+ZWd6S7caKPv6QidB+qxd2SBxUs+u+YZZRzIfH+EUZA84hEYQ39VHq5L5lQAv3ieZeO/LuVM0xq/aSzRqtgYYCgMw97KbR7QMyZLNRomkZWTPUcpPy4UAl+Oc57nMqvQPtDPxawKj57R0m+5WPkKrTfya8o2ZChEN0tit6hZ/bS3S7zYJXmh49IGvia5qBKJaCiwVHcH8Z/4x/Z0EotUOr1zzorIYCfmS0+MEbXjAhz/YrhasW4ylLOBKGyoMBBTMuFDDEzPZFNwRoitABzQxZ+HHu/8eRUizijaKEIurSkuQlQoYf+S+MY5opRVcgD1ABGx7aRjHL3uu3y2P+r1yejP35SkaGuYBLSEQpyE3RAxq9rcfzsDtBCwFrThoh0Vypzvg0ey77FtWxP4j5keZqqFJKM1w69waS2aXYHgdjoS8ozzJT/jHBc50M93ATiI9Of46pF5Msv/2ZtlKAYifPyiCa8vxeWM4crBfIwMjJb4czxUNi72kts2/Shq2fRCzhirKldixoSgOEJM4SxpV54jr6V5m536ymrwbdPEl5oQ+nRfGFxCWySeQtB0v8/yflBJnjIywHftbzwFyDqprx9k4ca5ppi9PEOzR6+TY0csAP9Vc/uqGeSdhhm8VRRXcbs33NcyJnAKTHojaZqbFTmyERA9UOmCAetQc5C3LDPRHJV9ypSkYtRFubMG/omy4Tidr26s4nRX5P4tYO65r1JKRGw6DP0OGUWdUxzVlqg/wlZSfzr/KAl2ZeRzXxA7InytQzJrtGvf8h8jspfe7m8sMzbp2iA6BaHdCY08enWU6LHibozMTHe+MiyLhtwHDPuQZO+Q9bUVCZ8B9SuK8SsSq6eiSgqRhqlRpFlxAQFhwDzO8unHKuqMEl+Vx3fwgrjZt/ZHlUh6X3COmTBOjM/s7Ll23sJDkjdJtxhAviLYh58FPNPHYZQ3jvJeCaR0XITIoBqq0ByPTMBO9scG6Z+xVuGoInv8FxODeiOSlmE0fUpiO6EOzQ+PF+59x2sq0k4ho/g0FsInurnW788LQKLK38dS0xiUo10pklJryJ3hMNzHvb2Bt2NziOi9SNMFOprtjgc0AQoxJiEiBlAnGrYJcL2+bYuEu8pexjCdgAc5hslfB24pBxCbwRpiS5zuFarOW/65FOSSDCiUz3Ct03Kv0/EzHvkcqPQF2YWA0/kJwJY9WcR5c46hfj7OU5ws6qYQ8dOpx9u9YuTdOXAEt5TWcJpmliFWLUIMSSid5kAF1O+wmeBXbd/SFSd4/btspciBE9DYaXj80MFDKIFADEzS3yhV7mVqqQgRJuO3MojTixaCJF7KaKZkwOnvUYusiOLJkFOASbORz1I0aAjeFeVBh4gpoUpMcr7YiLeys0kI35owJc2MyVgQq7X60pJQToxa0GmPFFhK9bEwlbAs7Nwszfo/eN4Ng8WXdCxkZZz89gB6tpH42WFkvSsosA/qwa4LcrjPf8cTTjXDPuc/MyNK3NcjyI3pHvZY2R4jBbOWfwnX/fcoJuwhEtwcQqZ799mq2bTLA/I8/vXACPH6J+f7+yAhp8LQQIwRPABhq5Zxa6+Ufj1cZfdqUzUS4GvjRC4JjRFmpZORtN66WfFeSkSampozDhpXnuifDQKfeZgrBCkWlyoGhxtHw3Xa4cid4tGE72s6E5WHmH5+t3NK6c5PIGhDhmCBZu4kgklTgLih/9nnEx7b9uiQYR2koW62/3XLjYjYoKJHiHGzq8AuAu4C7+7Nvy1FEWlvkYbWYTmrNlz8O2N/UT7vyxL62AVHw4dbswLpcuKvrv1aYjA4kchmpnXDSyAmP7JgHeReJBKFdMtGdBG+Tvnv18slGD+6aXtwSsgmiDGxhe/QNNSvyedbWnMlo2d8hxlzuXRSbbeC9NZlL1s7/6yHRwdEHUGURwsBx+97960D2ivPtob8+mMxVJRDXBRNRnFc8+nTR59sJZv2zIQq11UDbQrmsImDF648nmC6GZ5UY+bssRRwa0qEfkwEBqPh2TqS9/qc8cdVzC5r6k6vZkzW1RKV75t/CAFsx6BUoci1JzpOw9lGFO2fCibBRjMwNKVVp9Sonrlp7cJYAeRz98rbhgiutqSzcvKuV3pRwT7bHWL0UKGjUAnSWcD9EkfWpaHYYPf8XjfskH5lXntgey/VbG8W1q2zSq7Rh4dywIbjwVs1ha4pKxBFKEDI/yGHpSuYQHj5GwSmsSHZwLftCn4Upj/FCBiGG4CMQNrbloLwQ4NnMn4gapckqZuehN7tYHz2Oj2RVHYkDiVHdFJUJwT+KoqnqSOhuv6MHvOdQg+GOhYflDqmfytFb80HxtJO6U8ShF1OeyRfBcRr7e958poJjBwCx4ChKqS33ltijknficB8wMdcAECUwLTKbaRsoQ6WScDO8Qxs+/Wyrgz35aLkJpsGNSxrEpK9LpFBvulJbYnU1QGPcVzFxeYOZrtUQFMIXVtCb/EVjwS95OTCtxeGCxsioM8GpADkxMCJjgehXIiUvtPqcaBMgMZ25jMmSBpSAOk0ePKpuXod0SEGQMk57E+sMmbKA51VGTzYCVqdbKzvwR9P7qHVj7VIFxJNiBFtHTeX3w7xixN4xaraJkzdGXV0NZQUI0tp47jo3Zv1TwjKs9N6MZ6ff2kuFBKf/8/qJl4zZMTesprlHnK1ORRMMztpGe4RNQqjDP/VOYK7wZlStGoSTS952PzBjPuDjUy6nQtg7BBWTvX6H+6V7HcsiHmmwZMDJ4uCdb2/wwuBnAADA4rBNQ4QvRldo9p5sjSCXnOc6vkl4yp7ksI8ors9afmyABEQX/nrORhIYmqS+HYCADwgF3qdBrVlwMGCMtmaV7JiCUK1wTVXgLmobWQbeFselIOB0pYoFXul6JUymn8DbjWZrHn0axziGebzO0Ry65iqGwDBCz4TtqMpPC42OaouGJRWtgEthsDTcrU2al9iCufKJwzLOWXGvHHd6x99QQNtN4gVeun/KKXjJxbnYnkaAB9BjymkS8LGC0RLVD0RQJvNjQ1PlNNWr+vL16LUazBGhuKUMmjZ5mzrXoFLKt/le0Yvyol4146axOl7vNtXOu4wcu36LwFL+AQqoehTk9RZhwu774XZ66APVlKKsBxD0rUD0N9PJGQ5uCnV9VfeGR3g0nH5nZjaZf9AOfc0DYxoTIV3ZBcGw+/QSg3gi7Zt5oTvERbDlcgDD9UiFdm12D6zpz9pPBMAlSaTlG1XiajROa9tDi29rm/uVPlUqNaNYYuDK7mqS3iheq3es4soACJOn3dTIQKudZx2OwFgeicj6u3Ba4bgl9pmz6to9PNQ7TL8e5qFZAx0oEIC6y5E8NdZYA+55Vxq90Nu0kYN1fiO/7m2v+7WdBSvAakT1eF4W0kGNGiRKY+g07e+8U4CH9S88omeT5hF64q2UtltOGKfRn5mV/lGXDNmzflnvDuT1M3gp/yPCZNx+/sEivdiNT1ttdg12VBchc1YdgZ4PGCqXuJcMsJvBjENyMb9HhxSZOB9qawk7EScO4BBdZ7q69IKK6ntKAFR/uaif3mjFgTt+4LoZGFcOtKurlceYWzhq7KC2ucugKORoR37JE0mrQfXTknYOSIZaw2uBulusRRor36/pH/1z/vxS4vHbjDox2Hxhcx8p4GTAT7ikF+An0hamYkb1rjjMLJl0q+SueZVPQvyrJoBCU2HX90Hv2fwj7EWua9w0j7r24/t2gdLosmi4YfKAfpOebd1M2/VFYhOqtnQ2/Zufrc9FH+/xVU948r79Ia3a9Yx80WJI8+rCpD4+eOzv0zgPb55AF/V9ufNFEeti2sOe1TvkVU5fVqX/6BwXo9O6QEWKsn5Suv7FLCrJ45lUoYZiCedng4Ulu0tzpE/bQ5MXx5i1ABZYuNOTMGMo5Gr9aC8Kk/ymL5o49X5+uyjaCge6ATCTEaVDj3OPZ44vT5J7vJue/Tjl0HaX8388N/VKY724yw6rYkEbRgyhTYAMC27PCWyO/egL850E30waNfFeB/pInTM730lTP1QyzVCZTEz/OMvFR4CHMuDv01NDoO3haRWctxmuLZ0nP6kxK4WdUGaVuexvM7/9GFi/H9nxpTp8RZW39sO52gZcUjc5yQIBhogsMm+1Tx2FGnKgd5sb5VU6wrXBFtBXZTQiL2W8q+NTEVj7pXr5kxlEBNgbBIpUM8hLWNQyTvMVRmjNZscQ5e0KTLY3RFGTATUiT1p1BGXrc2HxopymkMg9kutWIwd7G84XFYKQxiVZVHzyVJRM+7xxClMEd3QST2ZWNHsZowtOU/+AG6PksJGTLghiWrTXWCvsCkpqcbK5aDQicVOUDD3/BXTjpfw+EoKY1kXfrpdgIw/yQXzBLEhLOPzoccKc8ioxhjJ4E98Qw6fP6z+knDwtaL6aPQYhznW0OAeiPYaHaPJgq676VbI3ngpw4DbjRkvgTG0DcPSo5UMS/TwOWtRBRYyVZSbkljaoyfXBdOTEApyfK3S5Go6R8KSCKa90pDCD2liUtC96rTLg6k9hvLqPNEXeIgtI01p3bNWxX1M0u2R4c7RlGHIg5yIZch8+eYgskqwgqtvstofUWckCvTdeJYcLR/I2u0K1QyXqvbxbeZTOUr9EHCHGmDkvfTsoSltg4tiA0n7gO5+aH7m3RH713oyOS1lzcBd2yW3GY4lCvkKozCYVxFgwYHMrbWvoesqcy5tf/zIdfZsIxH4mDSoYmexXNofQc8RWX3GIsEE8ubYYvV1wO5Ngs18aqRkER+Be+VClJ5D60lHXja2RGP2FZ0JszXZIGwOoeb0r0WdNXF2JFUCw1SeS/GvnWWAn/77Cyeoh0xPvXGn4ZTtigj6cQ5u9MaGxy/zZ1Tk4zZrq5bLfXywvpBS9tEu2iQ+EyrancUGmNm2q2pmrXkE7Gs4tYJwW085eDoZD4QTw/u4vPyWmWJEkmiSc8fUCB/EgEeDb8AqrqYQwcdgqBRbR+IRJ0YSVngK5daBwaqJSuYcFpO9Y0G1uzMNLRW4zq+zg0YPIYkJOhNmnZXfWZ7jrFzcbdd5TNuujKQZzvkmYGAXFOdYBTOKiXGGA4twl06AsQ8VyERN0f1tLEGIZ0B8TUj0sxEwawGwuutejV82urjdN2atGc0MLxWuVxYXSjY5UGa0Z0j/SOwaNCaixcV4fftYo9Q8AgdhER0IRuGHhu6wTa1GpyWUhjYU0CZhPSHe+ydM0CiLcxTp9lfrhJGlBojpH4B0yoyxfl7Wak0kk5cub54/+MdlTQUkG8XkGtxlrphVYN6QY9bDHzCp2U5zU/L+YStgnB8E7iqVxZWxTFbMmG6WzXRDn3zm4GRggiejLYCOQ7hiV/Q9XY7uJ6oMjU4VCt6fK6wj1cCL1QsuXluExar9euPkQsOvNQGlJEppCcCP0QiAudJjDfo959i3VrnUt2Njt7JrXLpUSzvXpPphMgsfiWMdCoZbCKOOtymuMoBQayeP9tRoRcwir9ECkFsCcUSv1SylwfVw7qeeGdDd1kTuDsJzD6F1V5bSZn1sU8KMV3BkTNGAd+pwJI2miTAkQxnqbTCkTZkhatuvtyMRFpS9J6RrIUnslLxI4B3cy506sLfmxp4YdZZxjB2zUj8BQIeVuqwuGSiCr/3elvCjXO/470GNFJil4VNxAKtrNaPXnWZj57Ud0oGbqE1kjn0D/tAqwpDCTEum68574f9RjJ4A7yu3YvWaprdB2i5kBC4tqk7M4bBUjr0D6V8hIbLdWjf+VN6HDmziBwyWqDEOSLnBZednTeCeQTTTyLfucQFiNNGMcEZII6iziQMoi5+vNEUNs0pnic6jbqAOA4hcj/7C2eGgmYbauuwgJT05Im7Ez3aRZDjrpLobyhb79ABP4L6LyrrLo7ZW/dUUN5HNQ9E9RdJR9ByiVl2cpDI0zLcCurtdSLC4cOf3Fxn1TZ/+eIN95jJzMIeKsewy5Nd+1oHUsUlCHrKY8ucs9pK0Y9NSei8CMuGntnqj74uKrVVlrlrHwQ0q668JClVxlVf1qUg6erzQy7v4IphTHe/eUEhM22e07yS3/BxGLkwzzYEPSeBw3nv82E2k4mCx2tBDXDUG2AKVVpmRNMyBZuG6vQbntCMWZxvg/NEQj+T0ZOXlf+B3Kd7WEdR2XTFu52pta0GjY6lGnxvcR4rSvovCoBvBdY2XwMiktA7g6JgZGxlOis6oH/hZ3rotYAYPqh4mzdWocX0FZoOh7OJ7WqJOQQgG12eZTB5GnCUsg3DGuGn8BKX/2tbETQwOLvXLfwIS7J97K62ijsZ7NZJoNDKfU6Kf5o9jmy0b7PVbYFwQ8NDqH0MypgACx9EM7vr9/5xwGqq6DypjqyKYa+/NF0W4ufHBUA0w/itt9E4hkpt/Na5qx7F3ahub5hroXrxiQBHxhP8i3jCxQWXdQe98p7HyUIyjE1M6bpVV22KJu/cd5F1buOyysF+LWDrhrjpIxLxFxYRJ6TDEke7MjGlqrfScD9eam6PTJR5QB6CN8XKIy8H7nxf/OpzwvqVQVswanmHFQFT4wlVQNkW9yEQAkDNP8zd/8yy4HKbEOB9yby7s0YQLZ8uKdbFhfgSA9HGm746kh7SqJJMX9ll4lRWb3QvLfZyNS47cao5S/N5DnLOafFZxS+pl0f87Cm1RtFjcwWpMm3fmN35fXpDohJQu4Rc6NFIUsYPiopHfZvTbX9Z/96PmwLnWpcHDvhFeqWGZSTzDqMsiKqbxWuYyV9uJftplkb1D0+XA+NJ1hkNVz1wDd1gveqr8hz7DhfN8ELVbiAAjvmlaSQW+MDk9gdSPs1gfV0VSxuIkzpIaOzewkDRePt+akftCzPL+U7J2ZjIbfE4MrjN2E7OoynkpD/kGrx8ln5CwcFXd9BPiv7vn3fnQIn0VTQRj1gl+GzUB1frgP+wJVGK4XbpNUWPn7taGdgBKUFAHElGoiHslxhb0H5GjhZ6Wq+FyVBgpBGzUhbrSRk7Na2J9IPNhePaGZSbyOxkw0fL11Oir4fRJBpXDeC+S2Tvyz8A7hTHz0ugVRTk2F5x+IX4Unubx3qNAcOpSDIqfssQ+oSkpctwFtWVnl3BTAPtB6fA8MWEstsFEGntyu24ERmE3+HkODr3lPxxRGKPa+5V8UiwooFy0S7R0WD8yyUbUzBzYedkP9qfLNI18LdERKSBhacAqaeSEpCyR24Geq10u3bNL5CM/Kcki5x5+fkFQIA57X/n9cJAGyPWU59kGfsn9j0vWsC7xB+0aOQWbfNL1dbLxcVhj9JkXmC3b0psvdnllVQluV4zpH0h6eDdZAYcJewT/20ECj6q5Umt5Ia96g9s4sI+rkuNEG2gijep/KNhzbNar+cHN/V9yBAg4HQOtMV+egIBUfqV0j1mLcgTLyadygWvACjbjTosLZT4KZLDEGzew9xXyP5GMqYIxz+EFbzuW1M4y1Udh/XF0a2kaKvDWWgMzw5CEQhhqEoBv9h94j+l8KJerK+OAzIuH92usMBjYVuJm2FHRVTlHVS3wb28L85HjSBAl7vIabrvt7R1IhkKvvA6nio/br0QuSKWk9ioDpzF2oA0xOtjRcWakqixqHxxhxe6ssSLn8XczMiw01CLtz26/ZdgdvRVyilaeTWv9gTTLxby5GQntgjtPV4TE0ZK2TMDz1eTMrhYFUq6LQpfdJQ/SYvyim0+DbaL6kcTNXBfhUVg+GG9gVtzmDANaQHWgXDsBUDAiCeBDXmhiqd+o9RXRLFNFxkStupzPBOgDfZpwwn9/q/AKoL80U+pK5WCTS2L7gjAbJq7hSzMuOKLr7nKlkich8AbrCGYLOmBvaFDXYA5y7W6kg4fH7w7McQ5ZInWo9cnjektHxfqqVMQBVEdOs+VCifO27wc+bMADm1xQ89S/cngjCjg+DsXb8PAZ31ectp1rFNimVc3nFjq6QUhtvAxF/k/P466XgYm3Tu9mPYnMbRSi1HnzMgCZwohsLIsl7k0m+MVq+WG0AVNu4i7lBEoCPmyyb8pPIRqi9cYBSIgLFcpk+9Gb0FWMiI8YXqIj8CDFT8wLZuSRTqHqH9amSXZNayP3VmEIORTncPxbtqmZsCk/0qT7+XUStfq0YaXjuDQXWxaRWVdswUfotLZTE+ivYOj7NFQKDPKXE3GI26O6eIXHPLXuWYkEXqaBr9Z7Km0htz3H8yPP7wR6ShPXhfStYicBfY+59x+ZaBR6JgBBV6VE3Rnks42xDJB4KpAkdBh1IqOVSottf96S0gMJ0zLYRZKm0xGmIOaOdqAeBJ27trP1Uf3CmNJU+vtWCtcMpE2zCZ15o9cVG3o1f1LZBWNHt4so5FezgMWfHYaY3CSfgIx3XnGGu9FbbiioPdPG5OBpffteXXBq5Ok8PxCpxSjvJSIxGidYDL4uAkFyGl05qlYuf/56vOoDKLyPgauk/jjfNM9CRB5MpCAHXnbD7FHk8gRfiq34E8cckMc+1VuA3iJI5EHwqe+M+R5Ngs3zTGlpkpU8ABYjRazAGpQ+7mP3QzO/MpA9S36clpCnP50r5zCsf8TlCILLsW7dYIlgS9tkVmGe0Fi9EF7yY2IqPpk+u6gVCdtZAooVpTtxeUgia3//0MXuRuAUr+NcOkXvlY3xau5OlqMJ/c4yxAikSh4w9HEch0ldDc+Usx6wS4z+JTLoMQ+1J7Z+xyaQN9nEtvm/+3doIjyd7tBB80KgHAgkUi1JOxAjNbk8MVIeMOSFEjxEUwAv9fYe4IQ5mVp29SN+LZE9OOjWbM1uoLbitZQ3pLsZK+4cmvEjS9G4oB4C9y+ryUEVgJKzjgKMQjA+bxxO71OBn/o/GLnYh/9QgxsMzBoy70JYU9HVOulwolghKDXyqt08wtLAlwx9IPxMVfOlT00wDOb7s9nDP4UiUFP+BcCtDah3g24IBqksfU2ls6JTjKmOxDYDKugTNtPqkH12dlwy2q2/zkNIk+UfONNH+FztUuKAgFj7soOO2XEXSexVjtNeAvE0Fgq0yT9lZJTmuD1nynMtU04VsnsfTaVRgBahYzZlM9mccwi5vUGGxQRgMmn0UVvMvfL+E8sVEAT7201/KRjRgxsuAiCGZxAOmJm9RgVPEsRJYGW7j+l9A4+v2c7TgGCeUwg77chfPabEvzbqTcer1l/TQBy046sXZ16gov3AC8GTe/C+MlA7q3nAtSUryTXvDixKFqaQFNRWUKRsJjjfvhJsklNarZCodn2/3wqt17Jk6ED1S2M8y2mtPssNtRuziQJAlFMAX9th2zy8YNCY8/Diu3Gtmo/EtnlZwKZ/8hVVHWC7v+rqIdFjehd9Co4FHmLPG7YCwpNLqAWQLwXCrAGv/hnVSMZrGSwjPZYBWbn+GlUrA+fvBVXiBFoyFcOHfpAp92mdFN+SELGTNXvCqOgFQd75wgS3c+rj2tzglycbrppQqb5GBMgmWUBNn4sRr3Mc2ns33+4556Q4dtXhzr8asOUHIZQpgcfG75Dfu/rAQYh4W4nuqwXX9eLWdldjQQvC4s32wIVQG/AMiWYNq8DhheNLpV3b3Kf2C0Av8ii+K7UWx2860AzEpHqsEzFCvAoMwmXrwd9NbY58lJ+8ga4S+H8E+5PhU12dyq5n1rmRjBIBVTLDdZDMLnu5vHN7yaWeWzw/z7klxuRnn1NGGxzD6wLXW7ul814MZZdNLY7qVpm025BZikgadYpPZwZYDAhw2f/lDDw0YAzP6OixfzYLukwNhmp0Q62Q1HmX6vgM1wlfdRW77QZ6JUk0TQFumoaz4wOsIZyxYUTKLQLNzp6iGrPfHJ9az3O5JtIzZKszmseE/DhraqRsHjBytRTLr3J6hiF/1k5XBOcm4443hRmes7SDGlaQOTOF/Xu/xxBLh81njqYOgGol3trZrT/h8Tump8OHt+PColvikqsu2QJkAVcD91dullKfZUZJV6U3HS2vrPKAv3QjTQrQrequsRi/jIxV6V9WFEdeUh8aLCOjTf/JXsg9HabPw0U9TOhETLEhKibBD5b4EjnOAUxkMF/rGe3YqS+sB7AsKXMyFMxjjbjDu3bxgC4V9T6QZ7MvpyPoHNc+4sEGqu/x8JtBvPdXePeM9ywFbjCZxjCX2Vv35rj/Gus8G3hObAaVWDOsNft9k8HlQwMSyg+oI4FAx+KHVv4yC06IB5x0WvGR91GYymN3NKFQroqytnu4ULtpgfdVuNt3QBjcEikkiSy55J/PziNCS02HTALFo9nHY+N38WfkdoyNDAAXMtdtf1K8otOrL+oitn0M4t52/6euHUy6KOMjMteNn/EC6p2P8f/oRmstrtnh1ruVKBgQK3rfctZY8QBTzj+z/EjUzpDIPRFsKPykcoKz3DXfJ+SQQpqUeSn7ZG/QViiOoQCTI1/Gqs3mKAAM2uFVpqqxPPm1IhyGZJe+YcWJI4YqxMW/caz1vnhwV/UvVwxcHdgPIrdUU7UYQDa8te4wt3obXTdp5P8PiDRTVsgEpCnM/3mRzeJPlBGzhyKX92kagpkWCjqj1r/60PUDCWXNcYi9a7hYf4flGpU02yNEvvpKm/wfhwJuIOCZhtOASHa3f9PE2sWBDe9afCglRQAW6drszaHj8l/0Nl1byUl6aHLRBssjHNVb0icNSX/z02Kesp8Y19L7exZWW7wqtseIlssht7Y6L0HAorLlLHBM5WjZ2kvNLOB28uGST97HrYywGcJxDpoVpQC/2bA2f/yvtzL57xA3X+KfoEl9rZqd4KRNorToTRvIj9N3TrPG2ZIClvs58WAzg2wuex9E7MuuMo3N9AS2UcNOw8qDhQu5gC1dsmt0aPg4vkG52HRX/n70X40KMO/ayyTFEPUS+EUqBfJyDvDxOqr8T64EcEGAf0tQ5LEhQ5g/Cy7RJY/N734iA6G9Bx+d2/3Yk67KlpLhI6stWykGuguxFN+0ef3nUvO7b1/MPKFQhN3TMB/CA6JzEt30HP61Y3ibaREojxpVXXeD8jYJweAVkiXKf7sithrfQReI8KC2CesvcDZ7lvzZF6wYM6v3mWp4dkLhghzAuH787GRmfMxh8/cYu0V9Wx0DFGPMMOH3RNOw0T0H3oKbD3MXfzOL5ZL9EUcT61YEm50ywTXsTgN5PtcqKMgTgq6byRaZkns1Tn/ytQymQOH0gWDieGul7P2hZyRX0+iYNVCh/7cBf5kS8hFnFuRM0nYaajA5+j5rTMTwXDe7DFEcnxcxZpASQIt5T45fYXfWytRocmRpD4W44Qz8ReyvXU8y1++t8PWwkMibzlPtx0VxGBCkv6oJbILz2gBy7alg/9kwXXVlNDQoFkpQIvBhQe1/y6WY7AN9bZ4uydjBeex6ky0Ar9f24vE9BhafwS6Vibto/bzEocVjlFxW6TxyisaacnEuZbMKWsewi2P7ZEM4rPNp8BfCm38Dw70kO3BEfGoj9jmI6OqV+XQPgj6g4xsoNOj24SzEB0Wk52m7oohsIl2ydW6yXiPTEp0zHiN5+YSdSDKZOZ4kguGhHbzk426k3tjHbtZNqyVa1/RpfJKfpkBiOwogER06BK25wAyfpRkX6PPpNqMtXXgHDY21crSCXpF4eJWdDkzW4jO7WguLbyn4otUrlCc++ybVhiNbVZn0EV/4aHvzsGWnPE+vm3283q3QdkpYCLpwtm/Thx30x/C+DPMpu08D4cRZnEvrgEh6LQ27d+chXYFHxtp00/Qpu2tsnFZiM+XqmsaFHfw/gXCRCb36OTK9htS7T9eW+bo5S99/fKnKLgSMOnlFG/yDQ3rr8w4QhnWtevhj4n1tZRT7tOmBWxel3YMp7TFdgHy5ZwMmEoD1VA8X5Hx+z0jDdiWQzgYoOp0Lcb2ryg02RTsNNyv3N2nz5Gw0ESwYbhuxZKqj2cbLTHoO9gvSKydVUnhp01IvFBgqxM9qJO5ND/fMuD6AU1d/TUDKRz4VUUVdbvFSH6H0quWqRwJbbhBPsGNigvVPeQU7C/G6kv0UCZ9PTMoWrCWd65y9iCg9QsJ1ImTb2L8POWQ1RY/U+Bt6njAv1Ca1KNRunxXd7eCSwzP4yk0wmLsZZ8T2I0f1YPcdCQxGGerNNsNcywofz2VSTC6qObaTSoGYgRZD+zUUBtw5nf95IWf/9PcYYrb4OxrHnn+iHg9BhT18xVhQDKuzVYbk0qS0nZvmhzeh9UyqIexVDOXSo5b7FTjgLbuaV1UgK5V+AwnbpN9HscjsvkPRne6oZBKhQbnubd/s7bZBkU5bPZwt3Easrgvk0bobfWEo4eCsXp+JtwbJt8Oc12KHnsiUVMbZKMA4u50MPsjwk3AFEYq9CUBDrNJp3Qd13LeTo+j1gIUTLurox+wkIg9ZZ6u3Qn8Odp1EVrT+Cf/GFH4mFnIZAWAwIhpdEKO+Q/r5OM5axpgWm9DkR9YN7HbMOajYjCB9qrpO/tiFS4+6VsqP+GqGzoiGNXnjFRY398QiU7Q2+7utIrFjLNvvGxIFiCA3R1WHEw7vgWmy1PRotkNkG328JIiH8HJPuIxIOttv346+zfS1kywDixKQaUMojhGi8m2Mej+usuN7Gu1x+iZLEVV4VQwBnycGqG+jIVA9op4WCqLEq7TPZonER5alYW1Pj+LlhirbVuvCpLj9yrr6oQuMw/0G60sG5acrBSoqPU5n2cmOYY4hjjNsbNspT5afRMHPY0RCtMAMW/CYjSl+faj/v/kMdRGAh6S2mSpH1/+xrk6EvkECkkEHvLp/J2VRVZGPWjgE65GPrfjmPfyr+osUx07FJqW7F+b/HQMGLILGvQuRKM9rhvZf5KgxN4mTngL5dN/+ePdwb4yBmc9wS144dIdhhvzJFHZ3EyoP24jykj0olK1+hftLFXrPjAnBFfncEwYG0PGsUBi7KgfXdau1qij1EKVhA5lTMc9fZLLWZR1NdSbooo+l7c2Fw/EwCzppCxPCtRp98TONSI8o/0g2TD7Ftw14Gilx1NvSAJ2Lv3JUWq8p+2G/ALF8YLiWtuulevPtYlMMRo6vXYa1QixmE7+mT/TfqHwhwOiEUrpmG46qLlNtjpwTWKaGoZTpG91uMROVk8ttKDrjdSHJ8CdG7Y6+yfLbkfu8A8CrLdMaadLnKmEtc6orxJ8q2YKiDpt2nNcFkIdCiFZuSWIUOJCDQSa38417iN/y/XCH6qYll9DpBEEgKAzHsG3sSnEzAczn5ZmEnh2AOyjydU8YXs5s+tPLxsV93gjuo/8H4iGIWwcHMrrEDhqvK9aY9LOmxKltKKTsx48lMCRzLNIMfR9lCPWrtfdGLo6QOmJpDCH97LsdaPa1qJlUcRsxn0yzKQ/jAOgl4QnnlRb2EIjkK62vV7MRuGsu9NvbhD9Ausbt1TBJn1ziHbs8QTo15KY8SUG7fhrsfU0EiHH2WviawTceMQhSkVbOUHIhA360kRFJx6YD3/Nbc9UhE8H+GrHNAh1ZAIcq9r2pB27Hll+8vRMbYlAVaLkaHWb+QOc2LdMyO+4wWy5PLcw7ikdCkanXvF3XVM3Qjl5oM9Pvfb/iqLTzpfvzMtBUegCBj7LaVLB4kJkP29pYEQ9kNW/TIAoz5dhVtyyyXtp1eOkSyUFOO1QTPxBS/Z7iNlPz3av7CfnfvU513qTVqjN/ZGmCbHggRAXZ4lJXPIPhZrMEJwvYh/FhtN6hHYV6pF/1nr8CIK09rNh/9U6U6DuR8skfuHzFkKEagqHhJXtUCaCz6okMJSrabJ22B8KLMKdeXWT15iPAWe6cOse2BJOqzBX+R0JKwF5FecyfMyQ5M4WStJekeZdOVY1/lZGzoORR4m3Tnl19viPOL1osY8yYIllX/Mynffa5zeycXFkT5ptVfZzPWIpxwVH9S9TKVXbLSxt7662VwYQketpzWpP4myP88sKiW9dQ0A9KQN0yCKef0soTzVFkF4JsUKvZr5/BUCH4yLG8uPiN8MIEsCScV1GBoXjG0LfTVVlrE8SugD7xlwvC7Ga2s+EiaLTqYhl9UiwRRS44aLfIj91PW180+QcCqonKGny6SdrFk0O18NYzy4pVW+tYEteF3jRP5ov8MjYQePHUhWVi/UgIJpwQEhE96rOzKHNGpOgPWRR9Mcwutw32zGSmI1yQVLulvoGwnzcqFI+g+5/6TQ6715sugg3xDrRMuJSuygylX/N5kNXMnvdSfQkxrVPJz4zMeuPEGnb4FOf2TbOdCPeYuoucIVkgl1vv7merFzcqZ8gUF6vyB6chdoP3nDBMT7HM9U1fO0t9vXoVLv6r7/TFxpTp5MA+qZt04B2Y9wl1tpghHgcHCWIhXz1oIoGFjCFqx+EJmNcRFRg9uk7ITVMWtG5g3wa0E++nXpRelwdxIrLvuiPh4W1V8P7dg8sHqsI51Ku5gj6JYsGErV8NcV79uEtHvbmZFiWpYIBJgTnmnqLsYaM7eSLGibNQvvD2coK9zNTtJ6CxbDYWt2j+XiaTZWxdDLe7mPJ8ApJPDtSQpq2MMd8zUQdbm2XGLTdf4OBY0GzwhvVHBJsvwGSzIcZXvzGY5jkmh8puJogYs2zbye9N5We10ZGiK2HHmHWiB+a/GAxGe5DOqCMDD03qQ09JxHP+Jrdzi3EJcTFQFTAl+kgslb4g/lITX4oN94ROktY2bhTAg7WswYuymtkqRp1BvetSWhKdFRJqFFMB+A8QYKPc+w7ZvsRYo41YyTspHp+KAm3rAXkLae7ub8j6tWFPCPczJd8eVDXYQg57UE9LGHjJlI/Lj2vwUatWH9NO6X7JOTZJiFdrUFWtKkm8nvdxmoXiXaNuDqEw/fWJebt2diqp8Q4SmHdbg8s05AQv8BtWj1vBy+tzJYD7FZQ3yHMNzLFC4MezStlcqvMNc3cKifT0+QBWRhmK0FtGEs+3UNSJ73pJq0kL9IuJOiYe4HdWQsCYaE+Thkgmmb33B9hLVk/bP+nMjgHgbINeFRUFz27Js4Bk6nX3ahrwKW6gi5GgJ0Wc4PIk9+kf3sxfp6+nBR7jYalMiLkyZ8aA6UsQ0DPfT6a2SP7TxqLsAL3ZaYmuOJWDOGBjKtKuq1nkRialYvcsbuFxBXDiQyx5RwMrU6podw4a4+kr1F61lKepDQ2419dEtm8SNBamJz40RQuaJuvyQDA+nwAriS3FQgDNkUr34KxtKRsttDmXjACjpSQvMPx5zwGKykPs/KmY/dQsAH7dyKgLQNAI67f9jnoIQO2A6E2V+FDPcty7GgHj9FZlJoQOoY6SZELfpGpdDtKt0xXSAyw2yP6ZZTM9O0KMCYYp1/FpgJNJwH1+TkSIjdhieqxO5GpmcHqyf75o9AImQq7eSTqUOZtEnqAzNu5PsEg6AFvjeOKQwUvjFgYSJB1w5mX2RmSoCamiOh3oiCRYoXoIdXt1yMtbcOHXioph4bKJDdZ5H/1+h0Hjhnpf1NNMTmP6mRapXAx4k2Lq9P/fH1xw7M7L//pi8HoFPeZrz58V1g/MyipzTcCDPSoNqOS2epY/nV3171u++U6uuucF+F8Re0V2MSot6wUlkaZDxl4R+m7yPxY1AeZrB+o4FYWLxvqscMsKrDnBWZCFisphCRLLCz8J4vaxyL/K+CeWgiS4Szy/LFA/sLNZx1odFBJOTTyiwYGu1jiGGyhM8Yhgc/4buCUVQ9I2N9hHC+cKo/ijuX/dTREYOeKIUYCKoKNdwGkhfEmhLS+JFXKsjIR/TYNUe0yz/JJw2N5zsZwKqepIAS8JrLnzD3sHK0oMVTOAndBDxfelYkX1tjUG0s8AvLFQk9rgOoHQReb1aFIM0d5R5ab8+KJAss1XMLtt4Iegr/4k0Qbp6nHIXfoB4Xa+Xfnub6Fbxoyt5RxWqdpwai11tmNnulHUSp7M/nWm4qmVOk/AVcPZE7BVlzdm4Ov7gUa1Vrqk25MP6Khd2NXh3Oqc6K4jrBDsae70bDWb/MV1A8xfsHuv0gD/o/U5PR1V+T55QywPI99UXY2mDsugkpfbTGSuJGFyZsJJ0gK346DvQxTiKrFgdOHPD7jBFs8Q/WJ1qOA9gMsJPGIrkMnGmQdkbT6iv9a/Lg2sPC4A3t0msOBKZbH4YeSChXkwb0zktZcvN1E4cvmpKlg4uEetR/cEZJquau1OKnVaZ+BwXQeOFOiO8iOVLMyB5I5Sx3Y3tR6KZVmgfpsLjIXCZRhOIJAENW3x0TS1Qf2wwoc7OR/cNg+BHC6H+1cR4aiZBO+TstwPjGoyN1PNDnbdVYtXU1pcO0uT6a+u9tunIP48pKCLARALjC04TQXrLRmIbYwoYoUl/u2mY8lXeZdFh+iJTapff4I36TtWK50Jzp217gv0lj24JSKgTPMwUBRe8aH/eVaPlcwg7zB+5oKTD9il4KPzh5KGilcGXlSTkVjvxgTYYlw1NpTO4HRSRZFvTsP7r0scFrAV2FuM0XhdDRKce+anMzlGiNvjHRTeBv0KypMhpXh/7Ru5z2HT1WS15XUjEwKW8rnBOHNVO8IJBzvqJUnly3aChNUzaePdvrahU94wAxfbWzEVolE4bdQhQdDSTRl54Z3kbrueJBEdXWEaXSSz10Kzt3YYKgLFolD3KyD2btCISFnbRtzuwit27R2cJZd4ORYM+d63CVc6VS7tut/CPgUZj2RRLOLZZTAlw1jJ8kz5dG4MJOA+veuDvcxo7o0VccbqPi3zFiVfkCWRhvoydXuyoySRIesmvWrAzAVTnDCodYLZcKCLEVBB4Xo5bbQ4W6BZx20Noxl2MTI3gbXH9644VLAZgEb/aSDTIN9HMb13tye3sYR2HsS2qbLglnXJKWTEmZrjJOOe1b+hZqESCRv3GayaD5iRpLVwnIt2UobcPdMzKlj8YymMHilhPcNn3PiK04Sc4KwCWpplkrN83u7bM2URNm9kdlSbj5gnL6VbVhW4rYVodjMuDcv+8XhfXCvMFh1d9aPJPs87AMvRq82WdOcMCxo1IbC4v4AVxgsgDviPXwO6yxODXah6c18wTVrym1tyatDVK+/PxVOeq6Y6bfUX2Ah/cdfqfM5d1zxkaxbhAhYAvFVF/a06Xf75IF953r5eTvFf5v+0nuSQKtDPHmrExhKRXAlwL4+DATiTbr6+Rt1Dcz8ciLczUCWUJ0R13yU6Kfkqal+eeS8+a1XYWWhvH288NcmMraTaDW50ZO3obOrxwpr4uCY02Xwga1EViO2KcSqvQxealorZyL5bs8D6JcxqQUYK/BF4TjVYSwPOx+qm+fVqmlY8lTTcrz5mgMlVDSxvNgtnYbTLZ4pNrsrtQu8DljLfZxT3X8B60uI3buqx76FBUoz8teJ5mvguontbdTOXTsXo78kxyPIExgNP94q+jIShCO0qzyAX6izQQRfv+PKejy1Qeah5VeEt3nEhG8Bl04yUnaL0Mjgd+z2HTW97FimTGwekf80WDUHclC3kWMUtNC89xo6ZHOqCUVhMi+CX9T7RPPfTGTFt3WtfcfdoNSuSpLBH4qW5zU7xWaeGz2REJjIX0yH9Ipo8VYXiOEt5WPtod0tt1w8jeQ2/tL/iKycwKpZ/4Jb6e1N9TV9GHTIx9qSJ2P1DhDZK5sQMPOSIzT54F2Js075e8PS2tOpeLlUrls2CKBrW6kP5bnXuiJhKQi2hHEeddfVQ7Zuv7DztdRiSDUnnPOkd8MSzn5Il4uUkYOjyibwG/QAsm3bxVjxtitLqt0DLv1yPPfHvWO+z6nlY9+0lMkhVpOXAgyADHBgMsi0tdQ2H5w6YdzZyQPfJ6Axa1AQbtD8b42nEP6HMxVvwY7Q79HBkV6dOm/CF3mhdAhczKCrwHYQFhGHVtUTSWrfMXWDbQpreeHFMIO/081CBD25YydhHgRkY2u1kLvdrHAe1cma27ZYECw4ZeAO3wv3uQ+X3TZjdsu4mlSErZgTCK0CvUhjacZyw6O1gGqhsG0DK9u6mIMGG3AqKrk0SmOXDqI7mMWaeKCx60QYgr2yJnd8on+6r3e+v5aflhzmWKEuyHZIZcY0aZg6ZbbO8T8rZZAleQoPG/JJXGzL9SfTKQ1Tiz4OIx4ohDxshl0SMWVxg+4Itv49+k21vVx2iDXDMT3GnJ3fgWvGCe8jrPOIRasYHRo27ReuL48P7xmekls5ZpVCq85PNaEBM+gnPwSBLBQSvfIQzuw8M8VHtY8TE8ZBJBXKw+iyySJabkXvRXa46cjAK3UEudl693+Cq820A8//SogU0SHMUEPJx/1cyo1AmjudYTomnSCLmceo1PR0vkDb5cfcIZ2Lg+m2ji/h8jnpiK5dN14AluYSHwzvdvsa1mhmCdYH5uz/OM7nZRc+XNGw14lBjUP6Ti2IuX1KBNcgVKGVaPUCKnhsPe7IQ4gQSqRCIFh9/BauRTErel3Ze4s5OjZx4T6xHqpyDwfr1n05i13NC2iPwEN2X9lQYYIS+nBFk95hdBYVARGxj7uM8HYryycRCc635ip9E0hkrbwMvN60YlMzEs2t2tiRZOpRhJVXAcF1wZZQmOZuoMDJ3+jUbkzuvkKYVWam/p6Zp2RPzc9iYrTHpJVK1xL9P5DVG5OzRmTbgRHsRrJOoUwzbjwPy0Mju6M483bVmcEzgdFxP+Yyj6hE96XFZR037dMBlCdmuQaGPKssqZ0outmhhTFSZW+TzE+AmdIlIBi0T10zMUzylI9GZlpAm7+5OdHUpEJsrKpar6kvvifUxGlVq9ir/YVPlVPIbjAQkCG74Ub8atKcUUf/kwXr7qn6onH9H7l6sATi27wL8iltcPJI2lsFg7T7rJ8RfW+U/2JqLPNVuX2BKgXQAE8kTd5Ts9/19yPm7syQqHy4zPc4AKbc5+ZkyJwS9tj1fsDSkwaGm92E7nOaakEt7B4Qk7aypZNE2dXDkM8quxKS26GVMNu+p/5LjBqEEb1oBqBg085r6h6rVB9YJzgLFjSqJZgY60k8qRPButjLMc0pIutQtS9JNFPXNSI61UPnD6A8c1J9Y+SralbgdlD81+I9OH9dmTrXCXk/4CyvpSIDjJsU2JNwjmDIlgp7A0oKxP9dGcwj+f3tXzfZpUUM3N+zyIMwopHxHCzIMRM1M7qC4KW07F+vOAoFEavq8PQC1rgUJuOq/vOHwBN0ay0Rzdx63mKif/vYqPScLlfnCgDbeNWeyW7P2BuQMjDVt0LIDCo3p2d+/oekANl6LSkKczlXzDnjOnl50gr+WWetWqvCpoZhmkjSREYUDn9cyfDxUo7qEhLm9lAuKpOB9iNi9HHsawHgzIFpARzQPllQNiqx2F63ozaQDNHfwPsu1jHxqA5QZ730UEOqbwMhYBQjLvq6ewIAp8jStudfjq2H86EExSR3xXT/CjYVH9OE9yZ2LSY+OVpPjMNKuGF0XZo45jow84I7ft79zu6AYOCetAg3nLryz1EoQaeef+H/8SmRrakt6oPdbrVZT2WiP8BwxYcjQMkWG3XDOWnWljfMFDb+wqNJZox4fcWyiohSP9WixL6yLSu0QKBwv6BoCHLSTOVspR57YOuw+hXZcy1Va+j9WSTwnsNlEv+fBOFCsFKTvA9gPTKTVH2+wxlz7TIz+JOwo7p+BYRXJ5lV2V4gJgupX/mU6MqoCX7bEobV/h7XHfRLB0U/rvZVTiKI0dKmZDOsfxezgxXlxRb75nx6OVmjra1by63x28v0Q2VbZPeDVObm1CmUHMArKkzR1y8rlyeq11jlsg+a/J9/xgSU8oyTdKrNfey/aRv+IvQyx2B7mQacmqzBQA8Et6J+Z+wqkbRjZagJHIT5F9VfK5fvlA4jCXtgnC+bkghJj8t9KlrxTcOOR3JE/Gi+iVKUFNehOfube1SZgW8VvCWRIlzz5HEWfab2/BSfWCIzUXaM43fmPJJY/6ZTRUCXqB+oLKe/CcGFKjCHmXXuibpArB/bODmqHC2yOmABH3wjt5AABqaZz+lYNyt7Aqn7/d6HhlZqqXhHXNMaBFOAtXH88HXr9FiN8QxqpcqWl0QQQ/QV29NV+JfXe/5L5SzYQHhBGWSEv7KJmTjzWreOZjZt0kYJwlLag8REucLcihtVz3WTp5aegtsOU3xj4MYcSPM5OGa06EYrE/KF/EwP7smo5zruJg8CjYgQhzYawzvapqWzO/L4EDDQDW1e11At9pnbuD1r4uBmgkPIZmV6wxS0bUwrzDMkGQ2Fahkj7O4J0sh6hTyIwe+wsQAmS21E+dGXZscMgGGIbKFGn9b0tW0Kh7fm1eUWGuMghONuV2Y6cFnmwTDwVICF1Zo9A8pmBc8ejF6wyMBMQkZ8Q2TwOtPYMdrQdFf0cRMi4fNl4SwJJo5ZQsjqJUA8mHqy794h0dyT4AsKln3tZZNznXMZTWakpD1nDM6LCzKjREtnu4uhE09XQNNfM/0V8nLZ4+3um92d4IAdt73fbNnhvFHycjHRNsMhs1xRwO5+puhCTefQi1yEQFQHm3vjCInX+Y/yd8u4bW2uX3jV1iN4fZ2Ivo8ffuxTgkASE242YTaVV05kFEoexrqEAIX1xzGU2Ev+Q3XeH8/xFfzN620aWe8AoFzi0NESjDqUjf6D/j8j6sOsw/ZdXpBpeEpmTIy2dQ+/2Cg9o6aoK9uTBA/gPVnryzJ8Hxd434fvC5+Pmjet8dqXhYR1V9OGFXXEjixnAGzIafTKRwF037W41MI7niEJY88qxOJVBYUtUfLX3AFeWLfJUiwOwlblHljZVeFLhSVycli0AHxIcBEJx+cgtBtu9rdNrD9R4NnlgqcDKGZ9oVLK1cptPvzjAOJb3+SOXwswGgH9/GYvxu+xcQtlWp8QmYJGT25dJ8GTZBPlGq1ZrMYLvri4ldiqO4/w917Mvr79XokmRb2dubSaA7fNLBBKCY2MaCAkIcMugIAhGfehD2QIC20MH5EXDWf5Ga3KLlXPtYSIojxbquvweAsZFHqoBArLxFXcgU3zgbj3UizKmAFFgMndf16rRD2z+ap2Fza7e7+1gOEPSWhNb5ksoqZ9OWO+SfUzgqT4DDyltOSTDQHUVhRG6ZOzf/epuUNXEviHoxZ+kFdy3bish36meI/vckyE/S4aaxm2zmG4TItx8UvX08WrYHOM3KVyhS2LSWJTNrNlmwm4euswILNjgUs4ScJ8sz+xautEAaW6C3cNlLvfsDSR/ODEIaVSZ6YcegouOllqC/dg8ysIPG3AaQbl9UqfYwzPsXSKKSda+Cxpw64s3C87RmT+dd+iac4qZRnMUvaW54xH1dMc17/X52BzkRz9QR9d1pBJ44H3JWrpLRimA4gb23VVOSK/995kALfLK0RtjeVYtmSm5Uv9xGlZiKhNUkJCsa4BnP/FDs3Y2TowEau86NN0OCfA1QTmFtFl5kXzY0rRuAZI7QD1PQmjy2h5ctj/namwZsAOIrPPXKpgSYwWllUKa+SJbsMlCLoOTJkS1C9DnS0gKe7uofYgVwq23pk31zHQLAZXokwIpY/inOJ1XB9dbPnagXpiKag2DmRoFFOd0p7+CaRSEvdd2VkAwfyXN1dx4kccGW/wPqJ3Y+JbGOAVo6Kw39zeEjFTqHY0fI/+cm8VmKddq5FfahkwIzcdJ0X5T1mnnDFQgc3Bs8K4UyLX5+bZ26/kPTWPebj9AQRNmQEL/IHOa0SMpaV+JklxZc/+BMekaY+1vXRssQkmLP1dR2aqd54rnq7Bopzdzi7Exo3NdDOeq9ZJ+m1rYmMzIbh/gNoMIKMgcff6mCIaFWdWYlzPXL14ryVR2NHjbQ2GW01O2C81oHHvz0TUcAKB6ImVOXjFJ8Odr261QJfnNtanqcQevvTXafMA02j7hBSnHntdU8BM1K+JKD//bolVbFiFpqS7hPChPLExcae4EjcNRBWoxzUSmq8EkEeELBHlwYEgqZpMMEp8NFXtfPtdJsOHywilJP9U4/Pua7qNGeO9K6JQxVjl+cO/BevC0W1lmbG/3VC4Tiqv1WFL+7Nmx4wgaxb+/fBq3chb0yoM+DugUsNNIePmo9kdcqRBD11yzML1xSUki26kJ8QJTRgqnTgFPf+yf5tnS6Ejarb/+6iSEx7YSKdc8ksJOnbaB/iJbpcf6NnIPElKkTNm9Hb1zoCHbQRYML/A2f/TAH8h5RLMrk+XUP8g580s1BdrBHWOthZphKAT/P7O0rGNac/evluT3W97u+Vjzbwyju21zWGgsJQK/kOCaRzi3rhW3yaEcpHDOae7JzdMF7FRQvXn1U7WCAzh6Gj7BATbzAtG7HMZwN6HLNEJ8db3FTG+QGqQY6ixbJYECmC8pBZyZhFgyE6bdJNwCNztBSGqcrcQbAooCeQoZ1ab5hPqypOcgrJmUROsgKmHBQn/APtDvzOgwBhz+9Rt1xYctVHrYsbQRRpkgDKqvpQjkLRHMMU2OAfXqTUSWOlypoKMjRaBpFRb6pb9a4pE06UtXjAz52SrAaNh3bRwzhiD6cxxSH92CylE3jfKwVA6Jg2RQPQPLmELGHAKt8bjlUbVDpYkGjtwsahgQQDpRAcHIr7iPZyEU0AOLI8Rtk+FRyHc2rzb7oB4twjPLTyvvWza5nXNjwIMPj/csoCDPegeE2BtwXd1CFMSmXc0rfQNAIol2ikY7omN8AX1A1alm/XBAM7kyrUqBJfDanBoZwLRxRUn5QZ1CXUKWDqfqKUuimUPZsrCdJS4/5vk+yrADkA+RD6n/Is/tS/E6PfhCgj21iy4It2USb+TQd5wti05I4CuYizbjhM4zMkRt2iJYZecBXhkfCEFpKaR/SRJNLjXuEerKBL3ay0lp6jP56FjuwSD+1yNB8IH8dj45Z9bCM6E6mcLrm3ObMDxxFecJbu47S8GSA9tmuj4lsp6g43hI8TB8k8KbmZ19k1eANMy2v5z/KkWC540wqVEyrAWsEEJQd2eO0YtJIK1S5srtL+BFs1mo9aNrOlxmTAzt96K9AkWEBF5HkrtoLk9J5woW5d5pJnjkxV/Mnnbai8S+tM+dK5ykV5oBsmVRMkmaTqAKFEBNSeJ2qmXraPG8FQhs2RPLaLMDaVA8DJzjhQo22083d5O7AEy+2oOqHf6WC46CJQUkl6ij5hVSrMNMtLjOVI8Coj92jZub7encDZHkxYqhrWx6GZf8suQmcG39JCgVyErYsuS73JkH4fVDlwvdzqSinT3mDMZtC1p5GdRes00P5SRjt4BYeiCKKM9PX5KgrxvKiN+V0jc0N/6Ke6GFACETsMxMoYt9v68YUIbCPCO29/0iZm3Is/H5Q6AN05qr4GCC8LFMEi0mlnuKW47Dyd1tAWAgWh6s8cit+uKDniIVXXE8HsKhBpmVAPeAgN80LsnhiZZc8uaXMExX/txLhhCtQVy1uV45L3tZ/MpttLEww2v6/AuJjteIQGTodA8/fYLFx4bfoGVjpEwGkWQJxKPQSbhW8aWJ12RO5rkvrJeygcZUn0w+uYHUbiBDtYIb4PlenekEh+mrckvzMrXVgnZOh1WFfd4H/wLVbPw+EKBFZy7KByhU1akMnzR3OBqv05Hav3I++HZMqoOJIWBSLJc5yq6h4ByA2uebsh//1N47ivGZGnG2dtVbjE8y51y6WcEWx6rULbgXOaqvje/N+Tx6Bjbs2egcSA9Ls6i1pX4a148rQdnxzX4CUYGcXwnbDp3VouUPJGOatlnakEngtN0Nq/y2IUdX5FvuG6jrzznGGGxECaRtH2cCg/b7C9yI2HIuNXCnIr3THiT0ZpQ3ftqZpuximPgRnD4DsMX1OACukcOaYa6Ily7YdhZSxKy92zYCzzxkFtg6geTNnOHhLSNTjO1F8YP+AZK2HMrvsSDFKqcVqq5ZEkGB7IBVFD5gOnRay9exlxpggwKddgRl1/lZS6Litk2nRFIklMkKbkyXtA0Wy2XAsgbdcx76wFYXLm8eKL9HqHpI+8OhzG/qlN1+tZQJlTyM0bi/ydMGK4+lMG00E1Yvy6/qUhj78XtTkl/LeoNouFbjrDbrCE10HCKihWdFmbXDVjrtBT6IGa7M53bz4OmPnLsSHpW9iVSu/OqNv8RJ5Vdu/T5YMF7RSanOuRQDO26y8QrjXESaCPL4PVWLjevgHq6sv3RXNwr0gny1gVSm+9OActm9M+gGo6gFKnf93JVjvmGkmwIa1QMUGDlnBDQ8DJZL1KOeolglFRvpH9FIW/r09JWwg2qkv80FyMQteODS6OGm8XJF4d0kbxyDZ1dWt7kPmNw5vfId4IHXbfiv7JHiyYhijTJM8wGLOHXfckPQqiYedTEOko3Q6ukhd3gX5A4vPQqBDJaHOcsJw+wfSct5P6yhBYUvqXaVQonp1HP4RxueBohe1HtsInQnGjP4nHiXdiivUkRKJOGk4Ahdfs+i18ZmHT19h8pMpUNawD3+Vw5Y9MuDmZa6wT90XAJJIZkFM0uXr5QctfbfA6LG6bGVlgQ2QJeITKj53kAfUum3xOq3fAdatTthdP3fldy+u81Q9oAAdXFNXhB9NTYdR7YGRQjxnEhPUAJg0P7h1PgmDXLnB36a244gggEWhLK65mlRxaVNtte6C1lTULadD0YOTDLsK0vtPpg3Qcvl+LDaoquUDANCKHtW8EDE650AxreG9nXNb+T1HzV5tl20D2dYX401MokY+OibIx9AbVRSc3SU30Y+jmPMQFTO5SXaAlRGjlb+P7dV5Mc1TxGYmDdQcwJdjbCvTWR/bLbZ294zZskPIEz8d05EehMWuoHrqXg6HU67aC1mD9/rAg/afW5s58CyMKReGvMoJ/jxStFBGiYZX9nZ4+725zw2hH+htIjiEVSEooOVNy2HYIjxPB7krb8JT+FRDqnSwijwer2sX96o5hreuA+BsGzHB7BQ5oijbi7xM+qyCnQMFbpxaF9T90gu1S7wMeq2Ss6pq/rnm1vtmvEcoFKeKTZAYA+Q8fhYh2E/TTvaORKcfQDfirCuuj/2/wSU5MQLKAK3QpYk/7NjVPFhH5HTk4MIMATz5T0ap9xZ6q3gVB0BFIqVRKNzZA2jIC8PjktlYXlqBN9bGM9jb5YFRZLB/KtXoPYYxEQsdDKiZyUnuOSfqhl7QWiIQZf7OY507UFohYc/LPUNjMw0D20nLtZ3yBKl6fKGqnUuGjUv84PCoRzZR0dA06WjpuVy3eDmIS9w6jCv01m8kGNl0gPQ7rlGit3IvZ87QcIgqbOaFKGQAwgbW9qnjY/eXF+DOzbiY6EgpmLj9I1nejDsiF1xeBs8q6FqJnc3PbdwpBxVLu6bYFG7niRXSUM5+SQ8RfXBsIYVd7VLev1UuUa35SpLv66iNgjUPv9H6uCLFJrtZWqAu0G5kDVSSjDRdL0wxkG5tyAgh9VAHfRDr6G6fYanQR3rJCPObqETWIE8g+sG+RCwgenCjQslzZgAxVg4GqSrpWmkWqB1iulHZ5vfXaU1yg8COx8GxdvYerEu4HyH7JnrUa4gkQBrrjOxM8uiUJ2bfeDktTb9N3/2yQWsa4KvGpD1v4OUC0xHlW3w2ie26HYAAA==";

/* =====================================================================
   Minimal ZIP writer (store method, no dependencies)
   ===================================================================== */
const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(u8){
  let c = 0xFFFFFFFF;
  for (let i = 0; i < u8.length; i++) c = CRC_TABLE[(c ^ u8[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}
function dosTime(d){
  return ((d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1)) & 0xFFFF;
}
function dosDate(d){
  return (((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate()) & 0xFFFF;
}
function makeZip(entries){
  // entries: [{name, data:Uint8Array}]
  const enc = new TextEncoder();
  const now = new Date();
  const time = dosTime(now), date = dosDate(now);
  const parts = [];
  const central = [];
  let offset = 0;

  for (const e of entries){
    const nameBytes = enc.encode(e.name);
    const crc = crc32(e.data);
    const size = e.data.length;

    const lh = new Uint8Array(30 + nameBytes.length);
    const lv = new DataView(lh.buffer);
    lv.setUint32(0, 0x04034b50, true);
    lv.setUint16(4, 20, true);
    lv.setUint16(6, 0x0800, true);   // UTF-8 names
    lv.setUint16(8, 0, true);        // store
    lv.setUint16(10, time, true);
    lv.setUint16(12, date, true);
    lv.setUint32(14, crc, true);
    lv.setUint32(18, size, true);
    lv.setUint32(22, size, true);
    lv.setUint16(26, nameBytes.length, true);
    lv.setUint16(28, 0, true);
    lh.set(nameBytes, 30);

    parts.push(lh, e.data);

    const ch = new Uint8Array(46 + nameBytes.length);
    const cv = new DataView(ch.buffer);
    cv.setUint32(0, 0x02014b50, true);
    cv.setUint16(4, 20, true);
    cv.setUint16(6, 20, true);
    cv.setUint16(8, 0x0800, true);
    cv.setUint16(10, 0, true);
    cv.setUint16(12, time, true);
    cv.setUint16(14, date, true);
    cv.setUint32(16, crc, true);
    cv.setUint32(20, size, true);
    cv.setUint32(24, size, true);
    cv.setUint16(28, nameBytes.length, true);
    cv.setUint32(42, offset, true);
    ch.set(nameBytes, 46);
    central.push(ch);

    offset += lh.length + size;
  }

  let cdSize = 0;
  for (const c of central) cdSize += c.length;

  const eocd = new Uint8Array(22);
  const ev = new DataView(eocd.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(8, entries.length, true);
  ev.setUint16(10, entries.length, true);
  ev.setUint32(12, cdSize, true);
  ev.setUint32(16, offset, true);

  return new Blob([...parts, ...central, eocd], {type:"application/zip"});
}

/* =====================================================================
   State
   ===================================================================== */
const RATIO_PRESETS = [
  {id:"free",  w:0, h:0},
  {id:"1:1",   w:1, h:1},
  {id:"4:5",   w:4, h:5},
  {id:"2:3",   w:2, h:3},
  {id:"3:4",   w:3, h:4},
  {id:"5:7",   w:5, h:7},
  {id:"16:9",  w:16, h:9},
  {id:"9:16",  w:9, h:16},
  {id:"custom",w:0, h:0}
];
const BOX_COLORS = ["--b1","--b2","--b3","--b4","--b5","--b6"];
const MAX_FILES = 200;
const MAX_BYTES = 200 * 1024 * 1024;
const MAX_SIDE  = 16384;   // canvas ceiling, measured
const MAX_CROPS = 6;

const PAGE_LANG = detectLang();   // this file's default language
/* The Chrome extension runs this same page from inside the extension
   (build.py writes it to extension/build/). There the site's own links have
   to name the site, and a picture sent from the right-click menu stands in
   for the sample plate. */
const EXTENSION = location.protocol === "chrome-extension:";
const SITE = EXTENSION ? "https://detailcrop.com" : "";
const S = {
  lang: PAGE_LANG,
  wide: false,
  items: [],
  cur: 0,
  sel: 0,
  ratioId: "2:3",
  ratioScope: "all",          // "all" = the whole batch, "one" = the selected crop

  rw: 2, rh: 3,
  outMode: "native",
  ow: 1600, oh: 2400,
  fmt: "image/webp",
  quality: 86,
  pattern: "{name}-d{n}",
  layout: null,               // boxes of the preset loaded last; new images start from it
  busy: false
};

const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));
const T = () => I18N[S.lang];
const clamp = (v,a,b) => v < a ? a : v > b ? b : v;

/* =====================================================================
   Language
   ===================================================================== */
function detectLang(){
  const l = (navigator.language || "en").toLowerCase();
  if (l.startsWith("ko")) return "ko";
  if (l.startsWith("ja")) return "ja";
  return "en";
}
function applyLang(){
  const t = T();
  document.documentElement.lang = S.lang;
  $$("[data-i]").forEach(el => {
    const v = t[el.dataset.i];
    if (typeof v === "string") el.textContent = v;
  });
  $("#hintBody").innerHTML = t.hint;
  $("#jobText").placeholder = t.jobPh;
  const msg = $("#exportMsg");
  if (msg) msg.hidden = true;              // stale text would stay in the old language
  if (typeof tourIdx === "number" && tourIdx >= 0) paintTourStep();
  if (typeof paintStatsToggle === "function") paintStatsToggle();
  if (typeof paintPresets === "function") paintPresets();
  $$(".langs button").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.lang === S.lang)));
  const sfx = S.lang === "en" ? "/" : "/" + S.lang + "/";
  $("#brandLink").href = SITE + sfx;
  $("#crossBan").href  = SITE + "/video" + sfx;
  $("#aboutLink").href = SITE + sfx + "about/";
  $("#howLink").href   = SITE + sfx + "how-to/";
  $("#usesLink").href  = SITE + sfx + "uses/";
  $("#policyLink").href = $("#signinPolicy").href = SITE + sfx + "privacy/";
  // ratio labels that are words
  $$("#ratioseg button").forEach(b => {
    if (b.dataset.r === "free") b.textContent = t.free;
    if (b.dataset.r === "custom") b.textContent = t.custom;
  });
  render();
}

/* =====================================================================
   Ratio helpers
   ===================================================================== */
/* The batch ratio is the one in Settings. A crop can carry its own instead —
   that is what the scope toggle above the ratio buttons writes — and every
   measurement below takes the box it is working on so the two never mix up. */
function ratioOf(b){
  if (b && b.rid){
    const p = RATIO_PRESETS.find(x => x.id === b.rid);
    if (b.rid === "free") return {id:"free", w:0, h:0, locked:false};
    if (p && p.w) return {id:p.id, w:p.w, h:p.h, locked:true};
    return {id:"custom", w:b.rw || S.rw, h:b.rh || S.rh, locked:true};
  }
  return {id:S.ratioId, w:S.rw, h:S.rh, locked:S.ratioId !== "free"};
}
function ratioLocked(b){ return ratioOf(b).locked; }
function ratioVal(b){ const r = ratioOf(b); return r.w / r.h; }     // pixel aspect w/h

// normalised height for a given normalised width, honouring the pixel ratio
function hForW(wN, item, b){
  return (wN * item.w) / ratioVal(b) / item.h;
}
function wForH(hN, item, b){
  return (hN * item.h) * ratioVal(b) / item.w;
}

/* =====================================================================
   Box placement
   ===================================================================== */
function defaultBoxSize(item, tight, b){
  const target = tight ? 0.30 : 0.38;
  if (!ratioLocked(b)){
    // free ratio: start square in *pixels*, sized off the shorter side
    const side = target * Math.min(item.w, item.h);
    return {w: clamp(side / item.w, 0.02, 1), h: clamp(side / item.h, 0.02, 1)};
  }
  let h = target;
  let w = wForH(h, item, b);
  if (w > 0.46){ w = 0.46; h = hForW(w, item, b); }
  if (h > 0.46){ h = 0.46; w = wForH(h, item, b); }
  return {w, h};
}

function gridCells(n, inset){
  const cols = Math.ceil(Math.sqrt(n));
  const rows = Math.ceil(n / cols);
  const cells = [];
  for (let i = 0; i < n; i++){
    const r = Math.floor(i / cols), c = i % cols;
    const colsInRow = (r === rows - 1) ? (n - cols * (rows - 1)) || cols : cols;
    const cx = inset + ((c + 0.5) / colsInRow) * (1 - 2 * inset);
    const cy = inset + ((r + 0.5) / rows) * (1 - 2 * inset);
    cells.push({cx, cy});
  }
  return cells;
}

function layoutBoxes(item, n, spread){
  const size = defaultBoxSize(item, n > 4);
  const cells = gridCells(n, spread ? 0.02 : 0.10);
  return cells.map(c => ({
    x: clamp(c.cx - size.w / 2, 0, 1 - size.w),
    y: clamp(c.cy - size.h / 2, 0, 1 - size.h),
    w: size.w, h: size.h
  }));
}

/* ---------- straighten & perspective ----------
   One homography per image drives all three surfaces: the stage, the crop
   previews and the export. Rotation levels a horizon; the two perspective
   sliders pull a keystoned wall back to square.

   Warping turns the photo into a quad with empty space around it. Rather
   than let a crop pick that up, the working area becomes the largest
   axis-aligned rectangle of the source aspect ratio that fits wholly inside
   the quad. Holding the aspect ratio means every ratio calculation below is
   untouched — only the pixel count shrinks as the sliders move. */

const K_MAX = 0.25;                 // keystone strength at slider 100

function rotOf(item){ return (item && item.rot) || 0; }
function khOf(item){  return (item && item.kh)  || 0; }
function kvOf(item){  return (item && item.kv)  || 0; }
function warped(item){ return !!(rotOf(item) || khOf(item) || kvOf(item)); }
function keystoned(item){ return !!(khOf(item) || kvOf(item)); }

/* row-major 3x3 over source pixels measured from the image centre, y down */
function homography(item){
  const th = rotOf(item) * Math.PI / 180;
  const c = Math.cos(th), sn = Math.sin(th);
  const a = (khOf(item) / 100) * K_MAX / (item.w / 2);
  const b = (kvOf(item) / 100) * K_MAX / (item.h / 2);
  // keystone first, then rotate, so the rotate slider always levels what
  // is actually on screen
  return [ c, -sn, 0,
           sn,  c, 0,
           a,   b, 1 ];
}
function applyH(M, x, y){
  const w = M[6] * x + M[7] * y + M[8];
  return [(M[0] * x + M[1] * y + M[2]) / w, (M[3] * x + M[4] * y + M[5]) / w];
}
function invH(M){
  const a = M[0], b = M[1], c = M[2], d = M[3], e = M[4],
        f = M[5], g = M[6], h = M[7], i = M[8];
  const A = e*i - f*h, B = c*h - b*i, C = b*f - c*e;
  const D = f*g - d*i, E = a*i - c*g, F = c*d - a*f;
  const G = d*h - e*g, H = b*g - a*h, I = a*e - b*d;
  const det = a*A + b*D + c*G;
  return [A/det, B/det, C/det, D/det, E/det, F/det, G/det, H/det, I/det];
}

function clipHalf(poly, nx, ny, d){
  const out = [];
  for (let i = 0; i < poly.length; i++){
    const A = poly[i], B = poly[(i + 1) % poly.length];
    const da = nx * A[0] + ny * A[1] - d, db = nx * B[0] + ny * B[1] - d;
    if (da <= 0) out.push(A);
    if ((da < 0 && db > 0) || (da > 0 && db < 0)){
      const t = da / (da - db);
      out.push([A[0] + t * (B[0] - A[0]), A[1] + t * (B[1] - A[1])]);
    }
  }
  return out;
}

/* Largest source-ratio rectangle inside the warped quad. A rectangle of
   half-extents (ha,hb) fits inside a convex polygon exactly when its centre
   satisfies every edge half-plane pulled inward by ha*|nx| + hb*|ny|, so the
   fit test is four half-plane clips and the size is a binary search. */
function fitUsable(item){
  const W = item.w, H = item.h, M = homography(item);
  // untouched image: the whole frame is usable, byte for byte as before
  if (!warped(item)) return { M: M, uw: W, uh: H, ox: 0, oy: 0 };
  const Q = [[-W/2,-H/2],[W/2,-H/2],[W/2,H/2],[-W/2,H/2]]
              .map(p => applyH(M, p[0], p[1]));
  const cx = (Q[0][0] + Q[1][0] + Q[2][0] + Q[3][0]) / 4;
  const cy = (Q[0][1] + Q[1][1] + Q[2][1] + Q[3][1]) / 4;
  const planes = [];
  for (let i = 0; i < 4; i++){
    const A = Q[i], B = Q[(i + 1) % 4];
    let nx = B[1] - A[1], ny = -(B[0] - A[0]);
    let d = nx * A[0] + ny * A[1];
    if (nx * cx + ny * cy > d){ nx = -nx; ny = -ny; d = -d; }
    planes.push([nx, ny, d]);
  }
  const big = 4 * Math.max(W, H);
  const centreAt = sc => {
    const ha = sc * W / 2, hb = sc * H / 2;
    let poly = [[-big,-big],[big,-big],[big,big],[-big,big]];
    for (let i = 0; i < 4; i++){
      const p = planes[i];
      poly = clipHalf(poly, p[0], p[1],
                      p[2] - (ha * Math.abs(p[0]) + hb * Math.abs(p[1])));
      if (!poly.length) return null;
    }
    let sx = 0, sy = 0;
    for (let i = 0; i < poly.length; i++){ sx += poly[i][0]; sy += poly[i][1]; }
    return [sx / poly.length, sy / poly.length];
  };
  let lo = 0, hi = 1.6, ctr = centreAt(0.0005) || [cx, cy];
  for (let i = 0; i < 44; i++){
    const mid = (lo + hi) / 2;
    const p = centreAt(mid);
    if (p){ lo = mid; ctr = p; } else hi = mid;
  }
  // one pixel in: an exact fit leaves the outermost corner pixels half
  // covered, which reads as a translucent speck in a PNG export
  const sc = Math.max(0.05, lo - 2 / Math.min(W, H));
  return { M: M, uw: W * sc, uh: H * sc, ox: ctr[0], oy: ctr[1] };
}

function geo(item){
  const key = rotOf(item) + "|" + khOf(item) + "|" + kvOf(item) + "|" + item.w + "x" + item.h;
  if (item._gk !== key){ item._g = fitUsable(item); item._gk = key; }
  return item._g;
}
function usableW(item){ return geo(item).uw; }
function usableH(item){ return geo(item).uh; }

/* the export transform, handed to CSS so screen and file cannot disagree */
function cssM(M){
  return "matrix3d(" + M[0] + "," + M[3] + ",0," + M[6] + "," +
                       M[1] + "," + M[4] + ",0," + M[7] + ",0,0,1,0," +
                       M[2] + "," + M[5] + ",0," + M[8] + ")";
}
function placeArt(im, item, g, k, qx, qy){
  im.style.width  = item.w + "px";
  im.style.height = item.h + "px";
  im.style.transform = "translate(-50%,-50%) translate(" + (-qx * k) + "px," +
    (-qy * k) + "px) scale(" + k + ") " + cssM(g.M);
}

function layoutStage(){
  const it = cur();
  if (!it) return;
  const stage = $("#stage"), img = $("#art"), wrap = stage.parentElement;
  const availW = Math.max(120, wrap.clientWidth - 40);
  const availH = Math.max(120, Math.round(window.innerHeight * (S.wide ? 0.88 : 0.74)));
  const g = geo(it);
  const k = Math.min(availW / g.uw, availH / g.uh);
  stage.style.width  = Math.max(80, Math.round(g.uw * k)) + "px";
  stage.style.height = Math.max(80, Math.round(g.uh * k)) + "px";
  placeArt(img, it, g, k, g.ox, g.oy);
}

/* Each crop preview is the same picture at a smaller scale, centred on that
   crop, so it cannot drift out of step with the stage. */
function layoutPreviews(){
  const it = cur();
  if (!it) return;
  const g = geo(it);
  const nodes = $("#crops").querySelectorAll(".crop");
  for (let i = 0; i < nodes.length; i++){
    const b = it.boxes[i];
    if (!b) continue;
    const pv = nodes[i].querySelector(".pv");
    const im = pv && pv.querySelector("img");
    if (!im) continue;
    const pw = pv.clientWidth;
    if (!pw) continue;
    const f = pw / (b.w * g.uw);
    placeArt(im, it, g, f,
      g.ox + (b.x + b.w / 2 - 0.5) * g.uw,
      g.oy + (b.y + b.h / 2 - 0.5) * g.uh);
  }
}

/* ---------- perspective export ----------
   Canvas 2D only does affine transforms, so a keystoned crop goes through
   WebGL: one quad, and the inverse homography evaluated per pixel. Output is
   drawn in bands, and each band uploads only the slice of the source it
   reads, so a 100 MP original never becomes a 400 MB texture. */
let GLC = null, GL = null, GLP = null, GLTEX = null, GLU = null, GLMAX = null;

function glReady(){
  if (GL !== null) return GL;
  try {
    GLC = document.createElement("canvas");
    GL = GLC.getContext("webgl", { antialias: false, depth: false, stencil: false })
      || GLC.getContext("experimental-webgl");
    if (!GL) throw new Error("no webgl");
    const vsrc =
      "attribute vec2 p;uniform vec2 o;uniform vec2 s;varying vec2 d;" +
      "void main(){vec2 t=vec2(p.x*0.5+0.5,0.5-p.y*0.5);d=o+t*s;gl_Position=vec4(p,0.0,1.0);}";
    const fsrc =
      "#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n" +
      "varying vec2 d;uniform mat3 hi;uniform vec2 hf;uniform vec2 b0;uniform vec2 bs;uniform sampler2D tex;" +
      "void main(){vec3 q=hi*vec3(d,1.0);vec2 pp=q.xy/q.z+hf;" +
      "gl_FragColor=texture2D(tex,clamp((pp-b0)/bs,0.0,1.0));}";
    const vs = GL.createShader(GL.VERTEX_SHADER);
    GL.shaderSource(vs, vsrc); GL.compileShader(vs);
    const fs = GL.createShader(GL.FRAGMENT_SHADER);
    GL.shaderSource(fs, fsrc); GL.compileShader(fs);
    GLP = GL.createProgram();
    GL.attachShader(GLP, vs); GL.attachShader(GLP, fs); GL.linkProgram(GLP);
    if (!GL.getProgramParameter(GLP, GL.LINK_STATUS)) throw new Error("link");
    GL.useProgram(GLP);
    const buf = GL.createBuffer();
    GL.bindBuffer(GL.ARRAY_BUFFER, buf);
    GL.bufferData(GL.ARRAY_BUFFER, new Float32Array([-1,-1, 1,-1, -1,1, 1,1]), GL.STATIC_DRAW);
    const loc = GL.getAttribLocation(GLP, "p");
    GL.enableVertexAttribArray(loc);
    GL.vertexAttribPointer(loc, 2, GL.FLOAT, false, 0, 0);
    GLTEX = GL.createTexture();
    GL.bindTexture(GL.TEXTURE_2D, GLTEX);
    GL.texParameteri(GL.TEXTURE_2D, GL.TEXTURE_WRAP_S, GL.CLAMP_TO_EDGE);
    GL.texParameteri(GL.TEXTURE_2D, GL.TEXTURE_WRAP_T, GL.CLAMP_TO_EDGE);
    GL.texParameteri(GL.TEXTURE_2D, GL.TEXTURE_MIN_FILTER, GL.LINEAR);
    GL.texParameteri(GL.TEXTURE_2D, GL.TEXTURE_MAG_FILTER, GL.LINEAR);
    GLU = {};
    ["hi", "hf", "o", "s", "b0", "bs"].forEach(n => { GLU[n] = GL.getUniformLocation(GLP, n); });
    GLMAX = {
      tex: GL.getParameter(GL.MAX_TEXTURE_SIZE) || 2048,
      out: Math.min(GL.getParameter(GL.MAX_RENDERBUFFER_SIZE) || 2048,
                    (GL.getParameter(GL.MAX_VIEWPORT_DIMS) || [2048, 2048])[0])
    };
  } catch (e){ GL = false; }
  return GL;
}

function warpGL(ctx, img, item, g, q0x, q0y, sw, sh){
  const gl = glReady();
  if (!gl) throw new Error("perspective needs WebGL");
  const Hi = invH(g.M), W = item.w, H = item.h;
  const tile = document.createElement("canvas");
  const tctx = tile.getContext("2d");
  const U = GLU;

  gl.uniformMatrix3fv(U.hi, false, new Float32Array(
    [Hi[0], Hi[3], Hi[6], Hi[1], Hi[4], Hi[7], Hi[2], Hi[5], Hi[8]]));
  gl.uniform2f(U.hf, W / 2, H / 2);

  // the slice of the source that a block of output reads from
  function srcBox(dx, dy, dw, dh){
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    for (let c = 0; c < 4; c++){
      const p = applyH(Hi, q0x + dx + (c & 1 ? dw : 0), q0y + dy + (c & 2 ? dh : 0));
      if (p[0] < x0) x0 = p[0];
      if (p[0] > x1) x1 = p[0];
      if (p[1] < y0) y0 = p[1];
      if (p[1] > y1) y1 = p[1];
    }
    x0 = Math.max(0, Math.floor(x0 + W / 2) - 2);
    y0 = Math.max(0, Math.floor(y0 + H / 2) - 2);
    x1 = Math.min(W, Math.ceil(x1 + W / 2) + 2);
    y1 = Math.min(H, Math.ceil(y1 + H / 2) + 2);
    return [x0, y0, Math.max(1, x1 - x0), Math.max(1, y1 - y0)];
  }

  function paint(dx, dy, dw, dh, box){
    tile.width = box[2]; tile.height = box[3];
    tctx.drawImage(img, box[0], box[1], box[2], box[3], 0, 0, box[2], box[3]);
    GLC.width = dw; GLC.height = dh;
    gl.viewport(0, 0, dw, dh);
    gl.bindTexture(gl.TEXTURE_2D, GLTEX);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, tile);
    gl.uniform2f(U.o, q0x + dx, q0y + dy);
    gl.uniform2f(U.s, dw, dh);
    gl.uniform2f(U.b0, box[0], box[1]);
    gl.uniform2f(U.bs, box[2], box[3]);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    ctx.drawImage(GLC, dx, dy);
  }

  /* Split until a block's source slice fits in a texture and its output fits
     in a framebuffer. Warped whole, a 100 MP original would want a 400 MB
     texture and would quietly blow past MAX_TEXTURE_SIZE — 8192 here, 4096 on
     plenty of phones — and the driver drops it with no error you can see. So
     the work gets cut up instead. Blocks split on integer pixels and each
     carries two pixels of margin, so the seams sample the same texels the
     neighbour does. */
  function block(dx, dy, dw, dh, depth){
    const box = srcBox(dx, dy, dw, dh);
    const tooBig = box[2] > GLMAX.tex || box[3] > GLMAX.tex ||
                   dw > GLMAX.out || dh > GLMAX.out || dw * dh > 4194304;
    if (tooBig && depth < 14 && (dw > 1 || dh > 1)){
      if (dw >= dh){
        const half = dw >> 1;
        block(dx, dy, half, dh, depth + 1);
        block(dx + half, dy, dw - half, dh, depth + 1);
      } else {
        const half = dh >> 1;
        block(dx, dy, dw, half, depth + 1);
        block(dx, dy + half, dw, dh - half, depth + 1);
      }
      return;
    }
    paint(dx, dy, dw, dh, box);
  }
  block(0, 0, sw, sh, 0);
  tile.width = tile.height = 0;
}

/* ---------- Instagram feed grid ----------
   Contiguous tiles that reassemble into one picture on the profile grid.
   Tiles keep the chosen ratio; the block moves and scales as one object,
   because a puzzle stops being a puzzle the moment a tile drifts. */
const FEED_COLS = 3;

function feedRows(n){ return Math.max(1, Math.round(n / FEED_COLS)); }

/* Instagram stacks newest first, so the last tile read is the first posted. */
function postNumber(item, i){
  return item.grid ? item.boxes.length - i : i + 1;
}

function buildGridBoxes(item){
  const g = item.grid;
  if (!g) return;
  const r = ratioVal();
  const gr = item.gridRect;
  const tw = (gr.w * item.w) / g.cols;      // tile width in source px
  const th = tw / r;                        // ratio is w:h
  const out = [];
  for (let ry = 0; ry < g.rows; ry++){
    for (let cx = 0; cx < g.cols; cx++){
      out.push({
        x: (gr.x * item.w + cx * tw) / item.w,
        y: (gr.y * item.h + ry * th) / item.h,
        w: tw / item.w,
        h: th / item.h
      });
    }
  }
  item.boxes = out;
}

function gridBlockH(item){
  const g = item.grid;
  const tw = (item.gridRect.w * item.w) / g.cols;
  return (tw / ratioVal()) * g.rows / item.h;
}

function clampGrid(item){
  const gr = item.gridRect;
  gr.w = clamp(gr.w, 0.12, 1);
  let h = gridBlockH(item);
  if (h > 1){                               // too tall to fit: shrink to height
    gr.w = gr.w / h;
    h = gridBlockH(item);
  }
  gr.x = clamp(gr.x, 0, Math.max(0, 1 - gr.w));
  gr.y = clamp(gr.y, 0, Math.max(0, 1 - h));
  buildGridBoxes(item);
}

function applyFeedGrid(n){
  const it = cur();
  if (!it) return;
  if (!n){                                  // off: back to free crops
    it.grid = null; it.gridRect = null;
    it.boxes = layoutBoxes(it, 1, false);
    S.sel = 0;
    render();
    return;
  }
  // These buttons are explicitly Instagram, so they set the feed ratio.
  // Changing the ratio afterwards rebuilds the grid at that ratio.
  setRatioSilent("4:5");
  it.grid = {cols: FEED_COLS, rows: feedRows(n)};
  it.gridRect = {x: 0.04, y: 0.04, w: 0.92};
  clampGrid(it);
  const h = gridBlockH(it);
  it.gridRect.y = clamp((1 - h) / 2, 0, 1);
  it.gridRect.x = clamp((1 - it.gridRect.w) / 2, 0, 1);
  clampGrid(it);
  S.sel = 0;
  render();
}

function setRatioSilent(id){
  S.ratioId = id;
  const p = RATIO_PRESETS.find(x => x.id === id);
  if (p && p.w){ S.rw = p.w; S.rh = p.h; }
  fitOutToRatio();
}

/* The fixed output frame is written for the batch ratio, so it follows that
   ratio when it changes: the width stays and the height follows, as it does
   when the width is typed. Otherwise a 4:5 crop would go out in the 2:3
   frame left from before, stretched. */
function fitOutToRatio(){
  if (ratioLocked()) S.oh = Math.max(1, Math.round(S.ow / ratioVal()));
}

function placeNewBox(item){
  const size = defaultBoxSize(item, item.boxes.length >= 4);
  const cands = [];
  for (let i = 1; i <= 3; i++) for (let j = 1; j <= 3; j++) cands.push({cx: i/4, cy: j/4});
  let best = cands[0], bestD = -1;
  for (const c of cands){
    let d = Infinity;
    for (const b of item.boxes){
      const bx = b.x + b.w/2, by = b.y + b.h/2;
      d = Math.min(d, Math.hypot(bx - c.cx, by - c.cy));
    }
    if (d === Infinity) d = 0;
    if (d > bestD){ bestD = d; best = c; }
  }
  return {
    x: clamp(best.cx - size.w/2, 0, 1 - size.w),
    y: clamp(best.cy - size.h/2, 0, 1 - size.h),
    w: size.w, h: size.h
  };
}

// re-fit every box to the current ratio, keeping the centre
function refitBoxes(item){
  if (item.grid) return;                    // grid tiles are rebuilt, not refitted
  for (const b of item.boxes){
    const cx = b.x + b.w/2, cy = b.y + b.h/2;
    if (!ratioLocked(b)) continue;
    let h = hForW(b.w, item, b);
    let w = b.w;
    if (h > 1){ h = 1; w = wForH(h, item, b); }
    b.w = w; b.h = h;
    b.x = clamp(cx - w/2, 0, Math.max(0, 1 - w));
    b.y = clamp(cy - h/2, 0, Math.max(0, 1 - h));
  }
}
function refitAll(){ S.items.forEach(refitBoxes); }

/* Reuse one image's boxes on another. A batch is often the same kind of
   shot over and over, so the areas worth cropping sit in the same places.
   Positions are fractions of the working area, which is what makes them
   carry across images of different sizes. On an image of another shape a
   box keeps its centre and its share of the picture while its ratio holds,
   so a portrait after a landscape does not get boxes half the size.
   Straighten values stay per image. */
function copyBoxes(from, to){
  if (from.grid){
    to.grid = {cols: from.grid.cols, rows: from.grid.rows};
    to.gridRect = {...from.gridRect};
    clampGrid(to);
    return;
  }
  to.grid = null; to.gridRect = null;
  to.boxes = from.boxes.map(src => {
    const b = {...src};
    if (ratioLocked(b)){
      const cx = b.x + b.w/2, cy = b.y + b.h/2;
      const r = hForW(1, to, b);             // normalised h per unit of w
      let w = Math.sqrt(src.w * src.h / r), h = w * r;
      const over = Math.max(w, h, 1);
      w /= over; h /= over;
      b.w = w; b.h = h;
      b.x = cx - w/2; b.y = cy - h/2;
    }
    b.x = clamp(b.x, 0, Math.max(0, 1 - b.w));
    b.y = clamp(b.y, 0, Math.max(0, 1 - b.h));
    return b;
  });
}

/* =====================================================================
   Files
   ===================================================================== */
let uid = 0;
async function addFiles(fileList, isSample){
  const files = Array.from(fileList);

  // a visitor bringing their own work replaces the untouched demo plate
  if (!isSample && S.items.some(i => i.isSample)){
    for (let i = S.items.length - 1; i >= 0; i--){
      if (S.items[i].isSample && !S.items[i].done){
        URL.revokeObjectURL(S.items[i].url);
        S.items.splice(i, 1);
      }
    }
    S.cur = 0; S.sel = 0;
  }

  let skippedBig = 0, skippedType = 0, skippedHuge = 0, skippedDecode = 0, biggestMB = 0;
  const room = MAX_FILES - S.items.length;
  const accepted = [];

  for (const f of files){
    if (accepted.length >= room) break;
    if (!f.type.startsWith("image/")){ skippedType++; continue; }
    if (f.size > MAX_BYTES){
      skippedBig++;
      biggestMB = Math.max(biggestMB, f.size / 1048576);
      continue;
    }
    accepted.push(f);
  }

  for (const f of accepted){
    const url = URL.createObjectURL(f);
    let dim;
    try { dim = await measure(url); }
    catch { URL.revokeObjectURL(url); skippedDecode++; continue; }
    if (dim.w > MAX_SIDE || dim.h > MAX_SIDE){
      URL.revokeObjectURL(url); skippedHuge++; continue;
    }
    const item = {
      id: ++uid,
      file: f,
      name: f.name.replace(/\.[^./\\]+$/, ""),
      url, w: dim.w, h: dim.h,
      thumb: dim.thumb,
      alpha: dim.alpha,
      boxes: [],
      done: false,
      isSample: !!isSample
    };
    item.boxes = layoutBoxes(item, 1, false);
    if (!isSample) startLayout(item);
    S.items.push(item);
  }

  const notes = [];
  if (skippedBig) notes.push(T().tooBig(skippedBig));
  if (skippedHuge) notes.push(T().tooWide(skippedHuge, MAX_SIDE));
  if (skippedDecode) notes.push(T().cantOpen(skippedDecode));
  if (skippedType) notes.push(T().notImage(skippedType));
  if (notes.length) flash(notes.join(" "), true);
  // Rejected files are otherwise invisible: the visitor sees a message and
  // leaves. This is how we learn whether the 40MB cap is costing real users.
  const rejected = skippedBig + skippedHuge + skippedDecode + skippedType;
  if (rejected){
    track("skip", { n: rejected, big: skippedBig, huge: skippedHuge,
                    nodecode: skippedDecode, bad: skippedType,
                    mb: Math.round(biggestMB * 10) / 10 });
  }

  render();

  if (!isSample && accepted.length){
    markAdded();
    const fresh = S.items.filter(i => !i.isSample).slice(-accepted.length);
    track("add", {
      n: accepted.length,
      iw: median(fresh.map(i => i.w)),
      ih: median(fresh.map(i => i.h)),
      mb: Math.round(median(fresh.map(i => i.file.size)) / 104857.6) / 10
    });
  }
}

function measure(url){
  return new Promise((res, rej) => {
    const im = new Image();
    im.onload = () => {
      const c = document.createElement("canvas");
      const scale = Math.min(1, 120 / Math.max(im.naturalWidth, im.naturalHeight));
      c.width = Math.max(1, Math.round(im.naturalWidth * scale));
      c.height = Math.max(1, Math.round(im.naturalHeight * scale));
      const cx = c.getContext("2d");
      cx.drawImage(im, 0, 0, c.width, c.height);
      let thumb = "";
      try { thumb = c.toDataURL("image/jpeg", 0.7); } catch {}
      // A picture with see-through parts can crop to an empty file on purpose;
      // one without cannot, so for those an empty crop means a failed draw.
      let alpha = false;
      try {
        const d = cx.getImageData(0, 0, c.width, c.height).data;
        let clear = false, solid = false;
        for (let k = 3; k < d.length; k += 4){
          if (d[k] < 255) clear = true;
          if (d[k] > 0) solid = true;
        }
        alpha = clear && solid;
      } catch {}
      res({w: im.naturalWidth, h: im.naturalHeight, thumb, alpha});
    };
    im.onerror = rej;
    im.src = url;
  });
}

function loadImage(url){
  return new Promise((res, rej) => {
    const im = new Image();
    im.onload = () => res(im);
    im.onerror = rej;
    im.src = url;
  });
}

/* =====================================================================
   Render
   ===================================================================== */
function cur(){ return S.items[S.cur]; }

function updateShell(){
  const empty = S.items.length === 0;
  $("#work").hidden = empty;
  $("#shell").classList.toggle("introonly", empty && !S.wide);
  $("#shell").classList.toggle("wide", S.wide && !empty);
  $("#sampleBtn").hidden = S.items.some(i => i.isSample);
  const wb = $("#wideBtn");
  wb.textContent = S.wide ? T().wideOff : T().wideOn;
  wb.setAttribute("aria-pressed", String(!!S.wide));
}

function render(){
  updateShell();
  if (!S.items.length) return;
  S.cur = clamp(S.cur, 0, S.items.length - 1);
  const it = cur();
  it.seen = true;
  S.sel = clamp(S.sel, 0, Math.max(0, it.boxes.length - 1));

  renderStrip();
  renderStage();
  renderRail();
  renderSettings();
  renderProgress();
}

function renderStrip(){
  const strip = $("#strip");
  strip.innerHTML = "";
  S.items.forEach((it, i) => {
    const wrap = document.createElement("div");
    wrap.className = "thumbwrap";
    const b = document.createElement("button");
    b.type = "button";
    b.className = "thumb" + (it.done ? " done" : "") + (it.boxes.length === 0 ? " skip" : "");
    b.style.backgroundImage = it.thumb ? `url(${it.thumb})` : "none";
    b.setAttribute("aria-current", String(i === S.cur));
    b.title = it.isSample ? T().sampleTip : it.file.name;
    b.innerHTML = (it.isSample ? `<span class="badge">${T().sampleBadge}</span>` : "") + '<span class="pip"></span>';
    b.addEventListener("click", () => { S.cur = i; S.sel = 0; render(); });
    const rm = document.createElement("button");
    rm.type = "button";
    rm.className = "rm";
    rm.textContent = "×";
    rm.title = T().removeOne;
    rm.setAttribute("aria-label", T().removeOne + " — " + it.file.name);
    rm.addEventListener("click", e => { e.stopPropagation(); removeItem(i); });
    wrap.append(b, rm);
    strip.appendChild(wrap);
  });
  const add = document.createElement("button");
  add.type = "button";
  add.className = "addmore";
  add.textContent = "+";
  add.title = T().pick;
  add.addEventListener("click", () => $("#fileInput").click());
  strip.appendChild(add);
}

function renderStage(){
  const it = cur();
  const img = $("#art");
  if (img.dataset.id !== String(it.id)){
    img.dataset.id = String(it.id);
    img.src = it.url;
    img.alt = it.file.name;
    img.onload = () => { layoutStage(); positionBoxes(); layoutPreviews(); };
  }
  const stage = $("#stage");
  Array.from(stage.querySelectorAll(".box")).forEach(n => n.remove());
  it.boxes.forEach((b, i) => {
    const el = document.createElement("div");
    el.className = "box";
    el.dataset.idx = String(i);
    el.dataset.sel = String(i === S.sel);
    el.dataset.dim = String(i !== S.sel);
    el.style.setProperty("--bc", `var(${BOX_COLORS[i % BOX_COLORS.length]})`);
    el.innerHTML = `<div class="edge"></div><div class="win"></div><div class="tag">${postNumber(it,i)}</div><div class="grip" data-grip="1"></div>`;
    stage.appendChild(el);
  });
  layoutStage();
  positionBoxes();
}

function positionBoxes(){
  const it = cur();
  const stage = $("#stage");
  stage.querySelectorAll(".box").forEach(el => {
    const b = it.boxes[+el.dataset.idx];
    if (!b) return;
    el.style.left   = (b.x * 100) + "%";
    el.style.top    = (b.y * 100) + "%";
    el.style.width  = (b.w * 100) + "%";
    el.style.height = (b.h * 100) + "%";
  });
}

function renderRail(){
  const it = cur();
  const t = T();
  $("#counter").textContent = `${S.cur + 1} / ${S.items.length}`;
  const rsel = ratioOf(it.boxes[S.sel]);
  $("#ratiotag").textContent = rsel.locked ? `${rsel.w}:${rsel.h}` : t.free;
  $("#wtitle").textContent = it.file.name;
  $("#wmeta").textContent = t.dims(it.w, it.h);

  // crop count segmented
  const seg = $("#countseg");
  if (seg.children.length !== MAX_CROPS + 1){
    seg.innerHTML = "";
    for (let n = 0; n <= MAX_CROPS; n++){
      const b = document.createElement("button");
      b.type = "button"; b.textContent = String(n); b.dataset.n = String(n);
      b.addEventListener("click", () => setCount(n));
      seg.appendChild(b);
    }
  }
  Array.from(seg.children).forEach(b =>
    b.setAttribute("aria-pressed", String(!it.grid && +b.dataset.n === it.boxes.length)));

  const fseg = $("#feedseg");
  const active = it.grid ? it.grid.cols * it.grid.rows : 0;
  Array.from(fseg.children).forEach(b =>
    b.setAttribute("aria-pressed", String(+b.dataset.feed === active)));
  $("#feedNote").hidden = !it.grid;
  const prev = S.items[S.cur - 1];
  $("#prevBtn").disabled = !prev || !prev.boxes.length;

  // crop previews
  const crops = $("#crops");
  crops.innerHTML = "";
  it.boxes.forEach((b, i) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "crop";
    btn.dataset.sel = String(i === S.sel);
    btn.style.setProperty("--bc", `var(${BOX_COLORS[i % BOX_COLORS.length]})`);
    const pv = document.createElement("div");
    pv.className = "pv";
    const gg = geo(it);
    pv.style.aspectRatio = `${b.w * gg.uw} / ${b.h * gg.uh}`;
    const pim = document.createElement("img");
    pim.src = it.url; pim.alt = "";
    pv.appendChild(pim);
    const cap = document.createElement("span");
    cap.className = "cap";
    cap.textContent = String(postNumber(it, i));
    btn.append(pv, cap);
    btn.addEventListener("click", () => { S.sel = i; renderStage(); renderRail(); });
    crops.appendChild(btn);
  });

  paintRot();
  layoutPreviews();
  updateReadout();
}

function updateReadout(){
  const it = cur();
  const b = it.boxes[S.sel];
  if (!b){
    $("#roPos").textContent = "—";
    $("#roSize").textContent = "—";
    $("#minwarn").hidden = true;
    return;
  }
  const uw = usableW(it), uh = usableH(it);
  const px = Math.round(b.x * uw), py = Math.round(b.y * uh);
  const pw = Math.round(b.w * uw), ph = Math.round(b.h * uh);
  $("#roPos").textContent = `${px}, ${py}`;
  $("#roSize").textContent = `${pw} × ${ph}`;
  const frame = outFrame(b);
  const under = !!frame && (pw < frame.w || ph < frame.h);
  $("#minwarn").hidden = !under;
}

function renderSettings(){
  const t = T();
  const seg = $("#ratioseg");
  if (!seg.children.length){
    RATIO_PRESETS.forEach(p => {
      const b = document.createElement("button");
      b.type = "button"; b.dataset.r = p.id;
      b.textContent = p.id === "free" ? t.free : p.id === "custom" ? t.custom : p.id;
      b.addEventListener("click", () => {
        if (p.id === "custom") markUse("custom");
        setRatio(p.id);
      });
      seg.appendChild(b);
    });
  }
  const it = cur();
  const box = it && it.boxes[S.sel];
  const gridOn = !!(it && it.grid);
  const one = S.ratioScope === "one" && !gridOn;
  const shown = one ? ratioOf(box) : {id:S.ratioId, w:S.rw, h:S.rh};
  const bc = one ? `var(${BOX_COLORS[S.sel % BOX_COLORS.length]})` : "var(--amber)";
  seg.classList.toggle("ofcrop", one);
  seg.style.setProperty("--bc", bc);
  $("#ratioPick").style.setProperty("--bc", bc);
  $("#ratioPick").textContent = one ? t.pickCrop(postNumber(it, S.sel)) : t.pickAll;
  $("#ratioNote").textContent = gridOn ? t.ratioNoteGrid : one ? t.ratioNoteOne : t.ratioNoteAll;
  Array.from($("#scopeseg").children).forEach(b => {
    b.setAttribute("aria-pressed", String((b.dataset.scope === "one") === one));
    if (b.dataset.scope === "one") b.disabled = gridOn || !box;
  });
  Array.from(seg.children).forEach(b =>
    b.setAttribute("aria-pressed", String(b.dataset.r === shown.id)));

  $("#customRatioRow").hidden = shown.id !== "custom";
  if (document.activeElement !== $("#rw") && document.activeElement !== $("#rh")){
    $("#rw").value = shown.w || S.rw; $("#rh").value = shown.h || S.rh;
  }

  Array.from($("#outseg").children).forEach(b =>
    b.setAttribute("aria-pressed", String(b.dataset.out === S.outMode)));
  $("#fixedRow").hidden = S.outMode !== "fixed";
  $("#fixedNote").hidden = ratioLocked();
  $("#ow").value = S.ow; $("#oh").value = S.oh;
  Array.from($("#outseg").children).forEach(b => {
    if (b.dataset.out === "fixed") b.disabled = !ratioLocked();
  });

  Array.from($("#fmtseg").children).forEach(b =>
    b.setAttribute("aria-pressed", String(b.dataset.fmt === S.fmt)));
  $("#qualityRow").hidden = S.fmt === "image/png";
  $("#quality").value = S.quality;
  $("#qval").textContent = S.quality;
  $("#pattern").value = S.pattern;
}

function renderProgress(){
  const t = T();
  const total = S.items.length;
  const done = S.items.filter(i => i.done).length;
  $("#doneCount").textContent = done;
  $("#doneTotal").textContent = t.imagesDone(done, total);
  $("#pbar").style.width = total ? (done / total * 100) + "%" : "0%";

  const files = S.items.filter(i => i.boxes.length > 0);
  const crops = files.reduce((a, i) => a + i.boxes.length, 0);
  $("#exportSummary").textContent = crops ? t.summary(crops, files.length) : t.summaryNone;
  $("#exportAll").disabled = !crops || S.busy;
  $("#exportOne").disabled = !cur() || cur().boxes.length === 0 || S.busy;
}

/* =====================================================================
   Mutations
   ===================================================================== */
function removeItem(i){
  const it = S.items[i];
  if (!it) return;
  URL.revokeObjectURL(it.url);
  S.items.splice(i, 1);
  if (S.cur >= S.items.length) S.cur = Math.max(0, S.items.length - 1);
  S.sel = 0;
  if (!S.items.length){
    $("#art").removeAttribute("data-id");
    $("#art").removeAttribute("src");
  }
  render();
}

function setCount(n){
  const it = cur();
  if (it.grid){ it.grid = null; it.gridRect = null; it.boxes = []; }
  if (n === it.boxes.length) return;
  if (n < it.boxes.length){
    it.boxes.length = n;
  } else if (it.boxes.length === 0){
    it.boxes = layoutBoxes(it, n, false);
  } else {
    while (it.boxes.length < n) it.boxes.push(placeNewBox(it));
  }
  S.sel = clamp(S.sel, 0, Math.max(0, it.boxes.length - 1));
  render();
}

function setRatio(id){
  const it = cur();
  /* "Selected crop" writes the ratio to that one box and leaves the batch
     alone. A feed grid lays its own tiles, so it always takes the batch. */
  if (S.ratioScope === "one" && it && !it.grid && it.boxes[S.sel]){
    const b = it.boxes[S.sel];
    b.rid = id;
    if (id === "custom"){ b.rw = S.rw; b.rh = S.rh; }
    refitBoxes(it);
    render();
    return;
  }
  S.ratioId = id;
  const p = RATIO_PRESETS.find(x => x.id === id);
  if (p && p.w){ S.rw = p.w; S.rh = p.h; }
  fitOutToRatio();
  if (id === "free" && S.outMode === "fixed") S.outMode = "native";
  if (id === "free") S.items.forEach(i => { if (i.grid){ i.grid = null; i.gridRect = null; } });
  S.items.forEach(i => { if (i.grid) clampGrid(i); });
  // the batch ratio is the whole batch: crops that had their own give it up
  S.items.forEach(i => i.boxes.forEach(b => { b.rid = null; }));
  refitAll();
  render();
  savePrefs();
}

function nudge(dir, big){
  const it = cur();
  const step = (big ? 0.02 : 0.0025);
  if (it.grid){
    const gr = it.gridRect;
    if (dir === "left")  gr.x -= step;
    if (dir === "right") gr.x += step;
    if (dir === "up")    gr.y -= step;
    if (dir === "down")  gr.y += step;
    if (dir === "bigger")  gr.w *= (big ? 1.08 : 1.02);
    if (dir === "smaller") gr.w *= (big ? 0.926 : 0.9804);
    clampGrid(it);
    afterBoxChange();
    return;
  }
  const b = it.boxes[S.sel];
  if (!b) return;
  const stepX = step, stepY = step;
  if (dir === "left")  b.x = clamp(b.x - stepX, 0, 1 - b.w);
  if (dir === "right") b.x = clamp(b.x + stepX, 0, 1 - b.w);
  if (dir === "up")    b.y = clamp(b.y - stepY, 0, 1 - b.h);
  if (dir === "down")  b.y = clamp(b.y + stepY, 0, 1 - b.h);
  if (dir === "bigger" || dir === "smaller"){
    const f = dir === "bigger" ? (big ? 1.08 : 1.02) : (big ? 0.926 : 0.9804);
    resizeBox(b, b.w * f, it);
  }
  afterBoxChange();
}

function resizeBox(b, newW, it){
  const cx = b.x + b.w/2, cy = b.y + b.h/2;
  let w = clamp(newW, 0.02, 1);
  let h = ratioLocked(b) ? hForW(w, it, b) : b.h * (w / b.w);
  if (h > 1){ h = 1; w = ratioLocked(b) ? wForH(h, it, b) : w; }
  h = clamp(h, 0.02, 1);
  b.w = w; b.h = h;
  b.x = clamp(cx - w/2, 0, 1 - w);
  b.y = clamp(cy - h/2, 0, 1 - h);
}

let rafPending = false;
function afterBoxChange(){
  positionBoxes();
  if (rafPending) return;
  rafPending = true;
  requestAnimationFrame(() => {
    rafPending = false;
    renderRail();
  });
}

/* =====================================================================
   Pointer interaction on the stage
   ===================================================================== */
(function setupStage(){
  const stage = $("#stage");
  let drag = null;

  stage.addEventListener("pointerdown", e => {
    const it = cur(); if (!it) return;
    const boxEl = e.target.closest(".box");
    const rect = stage.getBoundingClientRect();

    if (boxEl){
      const idx = +boxEl.dataset.idx;
      if (idx !== S.sel){ S.sel = idx; renderStage(); renderRail(); }
      const b = it.boxes[idx];
      const isGrip = !!e.target.dataset.grip;
      drag = {
        mode: it.grid ? (isGrip ? "gridsize" : "gridmove") : (isGrip ? "resize" : "move"),
        idx,
        rect,
        startX: e.clientX, startY: e.clientY,
        ox: b.x, oy: b.y, ow: b.w, oh: b.h,
        gr: it.gridRect ? Object.assign({}, it.gridRect) : null
      };
      stage.setPointerCapture(e.pointerId);
      e.preventDefault();
      return;
    }

    // clicking bare image: jump the selected box there
    if (!rect.width) return;
    const nx = (e.clientX - rect.left) / rect.width;
    const ny = (e.clientY - rect.top) / rect.height;
    if (it.grid){
      it.gridRect.x = nx - it.gridRect.w / 2;
      it.gridRect.y = ny - gridBlockH(it) / 2;
      clampGrid(it);
      afterBoxChange();
      return;
    }
    const b = it.boxes[S.sel];
    if (b){
      b.x = clamp(nx - b.w/2, 0, 1 - b.w);
      b.y = clamp(ny - b.h/2, 0, 1 - b.h);
      afterBoxChange();
    }
  });

  stage.addEventListener("pointermove", e => {
    if (!drag) return;
    const it = cur();
    const b = it.boxes[drag.idx];
    if (!b) return;
    const dx = (e.clientX - drag.startX) / drag.rect.width;
    const dy = (e.clientY - drag.startY) / drag.rect.height;

    if (drag.mode === "gridmove"){
      it.gridRect.x = drag.gr.x + dx;
      it.gridRect.y = drag.gr.y + dy;
      clampGrid(it);
    } else if (drag.mode === "gridsize"){
      it.gridRect.w = drag.gr.w + dx;
      clampGrid(it);
    } else if (drag.mode === "move"){
      b.x = clamp(drag.ox + dx, 0, 1 - b.w);
      b.y = clamp(drag.oy + dy, 0, 1 - b.h);
    } else {
      if (ratioLocked(b)){
        const w = clamp(drag.ow + dx, 0.02, 1 - drag.ox);
        let h = hForW(w, it, b);
        if (drag.oy + h > 1){ h = 1 - drag.oy; }
        b.w = wForH(h, it, b);
        b.h = h;
        if (b.w > 1 - drag.ox){ b.w = 1 - drag.ox; b.h = hForW(b.w, it, b); }
      } else {
        b.w = clamp(drag.ow + dx, 0.02, 1 - drag.ox);
        b.h = clamp(drag.oh + dy, 0.02, 1 - drag.oy);
      }
    }
    afterBoxChange();
    e.preventDefault();
  });

  const end = e => {
    if (!drag) return;
    drag = null;
    try { stage.releasePointerCapture(e.pointerId); } catch {}
    renderRail();
  };
  stage.addEventListener("pointerup", end);
  stage.addEventListener("pointercancel", end);

  stage.addEventListener("wheel", e => {
    const it = cur(); if (!it) return;
    const b = it.boxes[S.sel]; if (!b) return;
    e.preventDefault();
    if (it.grid){
      const gr = it.gridRect;
      if (e.ctrlKey || e.metaKey) gr.w *= (e.deltaY > 0 ? 0.97 : 1.03);
      else { gr.x += (e.deltaX || 0) * 0.0006; gr.y += (e.deltaY || 0) * 0.0006; }
      clampGrid(it); afterBoxChange();
      return;
    }
    if (e.ctrlKey || e.metaKey){
      resizeBox(b, b.w * (e.deltaY > 0 ? 0.97 : 1.03), it);
    } else {
      b.x = clamp(b.x + (e.deltaX || 0) * 0.0006, 0, 1 - b.w);
      b.y = clamp(b.y + (e.deltaY || 0) * 0.0006, 0, 1 - b.h);
    }
    afterBoxChange();
  }, {passive:false});
})();

/* =====================================================================
   Nudge pad with press-and-hold repeat
   ===================================================================== */
$$("[data-nudge]").forEach(btn => {
  let timer = null, delay = 260;
  const go = big => nudge(btn.dataset.nudge, big);
  const start = e => {
    if (S.busy) return;
    markUse("nudge");
    go(e.shiftKey);
    delay = 260;
    const tick = () => {
      go(e.shiftKey);
      delay = Math.max(40, delay * 0.72);
      timer = setTimeout(tick, delay);
    };
    timer = setTimeout(tick, delay);
  };
  const stop = () => { if (timer){ clearTimeout(timer); timer = null; } };
  btn.addEventListener("pointerdown", e => { e.preventDefault(); start(e); });
  ["pointerup","pointerleave","pointercancel"].forEach(ev => btn.addEventListener(ev, stop));
});

/* =====================================================================
   Keyboard
   ===================================================================== */
document.addEventListener("keydown", e => {
  if (!S.items.length || S.busy || signinOpen()) return;
  const tag = (e.target.tagName || "").toLowerCase();
  if (tag === "input" || tag === "select" || tag === "textarea") return;

  const it = cur();
  if (e.key >= "1" && e.key <= "6"){
    const i = +e.key - 1;
    if (i < it.boxes.length){ S.sel = i; renderStage(); renderRail(); e.preventDefault(); }
    return;
  }
  const map = {ArrowLeft:"left", ArrowRight:"right", ArrowUp:"up", ArrowDown:"down"};
  if (map[e.key]){ markUse("nudge"); nudge(map[e.key], e.shiftKey); e.preventDefault(); return; }
  if (e.key === "+" || e.key === "="){ markUse("nudge"); nudge("bigger", e.shiftKey); e.preventDefault(); return; }
  if (e.key === "-" || e.key === "_"){ markUse("nudge"); nudge("smaller", e.shiftKey); e.preventDefault(); return; }
  if (e.key === "Enter"){ confirmNext(); e.preventDefault(); return; }
  if (e.key === "["){ S.cur = clamp(S.cur - 1, 0, S.items.length - 1); S.sel = 0; render(); e.preventDefault(); return; }
  if (e.key === "]"){ S.cur = clamp(S.cur + 1, 0, S.items.length - 1); S.sel = 0; render(); e.preventDefault(); return; }
});

function confirmNext(){
  const it = cur();
  it.done = true;
  if (S.cur < S.items.length - 1){
    S.cur++; S.sel = 0;
    /* An image nobody has opened yet only holds the default single box, so
       it starts from the boxes just confirmed instead. One already visited
       keeps whatever it has. */
    const next = cur();
    if (!next.seen && !it.isSample && it.boxes.length) copyBoxes(it, next);
  }
  render();
}

/* =====================================================================
   Export
   ===================================================================== */
function extFor(mime){
  return mime === "image/png" ? "png" : mime === "image/jpeg" ? "jpg" : "webp";
}
function sanitize(s){
  return s.replace(/[\x00-\x1f\x7f<>:"/\\|?*]+/g, "_").replace(/\s+/g, " ").replace(/^[. ]+|[. ]+$/g, "").slice(0, 120) || "crop";
}
const PATTERN_DEFAULT = "{name}-d{n}";
const PATTERN_GRID    = "{name}-post{nn}";

function fileNameFor(item, idx, imgIdx, ow, oh){
  const n = postNumber(item, idx);
  // Feed tiles are posted in a strict order, so say so in the name — unless
  // the user has written their own pattern, which always wins.
  const pattern = (item.grid && S.pattern === PATTERN_DEFAULT) ? PATTERN_GRID : S.pattern;
  const out = pattern
    .replace(/\{name\}/g, item.name)
    .replace(/\{nn\}/g, String(n).padStart(2, "0"))
    .replace(/\{n\}/g, String(n))
    .replace(/\{i\}/g, String(imgIdx + 1))
    .replace(/\{w\}/g, String(ow))
    .replace(/\{h\}/g, String(oh));
  return sanitize(out) + "." + extFor(S.fmt);
}

/* The fixed output frame is written for the batch ratio. A crop that carries
   its own gets a frame of the same area, so every file still lands in the same
   resolution class instead of one of them coming out twice the size. */
function outFrame(b){
  if (!(S.outMode === "fixed" && ratioLocked())) return null;
  const r = ratioOf(b);
  if (!b || !b.rid) return {w: S.ow, h: S.oh};
  if (!r.locked) return null;                       // a free crop keeps its own pixels
  const area = S.ow * S.oh, k = r.w / r.h;
  return {w: Math.max(1, Math.round(Math.sqrt(area * k))),
          h: Math.max(1, Math.round(Math.sqrt(area / k)))};
}

function drawCrop(img, b, item){
  const g = geo(item);
  const uw = g.uw, uh = g.uh;
  const sw = Math.max(1, Math.round(b.w * uw));
  const sh = Math.max(1, Math.round(b.h * uh));

  let ow, oh;
  const frame = outFrame(b);
  if (frame){ ow = frame.w; oh = frame.h; }
  else { ow = sw; oh = sh; }

  // step down in halves for a clean downscale
  let cw = sw, ch = sh;
  let canvas = document.createElement("canvas");
  canvas.width = cw; canvas.height = ch;
  let ctx = canvas.getContext("2d");
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  // this crop's top-left corner in warped space
  const q0x = g.ox + (b.x - 0.5) * uw;
  const q0y = g.oy + (b.y - 0.5) * uh;

  if (!warped(item)){
    ctx.drawImage(img, Math.round(b.x * uw), Math.round(b.y * uh), sw, sh, 0, 0, cw, ch);
  } else if (!keystoned(item)){
    // rotation alone is affine, so canvas can do it
    const M = g.M;
    ctx.translate(-q0x, -q0y);
    ctx.transform(M[0], M[3], M[1], M[4], 0, 0);
    ctx.translate(-item.w / 2, -item.h / 2);
    ctx.drawImage(img, 0, 0);
    ctx.setTransform(1, 0, 0, 1, 0, 0);
  } else {
    warpGL(ctx, img, item, g, q0x, q0y, sw, sh);
  }

  while (cw / 2 > ow && ch / 2 > oh){
    const nw = Math.max(ow, Math.round(cw / 2));
    const nh = Math.max(oh, Math.round(ch / 2));
    const c2 = document.createElement("canvas");
    c2.width = nw; c2.height = nh;
    const x2 = c2.getContext("2d");
    x2.imageSmoothingEnabled = true;
    x2.imageSmoothingQuality = "high";
    x2.drawImage(canvas, 0, 0, cw, ch, 0, 0, nw, nh);
    // hand the bigger step back now rather than at some later GC: on a
    // phone the next crop needs that memory
    canvas.width = canvas.height = 0;
    canvas = c2; ctx = x2; cw = nw; ch = nh;
  }

  if (cw !== ow || ch !== oh){
    const c3 = document.createElement("canvas");
    c3.width = ow; c3.height = oh;
    const x3 = c3.getContext("2d");
    x3.imageSmoothingEnabled = true;
    x3.imageSmoothingQuality = "high";
    x3.drawImage(canvas, 0, 0, cw, ch, 0, 0, ow, oh);
    canvas.width = canvas.height = 0;
    canvas = c3;
  }
  return {canvas, ow, oh};
}

function toBlob(canvas, mime, q){
  return new Promise(res => canvas.toBlob(b => res(b), mime, q));
}

/* A browser that runs short of memory does not throw: the draw quietly does
   not happen, and the empty canvas still encodes — as an all-black JPEG, or
   a clear PNG. The screen looks fine throughout, since it never needs the
   picture at full size. So a crop of a picture with no see-through parts is
   looked at before it is written. */
function looksEmpty(canvas){
  const p = document.createElement("canvas");
  p.width = p.height = 16;
  const x = p.getContext("2d", {willReadFrequently: true});
  x.drawImage(canvas, 0, 0, 16, 16);
  const d = x.getImageData(0, 0, 16, 16).data;
  for (let k = 3; k < d.length; k += 4) if (d[k] > 8) return false;
  return true;
}

/* One crop, made and encoded. An empty result is tried again from a fresh
   object URL, so the browser decodes the file from scratch instead of
   reusing a decode that already failed, after a pause that lets it free
   what the failed try held. Null when every try came back empty. */
async function cropFile(item, img, b){
  for (let attempt = 0; attempt < 3; attempt++){
    let url = null;
    if (attempt){
      await new Promise(r => setTimeout(r, 500 * attempt));
      url = URL.createObjectURL(item.file);
      try { img = await loadImage(url); }
      catch { URL.revokeObjectURL(url); continue; }
    }
    const {canvas, ow, oh} = drawCrop(img, b, item);
    if (url) URL.revokeObjectURL(url);
    if (!item.alpha && looksEmpty(canvas)){
      canvas.width = canvas.height = 0;
      continue;
    }
    const blob = await toBlob(canvas, S.fmt, S.fmt === "image/png" ? undefined : S.quality / 100);
    canvas.width = canvas.height = 0;
    if (blob) return {blob, ow, oh};
  }
  return null;
}

async function runExport(only){
  if (S.busy) return;
  const targets = (only ? [cur()] : S.items).filter(i => i.boxes.length > 0);
  const totalCrops = targets.reduce((a, i) => a + i.boxes.length, 0);
  if (!totalCrops){ flash(T().nothing, true); return; }

  S.busy = true;
  renderProgress();
  const btn = only ? $("#exportOne") : $("#exportAll");
  const label = btn.textContent;
  const used = new Map();
  const entries = [];
  let n = 0, failed = 0;

  try {
    for (const item of targets){
      const imgIdx = S.items.indexOf(item);
      const img = await loadImage(item.url);
      let missed = 0;
      for (let i = 0; i < item.boxes.length; i++){
        const got = await cropFile(item, img, item.boxes[i]);
        // left out and said so, never written as a black file
        if (!got){ missed++; continue; }
        const {blob, ow, oh} = got;
        let name = fileNameFor(item, i, imgIdx, ow, oh);
        if (used.has(name)){
          const c = used.get(name) + 1;
          used.set(name, c);
          name = name.replace(/(\.[^.]+)$/, `-${c}$1`);
        } else used.set(name, 1);
        entries.push({name, data: new Uint8Array(await blob.arrayBuffer())});
        n++;
        btn.textContent = T().exporting(n, totalCrops);
        await new Promise(r => setTimeout(r, 0));
      }
      failed += missed;
      if (!missed) item.done = true;
    }

    if (!entries.length){ flash(T().failed(failed), true); return; }
    const zip = makeZip(entries);
    const stamp = new Date().toISOString().slice(0, 10);
    saveBlob(zip, `crops-${stamp}.zip`);
    if (failed) flash(T().exported(entries.length) + " " + T().failed(failed), true);
    else flash(T().exported(entries.length), false);
    const shape = {
      n: targets.length,
      crops: entries.length,
      ratio: ratioTag(targets), out: S.outMode,
      grid: targets.reduce((a, t) => Math.max(a, t.grid ? t.boxes.length : 0), 0),
      ow: S.outMode === "fixed" ? S.ow : 0,
      oh: S.outMode === "fixed" ? S.oh : 0
    };
    const sample = targets.every(t => t.isSample);
    track("export", Object.assign({
      sample: sample ? 1 : 0,
      fmt: S.fmt,
      rot: Math.round(targets.reduce((a, t) => Math.max(a, Math.abs(rotOf(t))), 0) * 10) / 10,
      persp: targets.reduce((a, t) => Math.max(a, Math.abs(khOf(t)), Math.abs(kvOf(t))), 0),
      q: S.quality,
      secs: elapsedSecs()
    }, shape));
    if (!sample) offerWhy(shape);
  } catch (err){
    console.error(err);
    flash(String(err && err.message || err), true);
  } finally {
    btn.textContent = label;
    S.busy = false;
    render();
  }
}

function saveBlob(blob, filename){
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}

let flashTimer = null;
function flash(msg, isWarn){
  const el = $("#exportMsg");
  el.hidden = false;
  el.textContent = msg;
  el.className = isWarn ? "warn" : "okmsg";
  clearTimeout(flashTimer);
  flashTimer = setTimeout(() => { el.hidden = true; }, 6000);
}

/* =====================================================================
   Wiring
   ===================================================================== */
$$(".langs button").forEach(b => b.addEventListener("click", () => {
  S.lang = b.dataset.lang;
  applyLang();
  savePrefs();
}));

$("#pickBtn").addEventListener("click", () => $("#fileInput").click());

/* the plate that dresses the hero doubles as the try-it-now sample */
$("#drop").style.backgroundImage = `url(${DEMO})`;
async function loadSample(){
  if (S.items.some(i => i.isSample)) return;
  const blob = await (await fetch(DEMO)).blob();
  const f = new File([blob], `${T().sampleName}.webp`, {type:"image/webp"});
  await addFiles([f], true);
  const it = S.items.find(i => i.isSample);
  if (it){
    it.boxes = layoutBoxes(it, 1, false);
    while (it.boxes.length < MAX_CROPS) it.boxes.push(placeNewBox(it));
    S.sel = MAX_CROPS - 1;
    render();
  }
}
$("#sampleBtn").addEventListener("click", async () => {
  markUse("sample");
  const btn = $("#sampleBtn");
  btn.disabled = true;
  try { await loadSample(); } catch (err){ console.error(err); }
  finally { btn.disabled = false; }
});
$("#fileInput").addEventListener("change", e => {
  if (e.target.files && e.target.files.length) addFiles(e.target.files);
  e.target.value = "";
});

const dzTarget = () => $("#drop").hidden ? $("#strip") : $("#drop");
["dragenter","dragover"].forEach(ev => document.addEventListener(ev, e => {
  e.preventDefault();
  dzTarget().classList.add("hot");
}));
["dragleave","drop"].forEach(ev => document.addEventListener(ev, e => {
  e.preventDefault();
  if (ev === "dragleave" && e.relatedTarget) return;
  $("#drop").classList.remove("hot");
  $("#strip").classList.remove("hot");
}));
document.addEventListener("drop", e => {
  e.preventDefault();
  if (e.dataTransfer && e.dataTransfer.files.length) addFiles(e.dataTransfer.files);
});

$("#autoBtn").addEventListener("click", () => {
  markUse("auto");
  const it = cur();
  it.grid = null; it.gridRect = null;
  it.boxes = layoutBoxes(it, Math.max(1, it.boxes.length), false);
  render();
});
$("#spreadBtn").addEventListener("click", () => {
  markUse("spread");
  const it = cur();
  it.grid = null; it.gridRect = null;
  it.boxes = layoutBoxes(it, Math.max(1, it.boxes.length), true);
  render();
});
Array.from($("#feedseg").children).forEach(b =>
  b.addEventListener("click", () => {
    if (+b.dataset.feed) markUse("grid");
    applyFeedGrid(+b.dataset.feed);
  }));
$("#prevBtn").addEventListener("click", () => {
  markUse("prev");
  const from = S.items[S.cur - 1];
  if (!from || !from.boxes.length) return;
  copyBoxes(from, cur());
  S.sel = 0;
  render();
});
$("#nextBtn").addEventListener("click", confirmNext);

let gridTimer = null;
function showGuide(on){
  const g = $("#sgrid");
  clearTimeout(gridTimer);
  if (on) g.classList.add("on");
  else gridTimer = setTimeout(() => g.classList.remove("on"), 700);
}
function paintGauge(sel, btn, v, max, text){
  const el = $(sel), row = el.closest(".rotrow"), b = $(btn);
  el.value = String(v);
  b.textContent = text;
  b.title = T().resetZero;
  row.style.setProperty("--p", String(v / max));   // drives the centre-out fill
  row.dataset.live = v ? "1" : "0";
}
function paintRot(){
  const it = cur(), t = T();
  const r = rotOf(it), kh = khOf(it), kv = kvOf(it);
  paintGauge("#rotSlider", "#rotReset", r, 15, (r > 0 ? "+" : "") + r.toFixed(1) + "\u00B0");
  paintGauge("#khSlider", "#khReset", kh, 100, (kh > 0 ? "+" : "") + kh);
  paintGauge("#kvSlider", "#kvReset", kv, 100, (kv > 0 ? "+" : "") + kv);

  // what the folded header says about this image
  const bits = [];
  if (r)  bits.push((r > 0 ? "+" : "") + r.toFixed(1) + "\u00B0");
  if (kh) bits.push(t.kHoriz + " " + (kh > 0 ? "+" : "") + kh);
  if (kv) bits.push(t.kVert + " " + (kv > 0 ? "+" : "") + kv);
  $("#alignSum").textContent = bits.join(" \u00B7 ");
  $("#alignPanel").dataset.live = bits.length ? "1" : "0";
}
function applyWarp(field, v){
  const it = cur(); if (!it) return;
  if (field === "rot"){
    let r = Math.max(-15, Math.min(15, v || 0));
    if (Math.abs(r) < 0.15) r = 0;                 // snap to level
    it.rot = r;
  } else {
    let n = Math.max(-100, Math.min(100, Math.round(v || 0)));
    if (Math.abs(n) < 2) n = 0;                    // snap to square
    it[field] = n;
  }
  paintRot();
  layoutStage(); positionBoxes(); layoutPreviews(); updateReadout();
}
[["#rotSlider", "#rotReset", "rot"],
 ["#khSlider",  "#khReset",  "kh"],
 ["#kvSlider",  "#kvReset",  "kv"]].forEach(([sel, btn, field]) => {
  const el = $(sel);
  el.addEventListener("input", e => {
    markUse(field === "rot" ? "rot" : "persp");
    showGuide(true); applyWarp(field, parseFloat(e.target.value));
  });
  el.addEventListener("pointerdown", () => showGuide(true));
  ["pointerup", "blur", "change"].forEach(ev => el.addEventListener(ev, () => showGuide(false)));
  $(btn).addEventListener("click", () => { showGuide(true); applyWarp(field, 0); showGuide(false); });
});
/* The alignment tools are the block earmarked to go behind a paywall later.
   Everything they need lives inside #alignPanel, so gating them means
   refusing to open this one section. */
$("#alignToggle").addEventListener("click", e => {
  const btn = e.currentTarget;
  const open = btn.getAttribute("aria-expanded") !== "true";
  btn.setAttribute("aria-expanded", String(open));
  $("#alignBody").hidden = !open;
  if (open) layoutPreviews();          // the rows were unmeasurable while hidden
});

// no WebGL means no keystone; rotation still works everywhere
(function(){
  let ok = false;
  try { ok = !!document.createElement("canvas").getContext("webgl"); } catch (e){}
  if (!ok) $("#perspRows").hidden = true;
})();

function setCustomSide(field, v){
  if (!(v > 0)) return;
  const it = cur();
  const b = it && it.boxes[S.sel];
  if (S.ratioScope === "one" && it && !it.grid && b){
    if (!b.rid || b.rid !== "custom"){ b.rw = S.rw; b.rh = S.rh; b.rid = "custom"; }
    b[field] = v;
    refitBoxes(it);
  } else {
    S[field] = v;
    fitOutToRatio();
    S.items.forEach(i => i.boxes.forEach(x => { x.rid = null; }));
    refitAll();
  }
  render();
}
$("#rw").addEventListener("input", e => setCustomSide("rw", parseInt(e.target.value, 10)));
$("#rh").addEventListener("input", e => setCustomSide("rh", parseInt(e.target.value, 10)));

Array.from($("#scopeseg").children).forEach(b => b.addEventListener("click", () => {
  if (b.disabled) return;
  S.ratioScope = b.dataset.scope;
  if (S.ratioScope === "one") markUse("scope");
  /* coming back to the whole batch puts every crop on the one ratio again, so
     the toggle always says what the crops are actually doing */
  if (S.ratioScope === "all") setRatio(S.ratioId);
  else render();
}));

Array.from($("#outseg").children).forEach(b => b.addEventListener("click", () => {
  if (b.disabled) return;
  S.outMode = b.dataset.out;
  render();
  savePrefs();
}));
$("#ow").addEventListener("input", e => {
  const v = parseInt(e.target.value, 10);
  if (v > 0){ S.ow = v; S.oh = Math.max(1, Math.round(v / ratioVal())); $("#oh").value = S.oh; updateReadout(); }
});
$("#oh").addEventListener("input", e => {
  const v = parseInt(e.target.value, 10);
  if (v > 0){ S.oh = v; S.ow = Math.max(1, Math.round(v * ratioVal())); $("#ow").value = S.ow; updateReadout(); }
});

Array.from($("#fmtseg").children).forEach(b => b.addEventListener("click", () => {
  S.fmt = b.dataset.fmt;
  renderSettings();
  savePrefs();
}));
$("#quality").addEventListener("input", e => {
  S.quality = +e.target.value;
  $("#qval").textContent = S.quality;
});
$("#pattern").addEventListener("input", e => { S.pattern = e.target.value || "{name}-d{n}"; });

$("#exportAll").addEventListener("click", () => runExport(false));
$("#exportOne").addEventListener("click", () => runExport(true));
$("#clearAll").addEventListener("click", () => {
  if (!confirm(T().confirmClear)) return;
  S.items.forEach(i => URL.revokeObjectURL(i.url));
  S.items = []; S.cur = 0; S.sel = 0;
  addedAt = 0;
  $("#art").removeAttribute("data-id");
  $("#art").removeAttribute("src");
  render();
  loadSample().catch(err => console.error(err));
});

window.addEventListener("resize", () => { layoutStage(); positionBoxes(); layoutPreviews(); });

/* ---- remember settings between visits ---- */
const PREF_KEYS = ["lang","ratioId","rw","rh","outMode","ow","oh","fmt","quality","pattern","wide"];
function savePrefs(){
  try {
    const o = {};
    PREF_KEYS.forEach(k => o[k] = S[k]);
    localStorage.setItem("mc.prefs", JSON.stringify(o));
  } catch {}
}
function loadPrefs(){
  let o = null;
  try { o = JSON.parse(localStorage.getItem("mc.prefs") || "null"); } catch {}
  if (!o || typeof o !== "object") return;
  PREF_KEYS.forEach(k => {
    if (o[k] === undefined || o[k] === null) return;
    if (typeof S[k] === "boolean") S[k] = !!o[k];
    else if (typeof S[k] === "number"){ const n = +o[k]; if (Number.isFinite(n) && n > 0) S[k] = n; }
    else if (typeof S[k] === "string") S[k] = String(o[k]);
  });
  if (!I18N[S.lang]) S.lang = I18N[PAGE_LANG] ? PAGE_LANG : detectLang();
  if (!RATIO_PRESETS.some(r => r.id === S.ratioId)) S.ratioId = "2:3";
  if (!["native","fixed"].includes(S.outMode)) S.outMode = "native";
  if (!["image/webp","image/jpeg","image/png"].includes(S.fmt)) S.fmt = "image/webp";
  S.quality = clamp(S.quality, 40, 100);
  if (S.ratioId === "free" && S.outMode === "fixed") S.outMode = "native";
  fitOutToRatio();
}
document.addEventListener("change", savePrefs);
window.addEventListener("beforeunload", savePrefs);

/* =====================================================================
   Anonymous usage stats.
   What leaves the browser: which settings were chosen, how many images
   were in the batch, and how big they were. What never leaves: the
   images. There is no code path here that reads pixel data.
   ===================================================================== */
const STATS_KEY = "dc.stats";
let STATS = (function(){
  try { return JSON.parse(localStorage.getItem(STATS_KEY) || "{}") || {}; }
  catch { return {}; }
})();
if (!STATS.id){
  STATS.id = Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
  STATS.visits = 0;
}
function statsSave(){
  try { localStorage.setItem(STATS_KEY, JSON.stringify(STATS)); } catch {}
}
function statsMuted(){
  // navigator.webdriver is true in Playwright/Puppeteer/Selenium, which is what
  // most crawlers that execute JS are driving. Cheap, and it keeps scanner hits
  // out of the numbers.
  return !!STATS.off || navigator.webdriver === true
      || navigator.doNotTrack === "1" || window.doNotTrack === "1";
}
function median(list){
  if (!list.length) return 0;
  const a = list.slice().sort((x, y) => x - y);
  return a[Math.floor(a.length / 2)];
}
function track(){}
/* When the first file of a run landed. Reset when the batch is cleared, so a
   second run in the same tab is timed from its own start, not the first one. */
let addedAt = 0;
function markAdded(){ if (!addedAt) addedAt = Date.now(); }
function elapsedSecs(){
  if (!addedAt) return 0;
  // capped so a tab left open overnight cannot drag the average
  return Math.min(1800, Math.round((Date.now() - addedAt) / 1000));
}
/* One beacon per feature per page load — the arrow nudges alone would otherwise
   fire dozens of times in a single session. */
const usedFeatures = new Set();
function markUse(feat){
  if (usedFeatures.has(feat)) return;
  usedFeatures.add(feat);
  track("use", { feat: feat });
}
/* The ratio an export carried. Crops can hold ratios of their own (the scope
   toggle), so the batch ratio alone would misreport a mixed export. */
function ratioTag(targets){
  const seen = new Map();
  targets.forEach(t => t.boxes.forEach(b => {
    const r = ratioOf(b);
    seen.set(r.id === "custom" ? r.w + ":" + r.h : r.id, r.id);
  }));
  if (seen.size > 1) return "mixed";
  return seen.size ? seen.values().next().value : S.ratioId;
}

/* What the batch was for. The numbers above say what people do, not who they
   are, so after the first export of the visitor's own images the page asks
   once: fixed choices, any number of them, nothing typed. Only while stats
   are on — with them off there is nowhere for an answer to go. Each answer
   carries the shape of the export it followed, so a purpose reads next to
   its crops per image without a JOIN. "Once" is literal: the box stays up for
   the rest of that visit, and a browser that has seen it is not asked again.
   A skip is recorded too.
   Below it, one optional line about the person: what they do for a living.
   Five fixed choices, one at most, and "Other" opens a short box for their
   own words. That box is the only typed thing the page ever sends, so it is
   capped at 30 characters and anything that looks like contact details is
   dropped, here and again in the Worker (cleanJob in src/index.js). */
function offerWhy(){} function paintStatsToggle(){}

/* =====================================================================
   Today's numbers, for the owner only.
   Visible when this browser holds the stats key (set once by opening
   /?admin=<STATS_KEY>). Visitors never see it — a public counter showing
   single digits is worse than no counter.
   ===================================================================== */
function paintToday(){}

/* Contact. Assembled at runtime so the served HTML holds no scrapable address.
   To change it, edit the three parts below and nothing else. */
const MAIL_USER = "contact";
const MAIL_HOST = "detailcrop.com";
function wireMail(){
  const addr = MAIL_USER + String.fromCharCode(64) + MAIL_HOST;
  const a = $("#mailLink");
  a.textContent = addr;
  a.href = "mailto:" + addr + "?subject=" + encodeURIComponent("DetailCrop");
}

/* =====================================================================
   Presets — a member's saved setups, kept in their account.
   The format and its cleaning rules live in src/preset.js, which build.py
   pastes in right here, so the page and the server read presets alike.
   Sign-in is lottodraw.kr's: Google's button hands over an ID token, the
   Worker checks it and answers with a session. Until the Worker has a
   Google client ID the whole panel stays hidden.
   ===================================================================== */
/**
 * The preset format — the one place it is defined.
 *
 * A preset is how a job is set up, never what is in it: ratio, output size,
 * format, quality, file names, feed split and where the boxes sit. No image,
 * no file name, no straighten or perspective values (those belong to one
 * photo, not to a job).
 *
 * This file is used twice. The Worker imports it to clean whatever a browser
 * sends before it is stored in an account, and build.py pastes it into the
 * stills page (at the PRESET_FORMAT marker, with `export` taken off) so the
 * page builds and reads presets by the very same rules. A later ?preset= link
 * or a list of shop specs only has to produce an object cleanPreset() accepts.
 *
 *   { v: 1, id, name, at,
 *     ratio:  { id, w, h, scope: "all" | "one" },
 *     out:    { mode: "native" | "fixed", w, h },
 *     fmt, quality, pattern,
 *     layout: { grid:  null | { cols, rows, x, y, w },
 *               boxes: [ { x, y, w, h, r: null | { id, w, h } } ] } }
 *
 *   An account holds { list: [preset…], last: id } — `last` is the one loaded
 *   or saved most recently.
 *
 * Box and grid positions are fractions of the working area: the coordinates
 * "Same boxes as previous image" already copies between images, so a preset
 * lands on an image of any size or shape the same way.
 *
 * Everything here is prefixed `preset`, because it shares the page's scope.
 */
const PRESET_V = 1;
const PRESET_MAX = 50;              // per account
const PRESET_NAME_MAX = 60;
/* keep in step with RATIO_PRESETS in template.html */
const PRESET_RATIOS = {
  "free": [0, 0], "1:1": [1, 1], "4:5": [4, 5], "2:3": [2, 3], "3:4": [3, 4],
  "5:7": [5, 7], "16:9": [16, 9], "9:16": [9, 16], "custom": [0, 0]
};
const PRESET_FORMATS = ["image/webp", "image/jpeg", "image/png"];
const PRESET_BOXES = 6;                    // MAX_CROPS on the page
const PRESET_SIDE = 16384;                 // MAX_SIDE on the page
const PRESET_ID_RE = /^[a-z0-9]{6,24}$/;

function presetNum(v, lo, hi, dflt){
  const n = Number(v);
  return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : dflt;
}
function presetInt(v, lo, hi, dflt){ return Math.round(presetNum(v, lo, hi, dflt)); }
function presetText(v, max){
  return String(v == null ? "" : v).normalize("NFC").replace(/[\x00-\x1f\x7f]+/g, " ").trim().slice(0, max);
}

/* {id, w, h} for a known ratio id, null for anything else */
function presetRatio(r){
  if (!r || typeof r !== "object" || !Object.prototype.hasOwnProperty.call(PRESET_RATIOS, r.id)) return null;
  if (r.id === "custom") return {id: "custom", w: presetInt(r.w, 1, 999, 1), h: presetInt(r.h, 1, 999, 1)};
  const p = PRESET_RATIOS[r.id];
  return {id: r.id, w: p[0], h: p[1]};
}

/* A clean preset, or null when there is nothing usable in it. */
function cleanPreset(o){
  if (!o || typeof o !== "object") return null;
  const name = presetText(o.name, PRESET_NAME_MAX);
  const id = typeof o.id === "string" && PRESET_ID_RE.test(o.id) ? o.id : null;
  if (!name || !id) return null;

  const r0 = o.ratio && typeof o.ratio === "object" ? o.ratio : {};
  const ratio = presetRatio(r0) || {id: "2:3", w: 2, h: 3};
  ratio.scope = r0.scope === "one" ? "one" : "all";
  const locked = ratio.id !== "free";

  const o0 = o.out && typeof o.out === "object" ? o.out : {};
  const out = {
    mode: o0.mode === "fixed" && locked ? "fixed" : "native",
    w: presetInt(o0.w, 1, PRESET_SIDE, 1600),
    h: presetInt(o0.h, 1, PRESET_SIDE, 2400)
  };

  const L = o.layout && typeof o.layout === "object" ? o.layout : {};
  let grid = null;
  if (L.grid && typeof L.grid === "object" && locked){
    const g = L.grid;
    grid = { cols: 3, rows: presetInt(g.rows, 1, 3, 1),
             x: presetNum(g.x, 0, 1, 0), y: presetNum(g.y, 0, 1, 0), w: presetNum(g.w, 0.12, 1, 0.92) };
  }
  const boxes = grid ? [] : (Array.isArray(L.boxes) ? L.boxes : []).slice(0, PRESET_BOXES)
    .filter(b => b && typeof b === "object")
    .map(b => {
      const w = presetNum(b.w, 0.02, 1, 0.3), h = presetNum(b.h, 0.02, 1, 0.3);
      return { x: presetNum(b.x, 0, 1 - w, 0), y: presetNum(b.y, 0, 1 - h, 0), w, h,
               r: ratio.scope === "one" ? presetRatio(b.r) : null };
    });

  return {
    v: PRESET_V, id, name,
    at: presetInt(o.at, 0, 1e13, 0),
    ratio, out,
    fmt: PRESET_FORMATS.indexOf(o.fmt) >= 0 ? o.fmt : "image/webp",
    quality: presetInt(o.quality, 40, 100, 86),
    pattern: presetText(o.pattern, 120) || "{name}-d{n}",
    layout: { grid, boxes }
  };
}

/* What an account holds: the presets, newest first as stored, and the last used. */
function cleanPresetBook(o){
  const list = [], seen = {};
  const src = o && typeof o === "object" && Array.isArray(o.list) ? o.list : [];
  for (const p of src){
    if (list.length >= PRESET_MAX) break;
    const c = cleanPreset(p);
    if (c && !seen[c.id]){ seen[c.id] = 1; list.push(c); }
  }
  const last = o && typeof o.last === "string" && seen[o.last] ? o.last : "";
  return { list, last };
}

const ACCT_STORE = "dc.account";
const A = {
  on: false, client: "",          // the Worker has sign-in turned on, and its client ID
  session: "", user: null,        // this browser's sign-in
  book: {list: [], last: ""},     // the account's presets
  busy: false,
  after: null                     // what to finish once sign-in succeeds
};

function newPresetId(){
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

/* The setup on screen as a preset. Box positions come from the current
   image, as fractions of its working area. */
function presetFrom(name, id){
  const it = cur();
  const layout = {grid: null, boxes: []};
  if (it && it.grid){
    layout.grid = {cols: it.grid.cols, rows: it.grid.rows,
                   x: it.gridRect.x, y: it.gridRect.y, w: it.gridRect.w};
  } else if (it){
    layout.boxes = it.boxes.map(b => ({x: b.x, y: b.y, w: b.w, h: b.h,
      r: b.rid ? {id: b.rid, w: b.rw, h: b.rh} : null}));
  }
  return cleanPreset({
    id: id || newPresetId(), name, at: Date.now(),
    ratio: {id: S.ratioId, w: S.rw, h: S.rh, scope: S.ratioScope},
    out: {mode: S.outMode, w: S.ow, h: S.oh},
    fmt: S.fmt, quality: S.quality, pattern: S.pattern, layout
  });
}

/* A preset's layout in the shape copyBoxes() takes from an image */
function presetSource(p){
  const L = p.layout;
  if (L.grid) return {grid: {cols: L.grid.cols, rows: L.grid.rows},
                      gridRect: {x: L.grid.x, y: L.grid.y, w: L.grid.w}, boxes: []};
  return {grid: null, gridRect: null, boxes: L.boxes.map(b => ({
    x: b.x, y: b.y, w: b.w, h: b.h,
    rid: b.r ? b.r.id : null, rw: b.r ? b.r.w : undefined, rh: b.r ? b.r.h : undefined
  }))};
}

/* Settings belong to the batch, so they reach every image the way the
   buttons do: boxes keep their centre and take the new ratio. The box layout
   reaches only this image, images not opened yet and images added from now
   on — the line Confirm & next already draws. An image someone has opened
   may hold work, so it keeps its boxes. */
function applyPreset(p){
  S.ratioId = p.ratio.id; S.rw = p.ratio.w; S.rh = p.ratio.h;
  S.ratioScope = p.ratio.scope;
  S.outMode = p.out.mode; S.ow = p.out.w; S.oh = p.out.h;
  fitOutToRatio();
  S.fmt = p.fmt; S.quality = p.quality; S.pattern = p.pattern;
  const it = cur();
  const fresh = i => i === it || !i.seen;
  S.items.forEach(i => {
    if (fresh(i)) return;
    if (S.ratioScope === "all") i.boxes.forEach(b => { b.rid = null; });
    if (i.grid && S.ratioId === "free"){ i.grid = null; i.gridRect = null; }
    if (i.grid) clampGrid(i); else refitBoxes(i);
  });
  S.layout = presetSource(p);
  S.items.forEach(i => { if (fresh(i)) copyBoxes(S.layout, i); });
  S.sel = 0;
  render();
  savePrefs();
}
/* a new image starts from the loaded preset, as long as it still fits */
function startLayout(item){
  if (!S.layout || (S.layout.grid && !ratioLocked())) return;
  copyBoxes(S.layout, item);
}

function acctBoot(){} function signinOpen(){ return false; }

/* =====================================================================
   First-run walkthrough
   ===================================================================== */
const TOUR = [
  {sel:'#stage .box[data-sel="true"]', key:"t1"},
  {sel:'#countseg',  key:"t2"},
  {sel:'#crops',     key:"t3"},
  {sel:'#ratioseg',  key:"t4"},
  {sel:'#strip',     key:"t5"},
  {sel:'#exportAll', key:"t6"}
];
let tourIdx = -1, tourEl = null;

function tourActive(){ return !$("#tour").hidden; }

function placeRing(r){
  const pad = 6, ring = $("#tourRing");
  ring.style.left   = (r.left - pad) + "px";
  ring.style.top    = (r.top - pad) + "px";
  ring.style.width  = (r.width + pad * 2) + "px";
  ring.style.height = (r.height + pad * 2) + "px";
}
function placeTip(r){
  const tip = $("#tourTip");
  const tw = tip.offsetWidth, th = tip.offsetHeight, gap = 14, m = 12;
  const vw = window.innerWidth, vh = window.innerHeight;
  let left, top;
  if (r.right + gap + tw + m <= vw){ left = r.right + gap; top = r.top + r.height/2 - th/2; }
  else if (r.left - gap - tw >= m){ left = r.left - gap - tw; top = r.top + r.height/2 - th/2; }
  else if (r.bottom + gap + th + m <= vh){ left = r.left + r.width/2 - tw/2; top = r.bottom + gap; }
  else { left = r.left + r.width/2 - tw/2; top = r.top - gap - th; }
  tip.style.left = clamp(left, m, Math.max(m, vw - tw - m)) + "px";
  tip.style.top  = clamp(top,  m, Math.max(m, vh - th - m)) + "px";
}
function repositionTour(){
  if (!tourActive() || !tourEl) return;
  const r = tourEl.getBoundingClientRect();
  placeRing(r); placeTip(r);
}
function paintTourStep(){
  const step = TOUR[tourIdx];
  if (!step) return;
  $("#tourStep").textContent = `${tourIdx + 1} / ${TOUR.length}`;
  $("#tourText").textContent = T()[step.key];
  $("#tourNext").textContent = tourIdx === TOUR.length - 1 ? T().tourDone : T().tourNext;
}
function goTourStep(i){
  tourIdx = i;
  if (tourIdx >= TOUR.length){ endTour(); return; }
  const el = document.querySelector(TOUR[tourIdx].sel);
  if (!el){ goTourStep(tourIdx + 1); return; }
  tourEl = el;
  track("tour", { step: tourIdx + 1 });
  el.scrollIntoView({block:"center", behavior:"smooth"});
  paintTourStep();
  setTimeout(repositionTour, 60);
  setTimeout(repositionTour, 400);
}
function startTour(){
  if (!S.items.length || tourActive()) return;
  $("#tour").hidden = false;
  goTourStep(0);
}
function endTour(){
  $("#tour").hidden = true;
  tourIdx = -1; tourEl = null;
  try { localStorage.setItem("mc.tour", "1"); } catch {}
}
$("#tourNext").addEventListener("click", () => goTourStep(tourIdx + 1));
$("#tourSkip").addEventListener("click", endTour);
$("#tourBtn").addEventListener("click", () => {
  $("#tourBtn").classList.remove("pulse");
  try { localStorage.setItem("mc.tour", "1"); } catch {}
  endTour(); startTour();
});
$("#wideBtn").addEventListener("click", () => {
  markUse("wide");
  S.wide = !S.wide;
  updateShell();
  savePrefs();
  setTimeout(() => { layoutStage(); positionBoxes(); layoutPreviews(); }, 60);
});
window.addEventListener("scroll", repositionTour, {passive:true});
window.addEventListener("resize", repositionTour);
document.addEventListener("keydown", e => {
  if (!tourActive()) return;
  if (e.key === "Escape"){ endTour(); e.preventDefault(); }
}, true);

/* boot */
(function boot(){
  loadPrefs();
  applyLang();
  renderSettings();
  wireMail();
  paintToday();
  acctBoot();
  STATS.visits = (STATS.visits || 0) + 1;
  statsSave();
  paintStatsToggle();
  track("visit", {});
  let seen = null;
  try { seen = localStorage.getItem("mc.tour"); } catch {}
  if (!seen) $("#tourBtn").classList.add("pulse");
  if (!(EXTENSION && location.hash.startsWith("#src="))) loadSample().catch(err => console.error(err));
})();

/* expose a tiny hook for automated checks */
window.__mc = {S, addFiles, runExport, makeZip};
